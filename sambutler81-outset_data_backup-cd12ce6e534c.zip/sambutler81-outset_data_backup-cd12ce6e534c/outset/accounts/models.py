from __future__ import unicode_literals

import uuid

from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.contrib.postgres.fields import ArrayField
from django.contrib.sites.models import Site
from django.core.mail import EmailMultiAlternatives
from django.core.urlresolvers import reverse
from django.db import models
from django.dispatch import receiver
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.http import urlsafe_base64_encode
from django.utils.translation import ugettext_lazy as _
from tagging.fields import TagField
from safedelete.config import SOFT_DELETE, SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel
from safedelete.signals import pre_softdelete

from outset.models import ModelDiffMixin
from outset.billing.models import Cash

from .managers import UserManager
from .tasks import user_soft_delete_cascade
from .utils import urljoin


class User(ModelDiffMixin, PermissionsMixin, AbstractBaseUser, SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE

    FOUNDER_ROLE = 'founder'
    ADMIN_ROLE = 'admin'
    EMPLOYEE_ROLE = 'employee'
    WATCHER_ROLE = 'watcher'
    ROLE_CHOICES = (
        (FOUNDER_ROLE,  'Founder'),
        (ADMIN_ROLE, 'Admin'),
        (EMPLOYEE_ROLE, 'Employee'),
        (WATCHER_ROLE,  'Watcher'),
    )

    email = models.EmailField(_('email address'), max_length=255, unique=True)
    first_name = models.CharField(_('first name'), max_length=30, blank=True, null=True)
    last_name = models.CharField(_('last name'), max_length=30, blank=True, null=True)
    startup = models.ForeignKey(
        'startups.Startup',
        related_name='users',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    accelerator = models.ForeignKey(
        'accelerators.Accelerator',
        related_name='users',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    role = models.CharField(max_length=8, choices=ROLE_CHOICES)
    role_in_company = models.TextField(verbose_name=_('Role in Company'), max_length=255, blank=True)

    NONE_SUBSCRIBE = 'none'
    WEEKLY_SUBSCRIBE = 'weekly'
    MONTHLY_SUBSCRIBE = 'monthly'
    QUARTERLY_SUBSCRIBE = 'quarterly'
    SUBSCRIBE_CHOICES = (
        (NONE_SUBSCRIBE, 'None'),
        (WEEKLY_SUBSCRIBE, 'Weekly'),
        (MONTHLY_SUBSCRIBE, 'Monthly'),
        (QUARTERLY_SUBSCRIBE, 'Quarterly'),
    )
    subscribe = models.CharField(max_length=10, choices=SUBSCRIBE_CHOICES, default=WEEKLY_SUBSCRIBE)

    login_screen = models.CharField(
        max_length=255, help_text='Login screen url to redirect after login', null=True, blank=True
    )

    # Social connections
    angel = models.URLField(_('Angel.co profile url'), max_length=100, blank=True, null=True)
    linkedin = models.URLField(_('Linkedin profile url'), max_length=100, blank=True, null=True)
    facebook = models.URLField(_('Facebook profile url'), max_length=100, blank=True, null=True)
    twitter = models.URLField(_('Twitter profile url'), max_length=100, blank=True, null=True)
    github = models.URLField(_('GitHub profile url'), max_length=100, blank=True, null=True)
    google_plus = models.URLField(_('Google+ profile url'), max_length=100, blank=True, null=True)
    skype = models.CharField(_('Skype profile'), max_length=100, blank=True, null=True)

    image = models.URLField(_('Profile image url'), max_length=800, blank=True)

    first_time = models.BooleanField(default=True)

    is_staff = models.BooleanField(
        _('staff status'),
        default=False,
        help_text=_('Designates whether the user can log into admin site.'),
    )
    is_active = models.BooleanField(
        _('active'),
        default=True,
        help_text=_(
            'Designates whether this user should be treated as active. '
            'Unselect this instead of deleting accounts.'
        ),
    )

    tags = TagField()

    cash = models.ForeignKey(Cash, related_name='users', on_delete=models.SET_NULL, null=True, blank=True)

    date_joined = models.DateTimeField(_('date joined'), default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = 'email'

    def __str__(self):
        return self.email

    def get_full_name(self):
        return ' '.join([self.first_name or '', self.last_name or '']).strip()

    def get_short_name(self):
        return self.first_name

    @property
    def recognize(self):
        data = self.get_full_name()
        name = data if data else self.email
        return name

    @property
    def account_type(self):
        """
        1. Accelerator Founder
        2. Accelerator Admin
        3. Accelerator Employee
        4. Company Founder
        5. Company Employee
        6. Watcher
        :return: index of account
        """
        if self.role in self.FOUNDER_ROLE:
            return 1 if self.accelerator else 4
        elif self.role == self.EMPLOYEE_ROLE:
            return 3 if self.accelerator else 5
        return 2 if self.role == self.ADMIN_ROLE else 6

    @property
    def tariff_plan(self):
        cash = self.cash if self.cash_id else Cash.create_for_user(self)
        return cash.plan_id

    @property
    def is_blocked(self):
        return hasattr(self, 'cash') and self.cash and self.cash.is_blocked

    @property
    def is_social(self):
        return self.social_auth.all().exists()

    @classmethod
    def related_users(cls, startup):
        return cls.objects.filter(models.Q(startup=startup) | models.Q(accelerator__cohorts__startups=startup))

    def check_option(self, option_id, value=None, **kwargs):
        if self.role == self.WATCHER_ROLE:
            return False
        try:
            cash = self.cash if self.cash_id else Cash.create_for_user(self)
        except User.DoesNotExist:
            # Not found accelerator founder for current user
            return False
        if callable(value):
            value = value()
        return cash.check_option(option_id, value, **kwargs)

    def save(self, *args, **kwargs):
        self.email = self.email.lower()
        return super(User, self).save(*args, **kwargs)


class ConfirmEmail(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    key = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='+')
    email = models.EmailField(max_length=255)
    set_active = models.BooleanField(default=False)

    is_used = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    updated = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return '{} email confirm for {} user'.format(self.email, self.user)

    class Meta:
        ordering = ('-created',)

    def send_email(self):
        if not self.user.subscribe:
            return False

        subject_template, text_template, html_template = (
            (
                'emails/admin_confirm_email_subject.txt',
                'emails/admin_confirm_email.txt',
                'emails/admin_confirm_email.html'
            )
            if self.user.is_active else
            (
                'emails/new_admin_confirm_email_subject.txt',
                'emails/new_admin_confirm_email.txt',
                'emails/new_admin_confirm_email.html'
            )
        )

        site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())
        context = dict(
            site=site,
            email=self.email,
            token=urlsafe_base64_encode('{0}:app-outset'.format(self.email)),
            invite=urljoin(site, reverse('activate', kwargs={'token': self.key})),
        )
        msg = EmailMultiAlternatives(
            subject=render_to_string(subject_template, context),
            body=render_to_string(text_template, context),
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[self.email],
            reply_to=[settings.DEFAULT_FROM_EMAIL]
        )
        msg.attach_alternative(render_to_string(html_template, context), 'text/html')
        return msg.send()


class Unsubscribe(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    email = models.EmailField()

    def __str__(self):
        return self.email

    class Meta:
        verbose_name = _('unsubscribe')
        verbose_name_plural = _('Unsubscribe List')


class StartupWatcher(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    user = models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='companies_views')
    startup = models.ForeignKey(to='startups.Startup', on_delete=models.CASCADE)
    view_kpi = models.BooleanField(default=False)

    def __str__(self):
        return 'Company Watcher: {} - {}'.format(self.user, self.startup)


class CohortWatcher(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    user = models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='cohorts_views')
    cohort = models.ForeignKey(to='accelerators.Cohort', on_delete=models.CASCADE)
    view_kpi = models.BooleanField(default=False)

    def __str__(self):
        return 'Cohort Watcher: {} - {}'.format(self.user, self.cohort)


class Feedback(models.Model):
    CLAIM_REASON = 'claim'
    REMOVE_ACCOUNT_REASON = 'remove account'
    OTHER_REASON = 'other'
    REASON_CHOICES = (
        (CLAIM_REASON, 'Claim reason'),
        (REMOVE_ACCOUNT_REASON, 'Remove account'),
        (OTHER_REASON, 'Other reason'),
    )

    user = models.ForeignKey(User, related_name='+', null=True, blank=True)
    contact = models.CharField(max_length=500, null=True, blank=True)
    reason = models.CharField(max_length=30, choices=REASON_CHOICES, default=OTHER_REASON)
    message = models.TextField()

    emails = ArrayField(models.EmailField(), null=True)

    sended = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True, editable=False)

    def __str__(self):
        return '{} ({}) feedback'.format(self.message[:20], self.reason)

    class Meta:
        ordering = ('-created',)

    def send_mail(self):
        emails = getattr(settings, 'MANAGERS', [])
        recipient_email = []
        emails = [i[1] for i in emails] if emails and isinstance(emails[0], (tuple, list)) else emails

        # loop because Amazon SES not allow send email to more one address
        for email in emails:
            msg = EmailMultiAlternatives(
                subject='{} feedback'.format(self.reason),
                body='Feedback from {}\n\nMessage: {}\n\nContact data: {}'.format(
                    self.user.recognize if self.user else 'anonymous user',
                    self.message,
                    self.user.email if self.user else self.contact
                ),
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[email],
            )
            if msg.send(fail_silently=True):
                recipient_email.append(email)

        self.emails = recipient_email
        self.sended = bool(recipient_email)
        self.save()

        return self.sended


@receiver(pre_softdelete, sender=User)
def cascade_soft_delete(sender, instance, using, **kwargs):
    diff = instance.get_field_diff('deleted')
    if diff and diff[0] is None:
        user_soft_delete_cascade.delay(instance.pk)
