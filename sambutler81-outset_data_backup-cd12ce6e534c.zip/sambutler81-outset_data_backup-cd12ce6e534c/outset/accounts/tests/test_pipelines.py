# from mock import Mock
# from django.test import TestCase

# from outset.accelerators.tests.factories import AcceleratorFactory
# from ..pipelines import create_accelerator


# class TestAcceleratorCreatePipeline(TestCase):
#     def setUp(self):
#         self.backend = Mock()
#         self.backend.name = 'angel'
#         self.details = {}
#         self.strategy = Mock()

#     def test_existing_user_passes(self):
#         create_accelerator(
#             self.strategy, 4, backend=self.backend, user=Mock(),
#             details=self.details)
#         self.assertEquals(self.details, {})

#     def test_another_provider_passes(self):
#         backend = Mock(name='google')
#         create_accelerator(self.strategy, 4, backend=backend)
#         self.assertEquals(self.details, {})

#     def test_user_with_invite_passes(self):
#         create_accelerator(
#             self.strategy, 4, backend=self.backend, details=self.details)
#         self.assertEquals(self.details, {})

#     def test_redirect_to_accelerator_create(self):
#         create_accelerator(
#             self.strategy, 4, backend=self.backend, details=self.details)
#         self.assertEquals(self.details, {})

#     def test_accelerator_tied_to_user(self):
#         accelerator = AcceleratorFactory()
#         self.strategy.request_data.return_value = {
#             'accelerator_id': accelerator.id}
#         create_accelerator(
#             self.strategy, 4, backend=self.backend, details=self.details)
#         self.assertEqual(self.details['accelerator'], accelerator)
