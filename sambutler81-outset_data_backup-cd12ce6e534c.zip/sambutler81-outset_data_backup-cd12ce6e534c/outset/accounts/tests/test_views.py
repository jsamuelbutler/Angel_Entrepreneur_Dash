from django.test import TestCase, RequestFactory

from outset.accounts.factories import UserFactory


class BaseUserTestCase(TestCase):

    def setUp(self):
        self.user = UserFactory()
        self.factory = RequestFactory()
