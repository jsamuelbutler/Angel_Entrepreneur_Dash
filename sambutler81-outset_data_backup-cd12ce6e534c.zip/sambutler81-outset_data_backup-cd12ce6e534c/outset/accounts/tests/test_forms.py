from django.test import TestCase

from outset.accounts.factories import UserFactory
from ..forms import RequireEmailForm, AuthenticationForm


class RequireEmailFormTestCase(TestCase):
    def setUp(self):
        self.email = 'person@mail.com'

    def test_email_exists(self):
        UserFactory(email=self.email)
        form = RequireEmailForm({'email': self.email})
        self.assertFalse(form.is_valid())
        self.assertIn('email', form.errors)

    def test_invalid_email(self):
        form = RequireEmailForm({'email': 'person'})
        self.assertFalse(form.is_valid())
        self.assertIn('email', form.errors)

    def test_correct_data(self):
        form = RequireEmailForm({'email': self.email})
        self.assertTrue(form.is_valid())


class AuthFormTestCase(TestCase):
    def setUp(self):
        self.user = UserFactory()
        self.user.set_password('password')
        self.user.save()

    def test_user_does_not_exist(self):
        form = AuthenticationForm(
            {'username': 'person@mail.com', 'password': 'password'})
        self.assertFalse(form.is_valid())

    def test_invalid_email(self):
        form = AuthenticationForm(
            {'username': 'wrong', 'password': 'password'})
        self.assertFalse(form.is_valid())

    def test_wrong_password(self):
        form = AuthenticationForm(
            {'username': self.user.email, 'password': 'wrong'})
        self.assertFalse(form.is_valid())

    def test_correct_data(self):
        form = AuthenticationForm(data={
            'username': self.user.email, 'password': 'password'})
        self.assertTrue(form.is_valid())
