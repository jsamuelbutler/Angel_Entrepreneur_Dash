from __future__ import unicode_literals

from django.apps import AppConfig
from django.utils.translation import ugettext_lazy as _


class JsonTokenConfig(AppConfig):
    name = 'outset.accounts.jsontoken'
    verbose_name = _('Auth Token')
