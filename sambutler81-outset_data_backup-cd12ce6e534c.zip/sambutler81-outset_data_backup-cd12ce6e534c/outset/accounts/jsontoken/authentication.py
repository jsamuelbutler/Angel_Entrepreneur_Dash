from datetime import timedelta

from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from rest_framework import exceptions
from rest_framework.authentication import TokenAuthentication

from outset.accounts.utils import is_allow_host

from .models import JsonToken, TOKEN_LIVE_PERIOD_IN_SECONDS


class JsonTokenAuthentication(TokenAuthentication):
    model = JsonToken

    def authenticate(self, request):
        if not is_allow_host(request):
            return None
        return super(JsonTokenAuthentication, self).authenticate(request)

    def authenticate_credentials(self, key):
        model = self.get_model()
        try:
            token = model.objects.select_related('user').filter(
                created__gte=now()-timedelta(seconds=TOKEN_LIVE_PERIOD_IN_SECONDS)
            ).get(key=key)
        except model.DoesNotExist:
            raise exceptions.AuthenticationFailed(_('Invalid token.'))

        if not token.user.is_active:
            raise exceptions.AuthenticationFailed(_('User inactive or deleted.'))

        if token.user.is_blocked:
            raise exceptions.AuthenticationFailed(_('User account is blocked. Need tariff pay for unblocking.'))

        return token.user, token
