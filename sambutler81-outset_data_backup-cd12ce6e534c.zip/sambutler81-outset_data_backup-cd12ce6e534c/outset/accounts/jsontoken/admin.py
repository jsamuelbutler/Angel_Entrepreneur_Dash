# from django.contrib import admin
#
# from .models import JsonToken
#
#
# @admin.register(JsonToken)
# class JsonTokenAdmin(admin.ModelAdmin):
#     list_display = ('key', 'user', 'created')
#     fields = ('user',)
#     ordering = ('-created',)
