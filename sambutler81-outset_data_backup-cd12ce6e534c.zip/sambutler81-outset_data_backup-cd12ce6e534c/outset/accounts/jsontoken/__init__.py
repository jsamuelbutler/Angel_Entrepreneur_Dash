default_app_config = 'outset.accounts.jsontoken.apps.JsonTokenConfig'
