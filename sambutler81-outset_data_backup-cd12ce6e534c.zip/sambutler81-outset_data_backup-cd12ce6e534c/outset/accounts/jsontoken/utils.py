from rest_framework.response import Response

from .models import JsonToken


def obtain_auth(serializer):
    serializer.is_valid(raise_exception=True)
    user = serializer.validated_data['user']
    token, created = JsonToken.objects.get_or_create(user=user, update_key=True)
    return Response({'token': token.key, 'login_screen': user.login_screen})
