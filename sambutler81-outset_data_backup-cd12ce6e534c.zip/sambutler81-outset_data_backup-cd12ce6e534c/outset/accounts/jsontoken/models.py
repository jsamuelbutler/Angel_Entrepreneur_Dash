from __future__ import unicode_literals

import base64
from datetime import timedelta

from django.conf import settings
from django.dispatch import receiver
from django.db import models
from django.utils.crypto import get_random_string
from django.utils.timezone import now
from rest_framework.renderers import JSONRenderer

from outset.accounts.models import User
from outset.accounts.serializers import UserSerializer

from .managers import JsonTokenManager


IS_INSTALLED = 'outset.accounts.jsontoken' in settings.INSTALLED_APPS
TOKEN_LIVE_PERIOD_IN_SECONDS = 24*60*60


class JsonToken(models.Model):
    key = models.CharField(max_length=6000, db_index=True)
    user = models.OneToOneField(User, related_name='auth_token', on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now=True)

    objects = JsonTokenManager()

    class Meta:
        abstract = not IS_INSTALLED
        verbose_name = 'JSON Token'

    @classmethod
    def generate_key(cls, user):
        serializer = UserSerializer(user)
        salt = get_random_string(length=11)
        return salt + base64.urlsafe_b64encode(JSONRenderer().render(serializer.data))

    @property
    def is_expired(self):
        return self.created + timedelta(seconds=TOKEN_LIVE_PERIOD_IN_SECONDS) < now()


if IS_INSTALLED:
    setattr(User, 'token_model', JsonToken)


try:
    from safedelete.signals import post_softdelete
except ImportError:
    pass
else:
    @receiver(post_softdelete, sender=User)
    def primary_delete_tokens(sender, instance, using, **kwargs):
        JsonToken.objects.using(using).filter(user=instance).delete()
