from django.contrib.auth.models import BaseUserManager


class JsonTokenManager(BaseUserManager):
    def get_or_create(self, update_key=False, *args, **kwargs):
        instance, created = super(JsonTokenManager, self).get_or_create(*args, **kwargs)
        if update_key or not instance.key or instance.is_expired:
            new_key = instance.generate_key(instance.user)
            if instance.key != new_key:
                instance.key = new_key
                instance.save()
        return instance, created
