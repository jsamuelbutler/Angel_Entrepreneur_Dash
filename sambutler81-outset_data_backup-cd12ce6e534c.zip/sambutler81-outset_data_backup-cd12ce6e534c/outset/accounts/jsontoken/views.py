from rest_framework import parsers, renderers
from rest_framework.views import APIView

from .serializers import AuthTokenSerializer
from .utils import obtain_auth


class ObtainAuthToken(APIView):
    throttle_classes = ()
    permission_classes = ()
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.JSONParser,)
    renderer_classes = (renderers.JSONRenderer,)
    serializer_class = AuthTokenSerializer

    def post(self, request, *args, **kwargs):
        return obtain_auth(self.serializer(data=request.data))


obtain_auth_token = ObtainAuthToken.as_view()
