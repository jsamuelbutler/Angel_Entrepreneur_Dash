from __future__ import unicode_literals

from rest_framework import routers
from . import views


router = routers.SimpleRouter()
router.register(r'auth', views.AuthViewSet)
# router.register(r'watchers', views.WatcherViewSet)
# router.register(r'startup_watchers', views.StartupWatcherViewSet)
# router.register(r'cohort_watchers', views.CohortWatcherViewSet)
router.register(r'team-members', views.TeamMemberViewSet)
