from __future__ import unicode_literals

import factory


class UserFactory(factory.django.DjangoModelFactory):
    email = factory.Sequence(lambda n: 'user{}@mail.com'.format(n))

    class Meta:
        model = 'accounts.User'
        django_get_or_create = ('email',)


class UserSocialAuthFactory(factory.django.DjangoModelFactory):
    provider = 'angel'
    uid = 1234
    extra_data = {
        'access_token': '123',
    }

    class Meta:
        model = 'default.UserSocialAuth'
