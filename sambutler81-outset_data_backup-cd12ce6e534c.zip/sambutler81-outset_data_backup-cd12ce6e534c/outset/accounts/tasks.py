from __future__ import absolute_import

from outset import celery_app
from celery.utils.log import get_task_logger


logger = get_task_logger(__name__)


@celery_app.task
def user_soft_delete_cascade(pk):
    logger.info('Starting user_soft_delete_cascade({})...'.format(pk))

    from safedelete.config import SOFT_DELETE_CASCADE
    from outset.accounts.models import User

    user = User.objects.all_with_deleted().filter(pk=pk).first()
    if user:
        logger.info('Cascade soft delete: {}'.format(user))
        user.delete(force_policy=SOFT_DELETE_CASCADE)
