from django.db.models import Case, SmallIntegerField, When, Value
from django.utils.crypto import get_random_string
from safedelete.managers import SafeDeleteManager, SafeDeleteQueryset

from outset.todos.query import WithToDoCountsQuerySetMixin


class UserQuerySet(WithToDoCountsQuerySetMixin, SafeDeleteQueryset):
    todo_field = 'assign_to_id'

    def order_by_priority(self):
        return self.annotate(
            priority=Case(
                When(role=self.model.FOUNDER_ROLE, then=Value(2)),
                When(role=self.model.ADMIN_ROLE, then=Value(1)),
                default=Value(0),
                output_field=SmallIntegerField()
            )
        ).order_by('-priority', 'first_name', 'last_name')


class BaseUserManagerMixin(object):
    """
    Copy from from django.contrib.auth.models.BaseUserManager for Mixin
    """

    @classmethod
    def normalize_email(cls, email):
        """
        Normalize the email address by lowercasing the domain part of it.
        """
        email = email or ''
        try:
            email_name, domain_part = email.strip().rsplit('@', 1)
        except ValueError:
            pass
        else:
            email = '@'.join([email_name, domain_part.lower()])
        return email

    def make_random_password(self, length=10,
                             allowed_chars='abcdefghjkmnpqrstuvwxyz'
                                           'ABCDEFGHJKLMNPQRSTUVWXYZ'
                                           '23456789'):
        """
        Generate a random password with the given length and given
        allowed_chars. The default value of allowed_chars does not have "I" or
        "O" or letters and digits that look similar -- just to avoid confusion.
        """
        return get_random_string(length, allowed_chars)

    def get_by_natural_key(self, username):
        return self.get(**{self.model.USERNAME_FIELD: username})


class UserManager(BaseUserManagerMixin, SafeDeleteManager):
    _queryset_class = UserQuerySet

    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Users must have an email address')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, password, **extra_fields)

    def order_by_priority(self):
        return self.get_queryset().order_by_priority()

    def with_todo_counts(self):
        return self.get_queryset().with_todo_counts()
