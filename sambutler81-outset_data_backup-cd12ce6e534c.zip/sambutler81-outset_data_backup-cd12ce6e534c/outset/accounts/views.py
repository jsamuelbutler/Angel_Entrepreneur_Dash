from django.db.models import Q
import django_filters
from rest_framework import generics, filters, mixins, parsers, renderers, response, status, viewsets
from rest_framework.authentication import SessionAuthentication
from rest_framework.decorators import list_route
from rest_framework.settings import api_settings

from outset.accelerators.models import Accelerator, Cohort
from outset.startups.models import Startup

from .filters import TeamMemberFilter
from .jsontoken.serializers import AuthTokenSerializer
from .jsontoken.authentication import JsonTokenAuthentication
from .jsontoken.utils import obtain_auth
from .models import User
from .permissions import (
    AuthPermission,
    IsAcceleratorFounderOrStartupFounderOrReadOnly,
    HostsOnlyAllow
)
from .serializers import (
    LoginScreenSerializer, SimpleUserSerializer, UnsubscribeSerializer, UploadSerializer,
    UserCreationSerializer, UserEmailConfirmSerializer, UserPasswordSerializer,
    UserPasswordResetSerializer, UserPasswordResetConfirmSerializer,
    UserSerializer, InviteValidationSerializer, FeedbackSerializer,
    SocialLinkSerializer, SocialAuthSerializer
)


class AuthViewSet(viewsets.GenericViewSet):
    throttle_classes = ()
    permission_classes = (HostsOnlyAllow, AuthPermission)
    authentication_classes = ()
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.JSONParser)
    renderer_classes = (renderers.JSONRenderer,)
    queryset = User.objects.none()
    serializer_class = AuthTokenSerializer
    pagination_class = None
    exclude_from_schema = True

    def get_object(self):
        return self.request.user

    def create(self, request, *args, **kwargs):
        """
        Get Auth token for API authentication
        """
        return obtain_auth(self.get_serializer(data=request.data))

    def _serialize(self, request, response_status=None):
        response_status = response_status or status.HTTP_200_OK
        user = request.user
        serializer = self.get_serializer(instance=user if user.is_authenticated() else None, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data, status=response_status)

    @list_route(methods=['post'], serializer_class=UserCreationSerializer)
    def signup(self, request):
        """
        New user registration (with sending confirm email or by invite token)
        """
        return self._serialize(request, response_status=status.HTTP_201_CREATED)

    @list_route(methods=['post'], serializer_class=UserPasswordResetSerializer)
    def reset_password(self, request):
        """
        Initiate the password recovery process
        """
        return self._serialize(request)

    @list_route(methods=['post'], serializer_class=UserPasswordResetConfirmSerializer)
    def reset_password_confirm(self, request):
        """
        Confirm email address to complete password resetting
        """
        return self._serialize(request)

    @list_route(methods=['post'], serializer_class=UserEmailConfirmSerializer)
    def email_confirm(self, request):
        """
        Confirm email for complete user registration
        """
        return self._serialize(request)

    @list_route(methods=['post'],
                serializer_class=UserPasswordSerializer,
                authentication_classes=(JsonTokenAuthentication, SessionAuthentication))
    def change_password(self, request):
        """
        Change password of current user (need auth token) without confirm email
        """
        return self._serialize(request)

    @list_route(methods=['post'],
                serializer_class=UnsubscribeSerializer,
                authentication_classes=(JsonTokenAuthentication, SessionAuthentication))
    def unsubscribe(self, request):
        """
        Subscribe or unsubscribe for emailing of letters
        """
        return self._serialize(request)

    @list_route(methods=['post'],
                serializer_class=LoginScreenSerializer,
                authentication_classes=(JsonTokenAuthentication, SessionAuthentication))
    def login_screen(self, request):
        """
        Set as a login screen
        """
        return self._serialize(request)

    @list_route(methods=['post'],
                serializer_class=UploadSerializer,
                authentication_classes=(JsonTokenAuthentication, SessionAuthentication))
    def upload(self, request):
        """
        Upload images to server for using as file link
        """
        return self._serialize(request)

    @list_route(methods=['post'], serializer_class=InviteValidationSerializer)
    def validate_invite(self, request):
        """
        Validate received invite for availability.
        """
        return self._serialize(request)

    @list_route(methods=['post'],
                serializer_class=FeedbackSerializer,
                authentication_classes=(JsonTokenAuthentication, SessionAuthentication))
    def feedback(self, request):
        """
        Feedback form to contact with supports.
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @list_route(methods=['post'], serializer_class=SocialLinkSerializer)
    def social(self, request):
        """
        Get URL for social auth redirect.
        """
        return self._serialize(request)

    @list_route(methods=['post'], serializer_class=SocialAuthSerializer)
    def social_auth(self, request):
        """
        Social auth.
        
        Return Auth Token.
        """
        return self._serialize(request)


class CurrentUserAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    pagination_class = None

    def get_object(self):
        return self.request.user


# class WatcherViewSet(viewsets.ReadOnlyModelViewSet):
#     """
#     list:
#         Read only list of all/cohort/startup watchers
#     """
#     queryset = User.objects.filter(role=User.WATCHER_ROLE)
#     serializer_class = WatcherSerializer
#     filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
#     filter_class = WatcherFilter
#
#     def get_queryset(self):
#         return self.queryset.filter(
#             accelerator__in=Accelerator.objects.available_to_user(self.request.user).values('id')
#         )
#
#
# class BulkCreateRemoveViewSetMixin(object):
#     bulk_create_serializer_class = None
#     bulk_remove_serializer_class = None
#
#     def get_serializer_class(self):
#         if self.action == 'bulk_create' and self.bulk_create_serializer_class is not None:
#             return self.bulk_create_serializer_class
#         elif self.action == 'bulk_remove' and self.bulk_remove_serializer_class is not None:
#             return self.bulk_remove_serializer_class
#         return super(BulkCreateRemoveViewSetMixin, self).get_serializer_class()
#
#     def _serialize(self, request):
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         serializer.save()
#         return response.Response(serializer.data)
#
#     @list_route(methods=['post'])
#     def bulk_create(self, request):
#         return self._serialize(request)
#
#     @list_route(methods=['post'])
#     def bulk_remove(self, request):
#         return self._serialize(request)
#
#
# class StartupWatcherViewSet(BulkCreateRemoveViewSetMixin, viewsets.ModelViewSet):
#     """
#     list:
#         List of available watcher to startup
#     bulk_create:
#         Adding multiple watcher access to startup
#     bulk_remove:
#         Remove multiple watcher access from startup
#     """
#     queryset = StartupWatcher.objects.all()
#     permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsWatcherSelfOrAcceleratorFounderSelfOrReadOnly]
#     filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
#     filter_class = StartupWatcherFilter
#     serializer_class = StartupWatcherSerializer
#     bulk_create_serializer_class = BulkCreateStartupWatcherSerializer
#     bulk_remove_serializer_class = BulkRemoveStartupWatcherSerializer
#
#     def get_queryset(self):
#         return self.queryset.filter(
#             startup__in=Startup.objects.available_to_user(self.request.user).values('id')
#         )
#
#
# class CohortWatcherViewSet(BulkCreateRemoveViewSetMixin, viewsets.ModelViewSet):
#     """
#     list:
#         List of available watcher to cohort
#     bulk_create:
#         Adding multiple watcher access to cohort
#     bulk_remove:
#         Remove multiple watcher access from cohort
#     """
#     queryset = CohortWatcher.objects.all().order_by('user__first_name', 'user__last_name')
#     permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsWatcherSelfOrAcceleratorFounderSelfOrReadOnly]
#     filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
#     filter_class = CohortWatcherFilter
#     serializer_class = CohortWatcherSerializer
#     bulk_create_serializer_class = BulkCreateCohortWatcherSerializer
#     bulk_remove_serializer_class = BulkRemoveCohortWatcherSerializer
#
#     def get_queryset(self):
#         return self.queryset.filter(
#             cohort__in=Cohort.objects.available_to_user(self.request.user).values('id')
#         )


class TeamMemberViewSet(mixins.RetrieveModelMixin,
                        mixins.UpdateModelMixin,
                        mixins.DestroyModelMixin,
                        mixins.ListModelMixin,
                        viewsets.GenericViewSet):
    """
    list:
        List of team member's information
    update:
        May be need closed editing here
    destroy:
        Deactivate user (not allow access)
    """
    queryset = User.objects.exclude(role=User.WATCHER_ROLE).with_todo_counts().order_by_priority()
    serializer_class = SimpleUserSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderOrStartupFounderOrReadOnly]
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend, filters.OrderingFilter)
    filter_class = TeamMemberFilter
    ordering_fields = ('priority', 'first_name', 'last_name', 'todo_count')

    def get_queryset(self):
        user = self.request.user
        qs = self.queryset.filter(
            Q(accelerator__in=Accelerator.objects.available_to_user(user).values('id')) |
            Q(startup__in=Startup.objects.available_to_user(user).values('id'))
        )
        if not user.is_superuser:
            qs = qs.exclude(is_superuser=True)
        return qs

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        startup = instance.startup
        if startup:
            startup.is_active = startup.users.filter(is_active=True).exists()
            startup.save()
        return response.Response(serializer.data)

    def perform_destroy(self, instance):
        instance.todos.all().update(assign_to=self.request.user, startup=self.request.user.startup)
        return super(TeamMemberViewSet, self).perform_destroy(instance)
