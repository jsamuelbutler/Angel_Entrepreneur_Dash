from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from rest_framework.serializers import ValidationError

try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin


DEFAULT_ALLOW_HOSTS = getattr(settings, 'INTERNAL_API_ALLOW_HOSTS', ['localhost', '127.0.0.1'])
ALLOW_ALL_HOSTS = getattr(settings, 'INTERNAL_API_ALLOW_ALL', False)
REMOTE_ADDR_HEADER = getattr(settings, 'REMOTE_ADDR_REQUEST_HEADER', 'REMOTE_ADDR')


def is_allow_host(request):
    meta = request.META
    return (
        ALLOW_ALL_HOSTS or
        meta.get(REMOTE_ADDR_HEADER) in DEFAULT_ALLOW_HOSTS or meta.get('REMOTE_HOST') in DEFAULT_ALLOW_HOSTS
    )


def validate_user(user):
    if user:
        # From Django 1.10 onwards the `authenticate` call simply
        # returns `None` for is_active=False users.
        # (Assuming the default `ModelBackend` authentication backend.)
        if not user.is_active:
            raise ValidationError(_('User account is disabled.'), code='authorization')
        if user.is_blocked:
            raise ValidationError(_('User account is blocked. Need tariff pay for unblocking.'), code='authorization')
    else:
        raise ValidationError(_('Unable to log in with provided credentials.'), code='authorization')
