from os.path import join

from django.conf import settings
from django.core.files.storage import FileSystemStorage

from .utils import urljoin

IMAGE_PATH = 'images'

image_storage = FileSystemStorage(
    location=join(settings.MEDIA_ROOT, IMAGE_PATH),
    base_url=urljoin(settings.MEDIA_URL, IMAGE_PATH)
)
