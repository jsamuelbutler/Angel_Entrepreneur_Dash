import itertools
from collections import namedtuple
import os
import re
import uuid
from io import BytesIO
from PIL import Image

from django.conf import settings
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth import update_session_auth_hash
from django.core.cache import cache
from django.core.files.base import File
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import F, Value as V
from django.db.models.functions import Concat
from django.http import Http404
from django.utils.http import urlsafe_base64_decode
from rest_framework import serializers
from rest_framework.permissions import SAFE_METHODS
from social_django.utils import psa, STORAGE
from social_core.exceptions import AuthException
from social_core.utils import get_strategy, user_is_authenticated

from outset.accelerators.models import Accelerator, Cohort
from outset.billing.consts import DATA_INTEGRATION_OPTION, API_ACCESS_OPTION
from outset.invitations.models import Invite
from outset.startups.models import Startup
from outset.utils import validate_uuid4

from .models import ConfirmEmail, CohortWatcher, StartupWatcher, Unsubscribe, User, Feedback
from .storages import image_storage
from .utils import is_allow_host


REDIRECT_URI = getattr(settings, 'REST_SOCIAL_OAUTH_REDIRECT_URI', '/')


class AuthTokenResponseMixin(object):
    use_update_key = False

    @property
    def data(self):
        token_model = getattr(User, 'token_model')
        if token_model is None or not is_allow_host(self.context['request']):
            return {}
        user = self.get_user()
        if not user or user.is_anonymous or not user.is_active:
            return {}
        token, created = token_model.objects.get_or_create(user=user, update_key=self.use_update_key)
        return {'token': token.key}

    def get_user(self):
        return self.validated_data.get('user', self.instance)


class InviteValidationMixin(object):
    @staticmethod
    def validate_invite(value):
        if not value:
            return None
        if not validate_uuid4(value):
            raise serializers.ValidationError('Invite token is invalid.')

        try:
            invite = Invite.objects.get(key=value)
        except Invite.DoesNotExist:
            raise serializers.ValidationError('Not found.')

        if invite.accepted:
            raise serializers.ValidationError('This invite link is already taken.')

        return invite


class AuthTokenResponseIfPostMixin(AuthTokenResponseMixin):
    use_update_key = True

    @property
    def data(self):
        default_data = super(serializers.Serializer, self).data
        request = self.context.get('request')
        if request and request.method not in SAFE_METHODS:
            default_data.update(super(AuthTokenResponseIfPostMixin, self).data)
        return default_data


def load_strategy(request=None):
    return get_strategy('outset.accounts.strategy.InviteStrategy', STORAGE, request)


@psa(REDIRECT_URI, load_strategy=load_strategy)
def decorate_request(request, backend):
    pass


SOCIAL_INVITE_CACHE_TIME = 24 * 60 * 60
SOCIAL_INVITE_CACHE_PREFIX = 'social_'


class SocialLinkSerializer(serializers.Serializer):
    provider = serializers.CharField(write_only=True)
    invite = serializers.CharField(required=False, allow_null=True, write_only=True)
    redirect = serializers.CharField(read_only=True)

    SocialLink = namedtuple('SocialLink', 'redirect')

    def validate(self, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError('Request is not specified.')
        if request.user.is_authenticated:
            raise serializers.ValidationError('You are already authorized.')
        try:
            decorate_request(request, validated_data['provider'])
        except Http404 as err:
            raise serializers.ValidationError(err.message)
        return dict(backend=request.backend, invite=validated_data.get('invite'))

    def create(self, validated_data):
        backend = validated_data['backend']
        cache.set(
            SOCIAL_INVITE_CACHE_PREFIX+backend.get_or_create_state(),
            validated_data['invite'],
            SOCIAL_INVITE_CACHE_TIME
        )
        return self.SocialLink(redirect=backend.auth_url())

    def update(self, instance, validated_data):
        raise NotImplementedError('You are already authorized.')


class SocialAuthSerializer(AuthTokenResponseMixin, serializers.Serializer):
    provider = serializers.CharField(write_only=True)
    state = serializers.CharField(write_only=True)
    code = serializers.CharField(write_only=True)

    SocialAuth = namedtuple('SocialAuth', 'user backend')

    def validate(self, validated_data):
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError('Request is not specified.')
        if request.user.is_authenticated:
            raise serializers.ValidationError('You are already authorized.')
        # set auth data
        request.auth_data = validated_data
        try:
            decorate_request(request, validated_data['provider'])
        except Http404 as err:
            raise serializers.ValidationError(err.message)

        user = request.user
        backend = request.backend
        is_authenticated = user_is_authenticated(user)
        user = is_authenticated and user or None
        backend.REDIRECT_STATE = False
        backend.STATE_PARAMETER = False

        # for pipelines
        key = SOCIAL_INVITE_CACHE_PREFIX + validated_data['state']
        invite = cache.get(key)
        if invite is not None:
            cache.delete(key)
        request.backend.strategy.session_set('invite', invite)

        try:
            authenticated_user = backend.complete(user=user)
        except AuthException as err:
            raise serializers.ValidationError(str(err.message) or str(err))

        return dict(backend=request.backend, request=request, user=authenticated_user)

    def create(self, validated_data):
        return self.SocialAuth(user=validated_data['user'], backend=validated_data['backend'])

    def update(self, instance, validated_data):
        raise NotImplementedError('Not allow.')


class UserCreationSerializer(AuthTokenResponseMixin, InviteValidationMixin, serializers.ModelSerializer):
    use_update_key = True

    email = serializers.EmailField(required=False, write_only=True)
    password = serializers.CharField(style={'input_type': 'password'}, write_only=True)
    invite = serializers.CharField(max_length=40, required=False, allow_null=True, write_only=True)
    first_name = serializers.CharField(write_only=True, required=False, allow_null=True, allow_blank=True)
    last_name = serializers.CharField(write_only=True, required=False, allow_null=True, allow_blank=True)

    class Meta:
        model = User
        fields = ('email', 'password', 'invite', 'first_name', 'last_name')

    def update(self, instance, validated_data):
        return self.create(validated_data)

    @staticmethod
    def validate_email(value):
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError('Already there is a user with same email.')
        if User.objects.deleted_only().filter(email=value).exists():
            raise serializers.ValidationError('User with same email is deleted. Wait while it will be cleaned.')
        return value

    def validate(self, validated_data):
        if not ('email' in validated_data or 'invite' in validated_data):
            raise serializers.ValidationError('Need email or invite.')
        if 'invite' in validated_data and validated_data['invite']:
            if User.objects.filter(email=validated_data['invite'].email).exists():
                raise serializers.ValidationError(
                    'User with this email is already exists. Remove it before accept invite.'
                )
            if User.objects.deleted_only().filter(email=validated_data['invite'].email).exists():
                raise serializers.ValidationError(
                    'User with same email is deleted. Wait while it will be cleaned.'
                )
        return validated_data

    def create(self, validated_data):
        invite = validated_data.get('invite')

        def _invite(field):
            return getattr(invite, field, None)

        email = validated_data.get('email') or _invite('email')
        user = User(
            email=email,
            invite=invite,
            first_name=validated_data.get('first_name', _invite('first_name')),
            last_name=validated_data.get('last_name', _invite('last_name')),
        )
        if Unsubscribe.objects.filter(email=email).exists():
            user.subscribe = User.NONE_SUBSCRIBE
        user.set_password(validated_data['password'])
        if invite:
            user.accelerator = invite.accelerator
            user.startup = invite.startup
            user.role = invite.role
            user.cash = invite.invited_by.cash
            user.save()
            invite.accepted = True
            invite.accepted_by = user
            invite.save(update_fields=['accepted', 'accepted_by'])
        else:
            user.accelerator = Accelerator.objects.create()
            user.role = User.FOUNDER_ROLE
            user.is_active = False
            user.save()
            ConfirmEmail.objects.create(user=user, email=user.email, set_active=True).send_email()
        return user

    @property
    def data(self):
        default_data = super(serializers.Serializer, self).data
        default_data.update(super(UserCreationSerializer, self).data)
        return default_data


class UserPasswordSerializer(serializers.ModelSerializer):
    current_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True)

    def validate_current_password(self, value):
        if not self.instance:
            raise serializers.ValidationError('User instance not found.')
        if self.instance.is_social:
            raise serializers.ValidationError('Does not allow change password for social auth users.')
        if not self.instance.check_password(value):
            raise serializers.ValidationError('Incorrect current password.')
        return value

    def update(self, instance, validated_data):
        instance.set_password(validated_data['new_password'])
        instance.save(update_fields=['password'])
        if 'request' in self.context:
            update_session_auth_hash(self.context['request'], instance)
        return instance

    def create(self, *args, **kwargs):
        raise NotImplementedError('You can not change your password without the user instance.')

    class Meta:
        model = User
        fields = ('current_password', 'new_password')


class UserPasswordResetSerializer(serializers.Serializer):
    email = serializers.EmailField(write_only=True)

    @staticmethod
    def validate_email(value):
        form = PasswordResetForm({'email': value})
        try:
            user = form.get_users(value).next()
        except StopIteration:
            user = None
        if not form.is_valid() or user is None:
            raise serializers.ValidationError('There is not user with such email.')
        return form

    def update(self, instance, validated_data):
        return self.create(validated_data)

    def create(self, validated_data):
        form = validated_data['email']
        request = self.context['request']
        opts = {
            'use_https': request.is_secure(),
            'token_generator': default_token_generator,
            'from_email': None,
            'email_template_name': 'registration/password_reset_email.html',
            'subject_template_name': 'registration/password_reset_subject.txt',
            'request': request,
            'html_email_template_name': None,
            'extra_email_context': None,
        }
        form.save(**opts)
        return {}


class UserPasswordResetConfirmSerializer(AuthTokenResponseMixin, serializers.Serializer):
    uidb64 = serializers.RegexField(r'[0-9A-Za-z_\-]+', write_only=True)
    token = serializers.RegexField(r'[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20}', write_only=True)
    new_password = serializers.CharField(write_only=True)

    def validate(self, data):
        uid = urlsafe_base64_decode(data['uidb64'])
        try:
            user = User.objects.get(pk=uid)
        except User.DoesNotExist:
            user = None
        if not (user and default_token_generator.check_token(user, data['token'])):
            raise serializers.ValidationError('Password reset unsuccessful.')
        data['user'] = user
        return data

    def update(self, instance, validated_data):
        return self.create(validated_data)

    def create(self, validated_data):
        user = validated_data['user']
        user.set_password(validated_data['new_password'])
        user.save(update_fields=['password'])
        return user


class UserEmailConfirmSerializer(AuthTokenResponseMixin, serializers.Serializer):
    token = serializers.RegexField(r'[0-9A-Za-z_\-]+', write_only=True)

    @staticmethod
    def validate_token(value):
        if not validate_uuid4(value):
            raise serializers.ValidationError('Activation url is invalid.')
        try:
            confirm = ConfirmEmail.objects.select_related('user').get(key=value, is_used=False)
        except (ConfirmEmail.DoesNotExist, ValueError):
            raise serializers.ValidationError('Activation url is invalid.')
        if confirm.set_active and confirm.user.is_active:
            raise serializers.ValidationError('This user is already activated.')
        if User.objects.filter(email=confirm.email).exclude(pk=confirm.user.pk).exists():
            raise serializers.ValidationError('This email is already activated by other user.')
        return confirm

    def validate(self, validated_data):
        validated_data['user'] = validated_data['token'].user
        return validated_data

    def update(self, instance, validated_data):
        return self.create(validated_data)

    def create(self, validated_data):
        confirm = validated_data['token']
        user = confirm.user
        if confirm.set_active:
            user.is_active = True
        if confirm.email != user.email:
            user.email = confirm.email
        user.save(update_fields=['is_active', 'email'])
        confirm.is_used = True
        confirm.save(update_fields=['is_used'])
        return user


class UnsubscribeSerializer(serializers.Serializer):
    token = serializers.CharField(write_only=True, required=False, allow_null=True)
    subscribe = serializers.BooleanField(write_only=True, default=False)

    @staticmethod
    def validate_token(value):
        try:
            data = urlsafe_base64_decode(value).split(':')
            email = data[0]
        except (KeyError, ValueError, TypeError):
            email = None
        if not email or not (User.objects.filter(email=email).exists() or Invite.objects.filter(email=email).exists()):
            raise serializers.ValidationError('Unsubscribe url is invalid.')
        return email

    def validate(self, validated_data):
        user = self.instance

        email = user.email if user and user.is_authenticated else None
        validated_data['email'] = email = validated_data.get('token', email)

        if not email:
            raise serializers.ValidationError('Email not found.')

        return validated_data

    def update(self, instance, validated_data):
        return self.create(validated_data)

    def create(self, validated_data):
        email = validated_data.get('email')
        subscribe = validated_data['subscribe']
        User.objects.filter(email=email).update(subscribe=subscribe)
        Invite.objects.filter(email=email).update(subscribe=subscribe)
        if subscribe:
            Unsubscribe.objects.filter(email=email).delete()
        else:
            Unsubscribe.objects.get_or_create(email=email)
        return {}


class LoginScreenSerializer(AuthTokenResponseIfPostMixin, serializers.ModelSerializer):
    login_screen = serializers.RegexField(r'^/.*', allow_null=True, allow_blank=True)

    class Meta:
        model = User
        fields = ('login_screen',)


class UploadSerializer(serializers.Serializer):
    IMAGE_EXTS = ['.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg']
    PATH = 'images'
    MAX_RESOLUTION = 4000

    file = serializers.FileField()
    name = serializers.CharField(required=False, write_only=True)
    height = serializers.IntegerField(
        validators=[MinValueValidator(1)], required=False, default=MAX_RESOLUTION, write_only=True)
    width = serializers.IntegerField(
        validators=[MinValueValidator(1)], required=False, default=MAX_RESOLUTION, write_only=True)

    def validate_file(self, value):
        origin, ext = os.path.splitext(self.context['request'].data.get('name', value.name))
        if ext.lower() not in self.IMAGE_EXTS:
            raise serializers.ValidationError('Bad file type.')
        return value

    def update(self, instance, validated_data):
        return self.create(validated_data)

    def create(self, validated_data):
        file_ = validated_data['file']

        img = Image.open(file_.file).convert('RGB')
        img.thumbnail((validated_data['width'], validated_data['height']))
        tmp = BytesIO()
        img.save(tmp, 'JPEG')

        name = image_storage.save(uuid.uuid4().hex[:8]+'.jpg', tmp, max_length=12)
        setattr(tmp, 'url', image_storage.url(name))
        return File(tmp)


class TinyUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'recognize', 'account_type', 'tags')


class SimpleUserSerializer(serializers.ModelSerializer):
    image = serializers.CharField(max_length=100, allow_blank=True)
    todos = serializers.IntegerField(source='todo_count', read_only=True)

    def validate_startup(self, value):
        if not value:
            return
        if ('request' is self.context and not
                Startup.objects.available_to_user(self.context['request'].user).filter(id=value.id).exists()):
            raise serializers.ValidationError('Startup not founded.')
        return value

    def validate(self, attrs):
        if (not attrs.get('startup') and
                (not self.instance or not self.instance.pk or not self.instance.startup_id) and
                'request' in self.context):
            attrs['accelerator_id'] = self.context['request'].user.accelerator_id
        else:
            attrs['accelerator_id'] = None
        return attrs

    class Meta:
        model = User
        fields = (
            'first_name', 'last_name', 'id', 'accelerator', 'startup', 'role', 'role_in_company',
            'email', 'image', 'recognize', 'tags', 'todos'
        )
        read_only_fields = ('recognize', 'accelerator')


def validate_social_link(regex, message, value):
    if value:
        value = value.strip()
    if value:
        data = re.match(regex, value)
        if not data:
            raise serializers.ValidationError(message)
    return value


class UserSerializer(AuthTokenResponseIfPostMixin, SimpleUserSerializer):
    allow_connect = serializers.SerializerMethodField(read_only=True)
    view_api = serializers.SerializerMethodField(read_only=True)
    google_drive_sync = serializers.SerializerMethodField(read_only=True)

    is_social = serializers.BooleanField(read_only=True)

    @staticmethod
    def validate_linkedin(value):
        return validate_social_link(
            r'http[s]?://([\w]+\.)?linkedin\.com/(pub|in|profile)',
            'Please enter correct LinkedIn profile url.',
            value
        )

    @staticmethod
    def validate_angel(value):
        return validate_social_link(
            r'http[s]?://([\w]+\.)?angel\.co/',
            'Please enter correct AngelList profile url.',
            value
        )

    @staticmethod
    def validate_facebook(value):
        return validate_social_link(
            r'http[s]?://([\w]+\.)?facebook\.com/',
            'Please enter correct Facebook profile url.',
            value
        )

    @staticmethod
    def validate_twitter(value):
        return validate_social_link(
            r'http[s]?://(www\.)?twitter\.com/([a-zA-Z0-9_]+)/',
            'Please enter correct Twitter profile url.',
            value
        )

    @staticmethod
    def validate_github(value):
        return validate_social_link(
            r'^https://(www\.)?github\.com/[a-zA-Z0-9_]{1,25}$',
            'Please enter correct GitHub profile url.',
            value
        )

    @staticmethod
    def validate_google_plus(value):
        return validate_social_link(
            r'http[s]?://plus.google.com/u/',
            'Please enter correct Google+ profile url.',
            value
        )

    def update(self, instance, validated_data):
        if 'email' in validated_data and instance.email != validated_data['email']:
            ConfirmEmail.objects.create(email=validated_data['email'], user=instance).send_email()
            del validated_data['email']
        return super(UserSerializer, self).update(instance, validated_data)

    class Meta:
        model = User
        fields = (
            'first_name', 'last_name', 'id', 'accelerator', 'startup', 'is_active',
            'role', 'role_in_company', 'first_time', 'email', 'tariff_plan', 'google_drive_sync',
            'account_type', 'image', 'subscribe', 'recognize', 'allow_connect', 'view_api',
            'angel', 'linkedin', 'facebook', 'twitter', 'github', 'skype', 'google_plus', 'is_social'
        )
        read_only_fields = ('is_superuser', 'recognize', 'tariff_plan', 'is_active', 'first_time', 'role')

    @staticmethod
    def get_allow_connect(obj):
        return obj.account_type == 4 and obj.check_option(DATA_INTEGRATION_OPTION)

    @staticmethod
    def get_view_api(obj):
        return obj.account_type in (1, 2) and obj.check_option(API_ACCESS_OPTION)

    @staticmethod
    def get_google_drive_sync(obj):
        return obj.google_drive.email if hasattr(obj, 'google_drive') and obj.google_drive else None


class StartupWatcherSerializer(serializers.ModelSerializer):
    class Meta:
        model = StartupWatcher
        exclude = ('id',)


class CohortWatcherSerializer(serializers.ModelSerializer):
    class Meta:
        model = CohortWatcher
        exclude = ('id',)


class BulkWatcherSerializer(serializers.Serializer):
    users = serializers.ListField(write_only=True)

    @staticmethod
    def validate_users(value):
        users = User.objects.filter(id__in=value, role=User.WATCHER_ROLE).values_list('id', flat=True)
        if not users:
            raise serializers.ValidationError('Does not exist such users.')
        return users


class BulkCreateWatcherSerializer(BulkWatcherSerializer):
    view_kpi = serializers.BooleanField(default=False, write_only=True)


class BulkStartupWatcherSerializer(serializers.Serializer):
    startups = serializers.ListField(write_only=True)

    def validate_startups(self, value):
        startups = Startup.objects.available_to_user(self.context['request'].user).filter(
            id__in=value
        ).values_list('id', flat=True)
        if not startups:
            raise serializers.ValidationError('Does not exist such startups.')
        return startups


class BulkCohortWatcherSerializer(serializers.Serializer):
    cohorts = serializers.ListField(write_only=True)

    def validate_cohorts(self, value):
        cohorts = Cohort.objects.available_to_user(self.context['request'].user).filter(
            id__in=value
        ).values_list('id', flat=True)
        if not cohorts:
            raise serializers.ValidationError('Does not exist such cohorts.')
        return cohorts


class BulkRemoveStartupWatcherSerializer(BulkWatcherSerializer, BulkStartupWatcherSerializer):
    def create(self, validated_data):
        StartupWatcher.objects.filter(
            user__in=validated_data['users'],
            startup__in=validated_data['startups']
        ).delete()
        return {}


class BulkCreateStartupWatcherSerializer(BulkCreateWatcherSerializer, BulkStartupWatcherSerializer):
    def create(self, validated_data):
        view_kpi = validated_data['view_kpi']
        user_startup_combine = list(itertools.product(validated_data['users'], validated_data['startups']))
        exist_watchers = StartupWatcher.objects.annotate(
            us=Concat(F('user__id'), V('|'), F('startup__id'), output_field=models.CharField())
        ).filter(
            us__in=['{}|{}'.format(*i) for i in user_startup_combine]
        )
        exist_watcher_combine = exist_watchers.values_list('user__id', 'startup__id')
        if exist_watcher_combine:
            exist_watchers.update(view_kpi=view_kpi)
        new_watcher_combine = list(set(user_startup_combine) - set(exist_watcher_combine))
        StartupWatcher.objects.bulk_create([
            StartupWatcher(
                user_id=user,
                startup_id=startup,
                view_kpi=view_kpi
            )
            for user, startup in new_watcher_combine
        ])
        return {}


class BulkRemoveCohortWatcherSerializer(BulkWatcherSerializer, BulkCohortWatcherSerializer):
    def create(self, validated_data):
        CohortWatcher.objects.filter(
            user__in=validated_data['users'],
            cohort__in=validated_data['cohorts']
        ).delete()
        return {}


class BulkCreateCohortWatcherSerializer(BulkCreateWatcherSerializer, BulkCohortWatcherSerializer):
    def create(self, validated_data):
        view_kpi = validated_data['view_kpi']
        user_cohort_combine = list(itertools.product(validated_data['users'], validated_data['cohorts']))
        exist_watchers = CohortWatcher.objects.annotate(
            uc=Concat(F('user__id'), V('|'), F('cohort__id'), output_field=models.CharField())
        ).filter(
            uc__in=['{}|{}'.format(*i) for i in user_cohort_combine]
        )
        exist_watcher_combine = exist_watchers.values_list('user__id', 'cohort__id')
        if exist_watcher_combine:
            exist_watchers.update(view_kpi=view_kpi)
        new_watcher_combine = list(set(user_cohort_combine) - set(exist_watcher_combine))
        CohortWatcher.objects.bulk_create([
            CohortWatcher(
                user_id=user,
                cohort_id=cohort,
                view_kpi=view_kpi
            )
            for user, cohort in new_watcher_combine
        ])
        return {}


class WatcherSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = (
            'email', 'first_name', 'last_name', 'id'
        )

    def get_validation_exclusions(self):
        exclusions = super(WatcherSerializer, self).get_validation_exclusions()
        return exclusions + ['role']

    def create(self, validated_data):
        user, created = User.objects.get_or_create(
            email=validated_data.get('email', ''),
            accelerator=self.context['request'].user.accelerator,
            role=User.WATCHER_ROLE,
        )
        user.first_name = user.first_name or validated_data.get('first_name', '')
        user.last_name = user.last_name or validated_data.get('last_name', '')
        user_cohorts = [
            CohortWatcher(user=user, cohort_id=cohort, view_kpi=True)
            for cohort in self.context['request'].data.get('cohorts', [])
        ]
        CohortWatcher.objects.filter(user=user).delete()
        CohortWatcher.objects.bulk_create(user_cohorts)
        user.save()
        return user

    def update(self, instance, validated_data):
        instance.first_name = validated_data.get('first_name')
        instance.last_name = validated_data.get('last_name')
        instance.save()
        return instance


class InviteValidationSerializer(InviteValidationMixin, serializers.Serializer):
    invite = serializers.CharField(max_length=40, write_only=True)

    def update(self, instance, validated_data):
        return {}

    def create(self, validated_data):
        return {}


class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        exclude = ('created', 'emails', 'user')
        extra_kwargs = {'sended': {'read_only': True}}

    def validate(self, validated_data):
        user = validated_data['user'] = (
            self.context['request'].user
            if 'request' in self.context and self.context['request'].user.is_authenticated else
            None
        )
        if not validated_data.get('contact') and not user:
            raise serializers.ValidationError('Need user or contact data for feedback.')
        elif validated_data.get('contact') and user:
            raise serializers.ValidationError('Not allow feedback with user and contact data together.')
        return validated_data

    def save(self, **kwargs):
        instance = super(FeedbackSerializer, self).save(**kwargs)
        instance.send_mail()
        return instance
