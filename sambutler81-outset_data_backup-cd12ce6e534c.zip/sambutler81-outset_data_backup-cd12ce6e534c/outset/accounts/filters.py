from django_filters import NumberFilter, BaseInFilter
from django_filters.rest_framework import FilterSet


from .models import CohortWatcher, StartupWatcher, User


class CohortWatcherFilter(FilterSet):
    class Meta:
        model = CohortWatcher
        fields = ('user', 'cohort')


class StartupWatcherFilter(FilterSet):
    class Meta:
        model = StartupWatcher
        fields = ('user', 'startup')


class TeamMemberFilter(FilterSet):
    roles = BaseInFilter(name='role', lookup_expr='in')

    class Meta:
        model = User
        fields = ('accelerator', 'startup', 'role', 'is_active')


class WatcherFilter(FilterSet):
    cohort = NumberFilter(name='cohorts_views__cohort')
    startup = NumberFilter(name='companies_views__startup')

    class Meta:
        model = User
        fields = ('cohort', 'startup')
