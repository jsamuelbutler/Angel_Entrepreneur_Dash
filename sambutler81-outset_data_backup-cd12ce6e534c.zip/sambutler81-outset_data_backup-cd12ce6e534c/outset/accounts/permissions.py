from rest_framework.permissions import BasePermission, SAFE_METHODS

from .models import User
from .utils import is_allow_host


AUTH_ACTIONS_WITHOUT_AUTHORIZATION = (
    'create', 'reset_password', 'signup', 'unsubscribe', 'reset_password_confirm', 'email_confirm', 'validate_invite',
    'feedback', 'social', 'social_auth'
)


class HostsOnlyAllow(BasePermission):
    def has_permission(self, request, view):
        return is_allow_host(request)


class AuthPermission(BasePermission):
    def has_permission(self, request, view):
        return (
            request.method in SAFE_METHODS or
            request.method == 'POST' and view.action in AUTH_ACTIONS_WITHOUT_AUTHORIZATION or
            request.user and request.user.is_authenticated()
        )


FOUNDER_ROLES = (User.FOUNDER_ROLE, User.ADMIN_ROLE)


class IsAcceleratorFounder(BasePermission):
    def has_permission(self, request, view):
        return request.user.role in FOUNDER_ROLES and request.user.accelerator_id


class IsAcceleratorFounderSelfOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return request.method in SAFE_METHODS or user.role in FOUNDER_ROLES and user.accelerator_id

    def has_object_permission(self, request, view, obj):
        return not hasattr(obj, 'accelerator_id') or obj.accelerator_id == request.user.accelerator_id


class IsWatcherSelfOrAcceleratorFounderSelfOrReadOnly(BasePermission):

    def has_permission(self, request, view):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            user.role == User.WATCHER_ROLE or
            user.role in FOUNDER_ROLES and user.accelerator_id
        )

    def has_object_permission(self, request, view, obj):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            obj and obj.user_id == user.id and user.role == User.WATCHER_ROLE or
            user.role in FOUNDER_ROLES and user.accelerator_id
        )


class IsStartupFounderOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return request.method in SAFE_METHODS or user.role == User.FOUNDER_ROLE and user.startup_id


class IsAcceleratorFounderOrStartupFounderOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            user.role in FOUNDER_ROLES and user.accelerator_id or
            user.role == User.FOUNDER_ROLE and user.startup_id
        )

    def has_object_permission(self, request, view, obj):
        user = request.user
        has_startup = hasattr(obj, 'startup_id')
        has_cohort = hasattr(obj, 'cohort_id')
        has_accelerator = hasattr(obj, 'accelerator_id')
        return (
            request.method in SAFE_METHODS or
            user.role == User.FOUNDER_ROLE and user.startup_id and (
                not has_startup or obj.startup_id == user.startup_id) or
            user.role in FOUNDER_ROLES and (
                not has_cohort and not has_accelerator or
                has_accelerator and obj.accelerator_id == user.accelerator_id or
                has_cohort and (obj.cohort is None or obj.cohort.accelerator_id == user.accelerator_id)
            )
        )
