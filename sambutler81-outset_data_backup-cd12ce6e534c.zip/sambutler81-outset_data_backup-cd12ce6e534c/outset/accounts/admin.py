from django.contrib import admin, messages
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin
from django.utils.translation import ugettext_lazy as _

from django_object_actions import DjangoObjectActions

from outset.invitations.forms import InviteForm

from .models import CohortWatcher, ConfirmEmail, StartupWatcher, Unsubscribe, User


@admin.register(ConfirmEmail)
class ConfirmEmailAdmin(admin.ModelAdmin):
    list_display = ('email', 'user', 'set_active', 'is_used', 'created')
    search_fields = ('email',)
    list_filter = ('set_active', 'is_used')
    readonly_fields = ('key', 'created', 'updated')
    fieldsets = (
        (None, {'fields': ('email', 'user', 'key')}),
        (_('Flags'), {'fields': ('set_active', 'is_used')}),
        (_('Important dates'), {'fields': ('created', 'updated')})
    )


@admin.register(User)
class UserAdmin(DjangoObjectActions, DefaultUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'image', 'tags')}),
        (_('Permissions'), {
            'fields': (
                'is_active', 'is_staff', 'is_superuser', 'subscribe', 'groups', 'user_permissions'
            )
        }),
        (_('Relations'), {
            'fields': (
                'role_in_company', 'role', 'accelerator', 'startup'
            )
        }),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (_('Social connections'), {
            'fields': (
                'angel', 'linkedin', 'facebook', 'twitter', 'github', 'skype', 'google_plus'
            )
        })
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2'),
        }),
    )
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups')
    search_fields = ('first_name', 'last_name', 'email')
    ordering = ('email',)
    list_display = ('email', 'first_name', 'last_name', 'accelerator', 'startup', 'role', 'is_active')
    change_actions = ('send_activate', 'send_invite',)

    def send_activate(self, request, obj):
        if obj.is_active:
            self.message_user(request, _('User is already activated'), messages.WARNING)
        else:
            confirm = ConfirmEmail.objects.filter(user=obj, set_active=True).first()
            if not confirm:
                confirm = ConfirmEmail.objects.create(user=obj, email=obj.email, set_active=True)
            confirm.send_email()
            self.message_user(request, _('Confirm email sended.'), messages.SUCCESS)
    send_activate.label = _('Send activate')
    send_activate.short_description = _('Send/resend email confirm')

    def send_invite(self, request, obj):
        opts = self.model._meta

        invite = obj.invite if hasattr(obj, 'invite') else None
        if invite is None:
            self.message_user(request, _('User has not invite,'), messages.WARNING)
            return
        form = InviteForm(request.POST or None, instance=invite)
        if form.is_valid():
            instance = form.save(commit=True)
            instance.send_mail()
            self.message_user(request, _('Invite email send.'), messages.SUCCESS)
            return

        adminForm = admin.helpers.AdminForm(form, [(None, {'fields': ('message',)})], {}, (), model_admin=self)

        context = dict(
            self.admin_site.each_context(request),
            title=_('Send Invite'),
            adminform=adminForm,
            object_id=obj.pk,
            original=obj,
            is_popup=False,
            media=self.media + adminForm.media,
            inline_admin_formsets=[],
            errors=admin.helpers.AdminErrorList(form, []),
            preserved_filters=self.get_preserved_filters(request)
        )

        return self.render_change_form(request, context, add=False, change=False, obj=obj)
    send_invite.label = _('Send Invite')
    send_invite.short_description = _('Send/resend invite to user')


admin.site.register(Unsubscribe)
admin.site.register(StartupWatcher)
admin.site.register(CohortWatcher)
