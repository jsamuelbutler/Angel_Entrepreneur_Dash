from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = 'outset.accounts'
