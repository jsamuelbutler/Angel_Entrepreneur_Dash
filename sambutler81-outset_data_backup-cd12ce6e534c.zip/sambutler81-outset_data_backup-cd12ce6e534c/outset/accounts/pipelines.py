from __future__ import unicode_literals

# import hashlib
from django.contrib.auth import get_user_model
from rest_framework.serializers import ValidationError
from social_core.exceptions import AuthUnknownError

from outset.accelerators.models import Accelerator

from .models import Unsubscribe, User
from .serializers import InviteValidationMixin
from .utils import validate_user


def auto_logout(*args, **kwargs):
    """Do not compare current user with new one"""
    return {'user': None}


def save_avatar(strategy, details, user=None, *args, **kwargs):
    """Get user avatar from social provider."""
    if user:
        backend = kwargs['backend']
        backend_name = backend.__class__.__name__.lower()
        response = kwargs.get('response', {})
        social_thumb = None
        if 'facebook' in backend_name:
            if 'id' in response:
                social_thumb = (
                    'http://graph.facebook.com/{0}/picture?type=normal'
                ).format(response['id'])
        elif 'twitter' in backend_name and response.get('profile_image_url'):
            social_thumb = response['profile_image_url']
        elif ('googleoauth2' in backend_name and
                response.get('image', {}).get('url') and
                not response.get('image', {}).get('isDefault', True)):
            social_thumb = response['image']['url'].split('?')[0]
        elif 'linkedin' in backend_name and response.get('pictureUrl'):
            social_thumb = response['pictureUrl']
        else:
            # social_thumb = 'http://www.gravatar.com/avatar/'
            # social_thumb += hashlib.md5(user.email.lower().encode('utf8')).hexdigest()
            # social_thumb += '?size=100'
            pass
        if social_thumb and user.image != social_thumb:
            user.image = social_thumb
            strategy.storage.user.changed(user)


def save_social_connections(strategy, details, user=None, *args, **kwargs):
    if user:
        backend_name = kwargs['backend'].__class__.__name__.lower()
        response = kwargs.get('response', {})
        changed = False
        if 'googleoauth2' in backend_name and response.get('isPlusUser', False) and response.get('url'):
            user.google_plus = response['url']
            changed = True
        elif 'linkedin' in backend_name and response.get('publicProfileUrl'):
            user.linkedin = response['publicProfileUrl']
            changed = True
        else:
            pass
        if changed:
            strategy.storage.user.changed(user)


def check_for_email(backend, uid, user=None, is_new=False, *args, **kwargs):
    if is_new:
        email = kwargs['details'].get('email')
        if not email:
            raise AuthUnknownError(backend, 'Email wasn\'t provided by oauth provider')
        elif get_user_model().objects.filter(email=email).exists():
            raise AuthUnknownError(backend, 'User with such email already exits.')


def check_invite(backend, details, user=None, is_new=False, *args, **kwargs):
    if is_new:
        try:
            invite = InviteValidationMixin().validate_invite(backend.strategy.session_get('invite'))
        except ValidationError as err:
            raise AuthUnknownError(backend, err.message)
        return {
            'invite': invite
        }


def check_safedelete(backend, details, user=None, is_new=False, *args, **kwargs):
    if user and user.deleted:
        raise AuthUnknownError(backend, 'User with same email is deleted. Wait while it will be cleaned.')


def extra_user_fields(backend, details, user=None, invite=None, is_new=False, *args, **kwargs):
    if user and not user.is_active:
        user.is_active = True
    if is_new:
        if Unsubscribe.objects.filter(email=user.email).exists():
            user.subscribe = User.NONE_SUBSCRIBE
        if invite:
            user.accelerator = invite.accelerator
            user.startup = invite.startup
            user.role = invite.role
            user.cash = invite.invited_by.cash
            user.save()
            invite.accepted = True
            invite.accepted_by = user
            invite.save(update_fields=['accepted', 'accepted_by'])
        else:
            user.accelerator = Accelerator.objects.create()
            user.role = User.FOUNDER_ROLE
            user.save()
    else:
        try:
            validate_user(user)
        except ValidationError as err:
            raise AuthUnknownError(backend, err.message)
