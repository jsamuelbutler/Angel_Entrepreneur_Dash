default_app_config = 'outset.yarn.apps.YarnConfig'
