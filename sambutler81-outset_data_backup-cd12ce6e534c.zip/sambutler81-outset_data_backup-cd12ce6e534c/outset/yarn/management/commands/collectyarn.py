from __future__ import unicode_literals

import subprocess

from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Build and collect front-end'

    def handle(self, *args, **options):
        kwargs = dict(stdout=self.stdout, stderr=self.stderr)

        process = subprocess.Popen(['yarn', 'add', 'card'], cwd=settings.ROOT_DIR('public'), **kwargs)
        process.wait()
        self.stdout.write(self.style.SUCCESS('Complete command: yarn add card'))

        process = subprocess.Popen(['yarn', 'run', 'build'], cwd=settings.ROOT_DIR('public'), **kwargs)
        process.wait()
        self.stdout.write(self.style.SUCCESS('Complete command: yarn run build'))
        process = subprocess.Popen(
            ['cp', '-R', str(settings.ROOT_DIR.path('public', 'src', 'img')), settings.STATIC_ROOT],
            cwd=str(settings.ROOT_DIR),
            **kwargs
        )
        process.wait()
        self.stdout.write(self.style.SUCCESS('Complete command: cp -R public/src/img outset/static/'))
