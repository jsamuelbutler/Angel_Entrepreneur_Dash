import stripe

from outset.accounts.models import User
from outset.billing.models import Plan, Option, Cash

BLOCK = 20


def clean_stripe(stripe_model):
    has_next = True
    while has_next:
        stripe_list = stripe_model.list(limit=BLOCK)
        has_next = stripe_list.has_more
        if stripe_list.data:
            [i.delete() for i in stripe_list.data]


def clean():
    Option.objects.all().update(monthly_id=None, annually_id=None)
    Plan.objects.all().update(monthly_id=None, annually_id=None)
    Cash.objects.all().delete()

    clean_stripe(stripe.Subscription)
    clean_stripe(stripe.Customer)
    clean_stripe(stripe.Plan)


def renew():
    [i.save() for i in Option.objects.filter(is_additional=True)]
    [i.save() for i in Plan.objects.all()]
    [Cash.create_for_user(i) for i in User.objects.filter(role=User.FOUNDER_ROLE, accelerator__isnull=False)]
