from django.db.models.query import QuerySet

from .models import ToDo


class WithToDoCountsQuerySetMixin(object):
    todo_field = 'id'

    def with_todo_counts(self):
        meta = self.model._meta
        todo_meta = ToDo._meta
        raw = 'SELECT COUNT(*) FROM {} WHERE is_complete = %s AND {} = {}.{}'.format(
            todo_meta.db_table,
            self.todo_field,
            meta.db_table,
            meta.get_field('id').attname
        )
        return self.extra(select={'todo_count': raw}, select_params=(False,))


class WithToDoCountsQuerySet(WithToDoCountsQuerySetMixin, QuerySet):
    pass
