from rest_framework import serializers

from outset.accelerators.models import Cohort
from outset.accounts.serializers import SimpleUserSerializer
from outset.startups.serializers import TinyStartupSerializer

from .models import ToDo
from .utils import get_activity_for_todo, get_status_for_todo


class StartupField(TinyStartupSerializer):
    def to_internal_value(self, data):
        if isinstance(data, int):
            try:
                return self.Meta.model._default_manager.get(pk=data)
            except self.Meta.model.DoesNotExist:
                return None
        return super(StartupField, self).to_internal_value(data)

    def validate(self, attrs):
        if not isinstance(attrs, self.Meta.model):
            raise serializers.ValidationError('Need send only id.')
        return attrs


class UserField(SimpleUserSerializer):
    def to_internal_value(self, data):
        if isinstance(data, int):
            try:
                return self.Meta.model._default_manager.get(pk=data)
            except self.Meta.model.DoesNotExist:
                return None
        return super(UserField, self).to_internal_value(data)

    def validate(self, attrs):
        if not isinstance(attrs, self.Meta.model):
            raise serializers.ValidationError('Need send only id.')
        return attrs


class ToDoSerializer(serializers.ModelSerializer):
    activity = serializers.SerializerMethodField(method_name='get_activity_name', read_only=True)
    status = serializers.SerializerMethodField(method_name='get_status_for_todo', read_only=True)
    startup = StartupField(allow_null=True)
    assign_to = UserField(allow_null=True)

    def validate_startup(self, value):
        if not value:
            return value
        user = self.context['request'].user
        if value.id != user.startup_id is not None and \
                not Cohort.objects.filter(accelerator=user.accelerator_id, id=value.cohort_id).exists():
            raise serializers.ValidationError('Unavailable startup.')
        return value

    def validate(self, validated_data):
        startup = validated_data.get('startup', self.instance.startup if self.instance else None)
        user = validated_data.get('assign_to', self.instance.assign_to if self.instance else None)

        if user:
            if user.startup_id and startup:
                if user.startup_id != startup.id:
                    raise serializers.ValidationError('Assign to user not in company team members.')
            elif user.accelerator_id:
                if user.accelerator_id != self.context['request'].user.accelerator_id:
                    raise serializers.ValidationError('Assign to user not in accelerator team members.')
            else:
                serializers.ValidationError('Assign to user not in team members.')

        return validated_data

    @staticmethod
    def get_activity_name(obj):
        return get_activity_for_todo(obj).html

    @staticmethod
    def get_status_for_todo(obj):
        return get_status_for_todo(obj)

    class Meta:
        model = ToDo
        fields = '__all__'
