from django_filters import NumberFilter
from django_filters.rest_framework import FilterSet
from django.db.models import Q

from .models import ToDo


class ToDoFilter(FilterSet):
    accelerator = NumberFilter(name='assign_to__accelerator')
    cohort = NumberFilter(name='startup__cohort')

    class Meta:
        model = ToDo
        fields = ('cohort', 'startup', 'assign_to', 'is_complete', 'accelerator')


def cohort_statistic_filter(queryset, name, value):
    return queryset.filter(Q(**{name: value}) | Q(startup__isnull=True))


class ToDoStatisticFilter(FilterSet):
    cohort = NumberFilter(name='startup__cohort', method=cohort_statistic_filter)
    startup = NumberFilter(name='startup')

    class Meta:
        model = ToDo
        fields = ('cohort', 'startup')

