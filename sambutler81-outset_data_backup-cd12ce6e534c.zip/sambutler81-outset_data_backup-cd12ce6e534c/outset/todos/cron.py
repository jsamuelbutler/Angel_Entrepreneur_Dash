from datetime import timedelta

from django.db import transaction
from django.db.models import Prefetch, Q
from django.db.models.functions import ExtractWeekDay, Now
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.timezone import now

from outset.activities.models import Activity

from .models import ToDo
from .utils import get_activity_for_todo


@transaction.atomic
def update_everyday_activities():
    today = now().date()
    todos = ToDo.objects.filter(is_complete=False, due_date__isnull=False)
    Activity.objects.bulk_create([get_activity_for_todo(i, for_date=today) for i in todos])


def send_reminder_emails():
    """
    To-Do's reminder

    To-Do's should send reminder email to person To-Do is assigned to One Week
    prior to due date, 3 days prior to due date, 1 day prior to due date, on
    due date & once per week when it is over due.
    """
    today = now().date()
    deadline_1_day = today + timedelta(days=1)
    deadline_3_days = today + timedelta(days=3)
    deadline_1_week = today + timedelta(days=7)

    site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())

    todo_queryset = ToDo.objects.filter(is_complete=False).order_by('name')

    user_queryset = get_user_model().objects.annotate(week_day=ExtractWeekDay('todos__due_date')).filter(
        (
            Q(todos__due_date__in=(today, deadline_1_day, deadline_3_days, deadline_1_week)) |
            Q(todos__due_date__lt=today, week_day=ExtractWeekDay(Now()))
        ),
        todos__is_complete=False
    ).prefetch_related(
        Prefetch('todos', queryset=todo_queryset.filter(due_date=deadline_1_week), to_attr='todos_1_week_due'),
        Prefetch('todos', queryset=todo_queryset.filter(due_date=deadline_3_days), to_attr='todos_3_days_due'),
        Prefetch('todos', queryset=todo_queryset.filter(due_date=deadline_1_day), to_attr='todos_1_day_due'),
        Prefetch('todos', queryset=todo_queryset.filter(due_date=today), to_attr='todos_today_due'),
        Prefetch(
            'todos',
            queryset=todo_queryset.annotate(week_day=ExtractWeekDay('due_date')).filter(
                due_date__lt=today, week_day=ExtractWeekDay(Now())
            ),
            to_attr='todos_over_due'
        )
    ).order_by('id').distinct('id')

    for user in user_queryset:
        context = {
            'site': site,
            'user': user,
            'todos_1_week_due': user.todos_1_week_due,
            'todos_3_days_due': user.todos_3_days_due,
            'todos_1_day_due': user.todos_1_day_due,
            'todos_today_due': user.todos_today_due,
            'todos_over_due': user.todos_over_due,
        }

        msg = EmailMultiAlternatives(
            subject=render_to_string('emails/todos_reminder_subject.txt', context),
            body=render_to_string('emails/todos_reminder.txt', context),
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
            reply_to=[settings.DEFAULT_FROM_EMAIL]
        )
        msg.attach_alternative(render_to_string('emails/todos_reminder.html', context), 'text/html')
        msg.send()
