from django.contrib import admin

from .models import ToDo


@admin.register(ToDo)
class ToDoAdmin(admin.ModelAdmin):
    list_display = ('name', 'startup', 'due_date', 'assign_to', 'is_complete')
    search_fields = ('name',)
