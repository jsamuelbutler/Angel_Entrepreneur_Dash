from datetime import timedelta

import django_filters
from django.db.models import Q
from django.utils.timezone import now
from rest_framework import decorators, filters, response, serializers, viewsets
from rest_framework.settings import api_settings

from outset.accelerators.models import Accelerator
from outset.accounts.models import User
from outset.startups.models import Startup

from .filters import ToDoFilter, ToDoStatisticFilter
from .models import ToDo
from .permissions import IsTodoTeamMemberSelfOrReadOnly
from .serializers import ToDoSerializer
from .utils import UPCOMING_PERIOD_DAYS


class ToDoViewSet(viewsets.ModelViewSet):
    """
    list:
        List of TO-DOs
    """
    queryset = ToDo.objects.all()
    serializer_class = ToDoSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsTodoTeamMemberSelfOrReadOnly]
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend, filters.SearchFilter)
    filter_class = ToDoFilter
    search_fields = ('name', 'description')

    def get_queryset(self):
        user = self.request.user
        return self.queryset.filter(
           Q(startup__in=Startup.objects.available_to_user(user).values('id')) |
           Q(assign_to__accelerator__in=Accelerator.objects.available_to_user(user).values('id'))
        ).order_by('due_date')

    @decorators.list_route(methods=['get'], filter_class=ToDoStatisticFilter, serializer_class=serializers.Serializer)
    def statistic(self, request):
        today = now().date()
        upcoming_period = (today, today + timedelta(days=UPCOMING_PERIOD_DAYS))

        queryset = self.filter_queryset(self.get_queryset()).filter(is_complete=False)
        if request.user == User.EMPLOYEE_ROLE:
            queryset = queryset.filter(assign_to=request.user)

        data = [
            ('OVERDO', queryset.filter(due_date__lt=today).count()),
            ('TO-DOs', queryset.count()),
            ('UPCOMING', queryset.filter(due_date__range=upcoming_period).count()),
        ]
        return response.Response(data=[{'text': k, 'count': v} for k, v in data])

