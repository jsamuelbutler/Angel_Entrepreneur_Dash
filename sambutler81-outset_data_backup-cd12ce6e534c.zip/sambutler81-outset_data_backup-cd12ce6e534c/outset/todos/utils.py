from django.conf import settings
from django.utils.timezone import now

from outset.activities.models import Activity


UPCOMING_PERIOD_DAYS = getattr(settings, 'TODOS_UPCOMING_PERIOD_DAYS', 7)

OVERDUE_NAME = 'Overdue'
UPCOMING_NAME = 'Upcoming'
FUTURE_NAME = 'Future'


def get_activity_for_todo(todo, for_date=None):
    for_date = for_date or now().date()
    activity = Activity(target=todo, template_id='todo_warn' if todo.due_date >= for_date else 'todo_expire')
    activity.render_html()
    return activity


def is_overdue(todo, today=None):
    today = today or now().date()
    return todo.due_date < today


def is_upcoming(todo, today=None):
    today = today or now().date()
    return 0 <= (todo.due_date - today).days <= UPCOMING_PERIOD_DAYS


def is_future(todo, today=None):
    today = today or now().date()
    return (todo.due_date - today).days > UPCOMING_PERIOD_DAYS


TODO_STATUSES = (
    (OVERDUE_NAME, is_overdue),
    (UPCOMING_NAME, is_upcoming),
    (FUTURE_NAME, is_future),
)


def get_status_for_todo(todo):
    return [name for name, test in TODO_STATUSES if test(todo)][0]
