from __future__ import unicode_literals

from django.conf import settings
from django.db import models
from django.dispatch import receiver
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel
from safedelete.signals import post_softdelete

from outset.models import ModelDiffMixin


class ToDo(ModelDiffMixin, SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    startup = models.ForeignKey('startups.Startup', related_name='todos', on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    assign_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name='todos',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    due_date = models.DateField()
    note = models.TextField(null=True, blank=True)
    is_complete = models.BooleanField(default=False)

    def __unicode__(self):
        return '"{}" to do'.format(self.name)

    @property
    def accelerator_id(self):
        return self.assign_to.accelerator_id if self.assign_to_id and not self.startup_id else None


@receiver(models.signals.post_save, sender=ToDo)
def update_todo(sender, instance, created=True, using=None, update_fields=None, **kwargs):
    from outset.activities.models import Activity

    template_id = None
    if created:
        template_id = 'todo_create'
    elif instance.is_complete and 'is_complete' in instance.changed_fields:
        template_id = 'todo_complete'
    if template_id:
        Activity.objects.using(using).create(target=instance, template_id=template_id)


@receiver(post_softdelete, sender=settings.AUTH_USER_MODEL)
def assign_to_set_null(sender, instance, using, **kwargs):
    # If assign_to set None we lost it in accelerator dashboard for team members (where it by name)
    # So, set assign_to to accelerator/company founder
    founder = sender.objects.using(using).filter(
        startup=instance.startup, accelerator=instance.accelerator, role=sender.FOUNDER_ROLE
    ).first()
    ToDo.objects.using(using).filter(assign_to=instance).update(assign_to=founder)
