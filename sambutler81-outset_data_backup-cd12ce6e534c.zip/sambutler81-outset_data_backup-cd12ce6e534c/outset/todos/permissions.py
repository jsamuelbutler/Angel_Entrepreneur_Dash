from rest_framework.permissions import BasePermission, SAFE_METHODS

from outset.accounts.models import User


class IsTodoTeamMemberSelfOrReadOnly(BasePermission):

    def has_permission(self, request, view):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            user.role in (User.ADMIN_ROLE, User.FOUNDER_ROLE, User.EMPLOYEE_ROLE)
        )

    def has_object_permission(self, request, view, obj):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            user.role in (User.ADMIN_ROLE, User.FOUNDER_ROLE, User.EMPLOYEE_ROLE) and (
                user.accelerator_id or obj.startup_id == user.startup_id
            )
        )
