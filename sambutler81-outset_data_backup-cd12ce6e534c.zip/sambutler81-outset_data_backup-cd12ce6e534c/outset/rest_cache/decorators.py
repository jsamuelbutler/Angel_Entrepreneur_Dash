from __future__ import unicode_literals

from functools import wraps

from django.http.request import HttpRequest
from django.template.response import SimpleTemplateResponse

from .utils import get_cache_key, is_caching_available, get_cache, set_cache


SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')


def cache_per_user(ttl=None, prefix=None, cache_non_safe=None, cache_by_method=None, cache_by_path=None):
    """
    Caching response data by user decorator

    :param ttl: time to live in seconds
    :param prefix: prefix for the caching
    :param cache_non_safe: cache non safe method (POST, PUT, PATCH and etc.)?
    :param cache_by_method: cache by method (different response for methods)?
    :param cache_by_path: cache by URL path
    :return: function decorator
    """

    def decorator(function):
        @wraps(function)
        def apply_cache(*args, **kwargs):
            self, request = (
                (getattr(function, '__self__'), args[0])
                if isinstance(args[0], HttpRequest) else
                (args[0], args[1])
            )
            can_cache = is_caching_available(request, cache_non_safe=cache_non_safe)

            cache_key = get_cache_key(
                request,
                prefix=prefix or 'cache_view_{}_{}'.format(
                    self.__class__.__name__ if self else '',
                    function.__name__
                ),
                cache_by_method=cache_by_method,
                cache_by_path=cache_by_path
            )
            response = get_cache(cache_key, request) if can_cache else None

            if not response:
                response = function(*args, **kwargs)
                if can_cache:
                    if isinstance(response, SimpleTemplateResponse):
                        response = response.render()
                    set_cache(cache_key, response, ttl)
            return response

        return apply_cache

    return decorator
