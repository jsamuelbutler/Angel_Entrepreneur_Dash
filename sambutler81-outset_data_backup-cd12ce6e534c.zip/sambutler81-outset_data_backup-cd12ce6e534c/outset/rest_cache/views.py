from __future__ import unicode_literals

from django.conf import settings
from django.template.response import SimpleTemplateResponse

from .utils import get_cache_key, is_caching_available, get_cache, set_cache, is_caching_update, cache_delete


DEFAULT_CACHE_TTL = getattr(settings, 'REST_DEFAULT_CACHE_TTL', 24 * 60 * 60)
DEFAULT_CACHE_NON_SAFE = getattr(settings, 'REST_DEFAULT_CACHE_NON_SAFE', None)
DEFAULT_CACHE_BY_METHOD = getattr(settings, 'REST_DEFAULT_CACHE_BY_METHOD', None)
DEFAULT_CACHE_BY_PATH = getattr(settings, 'REST_DEFAULT_CACHE_BY_PATH', None)


class CacheAPIViewMixin(object):
    cache_ttl = DEFAULT_CACHE_TTL
    cache_non_safe = DEFAULT_CACHE_NON_SAFE
    cache_by_method = DEFAULT_CACHE_BY_METHOD
    cache_by_path = DEFAULT_CACHE_BY_PATH

    # modified version of `rest_framework.views.APIView().dispatch()`
    def dispatch(self, request, *args, **kwargs):
        """
        `.dispatch()` is pretty much the same as Django's regular dispatch,
        but with extra hooks for startup, finalize, and exception handling.

        Some authentication make by `request.initialize_request()` inside in
        `rest_framework.views.APIView().dispatch()`. So, directly decoration
        dispatch function by `cache_per_user` is not correct way.
        """
        self.args = args
        self.kwargs = kwargs
        request = self.initialize_request(request, *args, **kwargs)
        self.request = request
        self.headers = self.default_response_headers  # deprecate?

        try:
            self.initial(request, *args, **kwargs)

            # Caching response
            can_cache = is_caching_available(request, cache_non_safe=self.cache_non_safe)
            cache_key = get_cache_key(
                request,
                instance=self.get_cache_instance(request),
                prefix='api_view_{}_{}'.format(self.__class__.__name__, self.action),
                cache_by_path=self.cache_by_path,
                cache_by_method=self.cache_by_method
            )

            # Get the appropriate handler method
            if request.method.lower() in self.http_method_names:
                handler = getattr(self, request.method.lower(),
                                  self.http_method_not_allowed)
            else:
                handler = self.http_method_not_allowed

            cached_response = get_cache(cache_key, request) if can_cache else None
            response = None if cached_response else handler(request, *args, **kwargs)

        except Exception as exc:
            can_cache = False
            cached_response = cache_key = None
            response = self.handle_exception(exc)

        if is_caching_update(request):
            cache_delete(cache_key)

        response = cached_response or self.finalize_response(request, response, *args, **kwargs)
        if not cached_response and can_cache:
            if isinstance(response, SimpleTemplateResponse):
                response = response.render()
            set_cache(cache_key, response, self.cache_ttl)

        self.response = response
        return response

    def get_cache_instance(self, request):
        return None
