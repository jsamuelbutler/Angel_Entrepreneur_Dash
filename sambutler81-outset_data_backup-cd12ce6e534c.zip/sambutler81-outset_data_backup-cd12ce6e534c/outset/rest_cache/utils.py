from __future__ import unicode_literals

from base64 import b64encode
import json

from django.core.cache import cache
from django.core.cache.backends.base import DEFAULT_TIMEOUT


SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS')


def get_cache_key(request, instance=None, prefix=None, cache_by_path=True, cache_by_method=True):
    """
    Generate cache key for request

    """
    cache_keys = [prefix] if prefix else []
    cache_keys.append(
        ('anonymous' if request.user.is_anonymous else str(request.user.id))
        if instance is None else
        (instance.pk if hasattr(instance, 'pk') else instance)
    )

    if cache_by_path:
        cache_keys.append(b64encode(request.path))
        cache_keys.append(b64encode(json.dumps(request.GET)))

    if cache_by_method:
        cache_keys.append(request.method)

    return '_'.join(cache_keys)


def is_caching_available(request, cache_non_safe=False):
    return request.method in SAFE_METHODS or cache_non_safe


def is_caching_update(request):
    return request.method not in SAFE_METHODS


def content_type_cache_key__(main_cache_key, content_type):
    return '{}_{}'.format(main_cache_key, b64encode(content_type))


def get_cache(cache_key, request, default=None, version=None):
    """
    Getting cached response by request accept content types.

    """
    for content_type in request.META.get('HTTP_ACCEPT', '').split(','):
        cached_response = cache.get(content_type_cache_key__(cache_key, content_type), version=version)
        if cached_response is not None:
            return cached_response
    return default


def set_cache(cache_key, response, timeout=DEFAULT_TIMEOUT, version=None):
    """
    Saving response in cache with a mark of its content type.

    """
    content_type = (
        content_type_cache_key__(cache_key, response['Content-Type'].split(';')[0])
        if 'Content-Type' in response else
        cache_key
    )
    cache.set(content_type, response, timeout, version)


USED_CONTENT_TYPES = (
    'text/html',
    'text/plain',
    'application/xhtml+xml',
    'application/xml',
    'application/json',
)


def cache_delete(cache_key):
    """
    Delete all related cash key by current.

    """
    # cache.delete_many([content_type_cache_key__(cache_key, content_type=i) for i in USED_CONTENT_TYPES])
    # Cache key contains get parameters. So, cannot delete all
    cache.clear()
