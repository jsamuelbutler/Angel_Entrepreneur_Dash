from rest_framework import serializers


class SerializerFieldMixin(object):
    def to_internal_value(self, data):
        model = self.Meta.model
        meta = model._meta
        pk_name = meta.pk.name

        # getting model instance by id. Example, `{ ..., "related_model_field": 12, ...}`
        if not isinstance(data, dict):
            try:
                return model.objects.filter(**{pk_name: data}).first()
            except ValueError:
                # incorrect pk value type
                raise serializers.ValidationError('Not found object with such id.')

        # getting model instance by serializable data (dict)
        # validate received data
        data = super(SerializerFieldMixin, self).to_internal_value(data)

        db_fields = meta.fields
        fields = [i for i in db_fields if i.related_model is None]
        related_fields = [i for i in db_fields if i.related_model is not None]
        new_fields = {k: v for k, v in data.items() if k in fields and k not in related_fields}

        #  it's case without receive primary key (created new model)
        if pk_name not in data:
            return self.Meta.model(**new_fields)

        # it's case with receive primary kay (update exist model)
        try:
            instance = self.Meta.model.objects.filter(**{pk_name: data[pk_name]}).first()
        except ValueError:
            raise serializers.ValidationError({pk_name: 'Not found object with such id.'})

        for attrname, attrvalue in new_fields:
            setattr(instance, attrname, attrvalue)

        return instance

    def run_validation(self, data=serializers.empty):
        (is_empty_value, data) = self.validate_empty_values(data)
        if is_empty_value:
            return data

        instance = self.to_internal_value(data)
        if isinstance(data, dict):
            a = super(SerializerFieldMixin, self).to_internal_value(data)
            value = super(SerializerFieldMixin, self).to_internal_value(data)
            try:
                self.run_validators(value)
                value = self.validate(value)
                assert value is not None, '.validate() should return the validated data'
            except (serializers.ValidationError, serializers.DjangoValidationError) as exc:
                raise serializers.ValidationError(detail=serializers.as_serializer_error(exc))

            for attr, v in value.items():
                setattr(instance, attr, v)

        return instance

    def validate(self, value):
        result = super(SerializerFieldMixin, self).validate(value)
        return result

