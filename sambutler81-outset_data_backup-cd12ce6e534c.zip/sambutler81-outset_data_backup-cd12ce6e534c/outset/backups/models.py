import boto3
from django.conf import settings
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver


class Backups(models.Model):
    key = models.CharField(max_length=1024)
    bucket_name = models.CharField(max_length=128)
    last_modified = models.DateTimeField(blank=True, null=True)
    size = models.IntegerField(default=0)

    def __unicode__(self):
        return self.key

    class Meta:
        verbose_name = 'Backup'
        verbose_name_plural = 'Backups'


@receiver(post_delete, sender=Backups)
def delete_aws_backup(sender, instance, **kwargs):
    s3 = boto3.resource(
        's3',
        aws_access_key_id=settings.DBBACKUP_STORAGE_OPTIONS['access_key'],
        aws_secret_access_key=settings.DBBACKUP_STORAGE_OPTIONS['secret_key'],
    )
    s3.Object(instance.bucket_name, instance.key).delete()
