import boto3
from django.core.management import call_command
from django.conf import settings
from outset.backups.models import Backups


def backup():
    if not settings.DEVELOPMENT:
        s3 = boto3.resource(
            's3',
            aws_access_key_id=settings.DBBACKUP_STORAGE_OPTIONS['access_key'],
            aws_secret_access_key=settings.DBBACKUP_STORAGE_OPTIONS['secret_key'],
        )
        bucket = s3.Bucket(settings.DBBACKUP_STORAGE_OPTIONS['bucket_name'])
        call_command('dbbackup')
        for obj in bucket.objects.all():
            dump, created = Backups.objects.get_or_create(bucket_name=obj.bucket_name, key=obj.key)
            dump.last_modified = obj.last_modified
            dump.size = obj.size
            dump.save()
