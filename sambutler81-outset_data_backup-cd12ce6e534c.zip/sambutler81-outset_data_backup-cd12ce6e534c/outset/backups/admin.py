from django.contrib import admin
from outset.backups.models import Backups


@admin.register(Backups)
class BackupsAdmin(admin.ModelAdmin):
    list_display = ('key', 'bucket_name', 'last_modified', 'size')

