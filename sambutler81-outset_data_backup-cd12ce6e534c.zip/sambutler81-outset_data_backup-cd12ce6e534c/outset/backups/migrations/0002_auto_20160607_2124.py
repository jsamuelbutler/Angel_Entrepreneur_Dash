# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('backups', '0001_initial'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='backups',
            options={'verbose_name': 'Backup', 'verbose_name_plural': 'Backups'},
        ),
    ]
