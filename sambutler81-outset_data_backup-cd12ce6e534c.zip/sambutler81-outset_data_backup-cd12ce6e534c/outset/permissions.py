from oauth2_provider.ext.rest_framework.authentication import OAuth2Authentication
from rest_framework.permissions import BasePermission, IsAuthenticated, SAFE_METHODS

from oauth2_provider.ext.rest_framework import TokenHasReadWriteScope as BaseTokenHasReadWriteScope


def is_not_oath(request):
    return (
        request.successful_authenticator and
        not isinstance(request.successful_authenticator, OAuth2Authentication)
    )


class OAuthReadOnly(BasePermission):
    def has_permission(self, request, view):
        return request.method in SAFE_METHODS or is_not_oath(request)


class TokenHasReadWriteScope(BaseTokenHasReadWriteScope):
    def has_permission(self, request, view):
        if is_not_oath(request):
            return True
        return super(TokenHasReadWriteScope, self).has_permission(request, view)


class IsModelSelfOrReadOnly(IsAuthenticated):
    object_field = 'id'
    model = None
    can_create_all = False
    can_create_roles = None
    can_update_all = False
    can_update_roles = None
    user_field = 'id'

    def has_permission(self, request, view):
        return (
            super(IsModelSelfOrReadOnly, self).has_permission(request, view) and (
                request.method in SAFE_METHODS or
                is_not_oath(request) and (
                    view.action != 'create' or
                    self.has_create_permission(request, view)
                )
            )
        )

    def has_object_permission(self, request, view, obj):
        assert self.model is not None, 'Model class is not set.'
        return (
            request.method in SAFE_METHODS or
            isinstance(obj, self.model) and
            self.has_update_permission(request, view, obj) and
            self.has_extra_object_permission(request, view, obj)
        )

    def has_extra_object_permission(self, request, view, obj):
        return getattr(obj, self.object_field) == getattr(request.user, self.user_field)

    def has_create_permission(self, request, view):
        return self.can_create_all or request.user.role in (self.can_create_roles or ())

    def has_update_permission(self, request, view, obj):
        return self.can_update_all or request.user.role in (self.can_update_roles or ())


