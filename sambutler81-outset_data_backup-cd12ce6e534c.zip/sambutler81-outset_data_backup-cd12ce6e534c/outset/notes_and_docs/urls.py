from __future__ import unicode_literals

from django.conf.urls import url
from rest_framework import routers

from . import views


router = routers.SimpleRouter()
router.register('docs/log', views.NodeHistoryViewSet)
router.register('docs', views.NodeViewSet)


urlpatterns = [
    url(r'^webhook/drive$', views.GoogleDriveWebhook.as_view(), name='web_hook'),
]
