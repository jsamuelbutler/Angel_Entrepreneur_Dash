from __future__ import unicode_literals

import base64
import boto3
import calendar
from collections import namedtuple
from datetime import timedelta
import logging
import json
import jsonpickle
import mimetypes
import httplib2
import os
from tempfile import NamedTemporaryFile
import uuid

from apiclient import discovery
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.contrib.sites.models import Site
from django.db import models
from django.dispatch import receiver
from django.db.models.signals import pre_delete, post_save
from django.urls import reverse
from django.utils.functional import cached_property
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError
from oauth2client.client import OAuth2WebServerFlow, TokenRevokeError, HttpAccessTokenRefreshError
from oauth2client.contrib.django_util.models import CredentialsField
from mptt.models import MPTTModel, TreeForeignKey

from outset.models import ModelDiffMixin
from outset.accelerators.models import Cohort
from outset.billing.consts import GOOGLE_DRIVE_SYNC_OPTION

from .mime_types import GOOGLE_FOLDER, GOOGLE_MIME_TYPES, GOOGLE_REVERSE_CONVERT
from .tasks import sync_google_drive_node, sync_google_drive
from .settings import (
    SECRET_KEY, ACCESS_KEY, BUCKET_NAME, DEFAULT_DIRECTORIES,
    GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_SCOPES, GOOGLE_REDIRECT_TO
)


logger = logging.getLogger(__name__)


mimetypes.init()


def set_watching_for_resource(instance, drive_service=None):
    assert isinstance(instance, AbstractGoogleDriveNode)
    if not hasattr(instance.user, 'google_drive'):
        logger.warning('User of {} have not connected Google Drive account'.format(instance))
        return
    if not drive_service:
        drive_service = instance.drive_service
    site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())
    web_hook_address = '{}{}'.format(site, reverse('notes_and_docs:web_hook'))
    expiration = long(
        calendar.timegm((now()+timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0).timetuple())*1000
    )
    # Google actual use first non expired channel. So do not need created more 1 channel for 1 resource
    if expiration <= instance.channel_expiration:
        logger.info('Resource watching for {} ({}): fileId={}'.format(instance, instance.pk, instance.google_drive_id))
        return
    logger.info(
        'Setting resource watching for {} ({}): fileId={}'.format(instance, instance.pk, instance.google_drive_id)
    )
    instance.channel_expiration = expiration
    try:
        drive_service.files().watch(
            fileId=instance.google_drive_id,
            body=dict(
                id=str(instance.channel),
                # resourceId=instance.google_drive_id,
                type='web_hook',
                address=web_hook_address,
                expiration=expiration
            )
        ).execute()
    except HttpError as err:
        logger.exception('HttpError {}: content={}'.format(err.uri, err.content))
    else:
        return True


S3File = namedtuple('S3File', 'file content_type')


class GoogleDriveFlow(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='+', on_delete=models.CASCADE)
    flow_pickle = models.TextField()

    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return '{} user flow pickle'.format(self.user)

    @property
    def flow(self):
        if hasattr(self, 'flow_'):
            return getattr(self, 'flow_')
        return jsonpickle.decode(self.flow_pickle)

    @flow.setter
    def flow(self, value):
        if not isinstance(value, OAuth2WebServerFlow):
            raise ValueError()
        setattr(self, 'flow_', value)
        self.flow_pickle = jsonpickle.encode(value)

    @property
    def authorize_url(self):
        return self.flow.step1_get_authorize_url()

    @classmethod
    def create(cls, request, **kwargs):
        assert request.user.is_authenticated, 'Non authorized user for flow creation.'
        flow = OAuth2WebServerFlow(
            client_id=GOOGLE_CLIENT_ID,
            client_secret=GOOGLE_CLIENT_SECRET,
            scope=GOOGLE_SCOPES,
            state=base64.urlsafe_b64encode(json.dumps(kwargs)),
            redirect_uri=request.build_absolute_uri(GOOGLE_REDIRECT_TO)
        )
        return cls.objects.create(user=request.user, flow=flow)


class GoogleDriveSync(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, primary_key=True, related_name='google_drive', on_delete=models.CASCADE
    )
    email = models.EmailField(null=True, blank=True)
    credentials = CredentialsField()
    is_system = models.BooleanField(default=False)

    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '{} user google drive ({}) sync'.format(self.user.recognize, self.email)

    def save(self, *args, **kwargs):
        if not self.email:
            self.email = self.get_current_email()
        return super(GoogleDriveSync, self).save(*args, **kwargs)

    def drive_sync(self):
        if not self.user.check_option(GOOGLE_DRIVE_SYNC_OPTION):
            return
        if self.user.accelerator_id:
            for cohort in Cohort.objects.filter(accelerator=self.user.accelerator_id):
                cohort_dir = self._create_dir(cohort.name, content_object=cohort)
                for startup in cohort.startups.all():
                    startup_dir = self._create_dir(
                        startup.name, parent=cohort_dir, content_object=startup, watchable=True
                    )
                    self._drive_sync(startup, parent_gd_id=startup_dir)
        elif self.user.startup_id:
            startup_dir = self._create_dir(self.user.startup.name, content_object=self.user.startup, watchable=True)
            self._drive_sync(self.user.startup, parent_gd_id=startup_dir)

    @cached_property
    def drive_service(self):
        return discovery.build('drive', 'v3', http=self.credentials.authorize(httplib2.Http()))

    def _create_dir(self, name, parent=None, content_object=None, watchable=False):
        try:
            id_ = AdditionallyGoogleDriveID.objects.filter(
                content_type=ContentType.objects.get_for_model(content_object._meta.model),
                object_id=content_object.id,
                user=self.user
            ).values_list('google_drive_id', flat=True)[0]
        except IndexError:
            pass
        else:
            return id_

        metadata = {
            'name': name,
            'parents': [parent if parent else 'root'],
            'mimeType': 'application/vnd.google-apps.folder',
        }

        logging.info('Creating non watch folder "{}" in {}'.format(name, metadata['parents']))

        try:
            file_ = self.drive_service.files().create(body=metadata, fields='id').execute()
        except HttpError as err:
            logger.error('Error on creating non watch folder "{}" to Google Drive ({} parent): {}'.format(
                name, metadata['parents'], str(err))
            )
            raise

        id_ = file_.get('id')

        if content_object:
            additional = AdditionallyGoogleDriveID(
                user=self.user, google_drive_id=id_, content_object=content_object, is_watchable=watchable
            )
            # create watching for this resource
            set_watching_for_resource(additional, drive_service=self.drive_service)
            additional.save()

        logger.info('Complete uploading to Google Drive: {}.'.format(id_))
        return id_

    def _drive_sync(self, startup, parent=None, parent_gd_id=None):
        queryset = Node.objects.prefetch_related(
            models.Prefetch('user_nodes', queryset=UserNode.objects.filter(user=self.user))
        ).filter(
            models.Q(parent=parent) if parent else models.Q(parent__isnull=True),
            startup=startup
        )
        for node in queryset:
            user_node = node.user_nodes.filter(user=self.user).first()
            if not user_node:
                user_node = UserNode.objects.create(user=self.user, node=node, parent_google_drive_id=parent_gd_id)
            elif user_node.parent_google_drive_id != parent_gd_id:
                user_node.parent_google_drive_id = parent_gd_id
                user_node.save(update_fields=['parent_google_drive_id'])
            if user_node.drive_sync(drive_service=self.drive_service):
                self._drive_sync(startup=startup, parent=node)

    def remove_sync(self, remove_google_drive_files=False):
        logger.info('Removing sync for user {}'.format(self.user))
        user_nodes = UserNode.objects.filter(user=self.user, google_drive_id__isnull=False)

        if remove_google_drive_files:
            logger.info('Removing Google Drive Root Files.')
            removed_ids = (
                AdditionallyGoogleDriveID.objects.filter(
                    content_type=ContentType.objects.get_for_model(Cohort),
                    user=self.user
                )
                if self.user.accelerator_id else
                user_nodes.filter(node__parent__isnull=True).order_by('google_drive_id').distinct('google_drive_id')
            ).values_list('google_drive_id', flat=True)

            s3 = discovery.build('drive', 'v3', http=self.credentials.authorize(httplib2.Http()))
            for id_ in removed_ids:
                logger.info('File with id {} removing...'.format(id_))
                try:
                    s3.files().delete(fileId=id_).execute()
                except HttpError:
                    logger.info('File with id {} can\'t remove.'.format(id_))

        AdditionallyGoogleDriveID.objects.filter(user=self.user).delete()
        user_nodes.update(google_drive_id=None, parent_google_drive_id=None)
        self.revoke_sync(self.credentials)
        logger.info('Removing sync complete.')

    @classmethod
    def get_email(cls, credentials):
        service = discovery.build('oauth2', 'v2', http=credentials.authorize(httplib2.Http()))
        return service.userinfo().get().execute().get('email')

    @classmethod
    def revoke_sync(cls, credentials):
        credentials.revoke(httplib2.Http())

    def get_current_email(self):
        return self.get_email(self.credentials)

    def ping(self):
        try:
            self.get_current_email()
        except (TokenRevokeError, HttpAccessTokenRefreshError):
            return False
        return True


class Node(ModelDiffMixin, MPTTModel):
    name = models.CharField(max_length=255)
    parent = TreeForeignKey(
        'self', null=True, blank=True, related_name='childs', db_index=True, on_delete=models.CASCADE
    )

    DIRECTORY_TYPE = 'dir'
    FILE_TYPE = 'file'
    NODE_TYPE_CHOICES = (
        (DIRECTORY_TYPE, 'Directory'),
        (FILE_TYPE, 'File'),
    )
    type = models.CharField(max_length=4, choices=NODE_TYPE_CHOICES, default=DIRECTORY_TYPE)
    extension = models.CharField(max_length=10, null=True, blank=True)

    startup = models.ForeignKey('startups.Startup', on_delete=models.CASCADE, related_name='nodes')

    uploaded = models.DateTimeField(editable=False, default=now)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='nodes', on_delete=models.SET_NULL, null=True, blank=True
    )
    updated = models.DateTimeField(editable=False, auto_now=True)

    class Meta:
        verbose_name = _('file tree node')

    class MPTTMeta:
        order_insertion_by = ['name']

    def get_children_count(self):
        return self.get_children().count()

    def __str__(self):
        return '"{}" {}'.format(self.fullname, 'folder' if self.type == self.DIRECTORY_TYPE else 'file')

    @property
    def fullname(self):
        return '.'.join([self.name, self.extension]) if self.extension else self.name

    @property
    def without_save_drive_sync(self):
        return getattr(self, 'without_save_drive_sync__', False)

    @without_save_drive_sync.setter
    def without_save_drive_sync(self, value):
        setattr(self, 'without_save_drive_sync__', bool(value))

    @classmethod
    def get_key(cls, parent, name, ext):
        assert parent is None or isinstance(parent, (int, cls))
        parent_node = parent if isinstance(parent, cls) else cls.objects.get(pk=parent)
        names = [str(parent.startup_id)]
        names += [i.fullname for i in parent_node.get_ancestors(include_self=True).only('name', 'extension')]
        names.append('.'.join([name, ext]) if ext else name)
        return '/'.join(names)

    @property
    def key(self):
        return self.get_key(self.parent, self.name, self.extension)

    @property
    def link(self):
        if self.type == self.DIRECTORY_TYPE:
            return None
        s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        return s3.generate_presigned_url('get_object', Params={'Bucket': BUCKET_NAME, 'Key': self.key})

    def save(self, *args, **kwargs):
        if self.type == self.DIRECTORY_TYPE:
            self.extension = None
        if {'name', 'parent'} & set(self.changed_fields):
            # rename or move current node
            name_diff = self.get_field_diff('name')
            if name_diff:
                old_name, new_name = name_diff
            else:
                old_name = new_name = self.name

            parent_diff = self.get_field_diff('parent')
            if parent_diff:
                old_parent, new_parent = parent_diff
            else:
                old_parent = new_parent = self.parent

            self.move_s3__(
                old_key=self.get_key(old_parent, old_name, self.extension),
                new_key=self.get_key(new_parent, new_name, self.extension)
            )

        is_adding = self._state.adding
        changed_fields = self.changed_fields
        result = super(Node, self).save(*args, **kwargs)
        if not self.without_save_drive_sync and (
                is_adding or {'name', 'extension', 'parent'} & set(changed_fields)):
            logger.warning('New async task generated.')
            sync_google_drive_node.delay([self.id])
        return result

    @classmethod
    def create_dir_mode(cls, parent=None, using=None, **kwargs):
        # assert parent is not None, 'top directory does not allow to create.'
        assert parent is None or isinstance(parent, cls), 'unsupported parent type.'
        assert 'name' in kwargs and kwargs['name'], 'need set node name'

        field_names = {i.name for i in cls._meta.fields} & set(kwargs.keys())
        # exception for `without_save_drive_sync`
        field_names |= {'without_save_drive_sync'}
        fields = {name: kwargs[name] for name in field_names if name in kwargs}
        fields.update({
            'type': cls.DIRECTORY_TYPE,
            'parent': parent
        })

        assert 'startup' in fields or parent
        if 'startup' not in fields:
            fields['startup'] = parent.startup

        return cls.objects.using(using).create(**fields)

    @classmethod
    def create_file_node(cls, file_object, filename=None, parent=None, using=None, **kwargs):
        assert hasattr(file_object, 'read') or isinstance(file_object, (str, unicode)), \
            'file_object should be a file-like object or string.'
        assert parent is None or isinstance(parent, cls), 'unsupported parent object.'
        assert hasattr(file_object, 'name') or filename is not None, \
            'Need send or `file_object` with `name` or `filename` parameter.'

        filename = getattr(file_object, 'name', filename)
        origin, ext, content_type = cls.split_name(filename)
        field_names = {i.name for i in cls._meta.fields} & set(kwargs.keys())
        # exception for `without_save_drive_sync`
        field_names |= {'without_save_drive_sync'}
        fields = {name: kwargs[name] for name in field_names if name in kwargs}
        fields.update({
            'type': cls.FILE_TYPE,
            'parent': parent,
            'extension': ext,
            'name': origin,
        })

        assert 'startup' in fields or parent
        if 'startup' not in fields:
            fields['startup'] = parent.startup

        s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        bucket = s3.Bucket(BUCKET_NAME)
        bucket.put_object(Key=cls.get_key(parent, origin, ext), Body=file_object, ContentType=content_type)

        return cls.objects.using(using).create(**fields)

    @staticmethod
    def split_name(file_name):
        name, ext = os.path.splitext(file_name)
        try:
            content_type = mimetypes.types_map[ext]
        except KeyError:
            content_type = 'application/octet-stream'
        return name, ext.lower()[1:], content_type

    @staticmethod
    def get_extension(content_type):
        ext = mimetypes.guess_extension(content_type)
        if not ext:
            return ''
        return ext[1:]

    @property
    def content(self):
        if hasattr(self, 'content__'):
            return getattr(self, 'content__')

        content_type = ''

        s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        try:
            s3_file_object = s3.get_object(Bucket=BUCKET_NAME, Key=self.key)
        except Exception as er:
            logger.warning('File {} not found on Amazon S3. Ignored in syncing: {}.'.format(self.key, str(er)))
            file_ = ''
        else:
            file_ = s3_file_object['Body'].read()
            content_type = s3_file_object['ContentType']

        result = S3File(file=file_, content_type=content_type)
        setattr(self, 'content__', result)
        return result

    @content.setter
    def content(self, s3_file):
        assert isinstance(s3_file, S3File)
        setattr(self, 'content__', s3_file)
        s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        bucket = s3.Bucket(BUCKET_NAME)
        old_key = self.key
        new_extension = self.get_extension(s3_file.content_type)
        if new_extension and self.pk and new_extension != self.extension:
            self.extension = new_extension
            self.save(update_fields=['extension'])
            s3.Object(BUCKET_NAME, old_key).delete()
        bucket.put_object(Key=self.key, Body=s3_file.file, ContentType=s3_file.content_type)
        if self.pk and not self.without_save_drive_sync:
            self.drive_sync()
            # sync_google_drive_node.delay([self.id])

    @staticmethod
    def move_s3__(old_key, new_key, s3_resource=None):
        """
        Recursive Update Amazon S3 keys

        :param old_key: old key of current node
        :param new_key: new key of current node
        :param s3_resource: boto3.resource for recursive calling
        :return: nothing
        """
        if s3_resource is None:
            s3_resource = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
        s3_resource.Object(BUCKET_NAME, new_key).copy_from(CopySource={'Bucket': BUCKET_NAME, 'Key': old_key})
        s3_resource.Object(BUCKET_NAME, old_key).delete()

    def drive_sync(self):
        logger.info('Mark node for all user as new.')
        self.user_nodes.all().update(is_new=True)

        logger.info('Creating new UserNode models.')
        content_type = ContentType.objects.get_for_model(self.startup._meta.model)
        startup_queryset = AdditionallyGoogleDriveID.objects.filter(
            object_id=self.startup.pk, content_type=content_type, user=models.OuterRef('pk')
        ).values('google_drive_id')[:1]
        users = get_user_model().related_users(self.startup).annotate(
            startup_google_drive_id=models.Subquery(startup_queryset, output_field=models.CharField(null=True))
        ).exclude(
            id__in=self.user_nodes.values('user_id')
        ).distinct()
        new_user_nodes = [
            UserNode(
                node=self,
                user=user,
                is_new=user != self.uploaded_by,
                parent_google_drive_id=None if self.parent else user.startup_google_drive_id
            )
            for user in users
        ]
        UserNode.objects.bulk_create(new_user_nodes)

        logger.info('Start node sync: {}'.format(self.id))
        for user_node in self.user_nodes.all():
            user_node.drive_sync()

            # setting watching to this resource
            if user_node in new_user_nodes:
                logger.info('Start add node watching: {}'.format(user_node))
                if set_watching_for_resource(user_node):
                    user_node.save()


class AbstractGoogleDriveNode(ModelDiffMixin, models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='+', on_delete=models.CASCADE)
    google_drive_id = models.CharField(max_length=100, null=True, blank=True)
    google_drive_version = models.BigIntegerField(default=0)
    channel = models.UUIDField(default=uuid.uuid4)
    channel_expiration = models.BigIntegerField(default=0)

    class Meta:
        abstract = True
        index_together = (('google_drive_id', 'channel'),)

    @property
    def drive_service(self):
        http = self.user.google_drive.credentials.authorize(httplib2.Http())
        return discovery.build('drive', 'v3', http=http)

    @property
    def google_link(self):
        if not hasattr(self, 'node') or self.node.type == Node.DIRECTORY_TYPE or not self.google_drive_id:
            return

        # We do not call API because the result link is static and it template is known
        # google_file = self.drive_service.files().get(fileId=self.google_drive_id, fields='webViewLink').execute()
        # return google_file.get('webViewLink')

        return 'https://drive.google.com/a/cronix.ms/file/d/{}/view?usp=drivesdk'.format(self.google_drive_id)

    def get_google_resource(self, fields=None):
        fields = fields or 'id,name,parents,mimeType,version'
        try:
            return self.drive_service.files().get(fileId=self.google_drive_id, fields=fields).execute()
        except (HttpError, HttpAccessTokenRefreshError):
            return None

    def get_google_content(self, mime_type=None):
        resource = self.get_google_resource(fields='mimeType')
        fh = ''
        if resource:
            resource_mime_type = resource['mimeType']
            if resource_mime_type == GOOGLE_FOLDER:
                pass
            elif resource_mime_type in GOOGLE_MIME_TYPES:
                mime_type = (
                    mime_type
                    if mime_type in GOOGLE_MIME_TYPES[resource_mime_type] else
                    GOOGLE_MIME_TYPES[resource_mime_type][0]
                )
                fh = self.drive_service.files().export_media(fileId=self.google_drive_id, mimeType=mime_type).execute()
            else:
                fh = self.drive_service.files().get_media(fileId=self.google_drive_id).execute()
                mime_type = resource_mime_type
        return S3File(file=fh, content_type=mime_type)

    def get_google_children(self, **kwargs):
        files = None
        page_token = None
        while files is None or page_token:
            params = kwargs.copy()
            params['q'] = '"{}" in parents'.format(self.google_drive_id)
            params.update(dict(pageToken=page_token) if page_token else dict())
            try:
                files = self.drive_service.files().list(**params).execute()
            except HttpError as err:
                logger.exception('HttpError {}: content={}'.format(err.uri, err.content))
                break

            for i in files['files']:
                yield i

            page_token = files.get('nextPageToken')


class UserNode(AbstractGoogleDriveNode):
    node = models.ForeignKey(Node, related_name='user_nodes', on_delete=models.CASCADE)
    is_new = models.BooleanField(default=True)
    parent_google_drive_id = models.CharField(
        max_length=100, null=True, blank=True, help_text='non Node Google Drive parent'
    )

    class Meta:
        unique_together = (('user', 'node'),)

    def __str__(self):
        return '{} for user {}{}'.format(self.node, self.user, ' with google sync' if self.google_drive_id else '')

    def save(self, *args, **kwargs):
        if not self.node.parent and not self.parent_google_drive_id:
            self.parent_google_drive_id = self.drive_service.files().get(fileId='root', fields='id').execute().get('id')
        return super(UserNode, self).save(*args, **kwargs)

    @cached_property
    def user_parent_node(self):
        return self.node.parent.user_nodes.filter(user=self.user).first() if self.node.parent else None

    @property
    def google_parent(self):
        return self.user_parent_node.google_drive_id if self.user_parent_node else self.parent_google_drive_id

    def drive_sync(self, drive_service=None):
        """
        Sync current node a with user google drive

        :param drive_service: Google Drive service API object to recursive calling
        :return:
        """
        if not self.user.check_option(GOOGLE_DRIVE_SYNC_OPTION):
            return

        logger.info('Start `UserNode.drive_sync`.')

        result = False

        if not drive_service:
            if not hasattr(self.user, 'google_drive') or not self.user.google_drive:
                return result
            drive_service = self.drive_service

        # Resolve did not uploaded by some fail
        if self.user_parent_node and not self.user_parent_node.google_drive_id:
            self.user_parent_node.drive_sync(drive_service)

        metadata = {'name': self.node.fullname}
        temp_file = None
        media = None
        if self.google_parent and not self.google_drive_id:
            metadata['parents'] = [self.google_parent]
        if self.node.type == Node.DIRECTORY_TYPE:
            metadata['mimeType'] = 'application/vnd.google-apps.folder'
        else:
            content = self.node.content

            # Convert popular formats to Google Documents
            if content.content_type in GOOGLE_REVERSE_CONVERT:
                metadata.update(dict(mimeType=GOOGLE_REVERSE_CONVERT[content.content_type], name=self.node.name))

            temp_file = NamedTemporaryFile(mode='wb', delete=False)
            temp_file.write(content.file)
            temp_file.close()

            logger.info('Sending data from {} (size {})'.format(temp_file.name, os.path.getsize(temp_file.name)))
            media = MediaFileUpload(temp_file.name, mimetype=content.content_type, resumable=True)

            result = True

        if not self.google_drive_id:
            logger.info('Sending to Google Drive')
            try:
                file_ = drive_service.files().create(body=metadata, media_body=media, fields='id,version').execute()
            except HttpError as err:
                logger.error('Error on sending file {} to Google Drive ({} parent): {}'.format(
                    str(self), metadata['parents'], str(err))
                )
                raise
            else:
                logger.info('Complete uploading to Google Drive.')
            self.google_drive_id = file_.get('id')
            self.google_drive_version = long(file_.get('version', 0))
            logger.info('Google Drive File ID: {} (version {})'.format(self.google_drive_id, self.google_drive_version))
            if not self._state.adding:
                # for not execute recursive self.save()
                self._meta.model.objects.filter(pk=self.pk).update(
                    google_drive_id=self.google_drive_id,
                    google_drive_version=self.google_drive_version,
                    channel=self.channel)
            result = True
        else:
            kwargs = {}
            file_ = self.get_google_resource(fields='parents')
            previous_parents = ','.join(file_.get('parents'))
            if previous_parents != self.google_parent:
                kwargs.update({
                    'addParents': self.google_parent,
                    'removeParents': previous_parents
                })

                result = True

            file_ = drive_service.files().update(
                fileId=self.google_drive_id, body=metadata, media_body=media, fields='version', **kwargs
            ).execute()
            if not self._state.adding:
                self._meta.model.objects.filter(pk=self.pk).update(google_drive_version=long(file_.get('version', 0)))

        if temp_file:
            os.unlink(temp_file.name)

        return result


class AdditionallyGoogleDriveID(AbstractGoogleDriveNode):
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    is_watchable = models.BooleanField(default=False)

    def __str__(self):
        return '{} content type with {}: {}'.format(self.content_type_id, self.object_id, self.google_drive_id)

    def save(self, *args, **kwargs):
        assert self.google_drive_id
        return super(AdditionallyGoogleDriveID,  self).save(*args, **kwargs)


@receiver(pre_delete, sender=Node)
def delete_node(sender, instance, using, **kwargs):
    s3 = boto3.resource('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
    bucket = s3.Bucket(BUCKET_NAME)
    try:
        bucket.Object(instance.key).delete()
    except:
        pass

    user_nodes = instance.user_nodes.using(using).filter(google_drive_id__isnull=False).select_related(
        'user', 'user__google_drive'
    )
    for user_node in user_nodes:
        if hasattr(user_node.user, 'google_drive') and user_node.user.google_drive:
            try:
                user_node.drive_service.files().delete(fileId=user_node.google_drive_id).execute()
            except HttpError:
                pass


@receiver(post_save, sender='startups.Startup')
def create_default_directories(sender, instance, created, raw, using, **kwargs):
    if created:
        [Node.create_dir_mode(name=name, startup=instance, using=using) for name in DEFAULT_DIRECTORIES]

        sync_google_drive.delay(
            list(GoogleDriveSync.objects.filter(
                user__in=get_user_model().related_users(instance).values('pk')
            ).values_list('pk', flat=True))
        )
