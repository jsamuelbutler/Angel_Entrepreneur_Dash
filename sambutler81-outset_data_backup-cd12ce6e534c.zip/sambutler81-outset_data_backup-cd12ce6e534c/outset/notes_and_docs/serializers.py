import base64
import json
import os

from oauth2client.client import FlowExchangeError
from django.contrib.auth import get_user_model
from django.db.models import Q
from googleapiclient.http import MediaFileUpload
from rest_framework import serializers
from tempfile import NamedTemporaryFile

from outset.accounts.serializers import SimpleUserSerializer, AuthTokenResponseIfPostMixin
from outset.billing.consts import GOOGLE_DRIVE_SYNC_OPTION
from outset.startups.models import Startup

from .mime_types import PLAIN_TEXT, MS_WORD, GOOGLE_DOCUMENT
from .models import Node, GoogleDriveSync, GoogleDriveFlow, AdditionallyGoogleDriveID, UserNode


TITLE_LENGTH = Node._meta.get_field('name').max_length


class NodeParentValidation(object):
    def validate_parent(self, value):
        parent = (
            value
            if isinstance(value, Node) else
            Node.objects.filter(
                Q(startup__in=Startup.objects.available_to_user(self.context['request'].user))
                  if 'request' in self.context else Q(),
                pk=value,
            ).first()
        )
        if not parent or self.instance and self.instance.startup_id != parent.startup_id:
            raise serializers.ValidationError(
                serializers.PrimaryKeyRelatedField.default_error_messages['does_not_exist'].format(
                    pk_value=value.pk if isinstance(value, Node) else value or 'None'
                )
            )
        return parent


class NodeSerializer(NodeParentValidation, serializers.ModelSerializer):
    title = serializers.CharField(source='name', max_length=TITLE_LENGTH, required=False)
    uploaded_by = SimpleUserSerializer(read_only=True)
    data = serializers.FileField(required=False, write_only=True)
    files = serializers.IntegerField(min_value=0, source='get_children_count', read_only=True)
    is_new = serializers.SerializerMethodField(read_only=True)
    google_link = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Node
        fields = ('id', 'title', 'startup', 'type', 'extension', 'uploaded', 'uploaded_by', 'files',
                  'parent', 'data', 'link', 'is_new', 'google_link')
        read_only_fields = ('type', 'uploaded', 'extension', 'link')
        extra_kwargs = {'startup': {'required': False}}

    def get_is_new(self, obj):
        if 'request' not in self.context:
            return False
        return obj.get_descendants(include_self=True).filter(
            Q(user_nodes__is_new=True, user_nodes__user=self.context['request'].user) | Q(user_nodes__isnull=True)
        ).exists()

    def get_google_link(self, obj):
        if not hasattr(obj, 'user_node'):
            if 'request' not in self.context:
                raise serializers.ValidationError('Not found request.')
            user_node = obj.user_nodes.filter(user=self.context['request'].user).first()
        else:
            user_node = obj.user_node[0] if obj.user_node else None
        return user_node.google_link if user_node else None

    def validate_startup(self, value):
        if self.instance and self.instance.startup_id != value.id:
            raise serializers.ValidationError('Different startup IDs.')
        return value

    def validate(self, validated_data):
        if validated_data.get('data') and not self.instance:
            node_type = Node.FILE_TYPE
        elif not self.instance:
            node_type = Node.DIRECTORY_TYPE
        else:
            node_type = self.instance.type
        validated_data['type'] = node_type

        if node_type == Node.FILE_TYPE and not self.instance and 'data' not in validated_data:
            raise serializers.ValidationError('Can not upload a file without data.')

        parent = validated_data.get('parent', self.instance.parent if self.instance else None)
        validated_startup = validated_data.get('startup')
        if not validated_startup and not parent:
            raise serializers.ValidationError('Need select startup or parent folder.')
        elif validated_startup and parent and validated_startup.pk != parent.startup_id:
            raise serializers.ValidationError('Selected startup differ from parent folder startup.')
        elif parent:
            validated_data['startup'] = parent.startup

        name = self.instance.name if self.instance else None
        ext = self.instance.extension if self.instance else None
        if node_type == Node.DIRECTORY_TYPE:
            name = validated_data.get('name')
            ext = None
        else:
            data_file = validated_data.get('data')
            if data_file:
                filename = getattr(data_file, 'name', validated_data.get('name'))
                if filename:
                    name, ext = os.path.splitext(filename)
            elif not self.instance:
                raise serializers.ValidationError('It is forbidden to create file without data.')
        node_type_name = 'file' if node_type == Node.FILE_TYPE else 'directory'
        if not name:
            raise serializers.ValidationError('Can not create {} with empty name.'.format(node_type_name))
        if Node.objects.filter(parent=parent,
                               name=name,
                               extension=(ext.lower()[1:] if ext else None),
                               type=node_type
                               ).exclude(pk=self.instance.id if self.instance else None).exists():
            raise serializers.ValidationError('{} with such name is already exists'.format(node_type_name.title()))

        if 'request' in self.context:
            validated_data['uploaded_by'] = self.context['request'].user

        return validated_data

    def create(self, validated_data):
        if validated_data['type'] == Node.DIRECTORY_TYPE:
            return super(NodeSerializer, self).create(validated_data)
        return Node.create_file_node(validated_data['data'], **validated_data)


class NoteSerializer(NodeParentValidation, serializers.Serializer):
    title = serializers.CharField(max_length=TITLE_LENGTH)
    text = serializers.CharField()

    def validate(self, validated_data):
        if 'parent' not in self.context:
            raise serializers.ValidationError('There is not parent to note.')
        parent_id = self.context['parent']
        validated_data['parent'] = parent = self.validate_parent(parent_id)
        if parent.type != Node.DIRECTORY_TYPE:
            raise serializers.ValidationError('Parent directory node is not found.')
        if Node.objects.filter(parent=parent_id, name=validated_data['title']).exists():
            raise serializers.ValidationError('Note with such name is already exists.')
        return validated_data

    def update(self, instance, validated_data):
        raise NotImplementedError('NoteSerialize class has not method update.')

    def create(self, validated_data):
        parent = validated_data['parent']
        content = validated_data['text']
        filename = validated_data['title']

        # We use system google sync to create temp Google Docs for MS Word
        # document getting else plain text file creation
        try:
            system_sync = next(i for i in GoogleDriveSync.objects.filter(is_system=True) if i.ping())
        except StopIteration:
            filename = '{}.txt'.format(filename)
        else:
            temp_file = NamedTemporaryFile(mode='wb', delete=False)
            temp_file.write(content)
            temp_file.close()

            media = MediaFileUpload(temp_file.name, mimetype=PLAIN_TEXT, resumable=True)

            google_doc = system_sync.drive_service.files().create(
                body=dict(name='temp.txt', parents=['root'], mimeType=GOOGLE_DOCUMENT),
                media_body=media,
                fields='id'
            ).execute()['id']
            google_content = UserNode(google_drive_id=google_doc, user=system_sync.user).get_google_content(MS_WORD)
            system_sync.drive_service.files().delete(fileId=google_doc).execute()
            os.unlink(temp_file.name)
            content = google_content.file
            filename = '{}.{}'.format(filename, Node.get_extension(google_content.content_type))

        return Node.create_file_node(
            content,
            filename=filename,
            parent=parent,
            startup=parent.startup,
            uploaded_by=self.context['request'].user if 'request' in self.context else None
        )


class GoogleSyncSerializer(serializers.ModelSerializer):
    def validate(self, validated_date):
        user = self.context['request'].user if 'request' in self.context else None
        if user:
            if user.is_anonymous:
                raise serializers.ValidationError('Need authenticate to edit it.')
            elif user.is_authenticated and not user.check_option(GOOGLE_DRIVE_SYNC_OPTION):
                raise serializers.ValidationError('Upgrade your plan to connect to this API.')
        return super(GoogleSyncSerializer, self).validate(validated_date)


class GoogleDriveSyncStep1Serializer(GoogleSyncSerializer):
    return_url = serializers.CharField(required=False, allow_null=True, allow_blank=True)

    @staticmethod
    def validate_return_url(value):
        if not value:
            return
        if not value.startswith('/'):
            raise serializers.ValidationError('Return URL may be only local type (starts with "/").')
        return value

    def validate(self, validated_data):
        validated_data = super(GoogleDriveSyncStep1Serializer, self).validate(validated_data)
        if 'request' not in self.context:
            raise serializers.ValidationError('Need user to Sync with Google Drive.')
        user = self.context['request'].user
        if self.Meta.model.objects.filter(user=user).exists():
            raise serializers.ValidationError('Link to Google Drive is already taken.')
        validated_data['user'] = user.id
        return validated_data

    class Meta:
        model = GoogleDriveSync
        fields = ('return_url',)


class GoogleDriveSyncStep2Serializer(AuthTokenResponseIfPostMixin, GoogleSyncSerializer):
    state = serializers.CharField(write_only=True)
    code = serializers.CharField(write_only=True)
    redirect = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = GoogleDriveSync
        fields = ('state', 'code', 'redirect')

    def validate_state(self, value):
        try:
            value = json.loads(base64.urlsafe_b64decode(value.encode('utf8')))
        except (ValueError, TypeError):
            raise serializers.ValidationError('Invalid.')
        user = value.get('user')

        if 'request' in self.context:
            request_user = self.context['request'].user
            if user != request_user.id:
                raise serializers.ValidationError('Invalid user.')
            else:
                user = request_user
        else:
            user_model = get_user_model()
            try:
                user = user_model.objects.get(id=user)
            except user_model.DoesNotExist:
                raise serializers.ValidationError('User not found.')

        if hasattr(user, 'google_drive') and user.google_drive and not self.context.get('renew_time_limit_token'):
            raise serializers.ValidationError('Link to Google Drive is already taken.')

        value['user'] = user
        return value

    def validate(self, attrs):
        attrs = super(GoogleDriveSyncStep2Serializer, self).validate(attrs)
        state = attrs['state']

        if 'flow' not in self.context:
            raise serializers.ValidationError('Invalid sync link.')

        try:
            credentials = self.context['flow'].flow.step2_exchange(attrs['code'])
        except FlowExchangeError as err:
            raise serializers.ValidationError(str(err))

        email = GoogleDriveSync.get_email(credentials)
        if not self.context.get('renew_time_limit_token') and self.Meta.model.objects.filter(email=email).exists():
            raise serializers.ValidationError('This Google account is already sync.')

        if not credentials.refresh_token:
            self.context['flow'].delete()
            GoogleDriveSync.revoke_sync(credentials)
            raise serializers.ValidationError(
                'You have not Google Drive refresh token. Please repeat the sync process.'
            )

        setattr(self, 'state_redirect', state.get('return_url'))

        return {
            'credentials': credentials,
            'user': state['user'],
            'email': email
        }

    def get_redirect(self, obj):
        return getattr(self, 'state_redirect', None)


class GoogleDriveRemoveSyncSerializer(AuthTokenResponseIfPostMixin, serializers.Serializer):
    remove_google_drive_files = serializers.BooleanField(default=False, required=False, write_only=True)

    def validate(self, validated_data):
        if self.instance:
            validated_data['ping'] = self.instance.ping()
        if 'request' not in self.context:
            raise serializers.ValidationError('User not found.')
        validated_data['user'] = self.context['request'].user
        return validated_data

    def delete(self):
        if self.instance:
            if self.validated_data.get('ping'):
                self.instance.remove_sync(remove_google_drive_files=self.validated_data['remove_google_drive_files'])
            self.instance.delete()
            user = self.instance.user_id
            UserNode.objects.filter(user=user).update(google_drive_id=None, parent_google_drive_id=None)
            AdditionallyGoogleDriveID.objects.filter(user=user).delete()

    @property
    def data(self):
        ret = super(GoogleDriveRemoveSyncSerializer, self).data
        if not self.validated_data.get('ping') and 'request' in self.context:
            request = self.context['request']
            gdflow = GoogleDriveFlow.create(request, return_url=request.META.get('HTTP_REFERER'), user=request.user.pk)
            ret['redirect'] = gdflow.authorize_url
        return ret



