from __future__ import unicode_literals


HTML = 'text/html'
ZIP = 'application/zip'
PLAIN_TEXT = 'text/plain'
RICH_TEXT = 'application/rtf'
OPEN_OFFICE_DOC = 'application/vnd.oasis.opendocument.text'
PDF = 'application/pdf'
MS_WORD = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
EPUB = 'application/epub+zip'

MS_EXCEL = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
OPEN_OFFICE_SHEET = 'application/x-vnd.oasis.opendocument.spreadsheet'
CSV = 'text/csv'
TSV = 'text/tab-separated-values'

JPEG = 'image/jpeg'
PNG = 'image/png'
SVG = 'image/svg+xml'

MS_POWERPOINT = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
OPEN_OFFICE_PRESENTATION = 'application/vnd.oasis.opendocument.presentation'


GOOGLE_DOCUMENT = 'application/vnd.google-apps.document'
GOOGLE_DRAWING = 'application/vnd.google-apps.drawing'
GOOGLE_FOLDER = 'application/vnd.google-apps.folder'
GOOGLE_SLIDERS = 'application/vnd.google-apps.presentation'
GOOGLE_SHEETS = 'application/vnd.google-apps.spreadsheet'


GOOGLE_MIME_TYPES = {
    GOOGLE_DOCUMENT: [MS_WORD, OPEN_OFFICE_DOC, HTML, ZIP, PLAIN_TEXT, RICH_TEXT, PDF, EPUB],
    GOOGLE_SHEETS: [MS_EXCEL, OPEN_OFFICE_SHEET, PDF, CSV, TSV, HTML],
    GOOGLE_DRAWING: [JPEG, PNG, SVG, PDF],
    GOOGLE_SLIDERS: [MS_POWERPOINT, OPEN_OFFICE_PRESENTATION, PDF, PLAIN_TEXT]
}

GOOGLE_REVERSE_CONVERT = {
    MS_WORD: GOOGLE_DOCUMENT,
    PLAIN_TEXT: GOOGLE_DOCUMENT,
    RICH_TEXT: GOOGLE_DOCUMENT,
    OPEN_OFFICE_DOC: GOOGLE_DOCUMENT,
    MS_EXCEL: GOOGLE_SHEETS,
    OPEN_OFFICE_SHEET: GOOGLE_SHEETS,
    MS_POWERPOINT: GOOGLE_SLIDERS,
    OPEN_OFFICE_PRESENTATION: GOOGLE_SLIDERS,
}
