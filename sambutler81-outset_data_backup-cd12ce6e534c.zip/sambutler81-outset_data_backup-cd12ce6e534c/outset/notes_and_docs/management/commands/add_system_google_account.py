from __future__ import absolute_import, unicode_literals

try:
    input = raw_input
except NameError:
    pass

from oauth2client.client import FlowExchangeError

from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from django.core.management.base import BaseCommand
from django.test.client import RequestFactory

from outset.notes_and_docs.models import GoogleDriveFlow, GoogleDriveSync


class Command(BaseCommand):
    help = 'Add system Google Drive Account to create/convert Google Docs to MS Word documents.'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE('Adding Google Drive account...'))

        user = credentials = None
        user_model = get_user_model()
        while user is None:
            try:
                user_id = int(input('Outset User ID: '))
            except (TypeError, ValueError):
                self.stdout.write(self.style.ERROR('Invalid user id.'))
                continue
            try:
                user = user_model.objects.get(id=user_id, is_staff=True)
            except user_model.DoesNotExists:
                self.stdout.write(self.style.ERROR('User not found.'))

            if hasattr(user, 'google_drive'):
                self.stdout.write(self.style.ERROR('{} already have a Google Drive sync.'.format(user)))
                user = None

        request = RequestFactory(SERVER_NAME=Site.objects.first().domain).get('/', secure=True)
        request.user = user
        gdflow = GoogleDriveFlow.create(request)
        self.stdout.write(self.style.NOTICE('Authorize URL: {}'.format(gdflow.authorize_url)))

        while credentials is None:
            try:
                credentials = gdflow.flow.step2_exchange(input('Code: '))
            except FlowExchangeError as err:
                self.stdout.write(self.style.ERROR('ERROR: {}'.format(str(err))))

        if not credentials.refresh_token:
            self.stdout.write(self.style.ERROR('Credentials are not refreshable.'))
            return

        email = GoogleDriveSync.get_email(credentials)
        GoogleDriveSync.objects.create(credentials=credentials, user=user, email=email, is_system=True)
        self.stdout.write(self.style.SUCCESS('Successfully adding sys credentials for "{}"'.format(email)))
