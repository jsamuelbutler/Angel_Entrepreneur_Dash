from __future__ import unicode_literals

from datetime import timedelta
import logging
from time import sleep

import django_filters
from django.db.models import Prefetch
from django.db.transaction import non_atomic_requests
from django.contrib.contenttypes.models import ContentType
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from django.utils.decorators import method_decorator
from django.utils.timezone import now
from rest_framework import filters, parsers, response, status, viewsets
from rest_framework.decorators import detail_route, list_route
from rest_framework.settings import api_settings

from outset.lock import redis_mutex
from outset.accounts.permissions import IsAcceleratorFounderOrStartupFounderOrReadOnly
from outset.activities.models import Activity
from outset.activities.filters import ActivityFilter
from outset.activities.serializers import ActivityLogSerializer
from outset.startups.models import Startup

from .tasks import sync_google_drive
from .filters import NodeFilter
from .mime_types import GOOGLE_FOLDER
from .models import (
    Node, GoogleDriveFlow, GoogleDriveSync, UserNode, AdditionallyGoogleDriveID, set_watching_for_resource)
from .serializers import (
    NodeSerializer, NoteSerializer, GoogleDriveSyncStep1Serializer, GoogleDriveSyncStep2Serializer,
    GoogleDriveRemoveSyncSerializer
)


logger = logging.getLogger(__name__)


UPDATE_PERIOD_DAYS = 7


def _activity(node, template):
    if node.startup.deleted:
        return
    return Activity.objects.create(target=node, template_id=template, owner=node.uploaded_by)


def create_activity(node):
    return _activity(node, 'doc_create')


def update_activity(node, force_template=None):
    return _activity(
        node,
        force_template or (
            'doc_update' if {'name', 'extension'} & set(node.changed_fields) or node.content_changed else 'doc_move')
    )


def remove_activity(node):
    return _activity(node, 'doc_delete')


class NodeViewSet(viewsets.ModelViewSet):
    queryset = Node.objects.select_related('uploaded_by').order_by('type', 'name')
    serializer_class = NodeSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.JSONParser)
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderOrStartupFounderOrReadOnly]
    pagination_class = None
    filter_backends = (filters.SearchFilter, django_filters.rest_framework.DjangoFilterBackend)
    filter_class = NodeFilter
    search_fields = ('name',)

    def get_queryset(self):
        return self.queryset.prefetch_related(
            Prefetch('user_nodes', queryset=UserNode.objects.filter(user=self.request.user), to_attr='user_node')
        ).filter(startup__in=Startup.objects.available_to_user(self.request.user))

    def get_serializer_class(self):
        if self.action == 'note':
            return NoteSerializer
        return self.serializer_class

    def list(self, request, *args, **kwargs):
        response = super(NodeViewSet, self).list(request, *args, **kwargs)

        user = self.request.user
        # Mark new nodes as non new from now
        queryset = self.filter_queryset(self.get_queryset())
        user_nodes = UserNode.objects.filter(node__in=queryset, user=user)
        user_nodes.filter(is_new=True).update(is_new=False)
        UserNode.objects.bulk_create([
            UserNode(node=node, user=user, is_new=False)
            for node in queryset.exclude(id__in=user_nodes.values('node'))
        ])

        return response

    def perform_create(self, serializer):
        super(NodeViewSet, self).perform_create(serializer)
        create_activity(serializer.instance)

    def perform_update(self, serializer):
        super(NodeViewSet, self).perform_update(serializer)
        update_activity(serializer.instance)

    def perform_destroy(self, instance):
        remove_activity(instance)
        super(NodeViewSet, self).perform_destroy(instance)

    @detail_route(methods=['post'])
    def note(self, request, pk):
        serializer = self.get_serializer(data=request.data)
        serializer.context['parent'] = pk
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()

        self.action = 'retrieve'
        response_serializer = self.get_serializer(instance)
        return response.Response(response_serializer.data)

    @list_route(methods=['get'])
    def statistic(self, request):
        today = now()
        updated_period = (today - timedelta(days=UPDATE_PERIOD_DAYS), today)
        queryset = self.filter_queryset(self.get_queryset()).filter(type=Node.FILE_TYPE)
        data = [
            ('UPDATED THIS WEEK', queryset.filter(updated__range=updated_period).count()),
            ('NEW UPLOADS THIS WEEK', queryset.filter(uploaded__range=updated_period).count()),
        ]
        return response.Response(data=[{'text': k, 'count': v} for k, v in data])

    @list_route(methods=['post', 'delete'], serializer_class=GoogleDriveSyncStep1Serializer)
    def google_sync(self, request):
        if request.method.lower() == 'delete':
            instance = GoogleDriveSync.objects.filter(user=self.request.user).first()
            serializer = GoogleDriveRemoveSyncSerializer(
                instance, data=request.data, context=self.get_serializer_context()
            )
            serializer.is_valid(raise_exception=True)
            serializer.delete()
            return response.Response(
                serializer.data,
                status=status.HTTP_404_NOT_FOUND if not instance else status.HTTP_200_OK
            )

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        gdflow = GoogleDriveFlow.create(request, **serializer.validated_data)
        return response.Response({'redirect': gdflow.authorize_url})

    @list_route(methods=['post'], serializer_class=GoogleDriveSyncStep2Serializer)
    def google_sync_complete(self, request):
        instance = GoogleDriveSync.objects.filter(user=self.request.user).first()
        token_revoke = instance and not instance.ping()

        serializer = self.get_serializer(instance, data=request.data)
        serializer.context.update({
            'flow': GoogleDriveFlow.objects.filter(user=request.user).first(),
            'renew_time_limit_token': token_revoke
        })
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        if not token_revoke:
            logger.warning('New async task to drive sync generated.')
            sync_google_drive.delay([instance.pk])
        return response.Response(serializer.data, status=status.HTTP_201_CREATED)


class NodeHistoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Activity.objects.all().order_by('-created')
    serializer_class = ActivityLogSerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = ActivityFilter

    def get_queryset(self):
        return self.queryset.filter(
            startup__in=Startup.objects.available_to_user(self.request.user),
            content_type=ContentType.objects.get_for_model(Node)
        )


@method_decorator(non_atomic_requests, name='dispatch')
@method_decorator(csrf_exempt, name='dispatch')
class GoogleDriveWebhook(View):
    http_method_names = ['post']

    RESOURCE_HEADER = 'HTTP_X_GOOG_RESOURCE_ID'
    STATE_HEADER = 'HTTP_X_GOOG_RESOURCE_STATE'
    CHANNEL_HEADER = 'HTTP_X_GOOG_CHANNEL_ID'
    CHANGED_HEADER = 'HTTP_X_GOOG_CHANGED'
    CHILDREN_CHANGED = 'children'
    PROPERTIES_CHANGED = 'properties'
    CONTENT_CHANGED = 'content'
    PARENTS_CHANGED = 'parents'

    def post(self, request):
        print 'curl -X POST --header "X-GOOG-CHANGED: {changed}" '\
              '--header "X-GOOG-CHANNEL-ID: {channel}" ' \
              '--header "X-GOOG-RESOURCE-ID: {resource}" ' \
              '--header "X-GOOG-RESOURCE-URI: {uri}" ' \
              '--header "X-GOOG-RESOURCE-STATE: {state}" ' \
              '--header "X-GOOG-MESSAGE-NUMBER: {number}" ' \
              '--header "X-GOOG-CHANNEL-EXPIRATION: {expiration}" http://localhost:8000/webhook/drive'.format(
                    channel=request.META[self.CHANNEL_HEADER],
                    changed=request.META.get(self.CHANGED_HEADER, ''),
                    resource=request.META[self.RESOURCE_HEADER],
                    uri=request.META['HTTP_X_GOOG_RESOURCE_URI'],
                    state=request.META[self.STATE_HEADER],
                    number=request.META['HTTP_X_GOOG_MESSAGE_NUMBER'],
                    expiration=request.META['HTTP_X_GOOG_CHANNEL_EXPIRATION'])
        state = request.META[self.STATE_HEADER]
        # request.META[self.RESOURCE_HEADER] is not used, because it is not google_drive_id!
        if state == 'update':
            self.update_resource(
                request.META[self.CHANNEL_HEADER],
                request.META.get(self.CHANGED_HEADER, '')
            )
        elif state in ('remove', 'trash'):
            self.delete_resource(request.META[self.CHANNEL_HEADER])
        return HttpResponse('Thanks')

    @staticmethod
    def get_user_node(channel_id):
        return UserNode.objects.filter(
            channel=channel_id
        ).select_related('user', 'user__google_drive', 'node').first()

    def delete_resource(self, channel_id):
        user_node = self.get_user_node(channel_id)
        if user_node:
            self.delete_google_resource(user_node.node, user_node.user)

    def update_resource(self, channel_id, changed):
        user_node = self.get_user_node(channel_id)
        changes = filter(lambda x: x, changed.split(','))

        if user_node is None:
            user_node = AdditionallyGoogleDriveID.objects.filter(
                channel=channel_id, is_watchable=True,
            ).select_related('user', 'user__google_drive').first()

            if self.CHILDREN_CHANGED not in changes:
                return

        if user_node is None:
            return

        with redis_mutex(channel_id):
            google_resource = user_node.get_google_resource()
            if google_resource is None:
                return
            google_resource_version = long(google_resource.get('version', 0))

            # children changes not change the resource version
            if self.CHILDREN_CHANGED not in changes and google_resource_version <= user_node.google_drive_version:
                return
            # saving new version to disable recursive watching
            user_node.google_drive_version = google_resource_version
            user_node.save(update_fields=['google_drive_version'])

        for change in changes:
            startup_content_type = ContentType.objects.get_for_model(Startup)

            if change == self.PROPERTIES_CHANGED:
                name, ext, content_type = Node.split_name(google_resource['name'])
                node = user_node.node
                if name != node.name or ext != node.extension:
                    node.name, node.extension = name, ext
                    # update activity creation function
                    update_activity(node)
                    node.save()
            elif change == self.CONTENT_CHANGED:
                user_node.node.content = user_node.get_google_content()
                # update activity creation function
                update_activity(user_node.node, force_template='doc_update')
            elif change == self.PARENTS_CHANGED:
                if isinstance(user_node, UserNode):
                    node_parent = (
                        Node.objects.filter(
                            id__in=UserNode.objects.filter(
                                google_drive_id__in=google_resource['parents'],
                                user=user_node.user,
                            ),
                            startup=user_node.node.startup_id,
                        ).first() or
                        AdditionallyGoogleDriveID.objects.filter(
                            google_drive_id__in=google_resource['parents'],
                            user=user_node.user,
                            content_type=startup_content_type,
                            object_id=user_node.node.startup_id,
                            is_watchable=True,
                        ).first()
                    )
                    if node_parent is None:
                        # This Google Resource moved to non watched directory
                        self.delete_google_resource(user_node.node, user_node.user)
                    else:
                        # moving to startup root folder if node_patent is AdditionallyGoogleDriveID object
                        if isinstance(node_parent, Node):
                            user_node.node.parent = node_parent
                            user_node.parent_google_drive_id = None
                        else:
                            user_node.node.parent = None
                            user_node.parent_google_drive_id = google_resource['parents'][0]
                        user_node.node.save()
                        user_node.save()
                        # move activity creation function
                        update_activity(user_node.node)
                else:
                    user_node.parent_google_drive_id = google_resource['parents'][0]
                    user_node.save(update_fields=['parent_google_drive_id'])

            elif change == self.CHILDREN_CHANGED:
                # Here only new file creation for folders (all moves in parent changes)
                node_parent = None if isinstance(user_node, AdditionallyGoogleDriveID) else user_node.node
                if node_parent is None and user_node.content_object != startup_content_type:
                    continue
                child_node_filter = (
                    Node.objects.filter(parent__isnull=True, startup=user_node.object_id)
                    if node_parent is None else
                    node_parent.childs.all()
                )
                childs = set(i.google_drive_id for i in UserNode.objects.filter(node__in=child_node_filter,
                                                                                user=user_node.user))
                # maybe not change at once
                sleep(10)

                google_childs = set(i['id'] for i in user_node.get_google_children())
                # Remove non exists nodes
                # Children changes in case when moved node !!! So we do not remove nodes on it
                # [self.delete_google_resource(i, user_node.user) for i in
                #  Node.objects.filter(id__in=UserNode.objects.filter(google_drive_id__in=childs-google_childs))]
                # Add new nodes
                [self.save_new_google_resource(
                    google_drive_id,
                    user_node.user,
                    parent_node=node_parent,
                    parent_google_drive_id=user_node.parent_google_drive_id
                 ) for google_drive_id in google_childs-childs]

    @staticmethod
    def delete_google_resource(node, user):
        # setting `uploaded_by` for Delete Node Activity creation
        node.uploaded_by = user
        # delete node activity creation function
        remove_activity(node)
        node.delete()

    def save_new_google_resource(self, google_drive_id, user, parent_node=None, parent_google_drive_id=None):
        # temp user_node to get Google Drive resource content
        user_node = UserNode(google_drive_id=google_drive_id, user=user)
        resource = user_node.get_google_resource()
        if not resource:
            return None
        default_kwargs = dict(
            parent=parent_node,
            uploaded_by=user,
            without_save_drive_sync=True
        )
        if resource['mimeType'] == GOOGLE_FOLDER:
            node = Node.create_dir_mode(name=resource['name'], **default_kwargs)
        else:
            content = user_node.get_google_content()
            name = '{}.{}'.format(resource['name'], Node.get_extension(content.content_type))
            node = Node.create_file_node(content.file, name, **default_kwargs)
        # create node activity creation function
        create_activity(node)
        user_node = UserNode.objects.create(
            node=node,
            user=user,
            google_drive_id=resource['id'],
            google_drive_version=long(resource.get('version')),
            is_new=False,
            parent_google_drive_id=parent_google_drive_id
        )
        set_watching_for_resource(user_node)
        node.drive_sync()
        if node.type == Node.DIRECTORY_TYPE:
            [self.save_new_google_resource(
                    i['id'],
                    user,
                    parent_node=node,
                    # parent_google_drive_id=user_node.google_drive_id
                ) for i in user_node.get_google_children()]
        return user_node

