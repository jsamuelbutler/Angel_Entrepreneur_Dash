from django_filters import NumberFilter, BooleanFilter
from django_filters.rest_framework import FilterSet

from .models import Node


class NodeFilter(FilterSet):
    cohort = NumberFilter(name='startup__cohort')
    top_level = BooleanFilter(name='parent', lookup_expr='isnull')

    class Meta:
        model = Node
        fields = ('cohort', 'startup', 'extension', 'type', 'parent', 'top_level')
