from __future__ import absolute_import, unicode_literals

from time import sleep
from outset import celery_app
from celery.utils.log import get_task_logger


logger = get_task_logger(__name__)


@celery_app.task
def sync_google_drive(google_drive_sync_pks):
    logger.info('Starting sync_google_drive({})...'.format(google_drive_sync_pks))
    from outset.notes_and_docs.models import GoogleDriveSync

    # Model object may not have time to survive, so
    sleep(10)

    for sync in GoogleDriveSync.objects.filter(pk__in=google_drive_sync_pks):
        logger.info('Sync object: {}'.format(str(sync)))
        sync.drive_sync()


@celery_app.task
def sync_google_drive_node(node_pks):
    logger.info('Starting sync_google_drive_node({})...'.format(node_pks))
    from outset.notes_and_docs.models import Node

    # Model object may not have time to survive, so
    sleep(10)

    for node in Node.objects.filter(pk__in=node_pks):
        logger.info('Node object: {}'.format(str(node)))
        node.drive_sync()

