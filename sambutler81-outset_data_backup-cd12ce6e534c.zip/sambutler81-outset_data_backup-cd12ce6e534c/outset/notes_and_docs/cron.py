from __future__ import unicode_literals, absolute_import

from oauth2client.client import HttpAccessTokenRefreshError

from .models import UserNode, AdditionallyGoogleDriveID, GoogleDriveSync, set_watching_for_resource


def _update_google_drive_node(queryset):
    for google_node in queryset:
        try:
            result = set_watching_for_resource(google_node)
        except HttpAccessTokenRefreshError:
            # clear expired Google Drive token
            if hasattr(google_node.user, 'google_drive'):
                google_node.user.google_drive.remove_sync()
            elif isinstance(google_node, UserNode):
                queryset.model.objects.filter(user=google_node.user).update(google_drive_id=None, google_drive_versio=0)
            elif isinstance(google_node, AdditionallyGoogleDriveID):
                queryset.model.objects.filter(user=google_node.user).delete()
            GoogleDriveSync.objects.filter(user=google_node.user).delete()
        else:
            if result:
                google_node.save()


def update_google_watch_channel_expires():
    _update_google_drive_node(
        UserNode.objects.select_related('user', 'user__google_drive').filter(google_drive_id__isnull=False))
    _update_google_drive_node(
        AdditionallyGoogleDriveID.objects.select_related('user', 'user__google_drive').filter(is_watchable=True))
