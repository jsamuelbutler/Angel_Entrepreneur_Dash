from __future__ import unicode_literals

from django.conf import settings as django_setting
from oauth2client.contrib.django_util import GOOGLE_OAUTH2_DEFAULT_SCOPES


# Amazon S3 settings
ACCESS_KEY = getattr(django_setting, 'NAD_S3_ACCESS_KEY', None)
SECRET_KEY = getattr(django_setting, 'NAD_S3_SECRET_KEY', None)
BUCKET_NAME = getattr(django_setting, 'NAD_S3_BUCKET_NAME', 'notes_and_docs')


assert ACCESS_KEY is not None, 'Need add `NAD_S3_ACCESS_KEY` to settings.py.'
assert SECRET_KEY is not None, 'Need add `NAD_S3_SECRET_KEY` to settings.py.'
assert BUCKET_NAME, '`NAD_S3_BUCKET_NAME` can\'t be empty.'


DEFAULT_DIRECTORIES = (
    'Due Diligence',
    'Legal',
    'Financials',
    'Marketing Materials',
    'Partnership Docs',
    'Customer Docs',
    'Pitch Materials',
)


GOOGLE_CLIENT_ID = getattr(django_setting, 'GOOGLE_OAUTH2_CLIENT_ID', None)
GOOGLE_CLIENT_SECRET = getattr(django_setting, 'GOOGLE_OAUTH2_CLIENT_SECRET', None)
GOOGLE_REDIRECT_TO = getattr(django_setting, 'GOOGLE_OAUTH2_REDIRECT_TO', None)
GOOGLE_SCOPES = getattr(django_setting, 'GOOGLE_OAUTH2_SCOPES', GOOGLE_OAUTH2_DEFAULT_SCOPES)

assert GOOGLE_CLIENT_ID is not None, 'Need add `GOOGLE_OAUTH2_CLIENT_ID` to settings.py.'
assert GOOGLE_CLIENT_SECRET is not None, 'Need add `GOOGLE_OAUTH2_CLIENT_SECRET` to settings.py.'
assert GOOGLE_REDIRECT_TO is not None, 'Need add `GOOGLE_OAUTH2_REDIRECT_TO` to settings.py.'

