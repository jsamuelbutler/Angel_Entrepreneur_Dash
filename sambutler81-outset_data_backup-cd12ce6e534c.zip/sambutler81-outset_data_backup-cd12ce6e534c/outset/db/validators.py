from django.core.validators import BaseValidator
from django.utils.translation import ugettext_lazy as _


class MoreValueValidator(BaseValidator):
    message = _('Ensure this value is greater than %(limit_value)s.')
    code = 'more_value'

    def compare(self, a, b):
        return a <= b


class LessValueValidator(BaseValidator):
    message = _('Ensure this value is less than %(limit_value)s.')
    code = 'less_value'

    def compare(self, a, b):
        return a >= b
