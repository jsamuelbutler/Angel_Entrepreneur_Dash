from django.db.models.fields import Field


class IntervalField(Field):
    """
    Fix to user `::interval` as output field
    
    It's not complete work field!
    """

    def db_type(self, connection):
        return 'interval'
