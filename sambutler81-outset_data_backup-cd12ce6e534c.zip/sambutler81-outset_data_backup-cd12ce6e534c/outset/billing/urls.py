from __future__ import unicode_literals

from django.conf.urls import url
from rest_framework import routers

from . import views

router = routers.SimpleRouter()
router.register(r'plans', views.PlanViewSet)


urlpatterns = [
    url(r'^webhook/stripe$', views.stripe_webhook),
]


