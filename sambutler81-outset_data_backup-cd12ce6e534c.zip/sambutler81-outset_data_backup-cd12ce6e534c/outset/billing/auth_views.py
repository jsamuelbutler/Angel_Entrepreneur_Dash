from __future__ import unicode_literals

from django.conf.urls import url
from django.contrib.auth import views

from .forms import APIAuthenticationForm

template_name = 'rest_framework/login.html'

app_name = 'rest_framework'
urlpatterns = [
    url(
        r'^login/$',
        views.login,
        {
            'template_name': template_name,
            'authentication_form': APIAuthenticationForm,
            'redirect_authenticated_user': True
        },
        name='login'
    ),
    url(r'^logout/$', views.logout, {'template_name': template_name}, name='logout'),
]
