
# Plans
HOBBY_PLAN = 'hobby'
PROFESSIONAL_PLAN = 'pro'

PLANS = (
    HOBBY_PLAN,
    PROFESSIONAL_PLAN
)

# Options
COMPANY_COUNT_OPTION = 'companies'
API_ACCESS_OPTION = 'api-access'
DATA_INTEGRATION_OPTION = 'data-integration'
GOOGLE_DRIVE_SYNC_OPTION = 'google-drive-sync'
