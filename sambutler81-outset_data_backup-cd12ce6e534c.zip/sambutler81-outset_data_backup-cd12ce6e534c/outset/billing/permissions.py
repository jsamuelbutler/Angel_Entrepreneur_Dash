from rest_framework.permissions import IsAuthenticated

from outset.accounts.jsontoken.authentication import JsonTokenAuthentication

from .utils import user_has_api_access


class APIAccessPermission(IsAuthenticated):
    def has_permission(self, request, view):
        return (
            super(APIAccessPermission, self).has_permission(request, view) and
            (isinstance(request.successful_authenticator, JsonTokenAuthentication) or user_has_api_access(request.user))
        )
