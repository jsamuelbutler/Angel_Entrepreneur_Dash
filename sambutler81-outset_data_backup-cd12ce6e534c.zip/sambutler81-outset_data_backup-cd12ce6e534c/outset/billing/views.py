from __future__ import unicode_literals

import json

from django.db.models import Prefetch
from django.http import HttpResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from rest_framework import generics, exceptions, status, viewsets
from rest_framework.settings import api_settings

from outset.accounts.models import User
from outset.accounts.permissions import IsAcceleratorFounderSelfOrReadOnly

from .models import AvailableOption, Cash, Plan
from .serializers import CashSerializer, PlanSerializer
from .utils import stripe, get_stripe, clean_stripe, is_deleted_stripe


class PlanViewSet(viewsets.ReadOnlyModelViewSet):
    """
    list:
        View list of available tariff plans
    """
    queryset = Plan.objects.prefetch_related(
        Prefetch(
            'available_options',
            queryset=AvailableOption.objects.filter(
                    option__is_additional=False, option__is_hidden=False,
                ).select_related('option').order_by('position'),
            to_attr='non_additional_available_options'
        ),
        Prefetch(
            'available_options',
            queryset=AvailableOption.objects.filter(
                    option__is_additional=True, option__is_hidden=False,
                ).select_related('option').order_by('position'),
            to_attr='additional_available_options'
        )
    ).order_by('monthly_pay', 'annually_pay').all()
    serializer_class = PlanSerializer


class CashAPIView(generics.RetrieveUpdateAPIView):
    """
    Cash API end-point allowed get information about current plan and change it
    """
    queryset = Cash.objects.none()
    serializer_class = CashSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderSelfOrReadOnly]
    pagination_class = None

    def get_object(self):
        user = self.request.user

        if user.role == User.WATCHER_ROLE:
            raise exceptions.NotFound('Watchers user does not have cash')

        return user.cash or Cash.create_for_user(user)


def get_plan(subscription_id, **kwargs):
    try:
        plan = Plan.objects.get(**kwargs)
    except Plan.DoesNotExist:
        plan = None
    except Plan.MultipleObjectsReturned:
        # select best plan by pay and others are deleted
        plans = list(Plan.objects.filter(**kwargs))
        plan = max(plans)
        other_plans = set(plans) - {plan}
        clean_stripe(
            stripe.SubscriptionItem,
            subscription=subscription_id,
            filter_func=lambda a: a.plan.id in other_plans
        )
    return plan


@require_POST
@csrf_exempt
def stripe_webhook(request):
    event_json = json.loads(request.body)
    # For disable accepting fake webhook requests check it by Stripe API
    event = get_stripe(stripe.Event, event_json['id'])
    if is_deleted_stripe(event):
        return HttpResponse(status=status.HTTP_200_OK)

    if event.type == 'customer.subscription.deleted':
        # Occurs whenever a customer ends their subscription.
        try:
            cash = Cash.objects.get(subscription_id=event.data.object.id)
        except Cash.DoesNotExist:
            pass
        else:
            # Because there is not this subscription from now user is blocked
            cash.subscription_id = None
            cash.is_blocked = True
            cash.save(update_fields=['subscription_id', 'is_blocked'])
    elif event.type == 'customer.deleted':
        # Occurs whenever a coupon is deleted.
        Cash.objects.filter(customer_id=event.data.object.id).delete()
    elif event.type == 'customer.source.created':
        # Occurs whenever a new source is created for the customer.
        Cash.objects.filter(customer_id=event.data.object.customer, is_with_source=False).update(is_with_source=True)
    elif event.type == 'customer.source.deleted':
        # Occurs whenever a source is removed from a customer.
        customer = get_stripe(stripe.Customer, event.data.object.customer)
        if not is_deleted_stripe(customer) and not customer.sources.data:
            Cash.objects.filter(customer_id=customer.id, is_with_source=True).update(is_with_source=False)
    elif event.type == 'invoice.payment_failed':
        # Occurs whenever an invoice attempts to be paid, and the payment
        # fails. This can occur either due to a declined payment, or because
        # the customer has no active card. A particular case of note is that
        # if a customer with no active card reaches the end of its free trial,
        # an invoice.payment_failed notification will occur.
        if event.data.object.subscription:
            Cash.objects.filter(
                customer_id=event.data.object.customer,
                subscription_id=event.data.object.subscription,
                is_blocked=False,
            ).update(is_blocked=True)
    elif event.type == 'invoice.payment_succeeded':
        # Occurs whenever an invoice attempts to be paid, and the payment
        # succeeds.
        if event.data.object.subscription:
            Cash.objects.filter(
                customer_id=event.data.object.customer,
                subscription_id=event.data.object.subscription,
                is_blocked=True,
            ).update(is_blocked=False)

    return HttpResponse(status=status.HTTP_200_OK)
