from __future__ import unicode_literals, print_function

import uuid

from django.db import models
from django.db.models import Q, Sum, signals
from django.dispatch import receiver
from django.utils.text import slugify
from django.utils.translation import ugettext_lazy as _
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel
from safedelete.signals import post_softdelete

from outset.startups.models import Startup, StartupFinicity, StartupStripe, StartupXero

from .consts import HOBBY_PLAN
from .tasks import update_subscription_task
from .utils import (
    Intervals, stripe, TRIAL_PERIOD_DAYS, is_deleted_stripe,
    get_stripe, delete_stripe, clean_stripe
)


USE_ANNUALLY_PLANS = False


def salted_id(name):
    return slugify('{} {}'.format(name, uuid.uuid4().get_hex()[:4]))


def get_unique_plan_id(base_id):
    """
    Generate unique plan_id for new or modified option plan
    :param base_id: base part for id
    :return: unique stripe plan id
    :rtype: string
    """
    plan = True
    plan_id = slugify(base_id)
    while plan is not None:
        plan = get_stripe(stripe.Plan, plan_id)
        if plan:
            plan_id = salted_id(base_id)
    return plan_id


def update_option_subscriptions(old_id, new_id, block=20, subscription=None):
    """
    Update exist Stripe subscription items with plan `old_id` to plan `new_id`
    :param old_id: stripe plan id
    :param new_id: stripe plan id
    :param block: reading package size
    :param subscription: stripe subscription id for selecting its subscription items
    """
    has_next = True
    last_element = None

    while has_next:
        stripe_list = (
            stripe.SubscriptionItem.list(subscription=subscription, limit=block, starting_after=last_element)
            if subscription is not None else
            stripe.Subscription.list(limit=block, starting_after=last_element)
        )
        has_next = stripe_list.has_more
        if stripe_list.data:
            last_element = stripe_list.data[-1].id

            for sub in stripe_list.data:
                if subscription is None:
                    update_option_subscriptions(old_id, new_id, subscription=sub)
                elif sub.plan.id == old_id:
                    sub.plan = new_id
                    sub.save()


def get_option_subscription(subscription, plan, block=20):
    """
    Get subscription item for subscription
    :param subscription: stripe subscription id
    :param plan: plan id for stripe subscription item
    :param block: reading package size
    :return: stripe subscription item or None
    """
    has_next = True
    last_element = None

    while has_next:
        stripe_list = stripe.SubscriptionItem.list(subscription=subscription, limit=block, starting_after=last_element)
        has_next = stripe_list.has_more
        if stripe_list.data:
            last_element = stripe_list.data[-1].id

            for sub in stripe_list.data:
                if sub.plan.id == plan:
                    return sub

    return None


class StripePlan(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    id = models.CharField(max_length=30, primary_key=True)
    monthly_pay = models.PositiveIntegerField(help_text=_('in cents'), default=0)
    annually_pay = models.PositiveIntegerField(help_text=_('in_cents'), default=0)
    monthly_id = models.CharField(max_length=80, editable=False, null=True, blank=True)
    annually_id = models.CharField(max_length=80, editable=False, null=True, blank=True)

    class Meta:
        abstract = True

    @property
    def is_sync(self):
        return bool(self.monthly_id) and (not USE_ANNUALLY_PLANS or bool(self.annually_id))


class Option(StripePlan):
    verbose_name = models.CharField(max_length=255)
    verbose_name_plural = models.CharField(max_length=255, help_text=_('for more one value'), null=True, blank=True)
    verbose_name_infinity = models.CharField(max_length=255, help_text=_('for infinity value'), null=True, blank=True)
    description = models.TextField(
        help_text=_('descriptions separated by \';\''),
        null=True,
        blank=True
    )
    description_plural = models.TextField(
        help_text=_('descriptions separated by \';\' for more one value'),
        null=True,
        blank=True
    )
    is_additional = models.BooleanField(default=False)
    is_hidden = models.BooleanField(default=False, help_text=_('option hidden from billing plan.'))

    def __unicode__(self):
        return _('\'{}\'{} option').format(self.id, _(' additional') if self.is_additional else '')

    def save(self, *args, **kwargs):
        if self.monthly_pay and not self.annually_pay:
            self.annually_pay = 12 * self.monthly_pay
        return super(Option, self).save(*args, **kwargs)


class Plan(StripePlan):
    name = models.CharField(max_length=90)

    class Meta:
        ordering = ('monthly_pay', 'annually_pay')

    def __unicode__(self):
        return _('\'{}\' plan').format(self.id)

    def __gt__(self, other):
        if not isinstance(other, Plan):
            return False
        return self.monthly_pay > other.monthly_pay and self.annually_pay > other.monthly_pay

    def __eq__(self, other):
        if not isinstance(other, Plan):
            return False
        return self.monthly_pay == other.monthly_pay and self.annually_pay == other.monthly_pay

    def __ne__(self, other):
        return not self.__eq__(other)

    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def __lt__(self, other):
        return not self.__ge__(other)

    def __le__(self, other):
        return not self.__gt__(other)


class AvailableOption(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    plan = models.ForeignKey(Plan, on_delete=models.CASCADE, related_name='available_options')
    option = models.ForeignKey(Option, on_delete=models.CASCADE, related_name='available_options')
    value = models.PositiveIntegerField(null=True, blank=True)
    position = models.PositiveIntegerField(default=1)

    class Meta:
        index_together = ('plan', 'option', 'deleted'),
        ordering = ('position',)

    def __unicode__(self):
        return _('{} is available for {}').format(self.option, self.plan)


class Cash(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    customer_id = models.CharField(max_length=20, editable=False, help_text=_('customer stripe id'), unique=True)
    subscription_id = models.CharField(
        max_length=30, editable=False, help_text=_('customer subscription stripe id'), null=True, blank=True
    )
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE, default=HOBBY_PLAN, related_name='+')
    accepted_options = models.ManyToManyField(Option, blank=True)
    is_annually = models.BooleanField(default=False)
    is_blocked = models.BooleanField(default=False, help_text=_('Blocking not paid user.'))
    is_with_source = models.BooleanField(default=False, help_text=_('User has Stripe source for pay.'))

    # Options to update from `Cash.check_option()`
    updated_options = []

    def __unicode__(self):
        return '{} - {} ({})'.format(
            self.customer_id, self.plan_id, _('blocked') if self.is_blocked else _('active')
        )

    @property
    def current_stripe_plan(self):
        if not USE_ANNUALLY_PLANS:
            return self.plan.monthly_id
        return self.plan.annually_id if self.is_annually else self.plan.monthly_id

    @classmethod
    def create_for_user(cls, user, using=None):
        from outset.accelerators.models import Cohort
        from outset.accounts.models import User
        from outset.startups.models import Startup

        assert user.role != User.WATCHER_ROLE, 'Watchers can not have cash'

        if user.role == User.FOUNDER_ROLE and (user.accelerator_id is not None or user.startup_id is None):
            founder_user = user
        else:
            try:
                founder_user = User.objects.using(using).filter(
                    (
                        Q(accelerator=user.accelerator_id)
                        if user.accelerator_id else
                        Q(accelerator__in=Cohort.objects.filter(startups=user.startup_id).values('accelerator'))
                    ),
                    role=User.FOUNDER_ROLE,
                    accelerator__isnull=False
                )[0]
            except IndexError:
                raise User.DoesNotExist()

        if founder_user.cash_id:
            user.cash = founder_user.cash
            if user.pk:
                user.save(update_fields=['cash'])
            return founder_user.cash

        customer = stripe.Customer.create(email=founder_user.email)
        instance = cls.objects.using(using).create(customer_id=customer.id)
        user.cash = instance
        User.objects.using(using).filter(
            Q(accelerator_id=founder_user.accelerator_id, accelerator__isnull=False) |
            Q(startup__in=Startup.objects.filter(cohort__accelerator_id=founder_user.accelerator_id).values('id'))
        ).update(cash=instance)
        return instance

    def paid_startups(self, is_companies=None, with_api_integration=None, using=None):
        q = Q(
            cohort__start_date__isnull=False,
            cohort__end_date__isnull=False,
        )
        api_q = Q(stripe__isnull=False) | Q(finicity__isnull=False) | Q(xero__isnull=False)
        return Startup.objects.using(using).filter(
            ~q if is_companies else q if is_companies is not None else Q(),
            api_q if with_api_integration else ~api_q if with_api_integration is not None else Q(),
            cohort__accelerator__in=self.users.filter(accelerator__isnull=False).values('accelerator_id')
        ).count()

    def move_to_plan(self, plan, annually=False, token=None):
        if isinstance(plan, (str, unicode)):
            plan = Plan.objects.get(id=plan)

        annually = USE_ANNUALLY_PLANS and annually

        # updating source if sending token
        if token is not None:
            customer = get_stripe(stripe.Customer, self.customer_id)
            customer.source = token
            customer.save()
            self.is_with_source = True
            self.save(update_fields=['is_with_source'])

        if self.plan_id == plan.id and self.is_annually == annually:
            return

        if not plan.is_sync:
            plan.save()

        self.plan = plan
        self.is_annually = annually
        self.save(update_fields=['plan', 'is_annually'])

        update_subscription_task(self.pk)

    def check_option(self, option_id, option_value=None, using=None):
        """
        Checking option with `option_id` and increase/decrease quantity for subscription by it.

        If limit for used plan is reached and user accept additional option then add or modify
        subscription item to user else `False` returns.

        `option_value = None` means that it option common available (without value or unlimited)

        Base principe is that default is does not allow option.

        :param option_id: local option id of checking option
        :param option_value: new option value changed to
        :param using: db alias names
        :return: True if it's possible else False
        :rtype: boolean
        """

        if self.is_blocked:
            return False

        options = self.plan.available_options.using(using).select_related('option').filter(
            Q(option__is_additional=False) | Q(option__in=self.accepted_options.all()),
            option__in=(option_id,)
        )
        has_unlimited = options.filter(value__isnull=True).exists()
        max_option_value = options.aggregate(Sum('value'))['value__sum']

        return (
            has_unlimited or option_value is None and options.exists() or max_option_value >= option_value is not None
        )


def _update_option(instance, stripe_field, stripe_pay_field, plan_id, name, interval):
    stripe_id = getattr(instance, stripe_field)
    stripe_pay = getattr(instance, stripe_pay_field)
    plan = get_stripe(stripe.Plan, stripe_id)
    if is_deleted_stripe(plan):
        plan = None

    if instance.is_additional or instance.monthly_pay or instance.annually_pay:
        if plan is None or plan.amount != stripe_pay:
            plan = stripe.Plan.create(
                id=get_unique_plan_id(plan_id),
                name=name,
                amount=stripe_pay,
                currency='usd',
                interval=interval,
                interval_count=1,
            )

        if stripe_id:
            update_option_subscriptions(stripe_id, plan.id)
            delete_stripe(stripe.Plan, stripe_id)
        setattr(instance, stripe_field, plan.id)
    elif plan is not None:
        plan.delete()


@receiver(signals.pre_save, sender=Option)
def add_stripe_option(sender, instance, **kwargs):
    annually_base = '{} (annually)'
    base_name = '\'{}\' additional option'.format(instance.id)
    if instance.monthly_pay and not instance.annually_pay:
        instance.annually_pay = 12 * instance.monthly_pay
    _update_option(instance, 'monthly_id', 'monthly_pay', instance.id, base_name, Intervals.MONTH)
    _update_option(
        instance,
        'annually_id',
        'annually_pay',
        annually_base.format(instance.id),
        annually_base.format(base_name),
        Intervals.YEAR
    )


@receiver(post_softdelete, sender=Option)
def softdelete_stripe_option(sender, instance, **kwargs):
    delete_stripe(stripe.Plan, instance.monthly_id)
    if USE_ANNUALLY_PLANS:
        delete_stripe(stripe.Plan, instance.annually_id)


@receiver(signals.pre_delete, sender=Option)
def delete_stripe_option(sender, instance, **kwargs):
    delete_stripe(stripe.Plan, instance.monthly_id)
    if USE_ANNUALLY_PLANS:
        delete_stripe(stripe.Plan, instance.annually_id)


def _update_plan(instance, stripe_field, stripe_pay_field, plan_id, name, interval):
    stripe_id = getattr(instance, stripe_field)
    stripe_pay = getattr(instance, stripe_pay_field)

    plan = get_stripe(stripe.Plan, stripe_id)
    if is_deleted_stripe(plan) or plan.amount != stripe_pay:
        plan = stripe.Plan.create(
            id=get_unique_plan_id(plan_id),
            name=name,
            amount=stripe_pay,
            currency='usd',
            interval=interval,
            interval_count=1,
            trial_period_days=TRIAL_PERIOD_DAYS,
        )
        if stripe_id:
            update_option_subscriptions(stripe_id, plan.id)
            delete_stripe(stripe.Plan, stripe_id)
        setattr(instance, stripe_field, plan.id)
    elif plan.name != instance.name:
        plan.name = name
        plan.save()


@receiver(signals.pre_save, sender=Plan)
def update_stripe_plan(sender, instance, **kwargs):
    _update_plan(instance, 'monthly_id', 'monthly_pay', instance.id, instance.name, Intervals.MONTH)
    if USE_ANNUALLY_PLANS:
        annually_base = '{} (annually)'
        _update_plan(
            instance,
            'annually_id',
            'annually_pay',
            annually_base.format(instance.id),
            annually_base.format(instance.name),
            Intervals.YEAR
        )


@receiver(post_softdelete, sender=Plan)
def softdelete_stripe_plan(sender, instance, **kwargs):
    delete_stripe(stripe.Plan, instance.monthly_id)
    if USE_ANNUALLY_PLANS:
        delete_stripe(stripe.Plan, instance.annually_id)


@receiver(signals.pre_delete, sender=Plan)
def delete_stripe_plan(sender, instance, **kwargs):
    delete_stripe(stripe.Plan, instance.monthly_id)
    if USE_ANNUALLY_PLANS:
        delete_stripe(stripe.Plan, instance.annually_id)


def update_subscription(cash):
    plan = cash.plan

    # if Stripe Plan ids does not exist create them.
    if not plan.is_sync:
        # Renew stripe plans for `plan`
        plan.save()

    stripe_plan = cash.current_stripe_plan
    company_count = cash.paid_startups()

    subscription = (
        get_stripe(stripe.Subscription, cash.subscription_id)
        if cash.subscription_id else
        None
    )

    if subscription:
        if subscription.plan != stripe_plan or subscription.quantity != company_count:
            subscription.plan = stripe_plan
            subscription.quantity = company_count
            # subscription_item.prorate = True # immediately pay
            subscription.save()
    else:
        subscription = stripe.Subscription.create(customer=cash.customer_id, plan=stripe_plan, quantity=company_count)
        cash.subscription_id = subscription.id
        cash.save(update_fields=['subscription_id'])


@receiver(signals.post_save, sender=Cash)
def add_default_subscription(sender, instance, created=True, using=None, **kwargs):
    if created:
        update_subscription_task.delay(instance.pk)


@receiver(signals.pre_delete, sender=Cash)
@receiver(post_softdelete, sender=Cash)
def softdelete_stripe_customer(sender, instance, using=None, **kwargs):
    delete_stripe(stripe.Customer, instance.customer_id)
    instance.users.using(using).filter(cash__isnull=False).update(cash=None)


@receiver(signals.post_save, sender=Startup)
def update_startup_option(sender, instance, created=True, using=None, **kwargs):
    if created:
        cohort = instance.cohort
        try:
            user = cohort.accelerator.users.using(using).all()[0]
        except IndexError:
            pass
        else:
            if user.cash_id:
                update_subscription_task.delay(user.cash_id)


@receiver(signals.post_delete, sender=Startup)
@receiver(post_softdelete, sender=Startup)
def remove_startup_option(sender, instance, using, **kwargs):
    cohort = instance.cohort
    try:
        user = cohort.accelerator.users.all()[0]
    except IndexError:
        pass
    else:
        if user.cash_id:
            update_subscription_task.delay(user.cash_id)


@receiver(signals.post_save, sender='accounts.User')
def create_cash_for_user(sender, instance, created=True, using=None, update_fields=None, **kwargs):
    ref_fields = {'role', 'accelerator_id', 'startup_id'}
    if instance.role and (instance.accelerator_id or instance.startup_id) and (
            created or
            set(instance.changed_fields) & ref_fields and (update_fields is None or set(update_fields) & ref_fields)):
        if instance.cash_id:
            sender.objects.using(using).filter(id=instance.id).update(cash=None)
        try:
            Cash.create_for_user(instance, using=using)
        except sender.DoesNotExist:
            pass
