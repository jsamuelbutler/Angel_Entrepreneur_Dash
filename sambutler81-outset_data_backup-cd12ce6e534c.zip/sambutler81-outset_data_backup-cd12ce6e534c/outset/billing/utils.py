import stripe

from django.conf import settings

from .consts import API_ACCESS_OPTION


SETTING_PRIVATE_KEY = 'PRIVATE_STRIPE_API_KEY'
SETTING_PUBLIC_KEY = 'PUBLIC_STRIPE_API_KEY'
TRIAL_PERIOD_DAYS = getattr(settings, 'STRIPE_TRIAL_PERIOD_DAYS', 14)

if not hasattr(settings, SETTING_PRIVATE_KEY):
    raise RuntimeError(
        'Need add \'{}\' in settings.py to allow communicate with Stripe API.'.format(SETTING_PRIVATE_KEY)
    )
PRIVATE_KEY = getattr(settings, SETTING_PRIVATE_KEY)

if not hasattr(settings, SETTING_PUBLIC_KEY):
    raise RuntimeError(
        'Need add \'{}\' in settings.py to allow communicate with Stripe API.'.format(SETTING_PUBLIC_KEY)
    )
PUBLIC_KEY = getattr(settings, SETTING_PUBLIC_KEY)


stripe.api_key = PRIVATE_KEY


class Intervals():
    DAY = 'day'
    WEEK = 'week'
    MONTH = 'month'
    YEAR = 'year'


def user_has_api_access(user):
    return (
        user.is_superuser or
        user.is_staff or
        user.check_option(API_ACCESS_OPTION) and user.account_type in (1, 2)
    )


def is_deleted_stripe(stripe_element):
    return stripe_element is None or hasattr(stripe_element, 'deleted') and stripe_element.deleted


def get_stripe(stripe_model, id, **kwargs):
    try:
        element = stripe_model.retrieve(id, **kwargs)
    except stripe.error.InvalidRequestError:
        return
    return element


def delete_stripe(*args, **kwargs):
    element = get_stripe(*args, **kwargs)
    if not is_deleted_stripe(element):
        element.delete()


def clean_stripe(stripe_model, block=20, filter_func=None, exclude_func=None, **kwargs):
    filter_func = filter_func or (lambda a: True)
    exclude_func = exclude_func or (lambda a: False)
    has_next = True
    while has_next:
        stripe_list = stripe_model.list(limit=block, **kwargs)
        has_next = stripe_list.has_more
        if stripe_list.data:
            [i.delete() for i in stripe_list.data if filter_func(i) and not exclude_func(i)]
