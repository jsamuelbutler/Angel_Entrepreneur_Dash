from __future__ import absolute_import

from outset import celery_app
from celery.utils.log import get_task_logger
from time import sleep


logger = get_task_logger(__name__)


@celery_app.task
def update_subscription_task(pk):
    logger.info('Starting update_subscription_task({})...'.format(pk))

    sleep(5)

    from outset.billing.models import Cash, update_subscription

    cash = Cash.objects.all_with_deleted().filter(pk=pk).first()
    if cash:
        logger.info('Update subscription: {}'.format(cash))
        update_subscription(cash)
