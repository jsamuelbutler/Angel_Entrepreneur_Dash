from django import forms
from django.contrib.auth.forms import AuthenticationForm

from .utils import user_has_api_access


class APIAuthenticationForm(AuthenticationForm):
    def clean(self):
        super(APIAuthenticationForm, self).clean()

        if self.user_cache is not None and not user_has_api_access(self.user_cache):
            raise forms.ValidationError('Does not have API access permission.')

        return self.cleaned_data
