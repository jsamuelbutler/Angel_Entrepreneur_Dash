from rest_framework import serializers

from outset.accounts.serializers import AuthTokenResponseIfPostMixin

from .models import AvailableOption, Cash, Plan
from .utils import stripe


class AvailableOptionSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source='option.id')
    name = serializers.SerializerMethodField(method_name='get_option_name')
    description = serializers.SerializerMethodField(method_name='get_option_description')

    @staticmethod
    def get_option_name(obj):
        option = obj.option
        if obj.value in (None, 0) and option.verbose_name_infinity:
            return option.verbose_name_infinity
        elif obj.value > 1 and option.verbose_name_plural:
            return option.verbose_name_plural.format(obj.value)
        return option.verbose_name

    @staticmethod
    def get_option_description(obj):
        option = obj.option
        description = (
            option.description
            if obj.value in (None, 0, 1) or not option.description_plural else
            option.description_plural.format(obj.value)
        )
        return [i.strip() for i in description.split(';')] if description else None

    class Meta:
        model = AvailableOption
        fields = ('id', 'name', 'description')


class PlanSerializer(serializers.ModelSerializer):
    options = AvailableOptionSerializer(source='non_additional_available_options', many=True, read_only=True)

    class Meta:
        model = Plan
        fields = ('id', 'name', 'monthly_pay', 'options')


class CashSerializer(AuthTokenResponseIfPostMixin, serializers.ModelSerializer):
    plan = PlanSerializer(read_only=True)
    new_plan = serializers.CharField(write_only=True)
    token = serializers.CharField(write_only=True, required=False, allow_null=True, allow_blank=True)

    class Meta:
        model = Cash
        fields = ('plan', 'new_plan', 'is_blocked', 'token', 'is_with_source')
        read_only_fields = ('is_blocked', 'is_with_source')

    def get_user(self):
        return self.context['request'].user if 'request' in self.context else None

    @staticmethod
    def validate_new_plan(value):
        try:
            plan = Plan.objects.get(pk=value)
        except Plan.DoesNotExist:
            raise serializers.ValidationError('Such tariff plan isn\'t found.')
        return plan

    @staticmethod
    def validate_token(value):
        if not value:
            return None
        try:
            token = stripe.Token.retrieve(value)
        except stripe.error.InvalidRequestError:
            raise serializers.ValidationError('Invalid token.')
        if token.used:
            raise serializers.ValidationError('You cannot use a Stripe token more than once: {}.'.format(value))
        return value

    def validate(self, validated_data):
        if not self.instance.is_with_source and not validated_data.get('token'):
            raise serializers.ValidationError('Need `token` before change plan.')
        return validated_data

    def update(self, instance, validated_data):
        instance.move_to_plan(
            validated_data.get('new_plan', instance.plan),
            annually=validated_data.get('is_annually', False),
            token=validated_data.get('token')
        )
        return super(CashSerializer, self).update(instance, validated_data)


