from django import template

from outset.billing.utils import PUBLIC_KEY


register = template.Library()


@register.simple_tag
def public_stripe_key():
    return PUBLIC_KEY
