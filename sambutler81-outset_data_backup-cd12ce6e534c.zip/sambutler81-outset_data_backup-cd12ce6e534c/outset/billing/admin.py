from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from .models import AvailableOption, Cash, Option, Plan


class AvailableOptionPlanInline(admin.TabularInline):
    fields = ('option', 'value', 'position')
    ordering = ('position', 'option__is_additional')
    model = AvailableOption
    extra = 1


class AvailableOptionOptionInline(admin.TabularInline):
    fields = ('plan', 'value', 'position')
    model = AvailableOption
    extra = 1


class AcceptedOptionInline(admin.TabularInline):
    model = Cash.accepted_options.through
    extra = 1


@admin.register(Plan)
class PlanAdmin(admin.ModelAdmin):
    inlines = (AvailableOptionPlanInline,)
    list_display = ('__unicode__', 'name', 'monthly_pay', 'monthly_id', 'annually_pay', 'annually_id')
    list_editable = ('monthly_pay', 'annually_pay')
    # readonly_fields = ('id', 'monthly_id', 'annually_id')
    readonly_fields = ('monthly_id', 'annually_id')
    search_fields = ('id',)
    fieldsets = (
        (None, {'fields': ('id', 'name')}),
        (_('Monthly'), {'fields': ('monthly_id', 'monthly_pay')}),
        (_('Annually'), {'fields': ('annually_id', 'annually_pay')}),
    )


@admin.register(Option)
class OptionAdmin(admin.ModelAdmin):
    inlines = (AvailableOptionOptionInline,)
    list_display = ('__unicode__', 'verbose_name', 'monthly_pay', 'monthly_id', 'annually_id', 'is_additional')
    list_filter = ('is_additional',)
    ordering = ('id', 'verbose_name')
    # readonly_fields = ('id', 'stripe_id')
    readonly_fields = ('monthly_id', 'annually_id')
    search_fields = ('id', 'verbose_name', 'verbose_name_plural', 'verbose_name_infinity')
    fieldsets = (
        (None, {'fields': ('id', 'is_additional')}),
        (_('Monthly'), {'fields': ('monthly_id', 'monthly_pay')}),
        (_('Annually'), {'fields': ('annually_id', 'annually_pay')}),
        (_('Description'), {
            'fields': (
                'verbose_name', 'verbose_name_plural', 'verbose_name_infinity', 'description', 'description_plural'
            ),
            'classes': ('wide',)
        }),
    )


@admin.register(Cash)
class CashAdmin(admin.ModelAdmin):
    inlines = (AcceptedOptionInline,)
    list_display = ('customer_id', 'subscription_id', 'plan', 'is_blocked')
    list_editable = ('is_blocked',)
    ordering = ('customer_id', 'subscription_id')
    readonly_fields = ('customer_id', 'subscription_id')
    search_fields = ('customer_id', 'subscription_id')
    fieldsets = (
        (None, {'fields': ('customer_id', 'is_blocked')}),
        (_('Plan'), {'fields': ('plan', 'subscription_id')})
    )
