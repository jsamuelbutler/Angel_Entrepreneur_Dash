from django.conf import settings
from rest_framework import serializers

from outset.startups.serializers import TinyStartupSerializer

from .models import Activity


class ActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        fields = ('html', 'cls', 'created', 'startup')
        extra_kwargs = {'created': {'format': settings.DATE_FORMAT}}


class ActivityLogSerializer(serializers.ModelSerializer):
    html = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Activity
        fields = ('html', 'cls')
        read_only_fields = ('cls',)

    @staticmethod
    def get_html(obj):
        return '{} on "{}"'.format(obj.html, obj.created.strftime('%m-%d-%Y'))
