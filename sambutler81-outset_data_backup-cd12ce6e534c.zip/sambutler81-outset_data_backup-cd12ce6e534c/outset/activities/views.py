from __future__ import unicode_literals

from datetime import timedelta

import django_filters
from django.utils.timezone import now
from rest_framework.decorators import list_route
from rest_framework import filters, mixins, pagination, response, viewsets

from outset.kpis.models import KPI, KPIValue
from outset.notes_and_docs.models import Node
from outset.startups.models import Startup
from outset.todos.models import ToDo
from outset.todos.utils import UPCOMING_PERIOD_DAYS

from .filters import ActivityFilter
from .models import Activity
from .serializers import ActivitySerializer


UPDATE_PERIOD_DAYS = 7


class ActivitiesPaginator(pagination.PageNumberPagination):
    page_size = 20


class ActivitiesViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Activity.objects.all().select_related('template')
    serializer_class = ActivitySerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend, filters.SearchFilter)
    filter_class = ActivityFilter
    search_fields = ('html',)
    pagination_class = ActivitiesPaginator

    def get_queryset(self):
        return self.queryset.filter(startup__in=Startup.objects.available_to_user(self.request.user))

    @list_route(methods=['get'])
    def statistic(self, request):
        today = now().date()
        updated_period = (today - timedelta(days=UPDATE_PERIOD_DAYS), today)
        queryset = self.filter_queryset(self.get_queryset())
        startups = queryset.values('startup')
        kpi_values = KPIValue.objects.filter(created__range=updated_period).values('kpi_id')
        todos = ToDo.objects.filter(startup__in=startups, is_complete=False)
        docs = Node.objects.filter(startup__in=startups, type=Node.FILE_TYPE)

        data = [
            ('UPDATED DOCUMENTS', docs.filter(uploaded__range=updated_period).count()),
            ('UPLOADED DOCUMENTS', docs.count()),
            ('KPIs UPDATED', KPI.objects.filter(startup__in=startups, id__in=kpi_values).count()),
            ('OVERDUE TO-DOs', todos.filter(due_date__lt=today).count()),
            ('UPCOMING TO-DOs', todos.filter(
                due_date__range=(today, today + timedelta(days=UPCOMING_PERIOD_DAYS))).count()
             ),
            ('INVESTOR UPDATES', (
                KPI.objects.filter(
                    startup__in=startups, base__created_by__accelerator__isnull=False
                ).order_by('id').distinct('id').count() +
                Node.objects.filter(
                    startup__in=startups, uploaded_by__accelerator__isnull=False
                ).order_by('id').distinct('id').count()
             ))
        ]
        return response.Response(data=[{'text': k, 'count': v} for k, v in data])

