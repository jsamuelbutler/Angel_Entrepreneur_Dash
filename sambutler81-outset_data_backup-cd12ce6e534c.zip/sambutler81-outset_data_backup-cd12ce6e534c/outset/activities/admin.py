from django.contrib import admin

from .models import Activity, Template


@admin.register(Template)
class TemplateAdmin(admin.ModelAdmin):
    list_display = ('id', 'status', 'html')


@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ('__unicode__', 'owner', 'startup', 'created', 'html')
    ordering = ('-created',)

    def save_model(self, request, obj, form, change):
        obj.created_by = request.user
        super(ActivityAdmin, self).save_model(request, obj, form, change)

