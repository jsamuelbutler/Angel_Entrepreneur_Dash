from __future__ import unicode_literals

from django.conf import settings
from django_filters import NumberFilter, DateFilter
from django_filters.rest_framework import FilterSet
from django.db.models import Q, DateField
from django.db.models.functions import Cast

from .models import Activity


DATE_FORMAT = getattr(settings, 'DATE_FORMAT', '%Y-%m-%d')


def filter_cohort_activity(queryset, name, value):
    return queryset.filter(Q(**{'startup__{}'.format(name): value})|Q(**{name: value}))


def filter_created(queryset, name, value):
    return queryset.annotate(date=Cast(name, output_field=DateField())).filter(date=value)


class ActivityFilter(FilterSet):
    cohort = NumberFilter(name='cohort', method=filter_cohort_activity)
    startup = NumberFilter(name='startup')
    created = DateFilter(name='created', method=filter_created)

    def __init__(self, *args, **kwargs):
        super(ActivityFilter, self).__init__(*args, **kwargs)

    class Meta:
        model = Activity
        fields = ('cohort', 'startup', 'created')

