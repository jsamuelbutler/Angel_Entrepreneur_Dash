from __future__ import unicode_literals

from datetime import date
import sys

from django.db import models
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.utils.safestring import mark_safe
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from django.template import Template as DjangoTemplate, Context
from django.contrib.sites.models import Site
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel

from outset.accelerators.models import Accelerator, Cohort
from outset.startups.models import Startup


class Template(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    INFO_STATUS = 'default'
    SUCCESS_STATUS = 'success'
    WARNING_STATUS = 'warning'
    ERROR_STATUS = 'danger'
    STATUS = (
        (INFO_STATUS,    'Info'),
        (SUCCESS_STATUS, 'Success'),
        (WARNING_STATUS, 'Warning'),
        (ERROR_STATUS,   'Error')
    )
    id = models.CharField(max_length=64, verbose_name=_('system name'), primary_key=True)
    html = models.TextField(verbose_name=_('body'), blank=True)
    status = models.CharField(max_length=12, choices=STATUS, default=INFO_STATUS)

    def __unicode__(self):
        return self.pk


class Activity(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True)
    template = models.ForeignKey(Template, on_delete=models.CASCADE, blank=True, null=True)
    html = models.TextField(blank=True)
    startup = models.ForeignKey(Startup, on_delete=models.CASCADE, blank=True, null=True)
    cohort = models.ForeignKey(Cohort, on_delete=models.CASCADE, blank=True, null=True)
    accelerator = models.ForeignKey(Accelerator, on_delete=models.CASCADE, blank=True, null=True)

    created = models.DateTimeField(auto_now_add=True, editable=False)

    # target object
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, blank=True, null=True)
    object_id = models.CharField(max_length=256)
    target = GenericForeignKey('content_type', 'object_id')

    def __unicode__(self):
        return 'Activity({}, {}, {})'.format(self.content_type_id, self.object_id, self.created)

    def render_html(self):
        days = (
            (
                now().date() - (
                    self.target.due_date if isinstance(self.target.due_date, date) else self.target.due_date.date()
                )
            ).days
            if hasattr(self.target, 'due_date') else
            None
        )

        context = Context({
            'user': mark_safe(str(self.owner)),
            'created': self.created,
            'target': self.target,
            'days': -days if days and days < 0 else days,
            'site': Site.objects.get_current()
        })

        # there is some bug with rendering string encoding. So, do it
        reload(sys)
        encoding = sys.getdefaultencoding()
        sys.setdefaultencoding('utf8')

        self.html = DjangoTemplate(self.template.html).render(context)

        # reset encoding back
        sys.setdefaultencoding(encoding)

        if not self.startup_id and hasattr(self.target, 'startup_id'):
            self.startup_id = self.target.startup_id
        if not self.cohort_id and hasattr(self.target, 'cohort_id'):
            self.cohort_id = self.target.cohort_id
        if not self.accelerator_id and hasattr(self.target, 'accelerator_id'):
            self.accelerator_id = self.target.accelerator_id

    @property
    def cls(self):
        return 'text-{}'.format(self.template.status)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.render_html()
        super(Activity, self).save(*args, **kwargs)

    class Meta:
        ordering = ['-created']
        verbose_name = 'activity'
        verbose_name_plural = 'activities'
