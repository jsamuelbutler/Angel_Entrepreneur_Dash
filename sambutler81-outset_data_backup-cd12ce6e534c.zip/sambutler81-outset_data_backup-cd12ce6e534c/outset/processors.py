from django.conf import settings


def settings_response(request):
    return {
        'dev': settings.DEVELOPMENT,
        'version': settings.PROJECT_VERSION
    }
