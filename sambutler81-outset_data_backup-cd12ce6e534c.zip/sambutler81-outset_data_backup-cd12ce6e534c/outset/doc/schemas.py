from collections import OrderedDict

from coreapi.document import Link as BaseLink
from rest_framework.schemas import SchemaGenerator as RFSchemaGenerator, insert_into
from rest_framework.compat import urlparse
from rest_framework_swagger.settings import swagger_settings


def _get_security_requirement_object():
    definitions = swagger_settings.SECURITY_DEFINITIONS
    return [{k: i.get('scopes', [])} for k, i in definitions.items()]


SECURITY_REQUIREMENT_OBJECT = _get_security_requirement_object()


class Link(BaseLink):
    def __init__(self, url=None, action=None, encoding=None, transform=None, title=None, description=None, fields=None,
                 security=None):
        super(Link, self).__init__(
            url=url,
            action=action,
            encoding=encoding,
            transform=transform,
            title=title,
            description=description,
            fields=fields
        )
        self._security = security

    @property
    def security(self):
        return self._security

    def __eq__(self, other):
        return (
            isinstance(other, Link) and
            self.url == other.url and
            self.action == other.action and
            self.encoding == other.encoding and
            self.transform == other.transform and
            self.description == other.description and
            self.security == other.security and
            sorted(self.fields, key=lambda f: f.name) == sorted(other.fields, key=lambda f: f.name)
        )


class SchemaGenerator(RFSchemaGenerator):
    def get_links(self, request=None):
        """
        Return a dictionary containing all the links that should be
        included in the API schema.
        """
        links = OrderedDict()

        # Generate (path, method, view) given (path, method, callback).
        paths = []
        view_endpoints = []
        for path, method, callback in self.endpoints:
            view = self.create_view(callback, method, request)
            if getattr(view, 'exclude_from_schema', False):
                continue
            is_allow = self.has_view_permissions(path, method, view)
            path = self.coerce_path(path, method, view)
            paths.append(path)
            view_endpoints.append((path, method, view, is_allow))

        # Only generate the path prefix for paths that will be included
        if not paths:
            return None
        prefix = self.determine_path_prefix(paths)

        for path, method, view, is_allow in view_endpoints:
            link = self.get_link(path, method, view, is_allow)
            subpath = path[len(prefix):]
            keys = self.get_keys(subpath, method, view)
            insert_into(links, keys, link)
        return links

    def get_link(self, path, method, view, is_allow=False):
        """
        Return a `coreapi.Link` instance for the given endpoint.
        """
        fields = self.get_path_fields(path, method, view)
        fields += self.get_serializer_fields(path, method, view)
        fields += self.get_pagination_fields(path, method, view)
        fields += self.get_filter_fields(path, method, view)

        if fields and any([field.location in ('form', 'body') for field in fields]):
            encoding = self.get_encoding(path, method, view)
        else:
            encoding = None

        description = self.get_description(path, method, view)

        if self.url and path.startswith('/'):
            path = path[1:]

        return Link(
            url=urlparse.urljoin(self.url, path),
            action=method.lower(),
            encoding=encoding,
            fields=fields,
            description=description,
            security=None if is_allow else SECURITY_REQUIREMENT_OBJECT
        )
