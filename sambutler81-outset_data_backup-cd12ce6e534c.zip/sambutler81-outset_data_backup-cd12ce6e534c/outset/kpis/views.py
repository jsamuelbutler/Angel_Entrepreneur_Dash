import calendar
from collections import Counter

import django_filters
from django.db.models import Prefetch

from django.http import Http404
from django.utils.timezone import now
from rest_framework import decorators, mixins, status, viewsets
from rest_framework.settings import api_settings
from rest_framework.response import Response

from outset.accounts.permissions import IsAcceleratorFounderOrStartupFounderOrReadOnly
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.rest_cache.views import CacheAPIViewMixin

from .consts import (
    CASH_IN_KPI, CASH_OUT_KPI, REVENUE_KPI, FORECAST_KPI, CASH_ON_HAND_KPI, NET_BURN_KPI, DAYS_TO_LIVE_KPI
)
from .filters import KPIFilter, KPITrackFilter, KPIStatisticFilter, KPIValueFilter
from .models import KPI, KPITrack, KPIValue, HistoricalKPIChart
from .permissions import (
    KPIChartSelfOrReadOnly, KPIChartManualUpdatableOrReadOnly, KPIValueManualUpdatableOrReadOnly
)
from .serializers import (
    KPITrackSerializer, KPISerializer, KPIChartSerializer, KPIValueSerializer, KPIStatisticSerializer
)
from .utils import calculate_cohort_kpi_values_by_startup_kpis, save_startup_historical_chart, clear_kpi_chart_cache


class KPIViewSet(CacheAPIViewMixin, viewsets.ModelViewSet):
    queryset = KPITrack.objects.select_related('default').all()
    serializer_class = KPITrackSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderOrStartupFounderOrReadOnly]
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = KPITrackFilter
    pagination_class = None

    def get_queryset(self):
        return self.queryset.available_for_user(self.request.user)

    def perform_update(self, serializer):
        serializer.validated_data['last_edited_by'] = self.request.user
        super(KPIViewSet, self).perform_update(serializer)
        clear_kpi_chart_cache(serializer.instance)

    def perform_create(self, serializer):
        serializer.validated_data['assigned_by'] = self.request.user
        super(KPIViewSet, self).perform_create(serializer)

    def perform_destroy(self, instance):
        if instance.is_default:
            return Response('You can not remove default kpi.', status=status.HTTP_423_LOCKED)
        # Setting current user as `KPITrack.last_edited_by` to mark he/she in activity
        instance.last_edited_by = self.request.user
        # Setting main kpi to mark it in activity (cashed it)
        instance.kpi = instance.kpi
        super(KPIViewSet, self).perform_destroy(instance)


class DefinedKPIViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = KPI.objects.select_related('base', 'base__created_by', 'startup', 'cohort').all()
    serializer_class = KPISerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = KPIFilter
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderOrStartupFounderOrReadOnly]
    pagination_class = None

    def get_queryset(self):
        return super(DefinedKPIViewSet, self).get_queryset().available_for_user(self.request.user)


class KPIChartViewSet(mixins.DestroyModelMixin,
                      mixins.ListModelMixin,
                      mixins.RetrieveModelMixin,
                      viewsets.GenericViewSet):
    queryset = KPITrack.objects.all().order_by('position')
    serializer_class = KPIChartSerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = KPITrackFilter
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [
        IsAcceleratorFounderOrStartupFounderOrReadOnly, KPIChartSelfOrReadOnly
    ]
    pagination_class = None

    def _get_year(self):
        try:
            year = int(self.request.query_params.get('year'))
        except (ValueError, TypeError):
            year = now().year
        return year

    def get_queryset(self):
        return self.queryset.prefetch_related(
            Prefetch(
                'historical',
                queryset=HistoricalKPIChart.objects.filter(year=self._get_year()),
                to_attr='current_historical'
            )
        ).available_for_user(self.request.user)

    def get_serializer_context(self):
        context = super(KPIChartViewSet, self).get_serializer_context()
        context['year'] = self._get_year()
        return context

    def perform_destroy(self, instance):
        if instance.is_default:
            return Response('You can not remove default kpi.', status=status.HTTP_423_LOCKED)
        # Setting current user as `KPITrack.last_edited_by` to mark he/she in activity
        instance.last_edited_by = self.request.user
        # Setting main kpi to mark it in activity (cashed it)
        instance.kpi = instance.kpi
        return super(KPIChartViewSet, self).perform_destroy(instance)


class KPIValueViewSet(viewsets.ModelViewSet):
    queryset = KPIValue.objects.all()
    serializer_class = KPIValueSerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = KPIValueFilter
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [KPIValueManualUpdatableOrReadOnly]
    parent_permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [
        KPIChartSelfOrReadOnly, KPIChartManualUpdatableOrReadOnly
    ]
    pagination_class = None

    def get_parent_permissions(self):
        if not self.parent_permission_classes:
            return []
        return [permission_class() for permission_class in self.parent_permission_classes]

    @property
    def kpi_track(self):
        if hasattr(self, '_kpi_track'):
            return self._kpi_track
        if 'id_kpi_chart' not in self.kwargs:
            return None
        obj = KPITrack.objects.available_for_user(self.request.user).filter(pk=self.kwargs.get('id_kpi_chart')).first()
        if obj is None:
            # raise Http404
            setattr(self, '_kpi_track_404', True)
        for permission in self.get_parent_permissions():
            if not permission.has_object_permission(self.request, self, obj):
                self.permission_denied(self.request, message=getattr(permission, 'message', None))
        setattr(self, '_kpi_track', obj)
        return obj

    def get_queryset(self):
        end_month = now().date()
        days_in_month = calendar.monthrange(end_month.year, end_month.month)[1]
        end_month = end_month.replace(day=days_in_month)
        user = self.request.user
        data_integration = user.check_option(DATA_INTEGRATION_OPTION) if user.is_authenticated else False
        if not self.kpi_track:
            return self.queryset.none()
        return self.queryset.filter(
            kpi__in=[
                i
                for i in self.kpi_track.kpis.available_for_user(self.request.user)
                if i.is_manual(data_integration)
            ],
            created__lte=end_month
        ).select_related('kpi', 'kpi__base')

    def get_object(self):
        if hasattr(self, '_kpi_track_404'):
            raise Http404
        return super(KPIValueViewSet, self).get_object()

    def get_serializer_context(self):
        context = super(KPIValueViewSet, self).get_serializer_context()
        context['kpi_track'] = self.kpi_track
        return context

    def perform_create(self, serializer):
        super(KPIValueViewSet, self).perform_create(serializer)
        self.update_kpichart_cache(serializer.instance)

    def perform_update(self, serializer):
        super(KPIValueViewSet, self).perform_update(serializer)
        self.update_kpichart_cache(serializer.instance)

    def perform_destroy(self, instance):
        super(KPIValueViewSet, self).perform_destroy(instance)
        self.update_kpichart_cache(instance)

    @staticmethod
    def update_kpichart_cache(instance):
        year = instance.created.year if instance.created else now().year
        # Update cohort values for this date
        calculate_cohort_kpi_values_by_startup_kpis(KPI.objects.filter(id=instance.kpi_id), from_date=instance.created)
        # Update historical and save cache (for Startup)
        save_startup_historical_chart(tracks=instance.kpi.kpi_tracks, year=year)


ACCELERATOR_STATISTIC_BASES = (
    CASH_IN_KPI, CASH_OUT_KPI, NET_BURN_KPI, CASH_ON_HAND_KPI, DAYS_TO_LIVE_KPI, REVENUE_KPI
)
STARTUP_STATISTIC_BASES = (
    CASH_IN_KPI, CASH_OUT_KPI, NET_BURN_KPI, CASH_ON_HAND_KPI, DAYS_TO_LIVE_KPI, REVENUE_KPI, FORECAST_KPI
)


class KPIStatisticViewSet(CacheAPIViewMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = KPI.objects.all()
    serializer_class = KPIStatisticSerializer
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend,)
    filter_class = KPIStatisticFilter
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsAcceleratorFounderOrStartupFounderOrReadOnly]
    pagination_class = None

    def get_queryset(self):
        return self.queryset.available_for_user(self.request.user).filter(
            base_id__in=(
                STARTUP_STATISTIC_BASES
                if self.request.query_params.get('startup') else
                ACCELERATOR_STATISTIC_BASES
            )
        ).with_monthly_value(now().date().replace(day=1))

    def list(self, request, *args, **kwargs):
        year = self.request.query_params.get('year')
        queryset = self.filter_queryset(self.get_queryset().filter(value__isnull=False))
        if year:
            queryset = queryset.filter(year=year)

        values = Counter()
        for kpi in queryset:
            values[(kpi.year, kpi.month, kpi.name)] += kpi.value

        data = [dict(year=k[0], month=k[1], name=k[2], value=v) for k, v in values.items()]
        serializer = self.get_serializer(data, many=True)
        return Response(serializer.data)

    @decorators.list_route(methods=['get'])
    def years(self, request):
        years = self.filter_queryset(
            self.get_queryset().values('year').distinct('year')
        ).order_by('-year').values_list('year', flat=True)
        return Response({'years': [i for i in years if i]})
