from __future__ import unicode_literals

import calendar
from django.db import transaction
from django.db.models import Q, Max
from django.utils import timezone
from django.utils.functional import cached_property
from rest_framework import serializers

from outset.accelerators.serializers import SimpleCohortSerializer
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.serializers import SerializerFieldMixin
from outset.startups.models import Startup
from outset.startups.serializers import TinyStartupSerializer

from .models import KPI, KPIBase, KPITrack, KPIValue, HistoricalKPIChart
from .series import get_render, get_render_params
from .utils import get_kpi_chart_cache, save_kpi_chart_cache


class KPIBaseSerializer(serializers.ModelSerializer):
    id = serializers.CharField(max_length=KPIBase._meta.get_field('id').max_length, required=False, allow_null=True)

    created_by = serializers.CharField(source='created_by.recognize', read_only=True)

    def validate_id(self, value):
        # This is Hack! This is Hack to have very nice a day.
        # we can not set instance in other way inside other serialization class
        if not self.instance:
            self.instance = self.Meta.model.objects.filter(id=value).first()

    def validate(self, validated_data):
        if self.instance and not self.instance.is_custom:
            raise serializers.ValidationError('You can not change defined kpi.')
        if 'request' in self.context:
            validated_data['created_by'] = self.context['request'].user

        if 'id' in validated_data:
            del validated_data['id']

        return validated_data

    def create(self, validated_data):
        # This function may be removed because is_custom=True set as default for KPIBase
        instance = KPIBase(**validated_data)
        instance.is_custom = True
        instance.save()
        return instance

    def update(self, instance, validated_data):
        return instance

    class Meta:
        model = KPIBase
        fields = ('id', 'name', 'provider', 'created', 'edited', 'created_by', 'is_custom')
        read_only_fields = ('created', 'edited', 'is_custom')


class SimpleCohortSerializerField(SerializerFieldMixin, SimpleCohortSerializer):
    pass


class TinyStartupSerializerField(SerializerFieldMixin, TinyStartupSerializer):
    pass


class KPISerializer(serializers.ModelSerializer):
    id = serializers.CharField(label='ID', required=False, allow_null=True)
    base = KPIBaseSerializer(required=True)
    startup = TinyStartupSerializerField(allow_null=True)
    cohort = SimpleCohortSerializerField(allow_null=True)

    def validate_base(self, value):
        if isinstance(value, KPIBase):
            return value
        instance = self.fields['base'].instance
        if instance:
            for attrname, attrvalue in value.items():
                setattr(instance, attrname, attrvalue)
        else:
            instance = KPIBase(**value)
        return instance

    def validate_startup(self, value):
        if not value:
            return
        if 'request' in self.context and (
                    self.context['request'].user.startup_id != value.id and
                    not Startup.objects.filter(
                        id=value.id, cohort__accelerator=self.context['request'].user.accelerator_id
                    ).exists()
                ):
            raise serializers.ValidationError('Unsupported startup.')
        return value

    def validate_cohort(self, value):
        if not value:
            return
        if 'request' in self.context and self.context['request'].user.accelerator_id != value.accelerator_id:
            raise serializers.ValidationError('Unsupported cohort.')
        return value

    def validate(self, validated_data):
        base = validated_data['base']
        if not (validated_data.get('startup') or validated_data.get('cohort')):
            raise serializers.ValidationError('Need select cohort or startup to associate new KPI with.')
        if base._state.adding and KPI.objects.filter(
                    base__name=base.name,
                    base__is_custom=base.is_custom,
                    startup_id=validated_data.get('startup'),
                    cohort_id=validated_data.get('cohort'),
                ).exists():
            raise serializers.ValidationError('KPI with same name is already assigned to. Use existed KPI.')

        if 'id' in validated_data:
            del validated_data['id']

        return validated_data

    class Meta:
        model = KPI
        fields = ('id', 'base', 'startup', 'cohort')


class KPISerializerField(SerializerFieldMixin, KPISerializer):
    pass


USER_AVAILABLE_CHART_TYPES = (
    KPITrack.NUMBER_CHART,
    KPITrack.LINE_CHART,
    KPITrack.BAR_CHART,
    KPITrack.COLUMN_CHART,
    KPITrack.AREA_CHART,
    KPITrack.DONUT_CHART,
    KPITrack.STACK_CHART
)


class KPITrackSerializer(serializers.ModelSerializer):
    kpi = KPISerializerField()
    compare_to_kpi = KPISerializerField(allow_null=True)
    assigned_by = serializers.CharField(source='assigned_by.recognize', read_only=True)

    is_manual = serializers.SerializerMethodField(read_only=True)
    is_default = serializers.SerializerMethodField(read_only=True)

    name = serializers.CharField(read_only=True)

    @staticmethod
    def validate_chart_type(value):
        if value and value not in USER_AVAILABLE_CHART_TYPES:
            raise serializers.ValidationError('Unsupported chart type.')
        return value

    def validate(self, validated_data):
        if self.instance and self.instance.is_default:
            raise serializers.ValidationError('Does not allow changing default KPI.')

        if not (
                validated_data.get('startup', self.instance.startup_id if self.instance else None) or
                validated_data.get('cohort', self.instance.cohort_id if self.instance else None)):
            raise serializers.ValidationError('Need select cohort or startup dashboard to assign new KPI.')

        chart_type = validated_data.get('chart_type', self.instance.chart_type if self.instance else None)
        compare_to_kpi = validated_data.get('compare_to_kpi', self.instance.compare_to_kpi if self.instance else None)

        if chart_type == KPITrack.NUMBER_CHART and compare_to_kpi:
            raise serializers.ValidationError('Can not be compared KPI with number chart type.')

        # add new chart to the end of list
        if not (validated_data.get('position') or (self.instance.position if self.instance else None)):
            validated_data['position'] = (
                KPITrack.objects.filter(
                    cohort=validated_data.get('cohort'),
                    startup=validated_data.get('startup')
                ).aggregate(Max('position'))['position__max'] or 0
            ) + 1

        return validated_data

    class Meta:
        model = KPITrack
        fields = ('id', 'kpi', 'compare_to_kpi', 'period', 'chart_type', 'position', 'created',
                  'assigned_by', 'is_default', 'is_manual', 'name', 'cohort', 'startup')
        read_only_fields = ('created',)

    def update(self, instance, validated_data):
        self.save_kpi(validated_data)
        return super(KPITrackSerializer, self).update(instance, validated_data)

    def create(self, validated_data):
        self.save_kpi(validated_data)
        return super(KPITrackSerializer, self).create(validated_data)

    @staticmethod
    def save_kpi(validated_data):
        kpi = validated_data.get('kpi')
        if kpi:
            # KPIBase.id generate auto. So, using other way to check is new instance
            if kpi.base.is_custom and (kpi.base._state.adding or kpi.base.has_changed):
                kpi.base.save()
            if kpi._state.adding or kpi.has_changed:
                kpi.save()

    def get_is_manual(self, obj):
        return obj.is_manual(self.context['request'].user if 'request' in self.context else None)

    @staticmethod
    def get_is_default(obj):
        return obj.is_default


class KPIChartSerializer(serializers.ModelSerializer):
    selects = serializers.ListField(required=False)
    data = serializers.DictField(required=False)

    # main description
    last_edited = serializers.DateField(required=False)
    last_edited_by = serializers.CharField(required=False)

    # flags
    manual = serializers.SerializerMethodField(read_only=True)

    name = serializers.CharField(read_only=True)
    expanded_series = serializers.DictField(required=False)

    # diffs (count and percent). Example:
    # diffs = {'month': {'amount': 23.4, 'percent': 2.3}, '30 days': {'amount': 43.4, 'percent': 12.3}}
    diffs = serializers.DictField(required=False)

    # data source
    source = serializers.CharField(required=False)

    class Meta:
        model = KPITrack
        fields = ('id', 'chart_type', 'position', 'is_default', 'manual', 'name',
                  'selects', 'data', 'diffs', 'expanded_series', 'last_edited', 'last_edited_by', 'source')

    def get_user(self):
        return self.context['request'].user if 'request' in self.context else self.context.get('user')

    @cached_property
    def data_integration(self):
        return self.get_user().check_option(DATA_INTEGRATION_OPTION)

    def validate(self, validated_data):
        year = self.context.get('year')
        if year and year > timezone.now().year:
            raise serializers.ValidationError('Do not allow view a future year.')
        user = self.get_user()
        if not user or user.is_anonymous:
            raise serializers.ValidationError('User not found.')
        return validated_data

    def to_representation(self, instance):
        # for migration using is needed
        using = self.context.get('using')
        year = self.context.get('year') or timezone.now().year
        cached_chart = get_kpi_chart_cache(instance, year)
        if cached_chart:
            return cached_chart

        render = get_render(instance, using=using)
        render_params = get_render_params(instance, self.data_integration, year)

        # if use using(None) prefetch_related will not work correct
        historical = (
            instance.historical.using(using).filter(year=year).first()
            if not hasattr(instance, 'current_historical') else
            instance.current_historical[0]
            if instance.current_historical else
            None
        )

        if historical:
            static_data = historical.data
        else:
            static_data = render.static_render(**render_params)
            HistoricalKPIChart.objects.create(track=instance, data=static_data, year=year)

        ret = super(KPIChartSerializer, self).to_representation(instance)
        ret.update(render.dynamic_render(**render_params))
        ret.update(static_data)

        save_kpi_chart_cache(instance, year, ret)
        return ret

    def get_manual(self, obj):
        if not obj.is_manual(self.get_user(), data_integration=self.data_integration):
            return []

        return [
            dict(id=i.id, name=i.base.name)
            for i in obj.kpis.select_related('base', 'startup', 'startup__stripe', 'startup__xero', 'startup__finicity')
            if i.is_manual(self.data_integration)
        ]


class KPIValueSerializer(serializers.ModelSerializer):
    name = serializers.CharField(read_only=True, source='kpi.base.name')

    class Meta:
        model = KPIValue
        fields = ('id', 'kpi', 'name', 'value', 'created')

    def validate(self, validated_data):
        kpi = validated_data.get('kpi', self.instance.kpi if self.instance else None)
        user = validated_data['created_by'] = self.context['request'].user if 'request' in self.context else None
        kpi_track = self.context.get('kpi_track')

        if not user or user.is_anonymous:
            raise serializers.ValidationError('User not found.')

        if not kpi_track:
            raise serializers.ValidationError('KPI Chart not found.')
        elif not kpi_track.kpis.filter(pk=kpi.pk).exists():
            raise serializers.ValidationError('KPI Chart has not such KPI.')

        today = timezone.now().date()
        created = validated_data.get('created', today)
        if created > today.replace(day=calendar.monthrange(today.year, today.month)[1]):
            raise serializers.ValidationError('Available update KPI value only for the current month.')

        if self.Meta.model.objects.filter(
                    kpi=kpi, created=validated_data.get('created', self.instance.created if self.instance else None)
                ).exclude(Q(pk=self.instance.pk) if self.instance else Q()).exists():
            raise serializers.ValidationError('Already there is  KPI value for this date.')

        data_integration = user.check_option(DATA_INTEGRATION_OPTION)
        if not kpi.is_manual(data_integration=data_integration):
            raise serializers.ValidationError('Current KPI auto updated.')

        return validated_data

    def create(self, validated_data):
        with transaction.atomic():
            result = super(KPIValueSerializer, self).create(validated_data)
        return result


class KPIStatisticSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    month = serializers.CharField()
    name = serializers.CharField()
    value = serializers.DecimalField(max_digits=32, decimal_places=4)
