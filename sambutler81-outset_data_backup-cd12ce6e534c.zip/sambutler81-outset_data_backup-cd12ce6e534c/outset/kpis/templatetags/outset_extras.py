#
# @file provide all custom tag of django template - outset project
#
from django import template

from django.contrib.humanize.templatetags.humanize import intcomma
from django.template.defaultfilters import stringfilter

# register custome filters
register = template.Library()

def commify(n):
    """
    Add commas to an integer `n`.

        >>> commify(1)
        '1'
        >>> commify(123)
        '123'
        >>> commify(1234)
        '1,234'
        >>> commify(1234567890)
        '1,234,567,890'
        >>> commify(123.0)
        '123.0'
        >>> commify(1234.5)
        '1,234.5'
        >>> commify(1234.56789)
        '1,234.56789'
        >>> commify('%.2f' % 1234.5)
        '1,234.50'
        >>> commify(None)
        >>>

    """
    if n is None: return None
    n = str(n)
    if '.' in n:
        dollars, cents = n.split('.')
    else:
        dollars, cents = n, None

    r = []
    for i, c in enumerate(str(dollars)[::-1]):
        if i and (not (i % 3)):
            r.insert(0, ',')
        r.insert(0, c)
    out = ''.join(r)
    if cents:
        out += '.' + cents
    return out

@register.filter
@stringfilter
def display_number(value, arg):
    """
    Params:
    value - input number 
    arg - type to convert. E.g #, $, %

    Return: string
    """

    number_string = commify(value)

    if arg == '%':
        number_string = number_string + '%'
    elif arg == '$':
        number_string = '$' + number_string

    return number_string
