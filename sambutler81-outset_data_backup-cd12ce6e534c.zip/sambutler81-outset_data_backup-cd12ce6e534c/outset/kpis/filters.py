from django_filters import NumberFilter, BooleanFilter, BaseInFilter
from django_filters.rest_framework import FilterSet

from .models import KPI, KPITrack, KPIValue


def filter_none(queryset, name, value):
    return queryset


def filter_is_default(queryset, name, value):
    return queryset.exclude(**{'{}__isnull'.format(name): value})


class KPITrackFilter(FilterSet):
    is_default = BooleanFilter(name='default', method=filter_is_default)
    year = NumberFilter(name='created', method=filter_none, distinct=False)

    class Meta:
        model = KPITrack
        fields = ('cohort', 'startup', 'is_default')


class KPIFilter(FilterSet):
    class Meta:
        model = KPI
        fields = ('startup', 'cohort')


class KPIStatisticFilter(KPIFilter):
    year = NumberFilter(name='values__created', method=filter_none, distinct=False)
    bases = BaseInFilter(name='base')


class KPIValueFilter(FilterSet):
    class Meta:
        model = KPIValue
        fields = ('kpi',)
