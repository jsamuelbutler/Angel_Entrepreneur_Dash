# from django.contrib import admin
#
# from django import forms
#
# from .models import DefaultKPITrack, KPI, KPIBase, KPIValue, KPITrack
#
#
# class KPIValueInline(admin.TabularInline):
#     model = KPIValue
#     list_display = ('value', 'created', 'created_by')
#     extra = 1
#
#
# @admin.register(KPI)
# class KPIAdmin(admin.ModelAdmin):
#     list_display = ('base', 'startup')
#     search_fields = ('base__name',)
#     inlines = (KPIValueInline,)
#
#
# @admin.register(KPIBase)
# class KPIBaseAdmin(admin.ModelAdmin):
#     list_display = (
#         'name', 'provider', 'is_custom', 'need_finicity', 'need_stripe', 'need_outset',
#         'need_xero', 'is_cohort_sum', 'provider', 'update_period'
#     )
#     list_filter = ('is_custom', 'provider', 'is_custom', 'need_finicity', 'need_stripe', 'need_xero',
#                    'need_outset', 'provider', 'update_period')
#     list_editable = ('is_cohort_sum', 'update_period')
#     readonly_fields = ('created', 'edited')
#     search_fields = ('name',)
#     ordering = ('name',)
#
#
# @admin.register(KPIValue)
# class KPIValueAdmin(admin.ModelAdmin):
#     list_display = ('kpi', 'value', 'created', 'created_by')
#     list_filter = ('created',)
#
#
# class KPITrackForm(forms.ModelForm):
#     def clean(self):
#         if len(self.cleaned_data.get('kpis', [])) < 1:
#             raise forms.ValidationError('Need select one or more kpi.')
#         return super(KPITrackForm, self).clean()
#
#
# @admin.register(KPITrack)
# class KPITrackAdmin(admin.ModelAdmin):
#     list_display = (
#         'id', 'period', 'chart_type', 'position', 'goal', 'deadline', 'created', 'edited', 'cohort', 'startup'
#     )
#     list_filter = ('created', 'edited', 'period', 'chart_type')
#     # form = KPITrackForm
#
#     def save_model(self, request, obj, form, change):
#         # This is toggle to create activity
#         obj.kpi = form.cleaned_data['kpis'][0]
#         return super(KPITrackAdmin, self).save_model(request, obj, form, change)
#
#
# @admin.register(DefaultKPITrack)
# class DefaultKPITrack(admin.ModelAdmin):
#     list_display = (
#         '__unicode__', 'period', 'chart_type', 'position', 'for_cohort', 'for_startup',
#         'is_kpi_selected', 'is_period_selected', 'is_compare_last_period', 'is_diff_percent', 'has_expanded'
#     )
#     list_filter = (
#         'period', 'chart_type', 'for_cohort', 'for_startup', 'is_kpi_selected',
#         'is_period_selected', 'is_compare_last_period', 'is_diff_percent', 'has_expanded'
#     )
#     list_editable = (
#         'position', 'for_cohort', 'for_startup', 'is_kpi_selected', 'is_period_selected',
#         'is_compare_last_period', 'is_diff_percent', 'has_expanded'
#     )
