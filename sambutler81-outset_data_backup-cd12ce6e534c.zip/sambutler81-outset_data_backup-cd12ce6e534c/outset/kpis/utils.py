from __future__ import unicode_literals

import calendar
from collections import Counter, defaultdict, OrderedDict, namedtuple
from datetime import date, datetime, timedelta
from decimal import Decimal
from functools import reduce
import pytz
import stripe
import sys

from django.db import connection, transaction
from django.db.models import F, Sum, Count, Min, Q
from django.db.models.functions import ExtractYear
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.utils.timezone import now

from outset.accelerators.models import Cohort
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.finicity.utils import finicity_api
from outset.startups.models import Startup
from outset.utils import to_timestamp

from .consts import *
from .models import KPI, KPIBase, HistoricalKPIChart, KPITrack, KPIValue
from .series import get_render, get_render_params

import logging

logger = logging.getLogger(__name__)


def stripe_list_iter(stripe_object_list, stripe_model_, block=1000000, **kwargs):
    """
    Get list of Stripe elements from `stripe_object_list` with adding elements
    if `has_more=True`

    :param stripe_object_list: Stripe list
    :param stripe_model_: stripe model. For example, Stripe.Balance
    :param block: reading package size
    :return: Stripe element iteration
    """
    while stripe_object_list.data:
        for element in stripe_object_list.data:
            yield element
        if stripe_object_list.has_more:
            stripe_object_list = stripe_model_.list(limit=block, starting_after=stripe_object_list.data[-1], **kwargs)
        else:
            break


def stripe_list(stripe_model_, block=1000000, **kwargs):
    """
    Get list of Stripe elements

    :param stripe_model_: stripe model. For example, Stripe.Balance
    :param block: reading package size
    :param **kwargs: other parameters for stripe_model_.list() function
    :return: Stripe element iteration
    """
    return stripe_list_iter(stripe_model_.list(limit=block, **kwargs), stripe_model_, **kwargs)


def last_month_dates(from_date, to_date):
    """
    Last date of months in range iterator.

    Example:
        list(last_month_dates(date(2016,12,15), date(2017, 5, 20)))
        # return
        # [datetime.date(2016, 12, 31),
        #  datetime.date(2017, 1, 31),
        #  datetime.date(2017, 2, 28),
        #  datetime.date(2017, 3, 31),
        #  datetime.date(2017, 4, 30)]
    """
    # last date of month iterator
    for year in range(from_date.year, to_date.year+1):
        for month in range(1, 13):
            date_ = date(year, month, calendar.monthrange(year, month)[1])
            if from_date <= date_ <= to_date:
                yield date_


def dates(from_date, to_date, with_to_date=True):
    """
    Date generator
    """
    assert isinstance(from_date, (date, datetime))
    assert isinstance(to_date, (date, datetime))
    for i in range((to_date - from_date).days + int(with_to_date)):
        yield from_date + timedelta(days=i)


class KPIResult(Counter):
    def __init__(self, results, *args, **kwargs):
        self._results = results
        super(KPIResult, self).__init__(*args, **kwargs)

    def __getitem__(self, key):
        return super(KPIResult, self).__getitem__(key) if key in self else Decimal(0)

    def __setitem__(self, key, value):
        assert isinstance(value, (Decimal, int, long))
        if key not in self._results.bases:
            self._results.bases.append(key)
        return super(KPIResult, self).__setitem__(key, value)

    def __add__(self, other):
        return KPIResult(self._results, super(KPIResult, self).__add__(other))

    def __sub__(self, other):
        return KPIResult(self._results, super(KPIResult, self).__sub__(other))

    def __or__(self, other):
        return KPIResult(self._results, super(KPIResult, self).__or__(other))

    def __and__(self, other):
        return KPIResult(self._results, super(KPIResult, self).__and__(other))


class KPIDateRangeResult(object):
    """
    Example of using:
        results = KPIDateRangeResult([CASH_IN, CASH_OUT, CASH_ON_HAND])
        results[date(2017, 1, 10)][CASH_IN] += 10 # CASH_IN for 2017-01-10 = Decimal(10)
        results[date(2017, 1, 12)][CASH_OUT] += 2 # CASH_OUT for 2017=01-12 = Decimal(2)
        results[date(2017, 1, 12)][CASH_OUT] += 3 # CASH_OUT for 2017=01-12 = Decimal(5)
        print results.dates # [date(2017, 1, 10), date(2017, 1, 12)]
        print results.bases # [CASH_IN, CASH_OUT, CASH_ON_HAND]
        print results[date(2017, 1, 10)] # <KPIResult for 2017-01-10>
        print results[date(2017, 1, 10)][CASH_IN] # Decimal(10)
        print results[date(2017, 1, 11)][CASH_IN] # Decimal(0)
        print results.month_dates # [date(2017, 1, 10)] # list of first date per months
    """
    def __init__(self):
        self.bases = []
        self._dates = dict()

    def __str__(self):
        return str(self._dates)

    @property
    def dates(self):
        dates = self._dates.keys()
        dates.sort()
        return dates

    @property
    def month_dates(self):
        months = OrderedDict()
        for i in self.dates:
            key = (i.year, i.month)
            if key not in months:
                months[key] = i
        return months.values()

    def __getitem__(self, key):
        if key in self._dates:
            return self._dates[key]
        result = KPIResult(self)
        self._dates[key] = result
        return result

    def __setitem__(self, key, value):
        if not isinstance(value, KPIResult):
            raise TypeError
        if key not in self._dates:
            self._dates[key] = value
        else:
            self._dates[key].update(value)

    def __contains__(self, key):
        return key in self._dates

    def items(self):
        return [(date_, self[date_]) for date_ in self.dates]

    def values(self):
        for date_, result in self._dates.items():
            for key, value in result.items():
                yield date_, key, value


def get_shared_results(results, base_id, startup, from_date, force, with_increase=False):
    shared_result = defaultdict(Decimal)
    shared_result.update(
        {i: result[base_id] for i, result in results.items() if result[base_id]}
        if base_id in results.bases else
        {i.value_created: i.value
         for i in KPI.objects.filter(startup=startup, base_id=base_id).with_daily_value(
            from_date, with_daily_increase=with_increase
         ) if i.value}
        if not force else
        {}
    )
    return shared_result


TinyStripeSubscriptions = namedtuple('TinyStripeSubscriptions', 'id start end')


def calculate_startup_stripe_kpi_values(startup, results, from_date=None, force=False):
    assert isinstance(startup, Startup)
    assert isinstance(results, KPIDateRangeResult)

    api_key = startup.stripe.api_key

    today = now()
    if from_date is None:
        created_plan_events = stripe_list(stripe.Event, type='plan.created', api_key=api_key)
        from_date = datetime.fromtimestamp(min(i.created for i in created_plan_events))
    from_date = from_date.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=pytz.timezone('UTC'))
    from_timestamp = str(to_timestamp(from_date))
    from_30_days_ago_timestamp = str(to_timestamp(from_date - timedelta(days=30)))
    from_3_months_ago_timestamp = str(to_timestamp((from_date.replace(day=1)-timedelta(days=28*3)).replace(day=1)))
    from_date_ = from_date.date()

    customer_revenue = defaultdict(Counter)
    source_customer = {}
    for customer in stripe_list(stripe.Customer, api_key=api_key):
        for source in customer.sources.data:
            source_customer[source.id] = customer.id
    for transaction in stripe_list(stripe.BalanceTransaction, currency='usd', type='charge',
                                   available_on={'gte': from_3_months_ago_timestamp}, api_key=api_key):
        date_ = datetime.fromtimestamp(transaction.available_on).date()

        if transaction.available_on >= from_timestamp:
            results[date_][REVENUE_KPI] += Decimal(transaction.amount) / 100
        if transaction.source in source_customer:
            customer_revenue[source_customer[transaction.source]][date_] += Decimal(transaction.amount) / 100

    non_mmr_transaction_revenue = Counter()
    for transaction in stripe_list(stripe.BalanceTransaction, currency='usd', type='adjustment',
                                   available_on={'gte': from_3_months_ago_timestamp}, api_key=api_key):
        date_ = datetime.fromtimestamp(transaction.available_on).date()
        non_mmr_transaction_revenue[date_] += Decimal(transaction.amount) / 100
    for transaction in stripe_list(stripe.BalanceTransaction, currency='usd', type='application_fee_refund',
                                   available_on={'gte': from_3_months_ago_timestamp}, api_key=api_key):
        date_ = datetime.fromtimestamp(transaction.available_on).date()
        non_mmr_transaction_revenue[date_] += Decimal(transaction.amount) / 100
    # for transaction in stripe_list(stripe.BalanceTransaction, currency='usd', type='charge',
    #                                available_on={'gte': from_3_months_ago_timestamp}, api_key=api_key):
    #     date_ = datetime.fromtimestamp(transaction.available_on).date()
    #     non_mmr_transaction_revenue[date_] += Decimal(transaction.amount) / 100

    total_customer_count = Counter()
    clv_sum = Counter()
    # active_subscription - list of TinyStripeSubscriptions objects
    active_subctiptions = defaultdict(list)
    active_customers = Counter()
    for subscription in stripe_list(stripe.Subscription, status='all', api_key=api_key):
        start_subscription_date = datetime.fromtimestamp(subscription.start).date()
        end_subscription_date = (
            datetime.fromtimestamp(subscription.ended_at) if subscription.ended_at else today
        ).date()
        active_subctiptions[subscription.customer].append(
            TinyStripeSubscriptions(subscription.id, subscription.start, subscription.ended_at)
        )
        total_customer_count[start_subscription_date] += 1
        for date_ in dates(start_subscription_date, end_subscription_date):
            active_customers[date_] += 1
            if date_ >= from_date_:
                clv_sum[date_] += (date_ - start_subscription_date).days

    for date_, value in active_customers.items():
        if date_ >= from_date_:
            results[date_][ACTIVE_CUSTOMERS_KPI] = value

    total_customer_count_ = sum(v for k, v in total_customer_count.items() if k < from_date_)
    for date_ in set(k for k in total_customer_count.keys() if k >= from_date_) and set(clv_sum.keys()):
        if date_ in total_customer_count:
            total_customer_count_ += total_customer_count[date_]
        if total_customer_count_ and date_ in clv_sum:
            results[date_][CLV_KPI] = clv_sum[date_] / Decimal(total_customer_count_)

    revenue_losts = Counter()
    for event in stripe_list(stripe.Event, type='customer.subscription.delete',
                             created={'gte': from_30_days_ago_timestamp}, api_key=api_key):
        date_ = datetime.fromtimestamp(event.created).date()
        if date_ >= from_date_:
            results[date_][CANCELLED_CUSTOMERS_KPI] += 1
        revenue_losts[date_] += sum(
            Decimal(i.plan.amount) / 100 * i.quantity
            for i in (dict(event.data.object.items())['items'].data or
                      ([event.data.object] if event.data.object.plan else []))
        )
    for event in stripe_list(stripe.Event, type='customer.subscription.created',
                             created={'gte': from_timestamp}, api_key=api_key):
        customer_id = event.data.object.customer
        customer_revenue_ = customer_revenue[customer_id][datetime.fromtimestamp(event.created).date()]
        date_ = datetime.fromtimestamp(event.created).date()
        result = results[date_]
        try:
            next(s for s in active_subctiptions[customer_id] if s.start < event.created and s.id != event.data.object.id)
        except StopIteration:
            result[NEW_CUSTOMERS_KPI] += 1
            result[NEW_MRR_KPI] += customer_revenue_
        else:
            result[REACTIVATED_CUSTOMERS_KPI] += 1
            result[REACTIVATION_MRR_KPI] += customer_revenue_

    for event in stripe_list(stripe.Event, type='customer.subscription.updated',
                             created={'gte': from_30_days_ago_timestamp}, api_key=api_key):
        customer_id = event.data.object.customer
        customer_revenue_ = customer_revenue[customer_id][datetime.fromtimestamp(event.created).date()]

        plan_amounts = [
            (el.plan.amount, el.quantity)
            for el in (dict(event.data.object.items())['items'].data or
                       ([event.data.object.plan] if event.data.object.plan else []))
        ]
        now_subscription_amount = sum([amount * quantity for amount, quantity in plan_amounts])
        before_subscription_amount = sum([
            el.get('amount', pa[0]) * el.get('quantity', pa[1])
            for el, pa in
            zip(dict(event.data.previous_attributes.items()).get('data', []), plan_amounts)
        ])

        date_ = datetime.fromtimestamp(event.created).date()
        if date_ >= from_date_:
            result = results[date_]
            if now_subscription_amount > before_subscription_amount:
                result[UPGRADED_CUSTOMERS_KPI] += 1
                result[EXPANSION_MRR_KPI] += customer_revenue_
            elif now_subscription_amount < before_subscription_amount:
                result[DOWNGRADED_CUSTOMERS_KPI] += 1
                result[CONTRACTION_REVENUE_KPI] += customer_revenue_

        if before_subscription_amount > now_subscription_amount:
            revenue_losts[date_] += Decimal(before_subscription_amount-now_subscription_amount) / 100

    all_customer_revenue = sum(customer_revenue.values(), Counter())
    for datetime_ in dates(from_date, today):

        datetime_month_start = datetime_.replace(day=1)
        datetime_30_days_ago = datetime_ - timedelta(days=30)
        datetime_last_month_start = (datetime_.replace(day=1) - timedelta(days=1)).replace(day=1)
        datetime_3_months_start = (datetime_last_month_start - timedelta(days=28*2)).replace(day=1)
        date_ = datetime_.date()
        date_month_start = datetime_month_start.date()
        date_30_days_ago = datetime_30_days_ago.date()
        date_last_month_start = datetime_last_month_start.date()
        date_3_months_start = datetime_3_months_start.date()
        start_today_timestamp = str(to_timestamp(datetime_))
        start_30_days_timestamp = str(to_timestamp(datetime_30_days_ago))
        start_last_month_timestamp = str(to_timestamp(datetime_last_month_start))
        result = results[date_]

        revenue_lost_for_30_days = sum(revenue_losts[d] for d in dates(date_30_days_ago, date_, with_to_date=False))

        results[date_][ANNUAL_RUN_RATE_KPI] = 12 * sum(all_customer_revenue[d] for d in dates(date_30_days_ago, date_))

        # We always calculate ACTIVE_CUSTOMER_KPI
        active_customers_30_days_ago = active_customers[date_30_days_ago]
        if date_30_days_ago in results.dates:
            revenue_30_days_ago = results[date_30_days_ago][REVENUE_KPI]
            canceled_customers_for_last_30_days = results[date_30_days_ago][CANCELLED_CUSTOMERS_KPI]
        else:
            if not force:
                kpis = dict(
                    KPI.objects.filter(
                        startup=startup,
                        base__in=(REVENUE_KPI, CANCELLED_CUSTOMERS_KPI)
                    ).with_value(date_30_days_ago).values_list('base_id', 'value')
                )
                revenue_kpi = kpis[REVENUE_KPI]
                canceled_customer_kpi = kpis[CANCELLED_CUSTOMERS_KPI]
            else:
                revenue_kpi = canceled_customer_kpi = None
            revenue_30_days_ago = (
                revenue_kpi
                if revenue_kpi is not None else
                sum([
                    Decimal(i.amount) for i in stripe_list(
                        stripe.BalanceTransaction,
                        currency='usd',
                        type='payment',
                        available_on={'gte': start_last_month_timestamp, 'lt': start_30_days_timestamp},
                        api_key=api_key
                    )
                ]) / Decimal(100)
            )
            canceled_customers_for_last_30_days = (
                canceled_customer_kpi
                if canceled_customer_kpi is not None else
                len(tuple(
                    stripe_list(
                        stripe.Event,
                        type='customer.subscription.deleted',
                        created={'gte': start_30_days_timestamp, 'lt': start_today_timestamp},
                        api_key=api_key
                    )
                ))
            )

        result[REVENUE_CHURN_KPI] = (
            Decimal(revenue_lost_for_30_days) / Decimal(revenue_30_days_ago) * 100
            if revenue_30_days_ago else
            Decimal(0)
        )
        result[CUSTOMER_CHURN_KPI] = (
            Decimal(canceled_customers_for_last_30_days) / Decimal(active_customers_30_days_ago) * 100
            if active_customers_30_days_ago else
            Decimal(0)
        )
        result[NET_NEW_MRR_KPI] = (
            result[NEW_MRR_KPI] +
            result[EXPANSION_MRR_KPI] +
            result[REACTIVATION_MRR_KPI] +
            result[CONTRACTION_REVENUE_KPI] +
            result[REVENUE_CHURN_KPI]
        )
        result[ARPU_KPI] = (
            Decimal(result[ACTIVE_CUSTOMERS_KPI]) / result[REVENUE_KPI] if result[REVENUE_KPI] else Decimal(0)
        )
        result[CLTV_KPI] = (
            Decimal(result[ARPU_KPI]) / result[CUSTOMER_CHURN_KPI] if result[CUSTOMER_CHURN_KPI] else Decimal(0)
        )
        result[CASH_IN_KPI] = result[REVENUE_KPI]
        result[CASH_ON_HAND_KPI] = sum(all_customer_revenue[i] for i in dates(date_month_start, date_))

        # FORECAST
        last_month_revenue = sum(all_customer_revenue[d] for d in dates(date_last_month_start, date_month_start, False))
        last_3_months_revenue = (
            last_month_revenue +
            sum(all_customer_revenue[d] for d in dates(date_3_months_start, date_last_month_start, False)) +
            # and any revenue that is not considered MRR by the Stripe API
            sum(non_mmr_transaction_revenue[d] for d in dates(date_3_months_start, date_month_start, False))
        )
        result[FORECAST_KPI] = (
            Decimal(last_month_revenue) * (1 - result[REVENUE_CHURN_KPI]) + last_3_months_revenue / Decimal(3)
        )


def calculate_startup_xero_kpi_values(startup, results, from_date=None, force=False):
    assert isinstance(startup, Startup)
    assert isinstance(results, KPIDateRangeResult)

    xero = startup.xero
    today = now().date()
    if from_date is None:
        from_date = min(
            [i['CreatedDateUTC'] for i in xero.connection.organisations.all()] +
            [now().astimezone(pytz.timezone('UTC')).replace(
                month=1, day=1, hour=0, minute=0, second=0, microsecond=0, tzinfo=None
            )]
        ).date()

    logger.info('Collecting data from Xero for {} from {} date'.format(startup, from_date))
    xero_kpis = KPI.objects.filter(
        startup=startup, base__name__startswith=KPIBase.xero_name(''), base__is_editable=False
    )
    xero_bases = {name: pk for pk, name in xero_kpis.annotate(name=F('base__name')).values_list('base_id', 'name')}

    xero_accounts = xero.accounts
    xero_available_accounts = {
        xero_bases[KPIBase.xero_name(a['Name'])]: a['AccountID'] for a in xero.available_accounts
    }
    xero_account_bases = [base_id for base_id, acc_id in xero_available_accounts.items() if acc_id in xero_accounts]
    total_revenue = (
        (KPIValue.objects.filter(
            kpi__base_id=REVENUE_KPI,
            kpi__startup=startup,
            created__lt=from_date
         ).aggregate(Sum('value'))['value__sum'] or 0)
        if not force else
        0
    )
    last_positive_cac_value = (
        KPIValue.objects.filter(
            created__lt=from_date, value__gt=0, kpi__base=CAC_KPI, kpi__startup=startup
        ).order_by('-created').first()
        if not force else
        None
    )
    last_xero_value = (
        KPIValue.objects.filter(kpi__in=xero_kpis.values('pk'), created__lt=from_date).order_by('-created').first()
        if not force else
        None
    )
    logger.info('Last date when Xero data loaded: {}.'.format(last_xero_value))

    if from_date is None:
        from_date = last_xero_value.created if last_xero_value else today.replace(month=1, day=1)

    new_customers = get_shared_results(results, NEW_CUSTOMERS_KPI, startup, from_date, force, with_increase=True)
    revenue = get_shared_results(results, REVENUE_KPI, startup, from_date, force)

    report_dates = frozenset([today]) | frozenset(last_month_dates(from_date, today))
    last_report = xero.account_values(to_date=last_xero_value.created) if last_xero_value else None
    for last_period_date in report_dates:
        logger.info('Report data: {}.'.format(last_period_date))
        result = results[last_period_date]

        new_report = xero.account_values(to_date=last_period_date)
        if last_period_date.month != 1 and last_report:
            current_report = new_report.copy()
            current_report.update(Counter({k: -1*v for k, v in last_report.items()}))
        else:
            current_report = new_report
        last_report = new_report

        for base_id, account_id in xero_available_accounts.items():
            logger.info('Account {} ({})'.format(base_id, account_id))
            result[base_id] += current_report[account_id]

        if startup.stripe_data:
            if new_customers[last_period_date]:
                try:
                    last_positive_cac_result_date = next(d for d in results.dates if results[d][CAC_KPI] > 0)
                except StopIteration:
                    collect_date = last_positive_cac_value.created if last_positive_cac_value else None
                else:
                    collect_date = max(last_positive_cac_result_date, last_positive_cac_value.created)
                sales_and_marketing_expense = sum(
                    sum(results[d][base] for base in xero_account_bases)
                    for d in results.dates if (collect_date or date.min) < d < last_period_date
                )
                if last_positive_cac_value and last_positive_cac_value == collect_date:
                    sales_and_marketing_expense += KPIValue.objects.filter(
                        kpi__startup=startup,
                        kpi__base_id__in=xero_account_bases,
                        created__lt=last_positive_cac_value.created
                    ).aggregate(Sum('value'))['value__sum'] or 0
                result[CAC_KPI] = Decimal(sales_and_marketing_expense) / new_customers[last_period_date]
            else:
                result[CAC_KPI] = Decimal(0)

            total_revenue_ = (
                total_revenue +
                sum(v for k, v in revenue.items() if k < last_period_date)
            )
            result[GROSS_MARGINS_KPI] = Decimal(xero.cogs()) / total_revenue_ * 100 if total_revenue_ else Decimal(0)

            result[CLTV_CAC_KPI] = Decimal(result[CLTV_KPI]) / result[CAC_KPI] if result[CAC_KPI] else Decimal(0)


def calculate_startup_finicity_kpi_values(startup, results, from_date=None, force=False):
    assert isinstance(startup, Startup)
    assert isinstance(results, KPIDateRangeResult)

    customer, institution = startup.finicity.customer_id, startup.finicity.institution_id
    from_date = from_date or startup.finicity.MIN_FINICITY_DATETIME

    for transaction in finicity_api().get_customer_transaction(customer, from_date, now()):
        amount = transaction['amount']
        if amount > 0:
            results[datetime.fromtimestamp(transaction['postedDate']).date()][CASH_IN_KPI] += Decimal(amount)
        else:
            results[datetime.fromtimestamp(transaction['postedDate']).date()][CASH_OUT_KPI] += Decimal(abs(amount))

    for account in finicity_api().get_customer_accounts(customer, institution):
        results[datetime.fromtimestamp(account.balanceDate).date()][CASH_ON_HAND_KPI] += Decimal(account.balance)

    revenue = get_shared_results(results, REVENUE_KPI, startup, from_date, force)
    net_burn = get_shared_results(results, NET_BURN_KPI, startup, from_date, force)

    for date_ in results.dates:
        result = results[date_]
        # result[NET_BURN_KPI] = result[CASH_OUT_KPI] - revenue[date_]
        result[NET_BURN_KPI] = result[CASH_IN_KPI] - result[CASH_OUT_KPI]

        result[DAYS_TO_LIVE_KPI] = (
            (result[CASH_ON_HAND_KPI] + revenue[date_] / net_burn[date_] * Decimal('30.4'))
            if net_burn[date_] else
            Decimal(0)
        )


def calculate_startup_outset_kpi_value(startup, results, from_date=None, force=False):
    assert isinstance(startup, (Startup, int, long))
    assert isinstance(results, KPIDateRangeResult)

    user_model = get_user_model()
    today = now().date()
    if from_date is None:
        from_date = (
            user_model.objects.filter(startup=startup).aggregate(Min('date_joined'))['date_joined__min'] or today
        ).date()

    user_count_queryset = Startup.objects.filter(
        pk=startup.pk if isinstance(startup, Startup) else startup,
        users__in=user_model.objects.filter(is_active=True).extra(where=['date_joined <= dd'])
    ).annotate(c=Count('users')).values('c')
    sql_raw, sql_params = user_count_queryset.query.get_compiler(user_count_queryset.db).as_sql()
    with connection.cursor() as cursor:
        cursor.execute(
            'SELECT date_trunc(\'day\', dd)::DATE AS "date", COALESCE(({}), 0) AS "user_count" '
            'FROM generate_series(%s::TIMESTAMP, %s::TIMESTAMP, \'1 day\'::INTERVAL) dd'.format(sql_raw),
            sql_params + (from_date, today)
        )
        for date_, count_ in cursor.fetchall():
            results[date_][FTE_KPI] = count_


def calculate_startup_kpi_values(startup, from_date=None, collect_finicity=False, collect_outset=False,
                                 collect_stripe=False, collect_xero=False, force=False):
    """
    Calculating KPI values for startup.

    If some needed kpi not in `kpi_queryset` get it from DB.

    :param startup: Startup instance
    :param from_date: date from that need calculate values include itself
    :param collect_finicity: need collect Finicity values?
    :param collect_outset: need collect Outset values?
    :param collect_stripe: need collect Stripe values?
    :param collect_xero: need collect Xero values?
    :param force: do load preview values from Outset DB?
    :return: KPIDateRangeResult instance
    """
    assert isinstance(startup, Startup)
    results = KPIDateRangeResult()
    if collect_outset:
        calculate_startup_outset_kpi_value(startup, results, from_date=from_date, force=force)
    if collect_stripe and startup.stripe_data:
        calculate_startup_stripe_kpi_values(startup, results, from_date=from_date, force=force)
    if collect_finicity and startup.finicity_data:
        calculate_startup_finicity_kpi_values(startup, results, from_date=from_date, force=force)
    if collect_xero and startup.xero_data:
        calculate_startup_xero_kpi_values(startup, results, from_date=from_date, force=force)
    return results


def calculate_cohort_kpi_values(cohort, from_date=None, collect_finicity=False, collect_outset=False,
                                collect_stripe=False, collect_xero=False, force=False, kpis=None):
    """
    Calculating KPI values for cohort.

    If some needed kpi not in `kpi_queryset` get it from DB.
    :param cohort: Cohort instance
    :param from_date: date from that need calculate values include itself
    :param collect_finicity: need collect Finicity values?
    :param collect_outset: need collect Outset values?
    :param collect_stripe: need collect Stripe values?
    :param collect_xero: need collect Xero values?
    :param force: not used. Need only for common interface with `calculate_startup_kpi_values(..)`
    :param kpis: KPI list. Used For selective KPI changes
    :return: KPIDateRangeResult instance
    """
    results = KPIDateRangeResult()

    today = now().date()
    if from_date is None:
        from_date = (
            KPIValue.objects.filter(kpi__startup__cohort=cohort).aggregate(Min('created'))['created__min'] or
            today
        )
    elif isinstance(from_date, datetime):
        from_date = from_date.date()

    base_meta = KPIBase._meta
    kpi_value_queryset = KPIValue.objects.filter(kpi__startup__cohort=cohort).annotate(
        base_id=F('kpi__base_id')
    ).extra(
        where=['created = dd', 'base_id = T1."{}"'.format(base_meta.get_field('id').attname)]
    ).order_by().extra(
        select={'x': 'SUM({})'.format(KPIValue._meta.get_field('value').attname)}
    ).values('x')
    sql_raw, sql_params = kpi_value_queryset.query.get_compiler(kpi_value_queryset.db).as_sql()

    base_params = dict(
        need_finicity=collect_finicity,
        need_outset=collect_outset,
        need_stripe=collect_stripe,
        need_xero=collect_xero,
    )
    base_queryset = KPI.objects.filter(
        Q(id__in=kpis) if kpis else Q(),
        cohort=cohort,
        base__in=KPIBase.objects.filter(
            Q(**{k: False for k in base_params.keys()}) |
            reduce(lambda x, y: x | y, [Q(**{k: True}) for k, v in base_params.items() if v], Q()),
            is_cohort_sum=True,
        ).values('id')
    ).values('base_id')
    base_sql_raw, base_sql_params = base_queryset.query.get_compiler(base_queryset.db).as_sql()

    with connection.cursor() as cursor:
        cursor.execute(
            'SELECT date_trunc(\'day\', dd)::DATE AS "date", '
            '       T1."{base_pk}" AS "base_id", '
            '       ({values_subquery}) AS "sum_value" '
            'FROM generate_series(%s::TIMESTAMP, %s::TIMESTAMP, \'1 day\'::INTERVAL) dd '
            'CROSS JOIN "{base_table}" T1 '
            'WHERE T1."{base_pk}" IN ({base_subquery})'.format(
                values_subquery=sql_raw,
                base_table=base_meta.db_table,
                base_pk=base_meta.get_field('id').attname,
                base_subquery=base_sql_raw,
            ),
            sql_params + (from_date, max(today, from_date)) + base_sql_params
        )
        for date_, base_, value_ in cursor.fetchall():
            results[date_][base_] = value_ or Decimal()
    return results


def calculate_cohort_kpi_values_by_startup_kpis(startup_kpis, from_date=None):
    cohorts = Cohort.objects.filter(startups__in=startup_kpis.values('startup')).distinct()
    cohort_kpis = KPI.objects.filter(cohort__in=cohorts, base__in=startup_kpis.values('base'))
    kwargs = dict(
        kpis=cohort_kpis,
        from_date=from_date,
        collect_finicity=True,
        collect_outset=True,
        collect_stripe=True,
        collect_xero=True,
        force=False,
    )
    dates = calculate_values(cohorts, calculate_cohort_kpi_values, func_kwargs=kwargs)

    # update historical and save cache (for Cohort)
    cohort_tracks = reduce(
        lambda a, b: a | b,
        [set(i.kpi_tracks.values_list('id', flat=True)) for i in cohort_kpis],
        set()
    )
    [save_startup_historical_chart(tracks=KPITrack.objects.filter(id__in=cohort_tracks), year=year)
     for year in {i.year for i in dates}]

    return dates


CACHE_KPI_CHART_PREFIX = 'kpi_chart_{id}_{year}'
CACHE_KPI_CHART_TIMEOUT = 60 * 60 * 24


def get_kpi_chart_cache(kpi_track, year):
    kpi_track = kpi_track.id if isinstance(kpi_track, KPITrack) else kpi_track
    return cache.get(CACHE_KPI_CHART_PREFIX.format(id=kpi_track, year=year))


def save_kpi_chart_cache(kpi_track, year, data):
    kpi_track = kpi_track.id if isinstance(kpi_track, KPITrack) else kpi_track
    cache.set(CACHE_KPI_CHART_PREFIX.format(id=kpi_track, year=year), data, CACHE_KPI_CHART_TIMEOUT)


def clear_kpi_chart_cache(kpi_track, year=None):
    assert isinstance(kpi_track, (int, long, KPITrack))
    if year:
        years = [year]
    else:
        if not isinstance(kpi_track, KPITrack):
            kpi_track = KPITrack.objects.filter(id=kpi_track).first()
        years = (
            set(KPIValue.objects.filter(kpi__in=kpi_track.kpis).annotate(
                year=ExtractYear('created')).order_by('year').distinct('year').values_list('year', flat=True))
            if kpi_track else
            {}
        )
    id_ = kpi_track.id if isinstance(kpi_track, KPITrack) else kpi_track
    for year_ in years:
        cache.delete(CACHE_KPI_CHART_PREFIX.format(id=id_, year=year_))


def calculate_values(element_queryset, func, func_args=None, func_kwargs=None, log=None):
    logger_ = log or logger
    func_args = func_args or ()
    func_kwargs = func_kwargs or {}
    values = []
    dates = set()
    for instance in element_queryset:
        bases_kpi = {i.base_id: i for i in instance.kpis.all().only('base_id', 'id')}
        try:
            with transaction.atomic():
                results = func(instance, *func_args, **func_kwargs)
                dates |= set(results.dates)
        except:
            logger_.exception(
                'Failed to complete `outset.kpis.utils.calculate_values` for {} with pk={}'.format(
                    str(instance),
                    instance.pk
                ),
                exc_info=sys.exc_info()
            )
            continue
        for date_, base_, value_ in results.values():
            if base_ in bases_kpi:
                values.append(KPIValue(kpi=bases_kpi[base_], value=value_, created=date_))
            else:
                logger_.warn('Not found "{}" base for {}'.format(base_, instance))

    if values:
        KPIValue.objects.filter(
            reduce(lambda a, b: a | b, [Q(kpi=i.kpi, created=i.created) for i in values])
        ).delete()
        KPIValue.objects.bulk_create(values)

    return dates


def collect_data(startup_queryset, from_date=None, force=False, collect_finicity=True,
                 collect_outset=True, collect_stripe=True, collect_xero=True, log=None):
    logger_ = log or logger
    cohort_queryset = Cohort.objects.filter(startups__in=startup_queryset).distinct()
    kwargs = dict(
        from_date=from_date,
        collect_finicity=collect_finicity,
        collect_outset=collect_outset,
        collect_stripe=collect_stripe,
        collect_xero=collect_xero,
        force=force,
    )

    logger_.info('Creating loading KPI values.')
    dates = calculate_values(startup_queryset, calculate_startup_kpi_values, func_kwargs=kwargs, log=logger_)

    logger_.info('Update KPI values for cohorts')
    dates |= calculate_values(cohort_queryset, calculate_cohort_kpi_values, func_kwargs=kwargs, log=logger_)

    logger_.info('Saving Historical Charts')
    [save_startup_historical_chart(startup, year=year)
     for startup in startup_queryset for year in {i.year for i in dates}]


def save_historical_chart(kpi_track, year):
    user = get_user_model().objects.filter(
        Q(startup=kpi_track.startup) | Q(accelerator__cohorts__startups=kpi_track.startup)
        if kpi_track.startup_id else
        Q(accelerator__cohorts=kpi_track.cohort)
    ).first()

    HistoricalKPIChart.objects.filter(track=kpi_track, year=year).delete()
    HistoricalKPIChart(
        track=kpi_track,
        data=get_render(kpi_track, startups={kpi_track.startup_id: kpi_track.startup}).static_render(
            **get_render_params(kpi_track, user.check_option(DATA_INTEGRATION_OPTION) if user else False, year)
        ),
        year=year
    ).save()


def save_startup_historical_chart(startup=None, year=None, tracks=None):
    """
    Create historical KPI Charts for last completed month.
    """
    year = year or now().year

    tracks = KPITrack.objects.filter(Q(id__in=tracks) if tracks else Q())

    HistoricalKPIChart.objects.filter(
        Q(track__startup=startup) if startup else Q(),
        track__in=tracks,
        year=year,
    ).delete()
    for i in tracks.filter(Q(startup=startup) if startup else Q()).select_related(
            'startup', 'startup__finicity', 'startup__xero', 'startup__stripe'):
        if startup:
            # reduce API and DB requests by second hand Startup object using
            setattr(i, 'startup', startup)
        clear_kpi_chart_cache(i, year)
        save_historical_chart(i, year)

    HistoricalKPIChart.objects.filter(
        Q(track__cohort__startups=startup) if startup else Q(),
        track__in=tracks,
        year=year,
    ).delete()
    for i in tracks.filter(Q(cohort__startups=startup) if startup else Q()):
        clear_kpi_chart_cache(i, year)
        save_historical_chart(i, year)

