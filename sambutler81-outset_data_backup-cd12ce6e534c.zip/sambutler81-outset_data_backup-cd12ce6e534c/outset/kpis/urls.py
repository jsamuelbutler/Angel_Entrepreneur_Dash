from rest_framework import routers

from . import views

router = routers.SimpleRouter()
router.register(r'kpi', views.KPIViewSet)
router.register(r'defined-kpi', views.DefinedKPIViewSet)
router.register(r'kpi-chart/(?P<id_kpi_chart>\d+)/values', views.KPIValueViewSet)
router.register(r'kpi-chart', views.KPIChartViewSet)
router.register(r'kpi-table', views.KPIStatisticViewSet)
