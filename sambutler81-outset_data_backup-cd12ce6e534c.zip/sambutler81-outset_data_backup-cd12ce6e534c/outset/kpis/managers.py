from datetime import datetime

from django.db.models import Subquery, OuterRef, DecimalField, DateField, Sum, Case, When, Func, Value, PositiveSmallIntegerField
from django.db.models.functions import ExtractYear, ExtractMonth, ExtractWeek, ExtractDay, Extract, Cast
from django.db.models.query import F, Q
from django.utils.timezone import now
from safedelete.managers import SafeDeleteQueryset, SafeDeleteManager

from outset.db.fields import IntervalField
from outset.accelerators.models import Cohort
from outset.startups.models import Startup


class KPIQuerySet(SafeDeleteQueryset):
    def available_for_user(self, user):
        if user.is_anonymous:
            return self.none()
        cohorts = Cohort.objects.available_to_user(user).values('id')
        return self.filter(
            Q(cohort__in=cohorts) |
            Q(startup__in=Startup.objects.filter(cohort__in=cohorts)) |
            Q(startup__isnull=False, startup=user.startup_id)
        )

    def with_value(self, to_date=None, from_date=None):
        from .models import KPIValue, KPI

        to_date = to_date or now()
        if isinstance(to_date, datetime):
            to_date = to_date.date()
        if isinstance(from_date, datetime):
            from_date = from_date.date()
        from_date = from_date or to_date.replace(day=1)

        return self.annotate(
            value=Case(
                When(
                    base__is_daily_increase=True,
                    then=Subquery(
                        KPI.objects.filter(
                            pk=OuterRef('pk'), values__created__gte=from_date, values__created__lte=to_date
                        ).annotate(summed=Sum('values__value')).values('summed'),
                        output_field=DecimalField(null=True)
                    )
                ),
                default=Subquery(
                    KPIValue.objects.filter(
                        kpi=OuterRef('pk'), created__gte=from_date, created__lte=to_date
                    ).order_by('-created').values('value')[:1],
                    output_field=DecimalField(null=True)
                )
            ),
            value_created=Subquery(
                KPIValue.objects.filter(
                    kpi=OuterRef('pk'), created__gte=from_date, created__lte=to_date
                ).order_by('-created').values('created')[:1],
                output_field=DateField(),
            )
        )

    def with_quarterly_value(self, to_date=None, from_date=None):
        q = Q(value_created__lte=to_date) if to_date else Q()
        q &= Q(value_created__gte=from_date) if from_date else Q()
        return self.annotate(value_created=F('values__created')).filter(q).annotate(
            year=ExtractYear('value_created'),
            quarter=Extract('value_created', 'quarter'),
            name=F('base__name')
        ).annotate(
            value=Case(
                When(base_id__is_daily_increase=True, then=Subquery(
                    self.model.objects.annotate(
                        quarter=Extract('values__created', 'quarter'),
                        year=ExtractYear('values__created'),
                    ).filter(
                        pk=OuterRef('pk'),
                        quarter=OuterRef('quarter'),
                        year=OuterRef('year')
                    ).annotate(total=Sum('values__value')).values('total'),
                    output_field=DecimalField()
                )),
                default=F('values__value'),
                output_field=DecimalField()
            ),
        ).order_by(
            'year', 'quarter', 'name', 'pk', 'startup', '-value_created'
        ).distinct('year', 'quarter', 'name', 'pk', 'startup')

    def with_monthly_value(self, to_date=None, from_date=None):
        """
        Return KPI * month * year elements
        """
        q = Q(value_created__lte=to_date) if to_date else Q()
        q &= Q(value_created__gte=from_date) if from_date else Q()
        return self.annotate(value_created=F('values__created')).filter(q).annotate(
            year=ExtractYear('value_created'),
            month=ExtractMonth('value_created'),
            name=F('base__name')
        ).annotate(
            value=Case(
                When(base_id__is_daily_increase=True, then=Subquery(
                    self.model.objects.filter(
                        pk=OuterRef('pk'),
                        values__created__month=OuterRef('month'),
                        values__created__year=OuterRef('year')
                    ).annotate(total=Sum('values__value')).values('total'),
                    output_field=DecimalField()
                )),
                default=F('values__value'),
                output_field=DecimalField()
            ),
        ).order_by(
            'year', 'month', 'name', 'pk', 'startup', '-value_created'
        ).distinct('year', 'month', 'name', 'pk', 'startup')

    def with_daily_value(self, to_date=None, from_date=None, with_daily_increase=True):
        q = Q(value_created__lte=to_date) if to_date else Q()
        q &= Q(value_created__gte=from_date) if from_date else Q()
        value = (
            Case(
                When(base_id__is_daily_increase=True, then=Subquery(
                    self.model.objects.filter(
                        pk=OuterRef('pk'),
                        values__created__month=OuterRef('month'),
                        values__created__year=OuterRef('year'),
                        values__created__day__lte=OuterRef('day'),
                    ).annotate(total=Sum('values__value')).values('total'),
                    output_field=DecimalField()
                )),
                default=F('values__value'),
                output_field=DecimalField()
            )
            if with_daily_increase else
            F('values__value')
        )
        return self.annotate(value_created=F('values__created')).filter(q).annotate(
            year=ExtractYear('value_created'),
            month=ExtractMonth('value_created'),
            day=ExtractDay('value_created'),
            name=F('base__name')
        ).annotate(value=value).order_by(
            'year', 'month', 'day', 'name', 'pk', 'startup', '-value_created'
        ).distinct('year', 'month', 'day', 'name', 'pk', 'startup')

    def with_weekly_value(self, to_date=None, from_date=None):
        q = Q(value_created__lte=to_date) if to_date else Q()
        q &= Q(value_created__gte=from_date) if from_date else Q()
        return self.annotate(value_created=F('values__created')).filter(q).annotate(
            year=ExtractYear('value_created'),
            week=ExtractWeek(
                Cast(
                    F('value_created')+Cast(Value('1 day'), output_field=IntervalField()),
                    output_field=DateField()
                )
            ),
            name=F('base__name'),
        ).annotate(
            value=Case(
                When(base_id__is_daily_increase=True, then=Subquery(
                    self.model.objects.annotate(
                        week=ExtractWeek(
                            Cast(
                                F('values__created')+Cast(Value('1 day'), output_field=IntervalField()),
                                output_field=DateField()
                            )
                        ),
                        year=ExtractYear('values__created'),
                    ).filter(
                        pk=OuterRef('pk'),
                        week=OuterRef('week'),
                        year=OuterRef('year'),
                    ).annotate(total=Sum('values__value')).values('total'),
                    output_field=DecimalField()
                )),
                default=F('values__value'),
                output_field=DecimalField()
            ),
        ).order_by(
            'year', 'week', 'name', 'pk', 'startup', '-value_created'
        ).distinct('year', 'week', 'name', 'pk', 'startup')


class KPITrackQuerySet(SafeDeleteQueryset):
    def available_for_user(self, user):
        if user.is_anonymous:
            return self.none()
        return self.filter(
            id__in=self.model.objects.filter(
                Q(startup__in=Startup.objects.available_to_user(user)) |
                Q(cohort__in=Cohort.objects.available_to_user(user))
            ).values('id')
        )


class KPIManager(SafeDeleteManager):
    _queryset_class = KPIQuerySet

    def available_for_user(self, *args, **kwargs):
        return self.get_queryset().available_for_user(*args, **kwargs)

    def with_value(self, *args, **kwargs):
        return self.get_queryset().with_value(*args, **kwargs)

    def with_yearly_value(self, *args, **kwargs):
        return self.get_queryset().with_yearly_value(*args, **kwargs)

    def with_monthly_value(self, *args, **kwargs):
        return self.get_queryset().with_monthly_value(*args, **kwargs)

    def with_daily_value(self, *args, **kwargs):
        return self.get_queryset().with_daily_value(*args, **kwargs)


class KPITrackManager(SafeDeleteManager):
    _queryset_class = KPITrackQuerySet

    def available_for_user(self, *args, **kwargs):
        return self.get_queryset().available_for_user(*args, **kwargs)
