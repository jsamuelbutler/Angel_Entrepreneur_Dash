from __future__ import absolute_import, unicode_literals

import calendar
from collections import Counter, OrderedDict, defaultdict, namedtuple
from datetime import date, datetime, timedelta
from decimal import Decimal
from functools import reduce
import inspect

from django.db.models import F, Q, Prefetch
from django.utils import formats, timezone

from outset.startups.models import Startup

from .models import KPI, KPIBase, KPITrack, KPIValue


QUARTER_MONTHS = {
    1: (1,  2,  3),
    2: (4,  5,  6),
    3: (7,  8,  9),
    4: (10, 11, 12),
}


DIFF_PERIODS = OrderedDict([
    ('month', 'month'),
    ('30 days', timedelta(days=30)),
    ('90 days', timedelta(days=90)),
    ('180 days', timedelta(days=180)),
    ('1 year', 'year')
])


BaseAxisValue = namedtuple('AxisValue', 'year quarter month week')
BaseAxisValue.__new__.__defaults__ = (0,) * len(BaseAxisValue._fields)


class AxisValue(BaseAxisValue):
    @property
    def month_name(self):
        return calendar.month_abbr[self.month]


def override_kpi_startup(kpi, startups):
    if kpi.startup_id in startups:
        setattr(kpi, 'startup', startups[kpi.startup_id])
    return kpi


class BaseKPISeriesRender(object):
    startup_divided = False
    allow_sums = True

    def __init__(self, kpi_queryset, startups=None, using=None):
        self.using = using
        self.queryset = (
            KPI.objects.filter(pk=kpi_queryset.pk)
            if isinstance(kpi_queryset, KPI) else
            kpi_queryset
        ).using(using).select_related('base')
        # Need to reduce API and DB requests
        self.startups = startups

    @staticmethod
    def from_date(year):
        return date(year, 1, 1)

    @staticmethod
    def to_date(year):
        return min(date(year, 12, 31), timezone.now().date())

    @staticmethod
    def percent(current_value, last_value):
        if current_value is None:
            return None
        return 100 * Decimal(current_value - last_value) / last_value if last_value else None

    def queryset_with_values(self, period, year):
        return (
            self.queryset.with_daily_value()
            if period == KPITrack.NONE_PERIOD else
            self.queryset.with_weekly_value()
            if period == KPITrack.WEEKLY_PERIOD else
            self.queryset.with_monthly_value()
            if period == KPITrack.MONTHLY_PERIOD else
            self.queryset.with_quarterly_value()
        ).filter(year=year)

    @staticmethod
    def week_number(date_value):
        # Week number that starts from Sunday
        assert isinstance(date_value, (date, datetime))
        # ISO standard (Mon - the first week day)
        # return date_value.isocalendar()[1]
        # US standard
        return int(date_value.strftime('%U'))

    @staticmethod
    def month_name(date_value):
        assert isinstance(date_value, (date, datetime))
        return calendar.month_abbr[int(date_value.month)]

    @staticmethod
    def quarter_number(date_value):
        assert isinstance(date_value, (date, datetime))
        return (date_value.month - 1) // 3 + 1

    @staticmethod
    def format_value(value, provider=None):
        decimal_places = 2 if provider == KPIBase.PERCENTAGE_PROVIDER else 0
        try:
            return round(value, decimal_places)
        except (ValueError, TypeError):
            return value

    @staticmethod
    def format_date(value):
        assert isinstance(value, (date, datetime))
        return formats.date_format(value, 'SHORT_DATE_FORMAT')

    @staticmethod
    def format_value_with_provider(value, base=None, provider=None):
        provider = provider or (base.provider if base else None)
        if provider == KPIBase.PERCENTAGE_PROVIDER:
            format_ = '{:.2f}%'
        elif provider == KPIBase.MONETARY_PROVIDER:
            format_ = '${:.0f}'
        else:
            format_ = '{:.0f}'
        return format_.format(value or 0)

    @classmethod
    def format_axis(cls, axis_value, period):
        if isinstance(axis_value, (date, datetime)):
            if period == KPITrack.NONE_PERIOD:
                return cls.format_date(axis_value)
            else:
                axis_value = AxisValue(
                    year=axis_value.year,
                    week=cls.week_number(axis_value),
                    month=axis_value.month,
                    quarter=cls.quarter_number(axis_value)
                )
        if isinstance(axis_value, AxisValue):
            if period == KPITrack.WEEKLY_PERIOD:
                return '{week} week, {year}'.format(week=axis_value.week, year=axis_value.year)
            elif period == KPITrack.MONTHLY_PERIOD:
                return '{month_name}, {year}'.format(month_name=axis_value.month_name, year=axis_value.year)
            elif period == KPITrack.QUARTERLY_PERIOD:
                return '{quarter} quarter, {year}'.format(quarter=axis_value.quarter, year=axis_value.year)
        try:
            return int(axis_value)
        except ValueError:
            return axis_value

    @classmethod
    def get_value_key(cls, axis_value, period):
        if isinstance(axis_value, (date, datetime)):
            if period == KPITrack.WEEKLY_PERIOD:
                return AxisValue(week=cls.week_number(axis_value), year=axis_value.year)
            elif period == KPITrack.MONTHLY_PERIOD:
                return AxisValue(month=axis_value.month, year=axis_value.year)
            elif period == KPITrack.QUARTERLY_PERIOD:
                return AxisValue(quarter=cls.quarter_number(axis_value), year=axis_value.year)
            elif period == KPITrack.NONE_PERIOD:
                return axis_value
        try:
            return int(axis_value)
        except ValueError:
            return axis_value

    def get_formatted_current_value(self, kpi, year):
        if hasattr(kpi, 'value'):
            # case of using queryset_with_values(...)
            kpi_value = kpi.value
        else:
            # base case (if all normal there is not execution of it)
            kpi_with_value = KPI.objects.using(self.using).filter(id=kpi.id).with_value(self.to_date(year)).first()
            kpi_value = kpi_with_value.value if kpi_with_value and kpi_with_value.value else Decimal(0)
        return self.format_value_with_provider(kpi_value, base=kpi.base)

    def get_kpis_with_data(self, period, year):
        kpis = {i: OrderedDict() for i in self.queryset.all()}
        for kpi in self.queryset_with_values(period, year):
            date_ = (
                self.get_value_key(kpi.value_created, period)
                if hasattr(kpi, 'value_created') else
                date(kpi.year, getattr(kpi, 'month', 12), calendar.monthrange(kpi.year, getattr(kpi, 'month', 12))[1])
            )
            kpis[kpi][date_] = kpi.value + (kpis[kpi].get(date_, 0) if kpi in kpis else 0)
        return kpis

    def get_startups_with_data(self, year):
        return Startup.objects.using(self.using).filter(
            Q(id__in=self.queryset.values('startup')) | Q(cohort__in=self.queryset.values('cohort')),
        ).prefetch_related(
            Prefetch(
                'kpis',
                queryset=KPI.objects.filter(
                    Q(id__in=self.queryset.values('id')) |
                    Q(startup__cohort__in=self.queryset.values('cohort'), base__in=self.queryset.values('base_id')),
                ).with_value(self.to_date(year), self.from_date(year)),
                to_attr='series_kpis'
            )
        ).distinct()

    @staticmethod
    def get_axis(kpi_data, period):
        return sorted(reduce(lambda x, y: x | y, [frozenset(i.keys()) for i in kpi_data.values()], frozenset()))

    def get_formatted_axis(self, period, axis, year):
        return [self.format_axis(i, period) for i in axis]

    def get_kpi_series(self, kpi, data, axis, formatted_axis, year, with_sums=False, name_format=None):
        # raise NotImplementedError('`get_kpi_series(..)` must be implemented.')
        series = {
            'id': kpi.id,
            'name': name_format.format(kpi.base.name) if name_format else kpi.base.name,
            'data': [self.format_value(data.get(i), provider=kpi.base.provider) for i in axis],
            'axis': formatted_axis,
            'current': self.get_formatted_current_value(kpi, year),
            'object_name': kpi.startup.name if kpi.startup_id else kpi.cohort.name,
            'object_type': 'startup' if kpi.startup_id else 'cohort',
        }
        if self.allow_sums:
            series.update({
                'single_data': (
                    [(c[1] - (p[1] if p[0] and p[0] == c[0] else 0))
                     for c, p in zip(data.items(), [(None, 0)]+data.items()[:-1])]
                    if with_sums and kpi.base.is_daily_increase else
                    []
                ),
                'sum_data': (
                    [current_value + next_value
                     for current_value, next_value in zip(data.values(), [0] + data.values()[:-1])]
                    if with_sums and not kpi.base.is_daily_increase else
                    []
                ),
            })
        return series

    def get_startup_series(self, startup, number, kpi, value):
        # raise NotImplementedError('`get_startup_series(..)` must be implemented.')
        return {
            'id': kpi.id,
            'name': startup.name,
            'data': (number, self.format_value(value, provider=kpi.base.provider)),
            'object_name': startup.name,
            'object_type': 'startup',
        }

    def form_data(self, kpi_data, axis, formatted_axis, period, year, with_sums, name_format=None):
        return [
            self.get_kpi_series(kpi, data, axis, formatted_axis, year, with_sums=with_sums, name_format=name_format)
            for kpi, data in kpi_data.items()
        ]

    def form_startup_data(self, startup_data, year):
        assert not startup_data or hasattr(startup_data[0], 'series_kpis')
        return [
            self.get_startup_series(
                startup,
                number,
                startup.series_kpis[0],
                sum([i.value for i in startup.series_kpis if i.value], 0)
            )
            for number, startup in enumerate(startup_data, start=1) if startup.series_kpis
        ]

    def data(self, period=None, year=None, with_sums=False):
        assert period or self.startup_divided
        year = year or timezone.now().year
        if self.startup_divided:
            return self.form_startup_data(self.get_startups_with_data(year), year)
        kpi_data = self.get_kpis_with_data(period, year)
        axis = self.get_axis(kpi_data, period)
        return self.form_data(kpi_data, axis, self.get_formatted_axis(period, axis, year), period, year, with_sums)

    def get_main_kpi(self, value_year):
        cache_key = '_{}'.format(inspect.stack()[0][3])
        if hasattr(self, cache_key):
            return getattr(self, cache_key)
        main_kpi = self.queryset.with_value(self.to_date(value_year)).first()
        setattr(self, cache_key, main_kpi)
        return main_kpi

    def last_edited_data(self, year):
        last_value = KPIValue.objects.using(self.using).filter(
            kpi=self.get_main_kpi(year)
        ).select_related('created_by').order_by('-added').first()
        return {
            'last_edited':    self.format_date(last_value.added) if last_value else None,
            'last_edited_by': last_value.created_by.recognize if last_value and last_value.created_by else None,
        }

    @staticmethod
    def diff_date(for_date, date_value):
        assert isinstance(for_date, (date, datetime))
        if isinstance(date_value, timedelta):
            return for_date - date_value
        if date_value == 'month':
            diff_date = for_date.replace(day=1) - timedelta(days=1)
            return diff_date.replace(day=min(for_date.day, calendar.monthrange(diff_date.year, diff_date.month)[1]))
        elif date_value == 'year':
            diff_date = for_date.replace(day=1, month=1) - timedelta(days=1)
            return diff_date.replace(
                day=min(for_date.day, calendar.monthrange(diff_date.year, diff_date.month)[1]),
                month=for_date.month
            )
        return None

    def diff_data(self, year):
        main_kpi = self.get_main_kpi(year)
        if not main_kpi:
            return {}
        current_period_value = main_kpi.value or Decimal(0)
        to_date = min(timezone.now().date(), self.to_date(year))
        diffs = OrderedDict()
        for period_name, period_date in DIFF_PERIODS.items():
            period_value = KPI.objects.with_value(self.diff_date(to_date, period_date)).filter(id=main_kpi.id).first()
            value = period_value.value or Decimal(0)
            diffs[period_name] = dict(
                amount=self.format_value(value, provider=main_kpi.base.provider),
                percent=self.format_value(
                    self.percent(current_period_value, value), provider=KPIBase.PERCENTAGE_PROVIDER
                )
            )
        return dict(diffs=diffs)

    def data_with_selects(self, period=None, year=None, with_sums=False, is_kpi_select=False, is_period_select=False):
        kpi_select = (
            OrderedDict(self.queryset.order_by('base__name').distinct('base__name').values_list('id', 'base__name'))
            if is_kpi_select else
            {}
        )
        period_select = (
            [k for k, v in KPITrack.PERIOD_CHOICES if k != KPITrack.NONE_PERIOD]
            if is_period_select else
            []
        )

        period_series = (
            {period_: self.data(period=period_, year=year, with_sums=with_sums) for period_ in period_select}
            if is_period_select else
            dict()
        )

        if is_kpi_select and is_period_select:
            # silly permutation of places period => kpi_name => series to kpi_name => period => series
            cross = [[(p, s['id'], s) for s in v] for p, v in period_series.items()]
            data = defaultdict(lambda: defaultdict(list))
            for period_name, kpi_id, series in reduce(lambda a, b: a + b, cross, []):
                data[kpi_select[kpi_id]][period_name].append(series)

            if not data:
                data = {kpi_name: period_series for kpi_name in kpi_select.values()}

            # BugFix of `defaultdict(..)` using
            data = dict(data.items())
        elif is_kpi_select:
            data = defaultdict(list)
            for i in self.data(period=period, year=year, with_sums=with_sums):
                data[kpi_select[i['id']]].append(i)

            # BugFix of `defaultdict(..)` using
            data = dict(data.items())
        elif is_period_select:
            data = period_series
        else:
            data = dict(series=self.data(period=period, year=year, with_sums=with_sums))

        return dict(data=data, selects=filter(lambda x: x, (kpi_select.values(), period_select)))

    def source_data(self, data_integration=False):
        kpis_queryset = KPI.objects.using(self.using).filter(
            Q(
                base__is_cohort_sum=True,
                startup__cohort__in=self.queryset.filter(cohort__isnull=False).values('cohort'),
                base__in=self.queryset.values('base')
            ) |
            Q(id__in=self.queryset.values('id')),
        ).select_related(
            'base', 'startup', 'startup__finicity', 'startup__stripe', 'startup__xero'
        )
        kpis = (
            [override_kpi_startup(i, self.startups) for i in kpis_queryset]
            if self.startups else
            kpis_queryset
        )
        sources = [i.source(data_integration) for i in kpis]
        return dict(source=', '.join(list(set(filter(lambda x: x, sources)))))

    def static_render(self, period=KPITrack.NONE_PERIOD, year=None, data_integration=False,
                      with_sums=False, is_kpi_select=False, is_period_select=False, has_expand=True):
        """
        Render elements that doesn't changed in historical view
        """
        year = year or timezone.now().year
        rendered_data = self.data_with_selects(
            period=period,
            year=year,
            with_sums=with_sums,
            is_kpi_select=is_kpi_select,
            is_period_select=is_period_select
        )
        rendered_data.update(self.diff_data(year))
        rendered_data.update(self.source_data(data_integration=data_integration))
        rendered_data.update(dict(
            expanded_series=self.data(period=KPITrack.NONE_PERIOD, year=year, with_sums=True) if has_expand else []
        ))
        return rendered_data

    def dynamic_render(self, year=None, **kwargs):
        """
        Render elements that are changing in historical view
        """
        year = year or timezone.now().year
        return self.last_edited_data(year)

    def render(self, *args, **kwargs):
        return self.dynamic_render(*args, **kwargs).update(self.static_render(*args, **kwargs))


class NumberKPISeriesRender(BaseKPISeriesRender):

    def data(self, period=None, year=None, with_sums=False):
        main_kpi = self.get_main_kpi(year)
        return dict(
            id=main_kpi.id,
            name=main_kpi.base.name,
            current=self.get_formatted_current_value(main_kpi, year),
            object_name=main_kpi.startup.name if main_kpi.startup_id else main_kpi.cohort.name,
            object_type='startup' if main_kpi.startup_id else 'cohort'
        )

    def data_with_selects(self, period=None, year=None, with_sums=False, **kwargs):
        return dict(data=self.data(period=period, year=year, with_sums=with_sums), selects=[])


class SimpleKPISeriesRender(BaseKPISeriesRender):
    pass


class ScatterKPISeriesRender(BaseKPISeriesRender):
    startup_divided = True

    def data_with_selects(self, period=None, year=None, with_sums=False, **kwargs):
        return dict(selects=[], data=self.data(period=period, year=year, with_sums=with_sums))


class BubbleKPISeriesRender(BaseKPISeriesRender):
    startup_divided = True

    def get_startup_series(self, startup, number, max_value, value):
        assert isinstance(max_value, (int, Decimal, float))
        return {
            'x': self.format_value(number),
            'y': self.format_value(value),
            'z': self.format_value(100*value/max_value if max_value and value else Decimal(0)),
            'name': startup.name
        }

    def form_startup_data(self, startup_data, year):
        try:
            cohort_name = self.queryset[:1].values('cohort__name')[0]['cohort__name']
        except KeyError:
            cohort_name = ''

        # bases = {i: {} for i in KPIBase.objects.using(self.using).filter(id__in=self.queryset.values('base__id'))}
        bases = defaultdict(dict)
        for startup in startup_data:
            for kpi in startup.series_kpis:
                bases[kpi.base][startup] = kpi.value

        # For common interface "id" - kpi id for all time
        kpis = dict(self.queryset.values_list('base_id', 'id'))

        return [
            {
                'id': kpis[base.id],
                'name': base.name,
                'data': [
                    self.get_startup_series(startup[0], i, max(startups.values()+[0]), startup[1])
                    for i, startup in enumerate(startups.items(), start=1)
                ],
                'object_name': cohort_name,
                'object_type': 'cohort'
            }
            for base, startups in bases.items()
        ]


class LastPeriodKPISeriesRender(BaseKPISeriesRender):
    @classmethod
    def get_value_key(cls, axis_value, period):
        return axis_value.month, axis_value.day

    def get_formatted_axis(self, period, axis, year):
        return [self.format_axis(date(year, *i), period) for i in axis]

    def form_data(self, kpi_data, axis, formatted_axis, period, year, with_sums, name_format=None):
        parent = super(LastPeriodKPISeriesRender, self)
        last_period_year = year - 1
        last_period_kpi_data = self.get_kpis_with_data(period, last_period_year)
        return (
            parent.form_data(kpi_data, axis, formatted_axis, period, year, with_sums, name_format) +
            parent.form_data(
                last_period_kpi_data,
                axis,
                self.get_formatted_axis(period, axis, last_period_year),
                period,
                last_period_year,
                with_sums,
                name_format='Last Year {}',
            )
        )


class DiffPercentKPISeriesRender(BaseKPISeriesRender):
    allow_sums = False

    def form_data(self, kpi_data, axis, formatted_axis, period, year, with_sums, name_format=None):
        parent = super(DiffPercentKPISeriesRender, self)

        percent_kpi_data = defaultdict(Counter)
        for kpi, data in kpi_data.items():
            previous_value = Decimal(0)
            percents = Counter()
            for key in axis:
                current_value = Decimal(data[key]) if key in data else Decimal(0)
                percents[key] = self.format_value(
                    self.percent(current_value, previous_value),
                    provider=KPIBase.PERCENTAGE_PROVIDER
                )
                previous_value = current_value
            percent_kpi_data[kpi].update(percents)

        return (
            parent.form_data(kpi_data, axis, formatted_axis, period, year, with_sums, name_format) +
            parent.form_data(percent_kpi_data, axis, formatted_axis, period, year, False, 'Percentage Change {}')
        )


def get_render(kpi_track, startups=None, using=None):
    chart_type = kpi_track.chart_type
    if chart_type == KPITrack.NUMBER_CHART:
        render_class = NumberKPISeriesRender
    elif chart_type == KPITrack.SCATTER_CHART:
        render_class = ScatterKPISeriesRender
    elif chart_type == KPITrack.BUBBLE_CHART:
        render_class = BubbleKPISeriesRender
    elif kpi_track.is_compare_last_period:
        render_class = LastPeriodKPISeriesRender
    elif kpi_track.is_diff_percent:
        render_class = DiffPercentKPISeriesRender
    else:
        render_class = SimpleKPISeriesRender
    return render_class(kpi_track.kpis.all(), startups=startups, using=using)


def get_render_params(kpi_track, data_integration, year):
    return dict(
        period=kpi_track.period,
        year=year,
        data_integration=data_integration,
        with_sums=False,
        is_kpi_select=kpi_track.is_kpi_selected,
        is_period_select=kpi_track.is_period_selected,
        has_expand=kpi_track.has_expanded
    )
