from rest_framework.permissions import BasePermission, SAFE_METHODS

from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.startups.models import Startup


class KPIChartSelfOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        return True

    def has_object_permission(self, request, view, obj):
        user = request.user
        return (
            request.method in SAFE_METHODS or
            user.accelerator_id and (obj.cohort_id and user.accelerator_id == obj.cohort.accelerator_id or
                                     Startup.objects.filter(cohort__accelerator=user.accelerator_id).exists()) or
            obj.startup_id and user.startup_id == obj.startup_id
        )


class KPIChartManualUpdatableOrReadOnly(BasePermission):
    def has_permission(self, request, view):
        return True

    def has_object_permission(self, request, view, obj):
        return request.method in SAFE_METHODS or obj.is_manual(user=request.user)


class KPIValueManualUpdatableOrReadOnly(KPIChartManualUpdatableOrReadOnly):
    def has_object_permission(self, request, view, obj):
        user = request.user
        data_integration = user.check_option(DATA_INTEGRATION_OPTION) if user.is_authenticated else False
        return request.method in SAFE_METHODS or obj.kpi.is_manual(data_integration)
