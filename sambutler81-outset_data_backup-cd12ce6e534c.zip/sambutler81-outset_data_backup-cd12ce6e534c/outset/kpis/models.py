from __future__ import unicode_literals

try:
    import cPickle
except ImportError:
    import _pickle as cPickle

from django.db import models
from django.db.models import Q, F, Value, Func, Max, Case, When
from django.db.models.functions import Cast
from django.db.models.signals import post_save
from django.conf import settings
from django.dispatch import receiver
from django.utils import formats, timezone
from django.utils.functional import cached_property
from django.utils.translation import ugettext_lazy as _
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel
from safedelete.signals import post_softdelete

from outset.accelerators.models import Cohort
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.models import ModelDiffMixin
from outset.startups.models import Startup, StartupXero


from .managers import KPIManager, KPITrackManager
from .tasks import create_cohort_kpi_task, create_startup_kpi_task


def generate_custom_kpibase_pk():
    max_id = KPIBase.objects.all_with_deleted().filter(id__startswith='custom-').annotate(
        x=Cast(
            Func(F('id'), Value('[^\d]'), Value(''), Value('g'), function='regexp_replace'),
            output_field=models.IntegerField()
        )
    ).aggregate(Max('x'))['x__max']
    return 'custom-{:d}'.format((max_id or 0) + 1)


class KPIBase(ModelDiffMixin, SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    id = models.CharField(max_length=20, primary_key=True, default=generate_custom_kpibase_pk)
    name = models.CharField(max_length=255)

    need_stripe = models.BooleanField(default=False)
    need_finicity = models.BooleanField(default=False)
    need_xero = models.BooleanField(default=False)
    need_outset = models.BooleanField(default=False)
    is_daily_increase = models.BooleanField(default=True, help_text=_('Sum-able?'))
    is_cohort_sum = models.BooleanField(default=False, help_text=_('Indicate that it is sum KPI of startup KPIs'))
    is_custom = models.BooleanField(default=True)
    is_editable = models.BooleanField(default=True)

    PERCENTAGE_PROVIDER = '%'
    NUMERIC_PROVIDER = '#'
    MONETARY_PROVIDER = '$'
    PROVIDERS = (
        (PERCENTAGE_PROVIDER, '% - Percentage'),
        (NUMERIC_PROVIDER, '# - Numeric'),
        (MONETARY_PROVIDER, '$ - Monetary'),
    )

    provider = models.CharField(max_length=1, choices=PROVIDERS, default=NUMERIC_PROVIDER, verbose_name=_('KPI Base'))

    DAILY_PERIOD = 'daily'
    WEEKLY_PERIOD = 'weekly'
    MONTHLY_PERIOD = 'monthly'
    PERIOD_CHOICES = (
        (DAILY_PERIOD, 'Nightly'),
        (WEEKLY_PERIOD, 'Weekly'),
        (MONTHLY_PERIOD, 'Monthly'),
    )
    update_period = models.CharField(
        max_length=10,
        choices=PERIOD_CHOICES,
        help_text=_('It shows how much the value obtained for a long time does not require recalculation.'),
        blank=True,
        null=True,
    )

    created = models.DateTimeField(auto_now_add=True)
    edited = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='+'
    )

    def __unicode__(self):
        return '{}({}) {}'.format(self.name, self.id, self.provider)

    @staticmethod
    def xero_name(name):
        return 'Xero: {}'.format(name)


class KPI(ModelDiffMixin, SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    base = models.ForeignKey(KPIBase, related_name='+', on_delete=models.CASCADE)

    startup = models.ForeignKey(
        Startup,
        verbose_name=_('Assigned Company'),
        related_name='kpis',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    cohort = models.ForeignKey(
        Cohort,
        verbose_name=_('Assigned Cohort'),
        related_name='kpis',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    objects = KPIManager()

    def __unicode__(self):
        return '{}  kpi for {}'.format(
            self.base,
            'startup {}'.format(self.startup_id) if self.startup_id else 'cohort {}'.format(self.cohort_id)
        )

    class Meta:
        verbose_name = _('KPI')
        verbose_name_plural = _('KPIs')

    def is_manual(self, data_integration=False):
        if self.cohort_id:
            return self.base.is_editable and self.base.is_custom
        # Remove additional requests to DB
        self.startup.data_integration_is_allow = data_integration
        return self.base.is_editable and not (self.base.need_outset or data_integration and (
                self.base.need_stripe and bool(self.startup.stripe_data) or
                self.base.need_finicity and bool(self.startup.finicity_data) or
                self.base.need_xero and bool(self.startup.xero_data)
            )
        )

    def source(self, data_integration):
        if self.is_manual(data_integration):
            r = 'Manual'
        elif self.base.need_outset:
            r = 'Outset'
        elif self.base.need_stripe and (not self.startup_id or self.startup.stripe_data):
            r = 'Stripe'
        elif self.base.need_finicity and (not self.startup_id or self.startup.finicity_data):
            r = 'Finicity'
        elif self.base.need_xero and (not self.startup_id or self.startup.xero_data):
            r = 'Xero'
        else:
            r = ''
        return r

    @cached_property
    def kpi_tracks(self):
        """
        Related KPI Tracks with KPI.

        It's analog KPITrack.kpis() for KPI

        :return: KPITrack queryset
        """
        return KPITrack.objects.filter(
            Q(kpi=self) |
            Q(compare_to_kpi=self) |
            Q(
                Q(default__bases=self.base_id) | Q(default__main_base=self.base_id),
                cohort=self.cohort,
                startup=self.startup
            )
        )


class KPITrack(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    # Only for custom added KPI Charts on dashboard
    kpi = models.ForeignKey(
        KPI, on_delete=models.CASCADE, verbose_name=_('KPI'), related_name='+', null=True, blank=True
    )
    compare_to_kpi = models.ForeignKey(
        KPI, on_delete=models.CASCADE, verbose_name=_('compare KPI'), related_name='+', null=True, blank=True
    )

    cohort = models.ForeignKey(
        Cohort,
        verbose_name=_('Assigned Cohort'),
        related_name='kpi_tracks',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    startup = models.ForeignKey(
        Startup,
        verbose_name=_('Assigned Company'),
        related_name='kpi_tracks',
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    NONE_PERIOD = 'none'
    WEEKLY_PERIOD = 'weekly'
    MONTHLY_PERIOD = 'monthly'
    QUARTERLY_PERIOD = 'quarterly'
    PERIOD_CHOICES = (
        (NONE_PERIOD, 'Without period'),
        (WEEKLY_PERIOD, 'Weekly'),
        (MONTHLY_PERIOD, 'Monthly'),
        (QUARTERLY_PERIOD, 'Quarterly'),
    )
    period = models.CharField(max_length=10, choices=PERIOD_CHOICES, default=WEEKLY_PERIOD)

    NUMBER_CHART = 'number'
    LINE_CHART = 'line'
    BAR_CHART = 'bar'
    BAR_AND_LINE_CHART = 'bar_and_line'
    COLUMN_CHART = 'column'
    COLUMN_AND_LINE_CHART = 'column_and_line'
    AREA_CHART = 'area'
    DONUT_CHART = 'donut'
    STACK_CHART = 'stack'
    STACK_AND_LINE_CHART = 'stack_and_line'
    SCATTER_CHART = 'scatter'
    BUBBLE_CHART = 'bubble'
    CHART_CHOICES = (
        (NUMBER_CHART, 'Number'),
        (LINE_CHART, 'Line'),
        (BAR_CHART, 'Bar'),
        (BAR_AND_LINE_CHART, 'Bar & Line'),
        (COLUMN_CHART, 'Column'),
        (COLUMN_AND_LINE_CHART, 'Column & Line'),
        (AREA_CHART, 'Area'),
        (DONUT_CHART, 'Donut'),
        (STACK_CHART, 'Stack'),
        (STACK_AND_LINE_CHART, 'Stack & Line'),
        (SCATTER_CHART, 'Scatter'),
        (BUBBLE_CHART, 'Bubble'),
    )
    chart_type = models.CharField(max_length=20, choices=CHART_CHOICES, default=LINE_CHART)

    position = models.SmallIntegerField(_('Position in dashboard'), null=True, default=None)
    # status dates
    created = models.DateField(auto_now_add=True)
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='+'
    )

    default = models.ForeignKey('DefaultKPITrack', on_delete=models.SET_NULL, related_name='+', null=True, blank=True)

    objects = KPITrackManager()

    def __unicode__(self):
        return '{} ({})'.format(self.name, self.position)

    class Meta:
        verbose_name = _('KPI on dashboard')
        verbose_name_plural = _('KPIs on dashboard')

    def manual_updated_kpis(self, user=None, data_integration=None):
        di = data_integration or (user.check_option(DATA_INTEGRATION_OPTION) if user else None)
        return [
            i
            for i in self.kpis.select_related(
                'base', 'startup', 'startup__finicity', 'startup__stripe', 'startup__xero'
            )
            if i.is_manual(di)
        ]

    def is_manual(self, user=None, data_integration=None):
        if self.chart_type in (self.BUBBLE_CHART, self.SCATTER_CHART):
            return False
        return user is not None and bool(len(self.manual_updated_kpis(user=user, data_integration=data_integration)))

    @property
    def is_default(self):
        return self.default_id is not None

    @property
    def name(self):
        # TODO: need it rebuild after creating normal compare with cohort KPI support
        return self.default.name if self.default_id else ' vs '.join(
            [i.base.name for i in (self.kpi, self.compare_to_kpi) if i]
        )

    @property
    def is_kpi_selected(self):
        return self.default_id is not None and self.default.is_kpi_selected

    @property
    def is_period_selected(self):
        return self.default_id is not None and self.default.is_period_selected

    @property
    def is_compare_last_period(self):
        return self.default_id is not None and self.default.is_compare_last_period

    @property
    def is_diff_percent(self):
        return self.default_id is not None and self.default.is_diff_percent

    @property
    def has_expanded(self):
        return self.default_id is not None and self.default.has_expanded

    @property
    def main_base_id(self):
        return self.default.main_base_id if self.default_id else None

    @cached_property
    def bases(self):
        """
        Default KPI Track bases.

        For non default KPI Track returns none.

        :return: KPIBase queryset
        """
        if not self.default_id:
            return KPIBase.objects.none()

        return KPIBase.objects.filter(
            Q(id__in=self.default.bases.all().values('id')) | Q(id=self.default.main_base_id)
        ).annotate(
            is_main=Case(
                When(id=Value(self.default.main_base_id), then=Value(1)),
                default=Value(0),
                output_field=models.SmallIntegerField()
            )
        ).order_by('-is_main', 'id')

    @cached_property
    def kpis(self):
        """
        Related KPI with KPI Chart.

        If it is custom assign KPI Track it returns quryset for self.kpi and self.compare_to_kpi.
        Otherwise it returns cohort or startup KPIs for default KPI Track.

        WARNING: Cohort queryset contains Startup KPI related by bases as own KPI

        :return: KPI queryset
        """
        main_q = Q(id=self.kpi_id)
        prime_kpi = filter(lambda x: x is not None, [self.kpi_id, self.compare_to_kpi_id])

        if not prime_kpi and self.default_id is None:
            return KPI.objects.none()
        elif self.default_id:
            prime_kpi = KPI.objects.filter(
                Q(cohort=self.cohort_id) if self.cohort_id else Q(startup=self.startup_id),
                base__in=self.bases.all().values('id'),
            ).values('id')
            main_q = Q(base_id__isnull=False, base_id=self.default.main_base_id)

        return KPI.objects.annotate(
            is_main=Case(
                When(main_q, then=Value(1)),
                default=Value(0),
                output_field=models.SmallIntegerField()
            )
        ).filter(id__in=prime_kpi).order_by('-is_main')


class DefaultKPITrack(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    id = models.CharField(max_length=20, primary_key=True)
    name = models.TextField(null=True, blank=True)
    main_base = models.ForeignKey(KPIBase, on_delete=models.CASCADE, related_name='+', blank=True, null=True)
    bases = models.ManyToManyField(KPIBase, related_name='+', blank=True)
    period = models.CharField(max_length=10, choices=KPITrack.PERIOD_CHOICES, default=KPITrack.WEEKLY_PERIOD)
    chart_type = models.CharField(max_length=20, choices=KPITrack.CHART_CHOICES, default=KPITrack.LINE_CHART)
    for_cohort = models.BooleanField(default=False)
    for_startup = models.BooleanField(default=False)
    is_kpi_selected = models.BooleanField(default=False)
    is_period_selected = models.BooleanField(default=False)
    is_compare_last_period = models.BooleanField(default=False)
    is_diff_percent = models.BooleanField(default=False)
    position = models.SmallIntegerField(default=0)
    has_expanded = models.BooleanField(default=True)

    def __unicode__(self):
        return self.id

    class Meta:
        ordering = ('id',)
        verbose_name = _('default KPI on dashboard')
        verbose_name_plural = _('default KPIs on dashboard')


class KPIValue(models.Model):
    kpi = models.ForeignKey(KPI, on_delete=models.CASCADE, related_name='values')
    value = models.DecimalField(max_digits=26, decimal_places=4)
    created = models.DateField(default=timezone.now)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='+'
    )
    added = models.DateTimeField(
        editable=False, auto_now_add=True, null=True, blank=True, help_text=_('Date of this value adding')
    )

    def __unicode__(self):
        return '{} value {} on {}'.format(self.kpi, self.value, formats.date_format(self.created, 'DATE_FORMAT'))

    class Meta:
        ordering = ('-created',)
        verbose_name = _('KPI Value')
        verbose_name_plural = _('KPI Values')
        get_latest_by = 'created'


def current_year():
    return timezone.now().year


class HistoricalKPIChart(models.Model):
    track = models.ForeignKey(KPITrack, on_delete=models.CASCADE, related_name='historical')
    picked_data = models.TextField()

    year = models.PositiveSmallIntegerField(default=current_year)
    created = models.DateField(auto_now_add=True)

    def __str__(self):
        return 'Historical Chart {} ({})'.format(self.track_id, formats.date_format(self.created, 'DATE_FORMAT'))

    class Meta:
        ordering = ('-created',)

    @property
    def data(self):
        return cPickle.loads(str(self.picked_data))

    @data.setter
    def data(self, value):
        self.picked_data = cPickle.dumps(value)


@receiver(post_save, sender=Startup)
def create_startup_kpi(sender, instance, created=False, using=None, **kwargs):
    create_startup_kpi_task.delay(instance.pk, created)


@receiver(post_save, sender=Cohort)
def create_cohort_kpi(sender, instance, created=False, using=None, **kwargs):
    create_cohort_kpi_task.delay(instance.pk, created)


@receiver(post_save, sender=KPI)
def create_kpi(sender, instance, created=True, using=None, **kwargs):
    if instance.base.is_custom and created:
        from outset.activities.models import Activity
        Activity.objects.using(using).create(target=instance, template_id='kpi_create')


@receiver(post_save, sender=KPIValue)
def update_kpi(sender, instance, created=True, using=None, **kwargs):
    if created and instance.created_by:
        from outset.activities.models import Activity
        Activity.objects.using(using).create(
            target=instance.kpi,
            owner=instance.created_by,
            template_id=('kpi_investor_update' if instance.created_by.accelerator_id else 'kpi_update')
        )


@receiver(post_softdelete, sender=KPITrack)
def offtrack_kpi(sender, instance, using=None, **kwargs):
    if not instance.is_default:
        from outset.activities.models import Activity

        for kpi in instance.kpis.using(using):
            q = Q(kpi=kpi) | Q(compare_to_kpi=kpi)
            if not KPITrack.objects.using(using).filter(q).exclude(pk=instance.pk).exists():
                Activity.objects.using(using).create(target=kpi, template_id='kpi_offtrack')


@receiver(post_save, sender=StartupXero)
def create_xero_kpi(sender, instance, created=True, using=None, **kwargs):
    if not instance.is_verified:
        return
    kpi_names = [KPIBase.xero_name(i['Name']) for i in instance.available_accounts]
    exists_kpi_names = KPI.objects.using(using).filter(
        startup=instance.startup, base__name__in=kpi_names
    ).values_list('base__name', flat=True)
    kpis = []
    for name in set(kpi_names) - set(exists_kpi_names):
        base = KPIBase.objects.using(using).create(
            name=name,
            need_xero=True,
            provider=KPIBase.MONETARY_PROVIDER,
            update_period=KPIBase.DAILY_PERIOD,
            is_editable=False,
        )
        kpis.append(KPI(startup=instance.startup, base=base))
    KPI.objects.using(using).bulk_create(kpis)
