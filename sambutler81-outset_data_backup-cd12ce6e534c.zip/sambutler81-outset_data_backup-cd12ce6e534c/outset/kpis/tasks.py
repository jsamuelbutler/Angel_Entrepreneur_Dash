from __future__ import absolute_import

from outset import celery_app
from celery.utils.log import get_task_logger
from time import sleep

from outset.accelerators.models import Cohort
from outset.startups.models import Startup


logger = get_task_logger(__name__)


@celery_app.task
def load_old_data_by_connect_task(pk, connect):
    """
    Loading old data from connected source.

    :param pk: startup id
    :param connect: one of ['stripe', 'xero', 'finicity']
    """
    logger.info('Starting load_old_data_by_connect_task({}, {})...'.format(pk, connect))

    assert connect in ['stripe', 'xero', 'finicity']

    from .models import KPIValue
    from .utils import collect_data

    sleep(10)

    startup_queryset = Startup.objects.filter(pk=pk)
    instance = startup_queryset.first()
    if not instance or not getattr(instance, '{}_data'.format(connect)):
        logger.warn('{} has not Startup.{}_data'.format(instance, connect))
        return

    kwargs = dict(
        from_date=None,
        collect_finicity=connect == 'finicity',
        collect_stripe=connect == 'stripe',
        collect_xero=connect == 'xero',
        force=connect == 'stripe',
        collect_outset=not KPIValue.objects.filter(
            kpi__in=instance.kpis.filter(base__need_outset=True).values('pk'),
            created_by__isnull=True
        ).exists(),
    )

    collect_data(startup_queryset, **kwargs)


@celery_app.task
def create_startup_kpi_task(pk, created):
    logger.info('Starting create_startup_kpi_task({}, {})...'.format(pk, created))

    from .consts import VALUATION_KPI
    from .models import DefaultKPITrack, KPI, KPIBase, KPITrack, KPIValue

    sleep(10)

    instance = Startup.objects.filter(pk=pk).first()
    if instance:
        logger.info('Creating startup KPIs: {}'.format(instance))

        bases = KPIBase.objects.exclude(id__in=instance.kpis.all().values('base__id')).filter(is_custom=False)
        KPI.objects.bulk_create([KPI(base=i, startup=instance) for i in bases])

        if created:
            # adding default kpitracks
            for default in DefaultKPITrack.objects.filter(for_startup=True):
                KPITrack.objects.create(
                    startup=instance,
                    period=default.period,
                    chart_type=default.chart_type,
                    position=default.position,
                    default=default
                )

            # setting initial valuation as first value of kpi
            try:
                kpi = KPI.objects.get(startup=instance, base=VALUATION_KPI)
            except KPI.DoesNotExist:
                pass
            else:
                KPIValue.objects.create(kpi=kpi, value=instance.initial_valuation)


@celery_app.task
def create_cohort_kpi_task(pk, created):
    logger.info('Starting create_cohort_kpi_task({}, {})...'.format(pk, created))

    from .models import DefaultKPITrack, KPI, KPIBase, KPITrack

    sleep(10)

    instance = Cohort.objects.filter(pk=pk).first()
    if instance:
        logger.info('Creating cohort KPIs: {}'.format(instance))

        bases = KPIBase.objects.exclude(id__in=instance.kpis.all().values('base__id')).filter(is_custom=False)
        KPI.objects.bulk_create([KPI(base=i, cohort=instance) for i in bases])

        if created:
            # adding default kpitracks
            for default in DefaultKPITrack.objects.filter(for_cohort=True):
                KPITrack.objects.create(
                    cohort=instance,
                    period=default.period,
                    chart_type=default.chart_type,
                    position=default.position,
                    default=default,
                )


@celery_app.task
def save_historical_chart(pk, year):
    logger.info('Starting save_historical_chart({}, {})...'.format(pk, year))

    from .models import KPITrack
    from .utils import save_historical_chart as _save_historical_chart

    sleep(5)

    instance = KPITrack.objects.filter(pk=pk).first()
    if instance:
        logger.info('Creating historical KPI Chart: {}'.format(instance))
        _save_historical_chart(instance, year)



