from __future__ import unicode_literals

from datetime import timedelta
import logging

from django.utils.timezone import now

from outset.startups.models import Startup

from .utils import collect_data as base_collect_data


logger = logging.getLogger('django_crontab')


def collect_data(from_date=None, force=False):
    """
    Auto collecting data from Stripe, Finicity and Xero

    Calling every day, but collect data that have only expire update date.
    """
    base_collect_data(
        Startup.objects.all(),
        from_date or now()-timedelta(days=1),
        force=force,
        collect_finicity=True,
        collect_outset=True,
        collect_stripe=True,
        collect_xero=True,
        log=logger
    )
