import django_filters
from rest_framework import filters, viewsets
from rest_framework.settings import api_settings

from outset.accounts.permissions import IsStartupFounderOrReadOnly
from outset.startups.models import Startup

from .filters import UpdateFilter
from .models import Update
from .serializers import UpdateSerializer


class UpdateViewSet(viewsets.ModelViewSet):
    queryset = Update.objects.all().select_related('startup').prefetch_related('links', 'kpis')
    serializer_class = UpdateSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [IsStartupFounderOrReadOnly]
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend, filters.SearchFilter)
    filter_class = UpdateFilter
    search_fields = ('title', 'overview')
    pagination_class = None

    def get_queryset(self):
        return self.queryset.filter(startup__in=Startup.objects.available_to_user(self.request.user))

    def perform_create(self, serializer):
        super(UpdateViewSet, self).perform_create(serializer)
        serializer.instance.send_email()
