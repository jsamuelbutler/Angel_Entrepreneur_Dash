from __future__ import absolute_import, unicode_literals

from django.contrib.auth import get_user_model

from .models import UpdateNotification


def send_update_notifications(user_model, subscribe_type):
    """
    Sending emails to users with new updates

    :return: nothing
    """
    from outset.accounts.models import Unsubscribe

    queryset = user_model.objects.filter(
        subscribe=subscribe_type,
        role__in=(user_model.FOUNDER_ROLE, user_model.ADMIN_ROLE, user_model.EMPLOYEE_ROLE)
    ).exclude(email__in=Unsubscribe.objects.all().values('email'))

    for user in queryset.all():
        if user.accelerator_id:
            UpdateNotification.objects.create(user=user).send_mail()


def send_weekly_update_notifications():
    user_model = get_user_model()
    send_update_notifications(user_model, user_model.WEEKLY_SUBSCRIBE)


def send_monthly_update_notifications():
    user_model = get_user_model()
    send_update_notifications(user_model, user_model.MONTHLY_SUBSCRIBE)


def send_quarterly_update_notifications():
    user_model = get_user_model()
    send_update_notifications(user_model, user_model.QUARTERLY_SUBSCRIBE)
