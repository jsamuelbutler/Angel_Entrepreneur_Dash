from __future__ import unicode_literals

import json
import subprocess
import tempfile
from functools import reduce
from PIL import Image, ImageFont, ImageDraw

from django.conf import settings

from outset.kpis.models import KPITrack


IMAGE_WIDTH = 600
IMAGE_HEIGHT = 310
BASE_FONT = str(settings.FONT_PATH.path('lato-regular-webfont.otf'))
ICON_FONT = str(settings.FONT_PATH.path('fontello-webfont.otf'))
ARROW_UP_ICON = '\ue8c6'
ARROW_DOWN_ICON = '\ue8c3'
COLORS = [
    '#8bc34a',
    '#673ab7',
    '#cddc39',
    '#3f51b5',
    '#ffeb3b',
    '#2196f3',
    '#ffc107',
    '#9c27b0',
    '#ff9800',
    '#ff5722',
    '#795548',
    '#B71C1C',
    '#880E4F',
    '#4A148C',
    '#f44336',
    '#311B92',
    '#e91e63',
    '#1A237E',
    '#4caf50',
    '#01579B',
    '#E65100',
    '#006064',
    '#BF360C',
    '#009688',
    '#004D40',
    '#00bcd4',
    '#1B5E20',
    '#607d8b',
    '#33691E',
    '#03a9f4',
    '#827717',
    '#F57F17'
]


def get_color_generator():
    while True:
        for color in COLORS:
            yield color


color_generator = get_color_generator()


def color():
    return next(color_generator)


def _line(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
          chartColor1, chartColor2, title):
    return {
        'chart': {'height': height, 'type': 'line'},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': (
            {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}}
        ),
        'yAxis': {'text': chartName1} if showLabels else {'title': {'text': None},
        'labels': {'enabled': False}},
        'series': (
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _area(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
          chartColor1, chartColor2, title):
    return {
        'chart': {'type': 'area', 'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None},
        'labels': {'enabled': False}},
        'plotOptions': {
            'area': {
                'marker': {
                    'enabled': False,
                    'symbol': 'circle',
                    'radius': 2,
                    'states': {'hover': {'enabled': True}}
                }
            }
        },
        'series': (
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _stack(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
           chartColor1, chartColor2, title):
    return {
        'chart': {'type': 'column', 'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None}, 'labels': {'enabled': False}},
        'plotOptions': {'column': {'stacking': 'normal'}},
        'series': (
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _scatter(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
             chartColor1, chartColor2, title):
    return {
        'chart': {'type': 'scatter', 'height': height},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None}, 'labels': {'enabled': False}},
        'credits': {'enabled': False},
        'plotOptions': {
            'scatter': {
                'marker': {
                    'radius': 5,
                    'states': {'hover': {'enabled': True, 'lineColor': 'rgb(100,100,100)'}
                    }
                },
                'states': {'hover': {'marker': {'enabled': False}}},
                'tooltip': {'headerFormat': '<b>{series.name}</b><br>', 'pointFormat': '{point.x}, {point.y}'}
            }
        },
        'series': (
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ] if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _bubble(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2, chartColor1,
            chartColor2, title):
    return {
        'chart': {'type': 'bubble', 'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None}, 'labels': {'enabled': False}},
        'series': (
            [
                {'showInLegend': False, 'color': 'rgba(105, 255, 174, 0.5)', 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': 'rgba(105, 255, 174, 0.3)', 'data': chartData1, 'name': chartName1}]
        )
    }


def _bar(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2, chartColor1,
         chartColor2, title):
    return {
        'chart': {'type': 'bar', 'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None}, 'labels': {'enabled': False}},
        'plotOptions': {},
        'series':(
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _column(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2, chartColor1,
            chartColor2, title):
    return {
        'chart': {'type': 'column', 'height': height},
        'title': {'text': title},
        'credits': {'enabled': False},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': {'text': ' '} if showLabels else {'title': {'text': None}, 'labels': {'enabled': False}},
        'plotOptions': {'column': {'pointPadding': 0.2, 'borderWidth': 0}},
        'series': (
            [
                {'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1},
                {'showInLegend': False, 'color': chartColor2, 'data': chartData2, 'name': chartName2}
            ]
            if compare else
            [{'showInLegend': False, 'color': chartColor1, 'data': chartData1, 'name': chartName1}]
        )
    }


def _bar_and_line(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
                  chartColor1, chartColor2, title):
    return {
        'chart': {'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': [
            {
                'labels': {'enabled': False},
                'title': chartName1
            },
            {
                'labels': {'enabled': False},
                'title': chartName2,
                'opposite': True
            }
        ],
        'series': [
            {
                'type': 'column',
                'yAxis': 1,
                'showInLegend': False,
                'color': chartColor1,
                'data': chartData1,
                'name': chartName1
            },
            {
                'type': 'spline',
                'showInLegend': False,
                'color': chartColor2,
                'data': chartData2,
                'name': chartName2
            }
        ]
    }


def _column_and_line(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1, chartName2,
                      chartColor1, chartColor2, title):
    return {
        'chart': {'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': [
            {
                'labels': {'enabled': False},
                'title': chartName1
            },
            {
                'labels': {'enabled': False},
                'title': chartName2,
                'opposite': True,
        }],
        'series': [{
            'type': 'column',
            'yAxis': 1,
            'showInLegend': False,
            'color': chartColor1,
            'data': chartData1,
            'name': chartName1
        }, {
            'type': 'spline',
            'showInLegend': False,
            'color': chartColor2,
            'data': chartData2,
            'name': chartName2
        }]
    }


def _stack_and_line(compare, chartLabel, chartData1, chartData2, showLabels, height, chartName1,
                    chartName2, chartColor1, chartColor2, title):
    chartData1.append({
        'type': 'spline',
        'yAxis': 1,
        'showInLegend': False,
        'color': chartColor1,
        'data': chartData2,
        'name': chartName2
    })
    return {
        'chart': {'height': height},
        'credits': {'enabled': False},
        'title': {'text': title},
        'xAxis': {'categories': chartLabel} if showLabels else {'categories': chartLabel, 'labels': {'enabled': False}},
        'yAxis': [{
            'labels': {'enabled': False},
            'title': chartName1
        }, {
            'labels': {'enabled': False},
            'title': chartName2,
            'opposite': True
        }],
        'plotOptions': {'column': {'stacking': 'normal'}},
        'series': chartData1
    }


CHART_TYPES = {
    'line':            _line,
    'area':            _area,
    'stack':           _stack,
    'scatter':         _scatter,
    'bubble':          _bubble,
    'bar':             _bar,
    'column':          _column,
    'bar_and_line':    _bar_and_line,
    'column_and_line': _column_and_line,
    'stack_and_line':  _stack_and_line,
}


def _get_options(json_data):
    params = dict(
        compare=False,
        chartLabel=[],
        chartData1=[],
        chartData2=[],
        showLabels=True,
        height=IMAGE_HEIGHT,
        chartName1=None,
        chartName2=None,
        chartColor1=color(),
        chartColor2=color(),
        title=json_data['name'],
    )
    chart_type = json_data['chart_type']
    if chart_type == KPITrack.STACK_AND_LINE_CHART:
        line = json_data['data']['series'][0]
        scope = json_data['data']['series'][1:]
        other_data = [
            dict(type='column', color=color(), showInLegend=False, data=i['data'], name=i['name']) for i in scope
        ]
        status = reduce(lambda a, b: a and b, [i['data'] for i in scope], True)
        params.update({
            'chartData1': other_data if status else [],
            'chartData2': line or [],
            'chartName1': json_data['name']
        })
    elif chart_type == KPITrack.SCATTER_CHART:
        scope = json_data['data']
        params.update({
            'chartData1': [i['data'] for i in scope],
            'chartLabel': [i['name'] for i in scope],
            'chartName1': json_data['name']
        })
    else:
        selects = json_data['selects']
        series = (
            json_data['data']['series']
            if not selects else
            json_data['data'][selects[0][0]][selects[1][0]]
            if len(selects) > 1 else
            json_data['data'][selects[0][0]]
        )

        compare = isinstance(series, (tuple, list)) and len(series) == 2
        if series:
            params.update(
                {
                    'chartData1': series[0]['data'],
                    'chartData2': series[1]['data'],
                    'chartLabel': series[0]['axis'],
                    'chartName1': series[0]['name'],
                    'chartName2': series[1]['name'],
                    'compare': True
                }
                if compare else
                {
                    'chartData1': series[0]['data'],
                    'chartLabel': series[0]['axis'],
                    'chartName1': series[0]['name'],
                    'compare': False
                }
                if isinstance(series, (list, tuple)) else
                {
                    'chartData1': series['data'],
                    'chartLabel': series['axis'],
                    'chartName1': series['name'],
                    'compare': False
                }
            )

    return CHART_TYPES[chart_type](**params)


def save_kpi_number_chart_image(json_data, filename):
    img = Image.new('RGB', (IMAGE_WIDTH, IMAGE_HEIGHT), 'white')
    draw = ImageDraw.Draw(img)
    title_font = ImageFont.truetype(BASE_FONT, 16)
    base_font = ImageFont.truetype(BASE_FONT, 42)
    percent_font = ImageFont.truetype(BASE_FONT, 22)
    percent_period_font = ImageFont.truetype(BASE_FONT, 16)
    icon_font = ImageFont.truetype(ICON_FONT, 22)

    title = json_data['name']
    percent = json_data['diffs']['month']['percent']
    percent_text = '{}%'.format(abs(percent or 0))
    percent_period = 'since last month'
    value = str(json_data['data']['current'])
    z = ARROW_UP_ICON if percent > 0 else ARROW_DOWN_ICON if percent < 0 else ''

    percent_width, percent_height = draw.textsize(percent_text, font=percent_font)
    percent_period_width, percent_period_height = draw.textsize(percent_period, font=percent_period_font)
    value_width, value_height = draw.textsize(value, font=base_font)
    z_width, z_height = draw.textsize(z, font=icon_font)

    draw.multiline_text((15, 20), title, fill='black', font=title_font, spacing=6, align='left')
    draw.text(
        ((IMAGE_WIDTH-value_width)/2, (IMAGE_HEIGHT+25-value_height)/2),
        value,
        fill=color(),
        font=base_font
    )
    percent_x = IMAGE_WIDTH - 20 - percent_width
    percent_y = IMAGE_HEIGHT - 45 - percent_height
    draw.text((percent_x, percent_y), percent_text, fill='#868686', font=percent_font)
    draw.text(
        (percent_x-5-z_width, percent_y-(z_height-percent_height)/2),
        z,
        fill='#26e8a4' if percent > 0 else '#e57373',
        font=icon_font
    )
    draw.text(
        (IMAGE_WIDTH-20-percent_period_width, percent_y + percent_height + 6),
        percent_period,
        fill='#a1acb3',
        font=percent_period_font
    )

    with open(filename, b'w') as fp:
        img.save(fp, 'PNG')


def save_kpi_chart_image(json_data, filename):
    data = json.loads(json_data) if isinstance(json_data, (bytes, str, unicode)) else json_data
    if data['chart_type'] == KPITrack.NUMBER_CHART:
        return save_kpi_number_chart_image(data, filename)
    with tempfile.NamedTemporaryFile() as fp:
        json.dump(_get_options(data), fp)
        fp.seek(0)
        process = subprocess.Popen(
            ['highcharts-export-server', '-infile', fp.name, '-outfile', filename, '-logLevel', '0']
        )
        process.wait()
