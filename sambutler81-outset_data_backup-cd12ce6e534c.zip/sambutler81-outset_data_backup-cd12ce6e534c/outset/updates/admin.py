from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from .models import Update, UpdateLink, UpdateEmail, UpdateFixedKPIChart


class UpdateLinkInline(admin.TabularInline):
    model = UpdateLink
    extra = 1


class UpdateEmailInline(admin.TabularInline):
    model = UpdateEmail
    extra = 1


class UpdateFixedKPIChartInline(admin.TabularInline):
    model = UpdateFixedKPIChart
    extra = 1
    fieldsets = (
        (None, {'fields': ('kpi_track',)}),
    )


@admin.register(Update)
class UpdateAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'created', 'updated')
    list_filter = ('created', 'updated')
    inlines = (UpdateFixedKPIChartInline, UpdateLinkInline, UpdateEmailInline)
    readonly_fields = ('created', 'updated', 'created_by')
    fieldsets = (
        (None, {
            'fields': ('title', 'startup', 'overview')
        }),
        (_('Customer Pipeline Updates'), {
            'fields': ('cpu_good_updates', 'cpu_negative_updates', 'cpu_need_help'),
            'classes': ('collapse',)
        }),
        (_('Partnership Updates'), {
            'fields': ('pau_good_updates', 'pau_negative_updates', 'pau_need_help'),
            'classes': ('collapse',)
        }),
        (_('Personal Updates'), {
            'fields': ('peu_good_updates', 'peu_negative_updates', 'peu_need_help'),
            'classes': ('collapse',)
        }),
        (_('Product Updates'), {
            'fields': ('pru_good_updates', 'pru_negative_updates', 'pru_need_help'),
            'classes': ('collapse', )
        }),
        (_('Fundraising Updates'), {
            'fields': ('fu_good_updates', 'fu_negative_updates', 'fu_need_help'),
            'classes': ('collapse',)
        }),
        (_('Others'), {
            'fields': ('next_focus', 'thank_yous'),
        }),
        (_('Statistics'), {
            'fields': ('created', 'updated', 'created_by')
        })
    )

    def save_model(self, request, obj, form, change):
        if change is False:
            obj.created_by = request.user
        return super(UpdateAdmin, self).save_model(request, obj, form, change)
