from django import template
from django.template.defaultfilters import stringfilter
from django.utils.safestring import mark_safe


register = template.Library()


NAMES = ['Positive Updates', 'Negative Updates', 'Where you can help?']


@register.filter
@stringfilter
def string_block_join(value, joiner=','):
    if not value:
        return ''
    return joiner.join(value.split('\n'))


@register.simple_tag
def update_block_html(update, block, title):
    good = getattr(update, '{}_good_updates'.format(block), None)
    negative = getattr(update, '{}_negative_updates'.format(block), None)
    help = getattr(update, '{}_need_help'.format(block), None)
    if not (good or negative or help):
        return ''
    blocks = ''.join([
        '<p style="text-align: left; font-weight: bold; margin: 0.5em 1em 0.3em">{title}</p>{elements}'.format(
            title=sub_tittle,
            elements=''.join(
                ['<p style="text-align: left; margin: 0.3em 1em 0">{}</p>'.format(i) for i in text.split('\n')]
            )
        )
        for sub_tittle, text in zip(NAMES, (good, negative, help))
    ])
    return mark_safe(
        '<p style="text-align: left; font-weight: bold; margin: 1em 0 0.3em">{title}</p>{blocks}'.format(
            title=title,
            blocks=blocks
        )
    )


@register.simple_tag
def update_block(update, block, title):
    good = getattr(update, '{}_good_updates'.format(block), None)
    negative = getattr(update, '{}_negative_updates'.format(block), None)
    help = getattr(update, '{}_need_help'.format(block), None)
    if not (good or negative or help):
        return ''
    blocks = '\n'.join([
        '\t{title}:\n{elements}'.format(
            title=sub_tittle,
            elements='\n'.join(
                ['\t\t{}'.format(i) for i in text.split('\n')]
            )
        )
        for sub_tittle, text in zip(NAMES, (good, negative, help))
    ])
    return mark_safe('{title}:\n{blocks}\n'.format(title=title, blocks=blocks))
