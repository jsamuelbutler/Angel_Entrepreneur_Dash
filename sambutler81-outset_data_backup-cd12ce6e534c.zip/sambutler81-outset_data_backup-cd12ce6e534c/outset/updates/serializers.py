from django.conf import settings
from rest_framework import serializers
from rest_framework.relations import PKOnlyObject
from rest_framework.renderers import JSONRenderer

from outset.accounts.serializers import SimpleUserSerializer
from outset.kpis.serializers import KPIChartSerializer
from outset.startups.models import Startup
from outset.startups.serializers import TinyStartupSerializer

from .models import Update, UpdateLink, UpdateEmail, UpdateFixedKPIChart, UpdateNotification


class UpdateFixedKPIChartSerializer(serializers.ModelSerializer):
    class Meta:
        model = UpdateFixedKPIChart
        fields = ('kpi_track', 'json')
        read_only_fields = ('json',)

    def validate(self, attrs):
        kpi_track = attrs.get('kpi_track', self.instance.kpi_track if self.instance else None)
        if 'request' not in self.context or self.context['request'].user.is_anonymous:
            raise serializers.ValidationError('User not found')
        if kpi_track:
            serializer = KPIChartSerializer(kpi_track, data={}, context={'user': self.context['request'].user})
            serializer.is_valid(raise_exception=True)
            attrs['json'] = JSONRenderer().render(serializer.data)
        return attrs


class StringListField(serializers.ListSerializer):
    child = serializers.CharField()
    separator = '\n'

    def to_internal_value(self, data):
        if not isinstance(data, (list, tuple)):
            return
        return self.separator.join([i for i in data if i and isinstance(i, (str, unicode))])

    def to_representation(self, data):
        return data.split(self.separator) if data else []


class StartupField(serializers.PrimaryKeyRelatedField):
    queryset = Startup.objects.all()

    def to_representation(self, value):
        instance = self.to_internal_value(value.pk) if isinstance(value, PKOnlyObject) else value
        serializer = TinyStartupSerializer(instance, context=self.context)
        return serializer.data


class UpdateSerializer(serializers.ModelSerializer):
    kpis = UpdateFixedKPIChartSerializer(many=True)
    links = serializers.ListSerializer(
        child=serializers.URLField(source='url'), required=False, allow_null=True, allow_empty=True
    )
    send_to = serializers.ListSerializer(
        child=serializers.EmailField(source='send_to'),
        required=False,
        allow_null=True,
        allow_empty=True,
        write_only=True
    )
    startup = StartupField()

    cpu_good_updates = StringListField()
    cpu_negative_updates = StringListField()
    cpu_need_help = StringListField()
    pau_good_updates = StringListField()
    pau_negative_updates = StringListField()
    pau_need_help = StringListField()
    peu_good_updates = StringListField()
    peu_negative_updates = StringListField()
    peu_need_help = StringListField()
    pru_good_updates = StringListField()
    pru_negative_updates = StringListField()
    pru_need_help = StringListField()
    fu_good_updates = StringListField()
    fu_negative_updates = StringListField()
    fu_need_help = StringListField()
    ru_good_updates = StringListField()
    ru_negative_updates = StringListField()
    ru_need_help = StringListField()
    eu_good_updates = StringListField()
    eu_negative_updates = StringListField()
    eu_need_help = StringListField()

    thank_yous = StringListField()

    created = serializers.DateTimeField(format=settings.DATE_FORMAT, read_only=True)
    created_by = SimpleUserSerializer(read_only=True)

    class Meta:
        model = Update
        fields = (
            'id', 'title', 'overview', 'cpu_good_updates', 'cpu_negative_updates', 'cpu_need_help',
            'pau_good_updates', 'pau_negative_updates', 'pau_need_help', 'peu_good_updates',
            'peu_negative_updates', 'peu_need_help', 'pru_good_updates', 'pru_negative_updates',
            'pru_need_help', 'fu_good_updates', 'fu_negative_updates', 'fu_need_help',
            'ru_good_updates', 'ru_negative_updates', 'ru_need_help', 'eu_good_updates',
            'eu_negative_updates', 'eu_need_help',
            'thank_yous', 'send_to', 'kpis', 'links', 'startup', 'created', 'created_by', 'next_focus'
        )

    def validate_startup(self, value):
        if 'request' in self.context and self.context['request'].user.startup_id != value.id:
            raise serializers.ValidationError('You does not have permissions to this a startup.')
        return value

    def validate(self, attrs):
        kpis = attrs.get('kpis', [])
        startup = attrs['startup']
        for kpi in kpis:
            if not kpi['kpi_track'].kpis.filter(startup=startup.id).exists():
                raise serializers.ValidationError('KPI startup differ from update startup.')
        if 'request' in self.context:
            attrs['created_by'] = self.context['request'].user
        return attrs

    def create(self, validated_data):
        links = validated_data.pop('links', [])
        send_to = validated_data.pop('send_to', [])
        kpis = validated_data.pop('kpis', [])
        instance = super(UpdateSerializer, self).create(validated_data)
        self.save_links(instance, links)
        self.save_send_to(instance, send_to)
        self.save_kpis(instance, kpis)
        return instance

    def update(self, instance, validated_data):
        links = validated_data.pop('links', [])
        send_to = validated_data.pop('send_to', [])
        kpis = validated_data.pop('kpis', [])
        instance = super(UpdateSerializer, self).update(instance, validated_data)
        if 'links' in self.initial_data:
            self.save_links(instance, links, replace=True)
        if 'send_to' in self.initial_data:
            self.save_send_to(instance, send_to, replace=True)
        if 'kpis' in self.initial_data:
            self.save_kpis(instance, kpis, replace=True)
        return instance

    def save_links(self, instance, links=None, replace=False):
        links = links or []
        if replace:
            UpdateLink.objects.filter(update=instance).delete()
        UpdateLink.objects.bulk_create([UpdateLink(update=instance, url=i) for i in links])

    def save_send_to(self, instance, send_to=None, replace=False):
        send_to = send_to or []
        if replace:
            UpdateEmail.objects.filter(update=instance).delete()
        UpdateEmail.objects.bulk_create(
            [UpdateEmail(update=instance, email=i) for i in set(i.lower() for i in send_to)]
        )

    def save_kpis(self, instance, kpis=None, replace=False):
        kpis = kpis or []
        if replace:
            UpdateFixedKPIChart.objects.filter(update=instance).delete()
        [UpdateFixedKPIChart.objects.create(update=instance, **i) for i in kpis]


class UpdateNotificationSerializer(serializers.ModelSerializer):
    updates = UpdateSerializer(many=True, read_only=True)

    class Meta:
        model = UpdateNotification
        fields = ('code', 'updates')
        read_only_fields = ('code',)
