from django_filters import NumberFilter, DateFilter
from django_filters.rest_framework import FilterSet
from django.db.models import DateField
from django.db.models.functions import Cast

from .models import Update


def filter_created(queryset, name, value):
    return queryset.annotate(date=Cast(name, output_field=DateField())).filter(date=value)


class UpdateFilter(FilterSet):
    cohort = NumberFilter(name='startup__cohort', distinct=False)
    created = DateFilter(name='created', method=filter_created)

    class Meta:
        model = Update
        fields = ('startup', 'cohort', 'created')
