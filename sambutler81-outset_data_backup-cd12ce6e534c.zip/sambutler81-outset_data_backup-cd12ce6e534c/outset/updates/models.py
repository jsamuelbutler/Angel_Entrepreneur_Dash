from __future__ import unicode_literals

from collections import defaultdict
from datetime import timedelta
from decimal import Decimal
from tempfile import NamedTemporaryFile
import uuid

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.postgres.fields import JSONField
from django.contrib.sites.models import Site
from django.core.files import File
from django.core.mail import EmailMultiAlternatives
from django.db import models
from django.db.models import F, Sum
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.template.loader import render_to_string
from django.utils import formats
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel

from outset.accounts.models import Unsubscribe
from outset.kpis.consts import (
    DAYS_TO_LIVE_KPI, NET_BURN_KPI, REVENUE_KPI, ANNUAL_RUN_RATE_KPI, REVENUE_CHURN_KPI,
    CUSTOMER_CHURN_KPI
)
from outset.kpis.models import KPI, KPIValue
from outset.startups.models import Startup

from .images import save_kpi_chart_image


SEPARATED_ROWS = _('Rows separated by new line.')
STARTUP_WITHOUT_UPDATE_NOTIFICATION_DAYS = 90


class Update(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    BLOCKS = (
        ('ru', 'Revenue Updates'),
        ('eu', 'Expense Updates'),
        ('cpu', 'Customer Pipeline Updates'),
        ('pau', 'Partnership Updates'),
        ('peu', 'Personnel Updates'),
        ('pru', 'Product Updates'),
        ('fu', 'Fundraising Updates')
    )

    title = models.CharField(_('title'), max_length=180)
    overview = models.TextField(_('overview'))

    # customer_pipeline_updates
    cpu_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    cpu_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    cpu_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # partnership_updates
    pau_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    pau_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    pau_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # personal_updates
    peu_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    peu_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    peu_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # product_updates
    pru_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    pru_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    pru_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # fundraising_updates
    fu_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    fu_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    fu_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # revenue update
    ru_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    ru_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    ru_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    # expense update
    eu_good_updates = models.TextField(_('Good Updates'), blank=True, help_text=SEPARATED_ROWS)
    eu_negative_updates = models.TextField(_('Negative Updates'), blank=True, help_text=SEPARATED_ROWS)
    eu_need_help = models.TextField(_('Where you can help'), blank=True, help_text=SEPARATED_ROWS)

    next_focus = models.TextField(_('next 90 day focus'), blank=True)
    thank_yous = models.TextField(_('any people to thanks'), blank=True, help_text=SEPARATED_ROWS)

    startup = models.ForeignKey(Startup, verbose_name=_('startup'))

    created = models.DateTimeField(_('created'), auto_now_add=True)
    updated = models.DateTimeField(_('updated'), auto_now=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name=_('created by'))

    def __str__(self):
        return _('Update on "{}" {}').format(formats.date_format(self.created, 'SHORT_DATE_FORMAT'), self.title)

    def send_email(self):
        result = True
        for email in self.send_to.exclude(email__in=Unsubscribe.objects.all().values('email')):
            subject, text, html = self.render_templates(email=email)
            msg = EmailMultiAlternatives(
                subject=subject,
                body=text,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[email],
                reply_to=[settings.DEFAULT_FROM_EMAIL]
            )
            msg.attach_alternative(html, "text/html")
            try:
                result &= msg.send()
            except Exception:
                result = False
        return result

    def render_templates(self, email):
        context = self.get_context(email)
        subject, text, html = self.get_templates()
        return (
            render_to_string(subject, context),
            render_to_string(text, context),
            render_to_string(html, context),
        )

    def get_context(self, email):
        site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())
        user = get_user_model().objects.filter(email=email).first()
        return {
            'site': site,
            'user': user.recognize if user else email,
            'update': self,
        }

    @staticmethod
    def get_templates():
        base = 'update'
        return [t.format(base) for t in ('emails/{}_subject.txt', 'emails/{}.txt', 'emails/{}.html')]


class UpdateLink(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    update = models.ForeignKey(Update, on_delete=models.CASCADE, related_name='links', verbose_name=_('update'))
    url = models.URLField()

    def __str__(self):
        return self.url


class UpdateEmail(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    update = models.ForeignKey(Update, on_delete=models.CASCADE, related_name='send_to', verbose_name=_('update'))
    email = models.EmailField(max_length=255)

    def __str__(self):
        return self.email


class UpdateFixedKPIChart(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    update = models.ForeignKey(Update, on_delete=models.CASCADE, related_name='kpis', verbose_name=_('update'))
    kpi_track = models.ForeignKey(
        'kpis.KPITrack', verbose_name=_('KPI Chart'), on_delete=models.SET_NULL, null=True, blank=True
    )
    json = JSONField(_('KPI Chart JSON'))
    image = models.ImageField(_('KPI Chart figure'), upload_to='fixed_kpi/', null=True, blank=True)


def unique_notification_code():
    code = None
    while code is None or UpdateNotification.objects.filter(code=code).exists():
        code = uuid.uuid4()
    return code


def _kpi_value(kpi_value, default=Decimal(0)):
    return (kpi_value.value or default) if kpi_value else default


def _growth_percent(last, new):
    if not last:
        return Decimal(100) if new else Decimal(0)
    return Decimal(100)*((new or Decimal(0))/last - Decimal(1))


class UpdateNotification(SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='notifications', on_delete=models.CASCADE)

    created = models.DateTimeField(auto_now_add=True, editable=False)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return 'Update Notification for {user} on {date}'.format(user=str(self.user), date=self.created)

    def send_mail(self):
        # if Unsubscribe.objects.filter(email=self.user.email).exists():
        #     return False
        subject, text, html = self.render_templates()
        msg = EmailMultiAlternatives(
            subject=subject,
            body=text,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[self.user.email],
            reply_to=[settings.DEFAULT_FROM_EMAIL]
        )
        msg.attach_alternative(html, "text/html")
        try:
            result = msg.send()
        except Exception:
            result = None
        return result

    def render_templates(self):
        context = self.get_context()
        subject, text, html = self.get_templates()
        return (
            render_to_string(subject, context),
            render_to_string(text, context),
            render_to_string(html, context),
        )

    def get_context(self):
        site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())

        context = self.get_accelerator_context() if self.user.accelerator_id else self.get_startup_context()
        context.update(dict(user=self.user, site=site))
        return context

    def get_notification_periods(self):
        today = now()
        if self.user.subscribe == self.user.QUARTERLY_SUBSCRIBE:
            start_quarter_date = (today - timedelta(days=80)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            end_last_quarter_date = start_quarter_date - timedelta(days=1)
            start_last_quarter_date = end_last_quarter_date.replace(day=1)
            period = (start_quarter_date, today)
            last_period = (start_last_quarter_date, end_last_quarter_date)
        else:
            start_month_date = (today - timedelta(days=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            end_last_month_date = start_month_date - timedelta(days=1)
            start_last_month_date = end_last_month_date.replace(day=1)
            period = (start_month_date, today)
            last_period = (start_last_month_date, end_last_month_date)
        return period, last_period

    def get_accelerator_context(self):
        period, last_period = self.get_notification_periods()

        startups = Startup.objects.available_to_user(self.user).annotate(
            cohort_name=F('cohort__name'),
            update_created=F('update__created')
        ).order_by('cohort_name', 'name', '-update__created').distinct('cohort_name', 'name')

        startups_data = defaultdict(list)
        for startup in startups:
            kpi_queryset = KPI.objects.filter(startup=startup, base__in=(DAYS_TO_LIVE_KPI, NET_BURN_KPI))
            current = {
                kpi.base_id: kpi.value
                for kpi in kpi_queryset.with_value(period[1])
            }
            last = {
                kpi.base_id: kpi.value
                for kpi in kpi_queryset.with_value(last_period[1])
            }

            # kpi per month to calculate total revenue
            revenue_queryset = KPIValue.objects.filter(kpi__base=REVENUE_KPI, kpi__startup=startup)
            last_total_revenue = (
                revenue_queryset.filter(created__lte=last_period[1]).aggregate(Sum('value'))['value__sum'] or Decimal(0)
            )
            total_revenue = last_total_revenue + (
                 revenue_queryset.filter(created__range=period).aggregate(Sum('value'))['value__sum'] or Decimal(0)
            )

            startups_data[startup.cohort_name].append({
                'name': startup.name,
                'days_to_live': current.get('DAYS_TO_LIVE_KPI', 0),
                'days_to_live_percent': (
                    _growth_percent(last.get('DAYS_TO_LIVE_KPI'), current.get('DAYS_TO_LIVE_KPI', 0))
                ),
                'net_burn': current.get('NET_BURN_KPI', 0),
                'net_burn_percent': _growth_percent(last.get('NET_BURN_KPI', 0), current.get('NET_BURN_KPI', 0)),
                'total_revenue': total_revenue,
                'total_revenue_percent': _growth_percent(last_total_revenue, total_revenue),
                'last_notification_date': startup.update_created,
                'days_from_last_notification': (
                    (period[1] - startup.update_created).days if startup.update_created else '-'
                )
            })

        # ranked from least to most by Amount of Days to Live
        for startup_list in startups_data.values():
            startup_list.sort(key=lambda x: x['days_to_live'])

        # The template variable resolution algorithm in Django will attempt to
        # resolve new_data.items as new_data['items'] first, which resolves to
        # an empty list when using defaultdict(list).
        # So, fix it by remove default factory
        startups_data.default_factory = None

        return dict(updated_startups=startups_data)

    def get_startup_context(self):
        startup = self.user.startup
        period, last_period = self.get_notification_periods()
        kpi_queryset = startup.kpis.with_value().filter(base__in=(
            REVENUE_KPI, ANNUAL_RUN_RATE_KPI, DAYS_TO_LIVE_KPI, NET_BURN_KPI, REVENUE_CHURN_KPI, CUSTOMER_CHURN_KPI,
        ))
        current = {
            kpi.base_id: kpi.value
            for kpi in kpi_queryset.with_value(period[1])
        }
        last = {
            kpi.base_id: kpi.value
            for kpi in kpi_queryset.with_value(last_period[1])
        }
        return {
            'name': startup.name,
            'revenue': current.get(REVENUE_KPI),
            'revenue_percent': _growth_percent(last.get(REVENUE_KPI), current.get(REVENUE_KPI)),
            'annual_run_rate': current.get(ANNUAL_RUN_RATE_KPI),
            'annual_run_rate_percent': _growth_percent(last.get(ANNUAL_RUN_RATE_KPI), current.get(ANNUAL_RUN_RATE_KPI)),
            'days_to_live': current.get(DAYS_TO_LIVE_KPI),
            'days_to_live_percent': _growth_percent(last.get(DAYS_TO_LIVE_KPI), current.get(DAYS_TO_LIVE_KPI)),
            'net_burn': current.get(NET_BURN_KPI),
            'net_burn_percent': _growth_percent(last.get(NET_BURN_KPI), current.get(NET_BURN_KPI)),
            'revenue_churn': current.get(REVENUE_CHURN_KPI),
            'revenue_churn_percent': _growth_percent(last.get(REVENUE_CHURN_KPI), current.get(REVENUE_CHURN_KPI)),
            'customer_churn': current.get(CUSTOMER_CHURN_KPI),
            'customer_churn_percent': _growth_percent(last.get(CUSTOMER_CHURN_KPI), current.get(CUSTOMER_CHURN_KPI)),
        }

    def get_templates(self):
        base = ('accelerator_update' if self.user.accelerator_id else 'startup_update')
        return [t.format(base) for t in ('emails/{}_subject.txt', 'emails/{}.txt', 'emails/{}.html')]


@receiver(post_save, sender=UpdateFixedKPIChart)
def save_kpi_chart_image_handler(sender, instance, created=True, raw=False, using=None, update_fields=None, **kwargs):
    if not instance.image and instance.json:
        with NamedTemporaryFile() as fp:
            save_kpi_chart_image(instance.json, filename=fp.name)
            instance.image.save('{}.png'.format(instance.kpi_track_id), File(fp))
