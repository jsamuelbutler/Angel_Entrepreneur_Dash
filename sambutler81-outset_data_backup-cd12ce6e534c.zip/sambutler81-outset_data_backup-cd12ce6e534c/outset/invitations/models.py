from __future__ import unicode_literals

try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

import uuid
from django.db import models
from django.db.models.functions import Now
from django.conf import settings
from django.contrib.sites.models import Site
from django.core.mail import EmailMultiAlternatives
from django.core.urlresolvers import reverse
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.http import urlsafe_base64_encode
from safedelete.config import SOFT_DELETE_CASCADE
from safedelete.models import SafeDeleteModel

from outset.models import ModelDiffMixin
from outset.accounts.models import Unsubscribe, User, CohortWatcher, StartupWatcher


def unique_invite_key():
    code = None
    while code is None or Invite.objects.filter(key=code, accepted=False).exists():
        code = uuid.uuid4()
    return code


class Invite(ModelDiffMixin, SafeDeleteModel):
    _safedelete_policy = SOFT_DELETE_CASCADE

    first_name = models.CharField(max_length=30, blank=True)
    last_name = models.CharField(max_length=30, blank=True)
    email = models.EmailField()
    message = models.TextField(blank=True, null=True)
    invited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='invite_set', on_delete=models.CASCADE
    )
    accepted_by = models.OneToOneField(
        settings.AUTH_USER_MODEL, null=True, blank=True, related_name='invite', on_delete=models.CASCADE
    )
    accelerator = models.ForeignKey('accelerators.Accelerator', on_delete=models.CASCADE, null=True, blank=True)
    cohort = models.ForeignKey('accelerators.Cohort', on_delete=models.CASCADE, null=True, blank=True)
    startup = models.ForeignKey('startups.Startup', on_delete=models.CASCADE, null=True, blank=True)
    role = models.CharField(max_length=8, choices=User.ROLE_CHOICES, default=User.FOUNDER_ROLE)
    key = models.UUIDField(default=unique_invite_key, editable=False)
    accepted = models.BooleanField(default=False)  # Need to remove field after disclose 'accepted_by' for all invites.
    created = models.DateTimeField(default=timezone.now)
    sent = models.DateTimeField(null=True)
    subscribe = models.BooleanField(default=True)

    def __unicode__(self):
        return self.email

    @property
    def name(self):
        return '{} {}'.format(self.first_name, self.last_name)

    @property
    def display_name(self):
        return self.invited_by.recognize

    def save(self, *args, **kwargs):
        assert self.startup or self.accelerator
        self.email = self.email.lower()
        super(Invite, self).save(*args, **kwargs)

    def render_templates(self):
        context = self.get_context()
        return (
            render_to_string('emails/invite_subject.txt', context),
            render_to_string('emails/invite.txt', context),
            render_to_string('emails/invite.html', context),
        )

    def get_context(self):
        site = 'http{}://{}'.format('s' if settings.USE_SSL else '', Site.objects.get_current())

        context = dict(
            name=self.name,
            email=self.email,
            token=self.token,
            invited_by=self.invited_by,
            accepted_by=self.accepted_by,
            accelerator=self.accelerator,
            startup=self.startup,
            message=self.message,
            site=site,
        )

        if self.role == User.WATCHER_ROLE:
            if not self.accepted_by_id:
                user = User(
                    email=self.email,
                    role=self.role,
                    first_name=self.first_name,
                    last_name=self.last_name,
                    startup=self.startup,
                    accelerator=self.accelerator
                )
                password = User.objects.make_random_password()
                user.set_password(password)
                user.save()
                self.accepted_by = user
                self.save(update_fields=['accepted_by'])
                context['password'] = password
            if self.cohort_id:
                CohortWatcher.objects.create(user=self.accepted_by, cohort_id=self.cohort_id)
            if self.startup_id:
                StartupWatcher.objects.create(user=self.accepted_by, startup_id=self.startup_id)
            context.update(dict(
                startups=self.accepted_by.companies_views.all(),
                cohorts=self.accepted_by.cohorts_views.all(),
                invite=urljoin(site, '/'),
            ))
        else:
            context.update(dict(
                startup=self.startup,
                invite=urljoin(site, self.get_accept_url())
            ))

        return context

    @property
    def token(self):
        return urlsafe_base64_encode('{}:app-outset'.format(self.email))

    def send_mail(self):
        if Unsubscribe.objects.filter(email=self.email).exists():
            return False

        subject, text, html = self.render_templates()
        msg = EmailMultiAlternatives(
            subject=subject,
            body=text,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[self.email],
            reply_to=[settings.DEFAULT_FROM_EMAIL]
        )
        msg.attach_alternative(html, "text/html")
        try:
            result = msg.send()
        except Exception:
            result = None
        else:
            Invite.objects.filter(id=self.id).update(sent=Now())
        return result

    def get_accept_url(self):
        return reverse('signup-invite', kwargs=dict(invite=self.key))

