# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.utils.timezone
from django.conf import settings
import uuid


class Migration(migrations.Migration):

    dependencies = [
        ('startups', '0002_auto_20151007_1850'),
        ('accelerators', '0002_auto_20151006_1658'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Invite',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=30)),
                ('email', models.EmailField(max_length=254)),
                ('role', models.CharField(max_length=8, choices=[(b'founder', b'Founder'), (b'employee', b'Employee')])),
                ('key', models.UUIDField(default=uuid.uuid4, editable=False)),
                ('accepted', models.BooleanField(default=False)),
                ('created', models.DateTimeField(default=django.utils.timezone.now)),
                ('sent', models.DateTimeField(null=True)),
                ('accelerator', models.ForeignKey(blank=True, to='accelerators.Accelerator', null=True)),
                ('invited_by', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
                ('startup', models.ForeignKey(blank=True, to='startups.Startup', null=True)),
            ],
        ),
    ]
