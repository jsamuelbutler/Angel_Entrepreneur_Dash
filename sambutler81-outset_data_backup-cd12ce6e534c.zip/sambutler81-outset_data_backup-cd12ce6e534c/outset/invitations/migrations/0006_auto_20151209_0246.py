# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('invitations', '0005_auto_20151113_0219'),
    ]

    operations = [
        migrations.AlterField(
            model_name='invite',
            name='role',
            field=models.CharField(max_length=8, choices=[(b'founder', b'Founder'), (b'employee', b'Employee'), (b'watcher', b'Watcher')]),
        ),
    ]
