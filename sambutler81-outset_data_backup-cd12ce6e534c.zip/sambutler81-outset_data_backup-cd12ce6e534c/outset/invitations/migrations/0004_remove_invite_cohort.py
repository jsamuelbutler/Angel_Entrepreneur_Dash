# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('invitations', '0003_auto_20151020_1858'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='invite',
            name='cohort',
        ),
    ]
