# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('accelerators', '0004_auto_20151013_1415'),
        ('invitations', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='invite',
            name='cohort',
            field=models.ForeignKey(blank=True, to='accelerators.Cohort', null=True),
        ),
        migrations.AlterField(
            model_name='invite',
            name='name',
            field=models.CharField(max_length=30, blank=True),
        ),
    ]
