import django_filters
from rest_framework import filters, mixins, response, status
from rest_framework.decorators import detail_route
from rest_framework.viewsets import GenericViewSet
from rest_framework.serializers import Serializer
from rest_framework.settings import api_settings

from .filters import InviteFilter
from .models import Invite
from .permissions import InvitePermission
from .serializers import InviteSerializer


class InviteViewSet(mixins.RetrieveModelMixin,
                    mixins.DestroyModelMixin,
                    mixins.ListModelMixin,
                    GenericViewSet):
    """
    list:
        List of created invites by the current user
    """
    queryset = Invite.objects.all()
    serializer_class = InviteSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [InvitePermission]
    filter_backends = (filters.SearchFilter, django_filters.rest_framework.DjangoFilterBackend)
    filter_class = InviteFilter
    search_fields = ('email', 'first_name', 'last_name')

    def get_queryset(self):
        if self.request.user.is_anonymous:
            return self.queryset.none()
        return self.queryset.filter(invited_by=self.request.user).exclude(accepted_by=self.request.user)

    @detail_route(methods=['post'], serializer_class=Serializer)
    def resend(self, request, pk):
        instance = self.get_object()
        instance.send_mail()
        return response.Response(status=status.HTTP_201_CREATED)

