from django.core.exceptions import ValidationError
from django.core.validators import EmailValidator
from rest_framework import serializers

from outset.accounts.models import User

from .models import Invite


class InviteTeamMemberSerializer(serializers.ModelSerializer):
    allow_roles = None

    emails = serializers.CharField(write_only=True, required=True)

    def validate_emails(self, value):
        emails = [i.strip() for i in value.split(',')]
        invalid_emails = []
        validate = EmailValidator()
        for email in emails:
            try:
                validate(email)
            except ValidationError:
                invalid_emails.append(email)
        if invalid_emails:
            raise serializers.ValidationError('Invalid emails: {}'.format(', '.join(invalid_emails)))
        if not emails:
            raise serializers.ValidationError('Not found any email address.')

        return set(i.lower() for i in emails)

    def extra_allow_role_rule(self, value):
        return True

    def validate_role(self, value):
        if self.allow_roles and value not in self.allow_roles or not self.extra_allow_role_rule(value):
            raise serializers.ValidationError('Does not allow to create the invites to the {}s.'.format(value))
        return value

    def validate(self, validated_data):
        if 'request' in self.context:
            emails = validated_data['emails']
            exist_invite_emails = Invite.objects.filter(
                email__in=emails,
                startup=validated_data.get('startup'),
                accelerator=validated_data.get('accelerator'),
                accepted_by__isnull=True,
            ).values_list('email', flat=True)
            if exist_invite_emails:
                raise serializers.ValidationError(
                    'Already there are invites for users with emails: {}'.format(exist_invite_emails)
                )
            exist_user_emails = User.objects.filter(email__in=emails).values_list('email', flat=True)
            if exist_user_emails:
                raise serializers.ValidationError('Emails are already used by users: {}'.format(exist_user_emails))
        return validated_data

    def update(self, instance, validated_data):
        raise NotImplemented('Not allow update invites with email list.')

    def create(self, validated_data):
        if 'request' in self.context:
            validated_data['invited_by'] = self.context['request'].user
        return self.create_invites(validated_data)

    @staticmethod
    def create_invites(validated_data):
        emails = validated_data['emails']

        defaults = dict(
            startup=validated_data.get('startup'),
            accelerator=validated_data.get('accelerator'),
            role=validated_data.get('role', User.FOUNDER_ROLE),
            message=validated_data.get('message', ''),
            invited_by=validated_data.get('invited_by'),
        )

        for email in emails:
            invite = Invite.objects.create(email=email, **defaults)
            invite.send_mail()
        return {}

    class Meta:
        model = Invite
        fields = ('emails', 'role', 'message')
        extra_kwargs = {'message': {'required': True, 'allow_null': False, 'allow_blank': False, 'write_only': True}}


class InviteWatcherSerializer(InviteTeamMemberSerializer):
    allow_roles = User.WATCHER_ROLE,


class InviteAcceleratorTeamMemberSerializer(InviteTeamMemberSerializer):
    allow_roles = (User.ADMIN_ROLE, User.EMPLOYEE_ROLE)


class InviteStartupTeamMemberSerializer(InviteTeamMemberSerializer):
    allow_roles = (User.FOUNDER_ROLE, User.EMPLOYEE_ROLE, User.WATCHER_ROLE)

    def extra_allow_role_rule(self, value):
        user_accelerator = self.context['request'].user.accelerator_id
        return value != User.EMPLOYEE_ROLE and user_accelerator or value != User.FOUNDER_ROLE and not user_accelerator


class InviteSerializer(serializers.ModelSerializer):
    invited_by = serializers.SlugRelatedField(
        read_only=True,
        slug_field='account_type'
    )

    class Meta:
        model = Invite
        fields = (
            'id', 'first_name', 'last_name', 'email', 'created', 'subscribe', 'accepted',
            'role', 'accelerator', 'startup', 'display_name', 'invited_by', 'accepted_by'
        )
        read_only_fields = ('id', 'display_name', 'created', 'accepted', 'invited_by', 'accepted_by')

    def create(self, validated_data):
        invite = Invite.objects.create(
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            email=validated_data.get('email', ''),
            accelerator=validated_data.get('accelerator'),
            startup=validated_data.get('startup'),
            invited_by=self.context['request'].user,
            role=validated_data.get('role'),
        )
        invite.send_mail()
        return invite

    def update(self, instance, validated_data):
        instance.accepted = False
        instance.first_name = validated_data.get('first_name')
        instance.last_name = validated_data.get('last_name')
        instance.role = validated_data.get('role')
        instance.invited_by = self.context['request'].user
        instance.save()
        instance.send_mail()
        return instance

