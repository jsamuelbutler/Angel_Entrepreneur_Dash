from django_filters import CharFilter, NumberFilter
from django_filters.rest_framework import FilterSet

from .models import Invite


class InviteFilter(FilterSet):
    exclude_role = CharFilter(name='role', exclude=True)
    startup_accelerator = NumberFilter(name='startup__cohort__accelerator_id')

    class Meta:
        model = Invite
        fields = ('role', 'accelerator', 'startup', 'startup_accelerator', 'exclude_role')
