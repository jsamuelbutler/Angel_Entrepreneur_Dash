from outset.accounts.permissions import IsAcceleratorFounderOrStartupFounderOrReadOnly

from .models import Invite


class InvitePermission(IsAcceleratorFounderOrStartupFounderOrReadOnly):
    def has_object_permission(self, request, view, obj):
        user = request.user
        return (
            super(InvitePermission, self).has_object_permission(request, view, obj) and
            isinstance(obj, Invite) and
            (user.startup_id and obj.startup_id or user.accelerator_id)
        )
