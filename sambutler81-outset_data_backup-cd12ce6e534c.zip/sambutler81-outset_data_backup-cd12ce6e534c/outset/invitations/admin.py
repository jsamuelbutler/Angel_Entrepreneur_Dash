from django.contrib import admin, messages
from django.utils.translation import ugettext_lazy as _

from django_object_actions import DjangoObjectActions

from .models import Invite


@admin.register(Invite)
class InviteAdmin(DjangoObjectActions, admin.ModelAdmin):
    list_display = ('email', 'first_name', 'last_name', 'invited_by', 'accepted_by')
    search_fields = ('email', 'first_name', 'last_name')
    change_actions = ('send',)

    def send(self, request, obj):
        if obj.accepted:
            self.message_user(request, _('This Invite is already accepted.'), messages.WARNING)
        else:
            obj.send_mail()
            self.message_user(request, _('Invite send.'), messages.SUCCESS)
    send.label = _('Send Invite')
    send.short_description = _('Send/resend invite to user.')



