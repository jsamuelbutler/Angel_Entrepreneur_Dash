from django.test import TestCase
from django.contrib.sites.models import Site
from django.core import mail

from outset.accelerators.factories import AcceleratorFactory
from outset.accounts.factories import UserFactory
from outset.accounts.models import User
from outset.startups.factories import StartupFactory

from .models import Invite


class InviteTestCase(TestCase):
    def setUp(self):
        self.accelerator = AcceleratorFactory()
        self.startup = StartupFactory()
        self.accelerator_founder = UserFactory(
            accelerator=self.accelerator, role=User.FOUNDER_ROLE)
        self.startup_founder = UserFactory(startup=self.startup, role=User.FOUNDER_ROLE)
        first_name = 'Peter'
        last_name = 'Peterson'
        self.name = ' '.join([first_name, last_name])
        self.email = 'person@mail.com'
        self.accelerator_to_startup = Invite.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=self.email,
            invited_by=self.accelerator_founder,
            role=User.FOUNDER_ROLE,
            startup=self.startup,
        )
        self.accelerator_to_employee = Invite.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=self.email,
            invited_by=self.accelerator_founder,
            role=User.EMPLOYEE_ROLE,
            accelerator=self.accelerator,
        )
        self.startup_to_employee = Invite.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=self.email,
            invited_by=self.startup_founder,
            role=User.EMPLOYEE_ROLE,
            startup=self.startup,
        )
        # site = Site.objects.create(domain='test.com')
        self.url = 'http://{domain}/accounts/login/?invite={{}}'.format(
            domain=Site.objects.get_current().domain)

    def test_get_context_accelerator_to_startup(self):
        context = self.accelerator_to_startup.get_context()
        self.assertEquals(context, dict(
            name=self.name,
            invited_by=self.accelerator_founder,
            startup=self.startup,
            accelerator=None,
            invite=self.url.format(self.accelerator_to_startup.key),
        ))

    def test_get_context_accelerator_to_employee(self):
        context = self.accelerator_to_employee.get_context()
        self.assertEquals(context, dict(
            name=self.name,
            invited_by=self.accelerator_founder,
            startup=None,
            accelerator=self.accelerator,
            invite=self.url.format(self.accelerator_to_employee.key),
        ))

    def test_get_context_startup_to_employee(self):
        context = self.startup_to_employee.get_context()
        self.assertEquals(context, dict(
            name=self.name,
            invited_by=self.startup_founder,
            startup=self.startup,
            accelerator=None,
            invite=self.url.format(self.startup_to_employee.key),
        ))

    def test_get_templates_accelerator_to_startup(self):
        subject, text, html = self.accelerator_to_startup.get_templates()
        self.assertEquals(
            subject, 'emails/accelerator_invites_startup_subject.txt')
        self.assertEquals(
            text, 'emails/accelerator_invites_startup.txt')
        self.assertEquals(
            html, 'emails/accelerator_invites_startup.html')

    def test_get_templates_accelerator_to_employee(self):
        subject, text, html = self.accelerator_to_employee.get_templates()
        self.assertEquals(
            subject, 'emails/accelerator_invites_employee_subject.txt')
        self.assertEquals(
            text, 'emails/accelerator_invites_employee.txt')
        self.assertEquals(
            html, 'emails/accelerator_invites_employee.html')

    def test_get_templates_startup_to_employee(self):
        subject, text, html = self.startup_to_employee.get_templates()
        self.assertEquals(
            subject, 'emails/startup_invites_employee_subject.txt')
        self.assertEquals(
            text, 'emails/startup_invites_employee.txt')
        self.assertEquals(
            html, 'emails/startup_invites_employee.html')

    def test_render_templates(self):
        subject, text, html = self.accelerator_to_startup.render_templates()
        self.assertIsNotNone(subject)
        self.assertIsNotNone(text)
        self.assertIsNotNone(html)

    def test_send_mail(self):
        self.accelerator_to_startup.send_mail()
        self.assertEquals(len(mail.outbox), 1)
        self.assertEquals(mail.outbox[0].to, [self.email])
