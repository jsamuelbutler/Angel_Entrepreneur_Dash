from __future__ import unicode_literals

from datetime import timedelta
from functools import reduce

from django.db import models
from django.utils.timezone import now


AUTH_TOKEN_REFRESH_TIMEOUT = timedelta(minutes=100)


class AuthToken(models.Model):
    token = models.CharField(max_length=128)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('created',)

    @property
    def expired(self):
        return now() > self.created + AUTH_TOKEN_REFRESH_TIMEOUT


class Institution(models.Model):
    id = models.BigIntegerField(primary_key=True)
    name = models.CharField(max_length=2000)
    account_type_description = models.CharField(max_length=255)
    url_home_app = models.URLField(null=True, blank=True, max_length=1200)
    url_logon_app = models.URLField(null=True, blank=True, max_length=1200)
    url_product_app = models.URLField(null=True, blank=True, max_length=1200)
    special_text = models.TextField(null=True, blank=True)
    phone = models.CharField(max_length=600, null=True, blank=True)
    email = models.CharField(max_length=600, null=True, blank=True)
    currency = models.CharField(max_length=5)

    def __str__(self):
        return '{} ({})'.format(self.name, self.id)

    @property
    def finicity_id(self):
        return self.id

    @finicity_id.setter
    def finicity_id(self, value):
        self.id = value

    def __eq__(self, other):
        if not isinstance(other, Institution):
            return False
        return reduce(
            lambda a, b: a and b,
            [getattr(self, i.name) == getattr(other, i.name) for i in self._meta.fields]
        )

    def __ne__(self, other):
        return not self.__eq__(other)
