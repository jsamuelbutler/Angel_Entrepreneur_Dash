from __future__ import absolute_import, unicode_literals

from .models import Institution
from .utils import finicity_api


def sync_institution_list(using=None):
    new_institutions = []
    institutions = {i.id: i for i in Institution.objects.all().using(using)}
    finicity_institutions = {i.id: i for i in finicity_api().institutions()}
    for institution in finicity_institutions.values():
        institution_obj = Institution(
            id=institution.id,
            name=institution.name,
            account_type_description=institution.accountTypeDescription,
            url_home_app=institution.urlHomeApp,
            url_logon_app=institution.urlLogonApp,
            url_product_app=institution.urlProductApp,
            special_text=institution.specialText,
            phone=institution.phoneNo,
            email=institution.emailAddress,
            currency=institution.tpCurrencyCode,
        )
        exist_institution_obj = institutions.get(institution.id)
        if exist_institution_obj is None:
            new_institutions.append(institution_obj)
        elif exist_institution_obj != institution_obj:
            institution_obj.pk = exist_institution_obj.pk
            institution_obj.save()
    Institution.objects.exclude(id__in=finicity_institutions.keys()).using(using).delete()
    Institution.objects.using(using).bulk_create(new_institutions)

