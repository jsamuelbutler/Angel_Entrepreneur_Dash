from __future__ import absolute_import, unicode_literals

from django.conf import settings

from .api import FinicityAPI


PARTNER_ID = getattr(settings, 'FINICITY_PARTNER_ID', None)
PARTNER_SECRET = getattr(settings, 'FINICITY_PARTNER_SECRET', None)
APPLICATION_KEY = getattr(settings, 'FINICITY_APP_KEY', None)
PROXIES = getattr(settings, 'FINICITY_PROXIES', None)
TEST = getattr(settings, 'FINICITY_TEST', settings.DEBUG)


assert PARTNER_ID and PARTNER_SECRET and APPLICATION_KEY, 'Not configured Finicity API'


def finicity_api(state=None):
    return FinicityAPI(
        partner_id=PARTNER_ID,
        partner_secret=PARTNER_SECRET,
        app_key=APPLICATION_KEY,
        proxies=PROXIES,
        state=state,
        debug=TEST
    )
