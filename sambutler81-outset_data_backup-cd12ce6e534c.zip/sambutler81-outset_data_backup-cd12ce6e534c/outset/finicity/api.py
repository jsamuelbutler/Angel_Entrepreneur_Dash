import json
from simplejson import JSONDecodeError
import requests

from django.utils.timezone import now

from outset.utils import to_timestamp

from .models import AuthToken, AUTH_TOKEN_REFRESH_TIMEOUT


class ResponseError(Exception):
    def __init__(self, http_url, response):
        try:
            response_json = response.json()
        except JSONDecodeError:
            self.content = response.content
            response_json = {}
        else:
            self.content = None
        self.http_url = http_url
        self.http_code = response.status_code
        self.code = response_json.get('code')
        self.message = response_json.get('message')

    def __str__(self):
        return (
            'Error {}: {}'.format(self.code, self.message)
            if self.code and self.message else
            'Error: {}'.format(self.content)
        )


class APIRequestNotAllowed(Exception):
    pass


class Container(dict):
    def __init__(self, **kwargs):
        super(Container, self).__init__(**kwargs)
        self.__dict__.update(kwargs)

    # def __str__(self):
    #     return str(self.__dict__)
    #
    # def __repr__(self):
    #     return repr(self.__dict__)


class FinicityAPI(object):
    BASE_URL = 'https://api.finicity.com/aggregation'
    AUTH_API = '/v2/partners/authentication'
    INSTITUTION_API = '/v1/institutions'
    CUSTOMER_API = '/v1/customers'

    def __init__(self, partner_id, partner_secret, app_key, proxies=None, state=None, debug=True):
        self.partner_id, self.partner_secret, self.app_key = partner_id, partner_secret, app_key
        self.proxies = proxies
        self.debug = debug
        self.__auth_token = None
        self.__session = None
        if state:
            self.state = state

    @property
    def session(self):
        if self.__session:
            return self.__session
        session = requests.Session()
        session.headers = {
            'Finicity-App-Key': self.app_key,
            'Finicity-App-Token': self.auth_token,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
        if self.proxies:
            session.proxies = self.proxies
        self.__session = session
        return session

    @property
    def auth_token(self):
        if self.__auth_token and not self.__auth_token.expired:
            return self.__auth_token.token

        # try get active token from DB
        db_token = AuthToken.objects.filter(created__gte=now()-AUTH_TOKEN_REFRESH_TIMEOUT).order_by('-created').first()
        if db_token:
            self.__auth_token = db_token
            return db_token.token

        session = requests.Session()
        session.headers.update({
            'Finicity-App-Key': self.app_key,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        if self.proxies:
            session.proxies = self.proxies
        response = session.post(
            self.BASE_URL+self.AUTH_API,
            json={'partnerId': self.partner_id, 'partnerSecret': self.partner_secret}
        )

        if response.status_code != requests.codes.ok:
            raise APIRequestNotAllowed(response.status_code)

        token = response.json()['token']
        self.__auth_token = AuthToken.objects.create(token=token)
        return token

    @property
    def state(self):
        return {k: v for k, v in self.session.headers.items() if k != 'Finicity-App-Token'}

    @state.setter
    def state(self, value):
        assert isinstance(value, dict)
        self.session.headers.update(value)

    def institutions(self, institution_id=None, **kwargs):
        url = self.BASE_URL + self.INSTITUTION_API
        if institution_id:
            url += '/{}'.format(institution_id)
        response = self.session.get(url, params={i: v for i, v in kwargs.items() if i in ('search', 'start', 'limit')})
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['institutions']]

    def institution_form(self, institution_id):
        url = '{}{}/{}/loginForm'.format(self.BASE_URL, self.INSTITUTION_API, institution_id)
        response = self.session.get(url)
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['loginForm']]

    def get_customers(self, **kwargs):
        url = self.BASE_URL + self.CUSTOMER_API
        kwargs['type'] = 'testing' if self.debug else 'active'
        response = self.session.get(
            url,
            params={i: v for i, v in kwargs.items() if i in ('search', 'username', 'start', 'limit', 'type')}
        )
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['customers']]

    def get_customer(self, customer_id):
        url = '{}{}/{}'.format(self.BASE_URL, self.CUSTOMER_API, customer_id)
        response = self.session.get(url)
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return Container(**response.json())

    def add_customer(self, username, first_name=None, last_name=None):
        url = '{}{}/{}'.format(self.BASE_URL, self.CUSTOMER_API, 'testing' if self.debug else 'active')
        response = self.session.post(
            url, data=json.dumps({'username': username, 'firstName': first_name or '', 'lastName': last_name or ''})
        )
        if response.status_code != requests.codes.created:
            raise ResponseError(url, response)
        return Container(**response.json())

    def delete_customer(self, customer_id):
        url = '{}/v1/customers/{}'.format(self.BASE_URL, customer_id)
        response = self.session.delete(url)
        if response.status_code != requests.codes.no_content:
            raise ResponseError(url, response)
        return Container()

    def add_account(self, customer_id, institution_id, credentials=None):
        url = '{}{}/{}/institutions/{}/accounts'.format(self.BASE_URL, self.CUSTOMER_API, customer_id, institution_id)
        credentials = credentials or []
        response = self.session.post(url, json={'credentials': credentials})

        if response.status_code == requests.codes.non_authoritative_info:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
            return response.json()
        elif response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['accounts']]

    def add_all_accounts(self, customer_id, institution_id, credentials=None):
        url = '{}{}/{}/institutions/{}/accounts/addall'.format(
            self.BASE_URL, self.CUSTOMER_API, customer_id, institution_id
        )
        credentials = credentials or []
        response = self.session.post(url, json={'credentials': credentials})

        if response.status_code == requests.codes.non_authoritative_info:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
            return response.json()
        elif response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        # requests.codes.ok means that all accounts have been added
        return [Container(**i) for i in response.json()['accounts']]

    def add_account_mfa(self, customer_id, institution_id, mfa_challenges):
        url = '{}{}/{}/institutions/{}/accounts/mfa'.format(
            self.BASE_URL, self.CUSTOMER_API, customer_id, institution_id
        )
        response = self.session.post(url, json={'mfaChallenges': mfa_challenges})
        if 'MFA-Session' in response.headers:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
        if response.status_code == requests.codes.non_authoritative_info:
            return response.json()
        elif response.status_code != requests.codes.ok:
            if 'MFA-Session' in self.session.headers:
                # MFA session is already expired
                del self.session.headers['MFA-Session']
            raise ResponseError(url, response)
        del self.session.headers['MFA-Session']
        return [Container(**i) for i in response.json()['accounts']]

    def add_all_accounts_mfa(self, customer_id, institution_id, mfa_challenges):
        url = '{}{}/{}/institutions/{}/accounts/addall/mfa'.format(
            self.BASE_URL, self.CUSTOMER_API, customer_id, institution_id
        )
        response = self.session.post(url, json={'mfaChallenges': mfa_challenges})
        if 'MFA-Session' in response.headers:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
        if response.status_code == requests.codes.non_authoritative_info:
            return response.json()
        elif response.status_code != requests.codes.ok:
            if 'MFA-Session' in self.session.headers:
                # MFA session is already expired
                del self.session.headers['MFA-Session']
            raise ResponseError(url, response)
        del self.session.headers['MFA-Session']
        # requests.codes.ok means that all accounts have been added
        return [Container(**i) for i in response.json()['accounts']]

    def refresh_institution_login_accounts(self, customer_id, institution_login_id):
        url = '{}{}/{}/institutionLogins/{}/accounts'.format(
            self.BASE_URL, self.CUSTOMER_API, customer_id, institution_login_id
        )
        response = self.session.post(url)
        if 'MFA-Session' in response.headers:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
        if response.status_code == requests.codes.non_authoritative_info:
            return response.json()
        elif response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return []

    def refresh_institution_login_accounts_mfa(self, customer_id, institution_login_id, mfa_challenges):
        url = '{}{}/{}/institutionLogins/{}/accounts/mfa'.format(
            self.BASE_URL, self.CUSTOMER_API, customer_id, institution_login_id
        )
        response = self.session.post(url, json=mfa_challenges)
        if 'MFA-Session' in response.headers:
            self.session.headers.update({'MFA-Session': response.headers['MFA-Session']})
        if response.status_code == requests.codes.non_authoritative_info:
            return response.json()
        elif response.status_code != requests.codes.ok:
            if 'MFA-Session' in self.session.headers:
                # MFA session is already expired
                del self.session.headers['MFA-Session']
            raise ResponseError(url, response)
        del self.session.headers['MFA-Session']
        # requests.codes.ok means that all accounts have been added
        return []

    def activate_customer_accounts(self, customer_id, institution_id, accounts):
        url = '{}/v2/customers/{}/institutions/{}/accounts'.format(self.BASE_URL, customer_id, institution_id)
        response = self.session.put(url, json={'accounts': accounts})
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['accounts']]

    def get_customer_accounts(self, customer_id, institution_id):
        url = '{}{}/{}/institutions/{}/accounts'.format(self.BASE_URL, self.CUSTOMER_API, customer_id, institution_id)
        response = self.session.get(url)
        if response.status_code != requests.codes.ok:
            raise ResponseError(url, response)
        return [Container(**i) for i in response.json()['accounts']]

    def get_customer_transaction(self, customer_id, from_date, to_date, **kwargs):
        from_date = to_timestamp(from_date)
        to_date = to_timestamp(to_date)
        url = '{}/v3/customers/{}/transactions'.format(self.BASE_URL, customer_id)
        response_data = None
        start = kwargs.get('start', 1)
        while response_data is None or 'moreAvailable' in response_data and response_data['moreAvailable'] == 'true':
            data = {k: v for k, v in kwargs.items() if k in ('limit', 'sort', 'includePending')}
            data.update({'fromDate': from_date, 'toDate': to_date, 'start': start})
            response = self.session.get(url, params=data)
            if response.status_code != requests.codes.ok:
                raise ResponseError(url, response)
            response_data = response.json()

            if response_data.get('moreAvailable', False):
                start += response_data['displaying']
            for transaction in response_data['transactions']:
                yield Container(**transaction)


