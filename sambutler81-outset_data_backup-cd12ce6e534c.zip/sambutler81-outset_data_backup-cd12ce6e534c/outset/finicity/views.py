from rest_framework import filters, pagination, viewsets

from django.db.models import Q

from .models import Institution
from .serializers import InstitutionSerializer
from .utils import TEST


class InstitutionViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Institution.objects.all()
    serializer_class = InstitutionSerializer
    filter_backends = (filters.SearchFilter,)
    search_fields = ('name',)
    pagination_class = pagination.LimitOffsetPagination

    def get_queryset(self):
        q = Q(name__contains='FinBank')
        return self.queryset.filter(q) if TEST else self.queryset.exclude(q)

