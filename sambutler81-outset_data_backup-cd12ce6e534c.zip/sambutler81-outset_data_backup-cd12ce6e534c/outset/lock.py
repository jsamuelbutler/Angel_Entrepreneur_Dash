from __future__ import absolute_import, unicode_literals

import contextlib
import redis
from time import sleep

from django.conf import settings


_server = redis.from_url(settings.REDIS_SERVER)


@contextlib.contextmanager
def redis_mutex(key):
    key = '__lock_{}'.format(key)

    while True:
        if _server.get(key):
            sleep(0.01)
            continue
        _server.set(key, 1)
        yield
        _server.delete(key)
        break
