# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from rest_framework import mixins, viewsets
from rest_framework.settings import api_settings

from oauth2_provider.models import AccessToken, Application

from outset.accounts.permissions import IsAcceleratorFounder, HostsOnlyAllow

from .serializers import OAuth2ApplicationSerializer, OAuth2AuthorizedTokensSerializer


class OAuth2ApplicationViewSet(viewsets.ModelViewSet):
    queryset = Application.objects.all()
    serializer_class = OAuth2ApplicationSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [HostsOnlyAllow, IsAcceleratorFounder]
    exclude_from_schema = True

    def get_queryset(self):
        if not self.request.user.accelerator_id:
            return self.queryset.none()
        return self.queryset.filter(user__in=self.request.user.accelerator.users.values('pk'))


class OAuth2AuthorizedTokensViewSet(mixins.ListModelMixin, mixins.DestroyModelMixin, viewsets.GenericViewSet):
    queryset = AccessToken.objects.all()
    serializer_class = OAuth2AuthorizedTokensSerializer
    permission_classes = api_settings.DEFAULT_PERMISSION_CLASSES + [HostsOnlyAllow, IsAcceleratorFounder]
    exclude_from_schema = True

    def get_queryset(self):
        if not self.request.user.accelerator_id:
            return self.queryset.none()
        return self.queryset.filter(
            application__in=Application.objects.filter(
                user__in=self.request.user.accelerator.users.values('pk')
            ).values('pk')
        )
