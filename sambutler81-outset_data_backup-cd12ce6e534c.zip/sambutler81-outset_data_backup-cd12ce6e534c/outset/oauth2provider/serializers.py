from __future__ import unicode_literals

from rest_framework import serializers

# oauth2_provider from django-oauth-toolkit package
from oauth2_provider.models import AccessToken, Application


class OAuth2ApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ('id', 'name', 'client_id', 'client_secret', 'redirect_uris', 'client_type', 'authorization_grant_type')
        extra_kwargs = {
            'client_id': {'read_only': True},
            'client_secret': {'read_only': True}
        }

    def validate(self, validated_data):
        if 'request' in self.context and self.context['request'].user.is_authenticated:
            validated_data['user'] = self.context['request'].user
        return validated_data


class OAuth2AuthorizedTokensSerializer(serializers.ModelSerializer):
    application = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = AccessToken
        fields = ('token', 'application', 'scope', 'expires')

    @staticmethod
    def get_application(obj):
        return obj.application.name

