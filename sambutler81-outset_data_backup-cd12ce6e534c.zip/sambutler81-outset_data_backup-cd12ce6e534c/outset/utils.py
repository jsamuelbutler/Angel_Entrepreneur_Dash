from __future__ import unicode_literals

import base64
from datetime import datetime
from Crypto.Cipher import AES
from os import urandom
from uuid import UUID

from django.conf import settings
from django.utils import timezone
from django.utils.crypto import get_random_string


class PluralStr(object):
    def __init__(self, singular, plural=None):
        self.singular = singular
        self.plural = plural or (singular + 's')

    def __call__(self, count):
        return '{} {}'.format(count, self.singular if int(count) == 1 else self.plural)


def plural(count, singular, plural=None):
    """
    Pluralization strings.

    Examples::
        > 'I have {}'.format(plural(2, 'dog'))
        I have 2 dogs

    :param count: object count
    :param singular: singular name string
    :param plural: plural name string
    :return: string
    """
    # return '{} {}'.format(count, singular if int(count) == 1 else (plural or (singular + 's')))
    return PluralStr(singular, plural)(count)


def to_timestamp(dt, epoch=datetime(1970, 1, 1)):
    """
    Getting datetime timestamp.

    In Python 3.3+ timestamp gets by `datetime.timestamp()`.
    For Python 2 and Django aware datetime need this function.

    :param dt: datetime (native or aware)
    :param epoch: datetime of the starting epoch
    :return: timestamp
    """
    assert isinstance(dt, datetime)
    if timezone.is_aware(dt):
        dt = timezone.make_naive(dt, timezone=timezone.utc)
    return int((dt - epoch).total_seconds())


def validate_uuid4(uuid_string):
    """
    Validate a UUID string is a valid uuid4.

    :param uuid_string: some string to validate
    :return: True or False
    """
    try:
        UUID(uuid_string, version=4)
    except ValueError:
        return False
    return True


def err_block(msg):
    return {'non_field_errors': [str(msg)]}


_iv_fake = 8
_key_len = 32


def _pad(s):
    pad_len = 16 - len(s) % 16
    return s + get_random_string(pad_len-1) + chr(pad_len)


def _unpad(s):
    return s[:-ord(s[len(s)-1])]


def mask(unmasked_string):
    if not unmasked_string:
        return ''
    iv = urandom(16)
    unmasked_bytes = bytes(_pad(bytes(unmasked_string)))
    encryption_suite = AES.new(settings.SECRET_KEY[:_key_len], AES.MODE_CBC, iv)
    return base64.b64encode(urandom(_iv_fake) + iv + encryption_suite.encrypt(unmasked_bytes))


def unmask(masked_string):
    masked_string = base64.b64decode(masked_string)
    masked_bytes = bytes(masked_string)
    iv = masked_bytes[_iv_fake:_iv_fake+16]
    masked_bytes = masked_bytes[_iv_fake+16:]
    if not iv or not masked_bytes:
        return None
    decryption_suite = AES.new(settings.SECRET_KEY[:_key_len], AES.MODE_CBC, iv)
    return str(_unpad(decryption_suite.decrypt(masked_bytes)))
