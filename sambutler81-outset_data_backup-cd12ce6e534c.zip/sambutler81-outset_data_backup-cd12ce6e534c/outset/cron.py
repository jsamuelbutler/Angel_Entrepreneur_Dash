from datetime import timedelta

from django.apps import apps
from django.utils.timezone import now
from safedelete.models import SafeDeleteManager, SafeDeleteModel
from safedelete.config import HARD_DELETE


def remove_non_active_objects():
    deadline = now() - timedelta(days=1)
    for model in apps.get_models():
        if not model._meta.abstract:
            manager = model._default_manager
            if isinstance(manager, SafeDeleteManager) or isinstance(model, SafeDeleteModel):
                for obj in manager.deleted_only().filter(deleted__lte=deadline):
                    obj.delete(force_policy=HARD_DELETE)
