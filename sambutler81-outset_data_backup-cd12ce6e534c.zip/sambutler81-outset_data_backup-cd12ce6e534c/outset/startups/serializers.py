from __future__ import unicode_literals

from datetime import timedelta
import stripe
from xero.exceptions import XeroBadRequest

from django.db import transaction
from django.db.models import Prefetch
from django.utils.timezone import now
from rest_framework import serializers

from outset.accelerators.models import Cohort
from outset.accelerators.serializers import SimpleAcceleratorSerializer
from outset.accounts.serializers import TinyUserSerializer
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.finicity.api import ResponseError
from outset.finicity.models import Institution
from outset.finicity.utils import finicity_api
from outset.invitations.serializers import InviteStartupTeamMemberSerializer
from outset.kpis.tasks import load_old_data_by_connect_task
from outset.utils import err_block

from .models import Startup, StartupFinicity, StartupStripe, StartupXero, StartupFinicityCustomer, StartupFinicityTemp


class NewStartupSerializer(serializers.ModelSerializer):
    invites = InviteStartupTeamMemberSerializer(write_only=True, allow_null=True, required=False)

    class Meta:
        model = Startup
        fields = ('name', 'invites', 'cohort', 'amount_invested', 'security_type', 'ownership')

    def validate_cohort(self, value):
        if not Cohort.objects.available_to_user(self.context['request'].user).filter(id=value.id).exists():
            raise serializers.ValidationError('Such cohort is not found.')
        return value

    def validate(self, attrs):
        name = attrs.get('name', self.instance.name if self.instance else None)
        cohort = attrs.get('cohort', self.instance.cohort if self.instance else None)

        if Startup.objects.filter(name=name, cohort=cohort).exists():
            raise serializers.ValidationError('Already there is startup with such name.')

        return attrs

    def create(self, validated_data):
        initial_fields = set(self.Meta.fields) - {'invites'}
        startup = Startup.objects.create(**{k: v for k, v in validated_data.items() if k in initial_fields})

        invites_validated_data = validated_data.get('invites')
        if invites_validated_data:
            invites_validated_data.update({
                'invited_by': self.context['request'].user,
                'startup': startup
            })
            InviteStartupTeamMemberSerializer.create_invites(invites_validated_data)

        return startup


class TinyStartupSerializer(serializers.ModelSerializer):
    logo = serializers.CharField(max_length=100, allow_blank=True)
    cohort = serializers.IntegerField(source='cohort_id', read_only=True)

    class Meta:
        model = Startup
        fields = ('id', 'logo', 'name', 'cohort')


class StartupSerializer(serializers.ModelSerializer):
    accelerator = SimpleAcceleratorSerializer(source='cohort.accelerator')
    logo = serializers.CharField(max_length=100, allow_blank=True)
    remind_me = serializers.BooleanField(read_only=True)
    name = serializers.CharField(max_length=50, allow_blank=False)
    users = TinyUserSerializer(many=True, read_only=True)
    stripe_data = serializers.SerializerMethodField(read_only=True)
    xero_data = serializers.SerializerMethodField(read_only=True)
    bank_data = serializers.SerializerMethodField(read_only=True)

    is_data_integration_showed = serializers.BooleanField(read_only=True)

    todos = serializers.IntegerField(source='todo_count', read_only=True)

    def validate_is_connect_choice_provided(self, value):
        user = self.context['request'].user if 'request' in self.context else None
        if not self.instance or self.instance.is_connect_choice_provided != value:
            if user and user.is_authenticate and user.account_type != 4 and value:
                raise serializers.ValidationError('Permission denied.')
            if self.instance and self.instance.is_connect_choice_provided:
                raise serializers.ValidationError('Set a "is_connect_choice_provided" flag only possible once.')
        return value

    class Meta:
        model = Startup
        # fields = '__all__'
        exclude = ('data_integration_fixed',)

    @staticmethod
    def get_stripe_data(obj):
        return obj.stripe_data

    @staticmethod
    def get_xero_data(obj):
        return obj.xero_data

    @staticmethod
    def get_bank_data(obj):
        return obj.finicity_data


class DataIntegrationShowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Startup
        fields = ()

    def validate(self, validated_data):
        if not self.instance.data_integration_is_allow:
            raise serializers.ValidationError('Not enabled Data Integration option.')
        return {'data_integration_fixed': True} if not self.instance.data_integration_fixed else {}


class DataIntegrationSerializer(serializers.ModelSerializer):

    def validate(self, attrs):
        if 'startup' not in self.context:
            raise serializers.ValidationError('Startup is missed.')
        attrs['startup'] = self.context['startup']
        user = self.context['request'].user if 'request' in self.context else None
        if user:
            if user.is_anonymous:
                raise serializers.ValidationError('Need authenticate to edit it.')
            elif user.is_authenticated and not user.check_option(DATA_INTEGRATION_OPTION):
                raise serializers.ValidationError('Upgrade your plan to connect to this API.')
        return super(DataIntegrationSerializer, self).validate(attrs)


class StartupStripeSerializer(DataIntegrationSerializer):
    redirect = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = StartupStripe
        fields = ('redirect',)

    def get_redirect(self, obj):
        return obj.authenticate_url(self.context['request'])

    def validate(self, validated_data):
        validated_data = super(StartupStripeSerializer, self).validate(validated_data)
        startup = validated_data['startup']

        if startup.stripe_data:
            raise serializers.ValidationError('You\'re already connected to the Stripe API.')

        return validated_data


class StartupStripeCompleteSerializer(DataIntegrationSerializer):
    code = serializers.CharField(write_only=True)

    class Meta:
        model = StartupStripe
        fields = ('code',)

    def validate(self, validated_data):
        validated_data = super(StartupStripeCompleteSerializer, self).validate(validated_data)

        if not self.instance:
            raise serializers.ValidationError('There is not started Stripe integration.')

        try:
            resp = stripe.OAuth.token(grant_type='authorization_code', code=validated_data['code'])
        except stripe.error.OAuthError as err:
            raise serializers.ValidationError(str(err))

        validated_data.update({
            k: v for k, v in resp.items() if k in (
                'stripe_publishable_key', 'stripe_user_id', 'refresh_token', 'access_token'
            )
        })

        return validated_data

    def save(self, **kwargs):
        instance = super(StartupStripeCompleteSerializer, self).save(**kwargs)
        load_old_data_by_connect_task.delay(instance.startup_id, 'stripe')
        return instance


class StartupXeroSerializer(DataIntegrationSerializer):
    redirect = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = StartupXero
        fields = ('redirect',)

    def validate(self, validated_data):
        validated_data = super(StartupXeroSerializer, self).validate(validated_data)
        startup = validated_data['startup']

        if startup.xero_data:
            raise serializers.ValidationError('You\'re already connected to the Xero API.')

        validated_data['state'] = StartupXero.base_credentials(startup, self.context.get('request')).state

        return validated_data

    @staticmethod
    def get_redirect(obj):
        return obj.credentials.url


class StartupXeroCompleteSerializer(DataIntegrationSerializer):
    code = serializers.CharField(write_only=True)

    class Meta:
        model = StartupXero
        fields = ('code',)
        extra_kwargs = {'code': {'write_only': True}}

    def validate_code(self, value):
        if self.instance is None:
            raise serializers.ValidationError('Invalid credentials.')

        credentials = self.instance.credentials

        try:
            credentials.verify(value)
        except Exception:
            raise serializers.ValidationError('Invalid verifier code.')
        return credentials

    def validate(self, validated_data):
        validated_data = super(StartupXeroCompleteSerializer, self).validate(validated_data)

        validated_data['state'] = validated_data['code'].state
        del validated_data['code']

        return validated_data


class XeroAccountSerializer(serializers.Serializer):
    code = serializers.SerializerMethodField()
    name = serializers.SerializerMethodField()
    accountID = serializers.SerializerMethodField()
    description = serializers.SerializerMethodField()

    @staticmethod
    def get_code(obj):
        return obj.get('Code')

    @staticmethod
    def get_name(obj):
        return obj.get('Name')

    @staticmethod
    def get_accountID(obj):
        return obj.get('AccountID')

    @staticmethod
    def get_description(obj):
        return obj.get('Description')


class StartupXeroAccountSerializer(serializers.ModelSerializer):
    accounts = XeroAccountSerializer(many=True, source='available_accounts', read_only=True)

    def validate(self, validated_data):
        if not self.instance:
            raise serializers.ValidationError('You\'re haven\'t connected  Xero API.')
        return validated_data

    class Meta:
        model = StartupXero
        fields = ('accounts',)


class StartupXeroSelectAccountsSerializer(DataIntegrationSerializer):
    accounts = serializers.ListField(write_only=True, child=serializers.CharField())

    class Meta:
        model = StartupXero
        fields = ('accounts',)

    def validate_accounts(self, value):
        if not self.instance:
            raise serializers.ValidationError('You\'re haven\'t connected  Xero API.')
        if not self.instance.is_verified:
            raise serializers.ValidationError('Xero integration not verified.')

        for account_id in value:
            try:
                account = self.instance.get_account(account_id)
            except XeroBadRequest:
                account = None
            if not account:
                raise serializers.ValidationError('Not found {} Account ID.'.format(account_id))

        return value

    def save(self, **kwargs):
        instance = super(StartupXeroSelectAccountsSerializer, self).save(**kwargs)
        load_old_data_by_connect_task.delay(instance.startup_id, 'xero')
        return instance


class StartupFinicitySerializer(DataIntegrationSerializer):
    institution = serializers.PrimaryKeyRelatedField(queryset=Institution.objects.all(), write_only=True)
    login_form = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = StartupFinicity
        fields = ('id', 'institution', 'login_form')

    def validate(self, validated_data):
        validated_data = super(StartupFinicitySerializer, self).validate(validated_data)

        if self.instance:
            raise serializers.ValidationError('You\'re already connected to the Bank API.')
        if 'request' not in self.context:
            raise serializers.ValidationError('There isn\'t request in context.')
        return validated_data

    def create(self, validated_data):
        institution_id = validated_data['institution'].id
        try:
            customer = StartupFinicityCustomer.create_for_user(self.context['request'].user)
        except ResponseError as err:
            raise serializers.ValidationError(err_block(err))
        StartupFinicityTemp.objects.create(
            finicity_customer=customer,
            institution_id=institution_id,
            startup=validated_data['startup'],
        )
        return self.Meta.model(institution_id=institution_id)

    @staticmethod
    def get_login_form(obj):
        try:
            login_form = finicity_api().institution_form(obj.institution_id)
        except ResponseError as err:
            raise serializers.ValidationError(err_block(err))
        return login_form


class StartupFinicityCredentialSerializer(serializers.Serializer):
    id = serializers.CharField()
    name = serializers.CharField()
    value = serializers.CharField()


class StartupFinicityLoginFormSerializer(DataIntegrationSerializer):
    credentials = serializers.ListField(
        child=StartupFinicityCredentialSerializer(),
        write_only=True,
        help_text='Login form data',
        required=False,
        allow_null=True
    )
    challenge = serializers.JSONField(write_only=True, help_text='MFA challenge data', required=False, allow_null=True)
    mfa_challenge = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = StartupFinicity
        fields = ('id', 'credentials', 'challenge', 'mfa_challenge')

    def validate(self, validated_data):
        validated_data = super(StartupFinicityLoginFormSerializer, self).validate(validated_data)

        if self.instance:
            raise serializers.ValidationError('You\'re already connected to the Bank API.')
        credentials = validated_data.get('credentials')
        challenge = validated_data.get('challenge')
        if credentials and challenge:
            raise serializers.ValidationError('Only credentials or challenge can be send at the same time.')
        if not credentials and not challenge:
            raise serializers.ValidationError('Need credentials or challenge parameter.')
        if 'request' not in self.context:
            raise serializers.ValidationError('There isn\'t request in context.')

        finicity_customer = StartupFinicityCustomer.objects.filter(user=self.context['request'].user).prefetch_related(
            Prefetch(
                'temps',
                queryset=StartupFinicityTemp.objects.filter(
                    startup=validated_data['startup'],
                    created__gte=now()-timedelta(hours=1)
                ),
                to_attr='finicity_temps'
            )
        ).first()

        if not finicity_customer or not finicity_customer.finicity_temps:
            raise serializers.ValidationError(
                'Invalid session data. Please start the integration process at the start.'
            )
        validated_data['temp'] = finicity_customer.finicity_temps[0]

        return validated_data

    def create(self, validated_data):
        credentials = validated_data.get('credentials')
        challenge = validated_data.get('challenge')
        temp = validated_data.get('temp')

        instance = StartupFinicity(
            finicity_customer=temp.finicity_customer,
            institution_id=temp.institution_id,
            startup=temp.startup,
        )

        if credentials:
            temp.credentials = credentials
            with transaction.atomic():
                temp.save()

        fapi = finicity_api(state=temp.state)
        if not temp.institution_login_id:
            try:
                response = (
                    fapi.add_all_accounts(instance.customer_id, instance.institution_id, credentials=credentials)
                    if credentials else
                    fapi.add_all_accounts_mfa(instance.customer_id, instance.institution_id, mfa_challenges=challenge)
                )
            except ResponseError as err:
                if err.code == 331 and temp.credentials:
                    # Expired MFA session
                    try:
                        fapi.add_all_accounts(
                            instance.customer_id, instance.institution_id, credentials=temp.credentials
                        )
                        response = fapi.add_all_accounts_mfa(
                            instance.customer_id, instance.institution_id, mfa_challenges=challenge
                        )
                    except ResponseError as err:
                        raise serializers.ValidationError(err_block(err))
                else:
                    raise serializers.ValidationError(err_block(err))
        else:
            try:
                response = fapi.refresh_institution_login_accounts_mfa(
                    temp.customer_id, temp.institution_login_id, mfa_challenges=challenge
                )
            except ResponseError as err:
                if err.code == 331 and temp.institution_login_id:
                    # Expired MFA session
                    try:
                        fapi.refresh_institution_login_accounts(temp.customer_id, temp.institution_login_id)
                        response = fapi.refresh_institution_login_accounts_mfa(
                            temp.customer_id, temp.institution_login_id, mfa_challenges=challenge
                        )
                    except ResponseError as err:
                        raise serializers.ValidationError(err_block(err))
                else:
                    raise serializers.ValidationError(err_block(err))

        # refresh accounts (with mfa)
        if isinstance(response, list) and not temp.institution_login_id:
            try:
                temp.institution_login_id = response[0].institutionLoginId
            except IndexError:
                raise serializers.ValidationError(err_block('Not found bank account.'))

            try:
                response = fapi.refresh_institution_login_accounts(temp.customer_id, temp.institution_login_id)
            except ResponseError as err:
                # Ignore error "The account is already currently being aggregated.
                # Please check back later for aggregation results."
                if err.code != 325:
                     raise serializers.ValidationError(err_block(err))

        if isinstance(response, list):
            instance.save()
            temp.delete()
            load_old_data_by_connect_task.delay(instance.startup_id, 'finicity')
        else:
            # response is mfa
            temp.state = fapi.state
            temp.save()
            setattr(instance, 'mfa_challenge', response)

        return instance

    @staticmethod
    def get_mfa_challenge(obj):
        return getattr(obj, 'mfa_challenge', None)


