from __future__ import unicode_literals

import factory

from outset.accelerators.factories import CohortFactory


class StartupFactory(factory.django.DjangoModelFactory):
    name = factory.Sequence(lambda n: "Startup {}".format(n))
    website = 'http://example.com'
    info = 'Some startup'
    cohort = factory.SubFactory(CohortFactory)

    class Meta:
        model = 'startups.Startup'
