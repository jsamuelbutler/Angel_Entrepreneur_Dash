from django_filters import BaseInFilter
from django_filters.rest_framework import FilterSet

from .models import Startup


class StartupFilter(FilterSet):
    cohorts = BaseInFilter(name='cohort', lookup_expr='in')

    class Meta:
        model = Startup
        fields = ('cohort', 'cohorts')
