from __future__ import unicode_literals

try:
    import cPickle
except ImportError:
    import _pickle as cPickle

from collections import Counter
from datetime import datetime
from dateutil import tz
from decimal import Decimal
from functools import wraps
import re
import stripe
from time import sleep

from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator, MinValueValidator
from django.dispatch import receiver
from django.utils import timezone, crypto
from django.utils.translation import ugettext_lazy as _
from django.utils.functional import cached_property
from safedelete.config import SOFT_DELETE, HARD_DELETE
from safedelete.signals import pre_softdelete
from xero import Xero
from xero.auth import PartnerCredentials, PublicCredentials
from xero.exceptions import XeroRateLimitExceeded

from outset.models import ModelDiffMixin
from outset.accelerators.models import BaseOrganization, Accelerator
from outset.billing.consts import DATA_INTEGRATION_OPTION
from outset.db.validators import MoreValueValidator
from outset.finicity.api import ResponseError as FinicityResponseError
from outset.finicity.utils import finicity_api
from outset.utils import mask, unmask

from .managers import StartupManager
from .tasks import startup_soft_delete_cascade


STRIPE_CLIENT_ID = settings.STRIPE_CLIENT_ID
STRIPE_REDIRECT_URL = settings.STRIPE_REDIRECT_URL
STRIPE_SCOPE = settings.STRIPE_SCOPE

XERO_CUSTOMER_KEY = settings.XERO_CUSTOMER_KEY
XERO_CUSTOMER_SECRET = settings.XERO_CUSTOMER_SECRET
XERO_REDIRECT_TO = settings.XERO_REDIRECT_TO
XERO_USER_AGENT = getattr(settings, 'XERO_USER_AGENT', 'Outset')


class Startup(ModelDiffMixin, BaseOrganization):
    _safedelete_policy = SOFT_DELETE

    info = models.TextField(_('Additional Info'), max_length=500, blank=True)
    country = models.CharField(_('Country'), max_length=255, blank=True)
    incorporation_date = models.DateField(_('Founding date'), default=timezone.now)
    cohort = models.ForeignKey('accelerators.Cohort', related_name="startups", on_delete=models.CASCADE)
    reminder = models.DateField(blank=True, null=True)

    amount_invested = models.BigIntegerField(
        _('Amount invested'),
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(99999999999)],
        null=True,
        blank=True,
    )

    COMMON_SECURITY_TYPE = 'common stock'
    PREFERRED_SECURITY_TYPE = 'preferred stock'
    CONVERTIBLE_SECURITY_TYPE = 'convertible note'
    SAFE_SECURITY_TYPE = 'safe'
    WARRANT_SECURITY_TYPE = 'warrant'
    SECURITY_TYPES = (
        (COMMON_SECURITY_TYPE, 'Common Stock'),
        (PREFERRED_SECURITY_TYPE, 'Preferred Stock'),
        (CONVERTIBLE_SECURITY_TYPE, 'Convertible note'),
        (SAFE_SECURITY_TYPE, 'SAFE'),
        (WARRANT_SECURITY_TYPE, 'Warrant')
    )

    security_type = models.CharField(
        _('Security Type'), max_length=20, choices=SECURITY_TYPES, default=COMMON_SECURITY_TYPE
    )
    ownership = models.DecimalField(
        _('Ownership'),
        max_digits=5,
        decimal_places=2,
        help_text='in %',
        validators=[MoreValueValidator(0), MaxValueValidator(Decimal(100))],
        null=True,
        blank=True
    )

    data_integration_fixed = models.BooleanField(_('Data Integration Message Fixed'), default=False)

    objects = StartupManager()

    def __str__(self):
        return '"{}" company'.format(self.name)

    @property
    def initial_valuation(self):
        return 100 * self.amount_invested / self.ownership if self.ownership and self.amount_invested else 0

    class Meta:
        verbose_name = _('company')
        verbose_name_plural = _('companies')

    @cached_property
    def finicity_data(self):
        return self.data_integration_is_allow and hasattr(self, 'finicity') and self.finicity.ping()

    @cached_property
    def stripe_data(self):
        return self.data_integration_is_allow and hasattr(self, 'stripe') and self.stripe.is_completed

    @cached_property
    def xero_data(self):
        return self.data_integration_is_allow and hasattr(self, 'xero') and self.xero.ping() and self.xero.is_completed

    @property
    def data_integration_is_allow(self):
        if hasattr(self, '_data_integration_is_allow'):
            return getattr(self, '_data_integration_is_allow')
        accelerator = Accelerator.objects.filter(cohorts=self.cohort_id).first()
        if accelerator is None:
            return False
        user = accelerator.users.first()
        if user is None:
            return False
        result = user.check_option(DATA_INTEGRATION_OPTION)
        setattr(self, '_data_integration_is_allow', result)
        return result

    @data_integration_is_allow.setter
    def data_integration_is_allow(self, value):
        setattr(self, '_data_integration_is_allow', value)

    @property
    def is_data_integration_showed(self):
        return self.data_integration_is_allow and not self.data_integration_fixed


class StartupStripe(models.Model):
    startup = models.OneToOneField(Startup, related_name='stripe', on_delete=models.CASCADE)
    access_token_k = models.TextField(null=True, blank=True)
    refresh_token_k = models.TextField(null=True, blank=True)
    stripe_user_id_k = models.TextField(null=True, blank=True)
    stripe_publishable_key_k = models.TextField(null=True, blank=True)

    @property
    def access_token(self):
        return unmask(self.access_token_k) if self.access_token_k else None

    @access_token.setter
    def access_token(self, value):
        self.access_token_k = mask(value) if value else None

    @property
    def refresh_token(self):
        return unmask(self.refresh_token_k) if self.refresh_token_k else None

    @refresh_token.setter
    def refresh_token(self, value):
        self.refresh_token_k = mask(value) if value else None

    @property
    def stripe_user_id(self):
        return unmask(self.stripe_user_id_k) if self.stripe_user_id_k else None

    @stripe_user_id.setter
    def stripe_user_id(self, value):
        self.stripe_user_id_k = mask(value) if value else None

    @property
    def stripe_publishable_key(self):
        return unmask(self.stripe_publishable_key_k) if self.stripe_publishable_key_k else None

    @stripe_publishable_key.setter
    def stripe_publishable_key(self, value):
        self.stripe_publishable_key_k = mask(value) if value else None

    @property
    def masked_key(self):
        key = self.access_token
        if not key:
            return ''
        return '{}****{}'.format(key[:5], key[-5:])

    @property
    def api_key(self):
        api_key = self.access_token
        try:
            stripe.Account.list(api_key=api_key, limit=1)
        except stripe.error.APIConnectionError:
            resp = stripe.OAuth.token(
                client_id=STRIPE_CLIENT_ID, grant_type='refresh_token', refresh_token=self.refresh_token
            )
            self.access_token = api_key = resp['access_token']
            self.save(update_fields=['access_token_k'])
        return api_key

    @staticmethod
    def authenticate_url(request):
        redirect_url = request.build_absolute_uri(STRIPE_REDIRECT_URL)
        return stripe.OAuth.authorize_url(
            client_id=STRIPE_CLIENT_ID, scope=STRIPE_SCOPE, redirect_uri=redirect_url
        )

    @property
    def is_completed(self):
        return bool(self.access_token_k)

    def __str__(self):
        return 'Stripe key {} for {}'.format(self.masked_key, self.startup)


def xero_call(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        iterations = 100
        while iterations > 0:
            iterations -= 1
            try:
                return func(*args, **kwargs)
            except XeroRateLimitExceeded:
                sleep(60)
        raise Exception('Xero Rate Limit Exceeded all time.')
    return wrapper


class StartupXero(models.Model):
    credentials_class = PublicCredentials

    startup = models.OneToOneField(Startup, related_name='xero', on_delete=models.CASCADE)
    state_k = models.TextField()
    accounts_k = models.TextField(null=True, blank=True)

    @property
    def state(self):
        try:
            return cPickle.loads(unmask(self.state_k))
        except ValueError:
            return None

    @state.setter
    def state(self, value):
        self.state_k = mask(cPickle.dumps(value))

    @property
    def accounts(self):
        if not self.accounts_k:
            return None
        try:
            return cPickle.loads(unmask(self.accounts_k))
        except ValueError:
            return None

    @accounts.setter
    def accounts(self, value):
        self.accounts_k = mask(cPickle.dumps(value)) if value else None

    @xero_call
    def get_account(self, account_id):
        return self.connection.accounts.filter(AccountID=account_id)

    @property
    @xero_call
    def available_accounts(self):
        if not self.is_verified:
            return []
        return self.connection.accounts.all()

    def __str__(self):
        return 'Xero credentials for {}'.format(self.startup)

    @classmethod
    def base_credentials(cls, startup, request=None):
        callback_uri = request.build_absolute_uri(XERO_REDIRECT_TO.format(startup.id)) if request else None
        return cls.credentials_class(XERO_CUSTOMER_KEY, XERO_CUSTOMER_SECRET, callback_uri)

    @property
    def is_verified(self):
        state = self.state
        return state and self.state.get('verified', False)

    @property
    def is_completed(self):
        return self.is_verified and bool(self.accounts)

    @property
    def credentials(self):
        return self.credentials_class(**self.state)

    @property
    def connection(self):
        credentials = self.credentials
        if credentials.expired() and hasattr(credentials, 'refresh'):
            credentials.refresh()
            self.state = credentials.state
            self.save(update_fields=['state'])
        return Xero(credentials, user_agent=XERO_USER_AGENT)

    def ping(self):
        credentials = self.credentials
        result = credentials and credentials.verified and not credentials.expired()
        # TODO: return commented code before release
        # if not result:
        if False:
            self.delete_referred_kpis()
        return result

    def delete_referred_kpis(self):
        # Delete all Xero KPI
        from outset.kpis.models import KPI, KPIBase
        kpi_bases = KPI.objects.filter(startup=self.startup).values('base_id')
        for base in KPIBase.objects.filter(id__in=kpi_bases, name__startswith='Xero: ', is_editable=False).all():
            base.delete(force_policy=HARD_DELETE)

    @staticmethod
    def xero_report_data_(report, is_negative=False):
        m = -1 if is_negative else 1
        return Counter({
            x['Cells'][3]['Attributes'][0]['Value']: m * (
                Decimal(x['Cells'][3]['Value'] or 0) + Decimal(x['Cells'][4]['Value'] or 0)
            )
            for x in sum([i.get('Rows', []) for i in report[0]['Rows']], [])
            if x['RowType'] == 'Row'
        })

    @xero_call
    def trial_balance_report(self, date_):
        return self.connection.reports.get('TrialBalance', params={'date': date_} if date_ else None)

    @xero_call
    def cogs(self):
        return sum([i.get('COGSAccountCode', 0) for i in self.connection.items.all()])

    def account_values(self, from_date=None, to_date=None):
        """
        Receive account values.

        Request Xero report and parse it.

        :param from_date: date for exclude values (request report) or YTD values return
        :param to_date: report date or today if none
        :return: dict<account_id: value>
        """
        values = self.xero_report_data_(self.trial_balance_report(to_date))
        if from_date:
            values.update(self.xero_report_data_(self.trial_balance_report(from_date), is_negative=True))
        return values


class StartupFinicityCustomer(models.Model):
    """
    Created for every Outset Startup Founder User for Finicity.

    Finicity support do not like the customer creation by necessity.
    """
    USERNAME_IGNORE_PATTERN = r'[^\w\d\!\@\#\$\%\&\*\_\-\+]'
    NAME_IGNORE_PATTERN = r'[\!\"\#\$\%\&\`\{\|\}\~]'

    user = models.OneToOneField(settings.AUTH_USER_MODEL, related_name='+', on_delete=models.CASCADE)
    customer_id_k = models.CharField(max_length=255)

    created = models.DateTimeField(auto_now_add=True, editable=False)

    def __str__(self):
        return '"{}" Finicity Customer for {} user'.format(self.customer_id, self.user)

    @property
    def customer_id(self):
        if not self.customer_id_k:
            return None
        try:
            return unmask(self.customer_id_k)
        except ValueError:
            return None

    @customer_id.setter
    def customer_id(self, value):
        self.customer_id_k = mask(value)

    @classmethod
    def create_for_user(cls, user, using=None):
        assert isinstance(user, get_user_model())
        exist_customer = cls.objects.using(using).filter(user=user).first()
        if exist_customer:
            return exist_customer

        customer = None
        remaining_attempts = 3
        last_error = None
        while customer is None and remaining_attempts > 0:
            remaining_attempts -= 1
            finicity_username = '{name}_{salt}'.format(
                name=re.sub(
                    cls.USERNAME_IGNORE_PATTERN,
                    '',
                    ''.join([i.title() for i in (
                        [user.first_name, user.last_name]
                        if user.first_name and user.last_name else
                        user.email[:user.email.index('@')].split('.')
                    )])
                ),
                salt=crypto.get_random_string(5, allowed_chars='0123456789')
            )
            try:
                customer = finicity_api().add_customer(
                    finicity_username,
                    first_name=re.sub(cls.NAME_IGNORE_PATTERN, '', user.first_name) or None if user.first_name else None,
                    last_name=re.sub(cls.NAME_IGNORE_PATTERN, '', user.last_name) or None if user.last_name else None,
                )
            except FinicityResponseError as err:
                last_error = err

        if customer is None and last_error:
            raise last_error

        return cls.objects.using(using).create(user=user, customer_id=customer.id)


class StartupFinicityTemp(models.Model):
    finicity_customer = models.ForeignKey(StartupFinicityCustomer, related_name='temps', on_delete=models.CASCADE)
    startup = models.ForeignKey(Startup, on_delete=models.CASCADE, related_name='+')
    state_k = models.TextField(null=True, blank=True)
    credentials_k = models.TextField(null=True, blank=True)
    institution_id = models.CharField(max_length=32, null=True, blank=True)
    institution_login_id = models.CharField(max_length=32, null=True, blank=True)

    created = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return 'Finicity temp key data for {}'.format(self.startup)

    class Meta:
        ordering = ('-created',)

    @property
    def state(self):
        if not self.state_k:
            return None
        try:
            return cPickle.loads(unmask(self.state_k))
        except ValueError:
            return None

    @state.setter
    def state(self, value):
        self.state_k = mask(cPickle.dumps(value))

    @property
    def credentials(self):
        if not self.credentials_k:
            return None
        try:
            return cPickle.loads(unmask(self.credentials_k))
        except ValueError:
            return None

    @credentials.setter
    def credentials(self, value):
        self.credentials_k = mask(cPickle.dumps(value))

    @property
    def customer_id(self):
        return self.finicity_customer.customer_id


class StartupFinicity(models.Model):
    startup = models.OneToOneField(Startup, related_name='finicity', on_delete=models.CASCADE)
    finicity_customer = models.ForeignKey(StartupFinicityCustomer, related_name='connects', on_delete=models.CASCADE)
    institution_id_k = models.TextField()

    MIN_FINICITY_DATETIME = datetime(2000, 1, 1, 0, 0, 0, 0, tzinfo=tz.gettz('MST'))

    def __str__(self):
        return 'Finicity key for {}'.format(self.startup)

    @property
    def institution_id(self):
        return unmask(self.institution_id_k)

    @institution_id.setter
    def institution_id(self, value):
        self.institution_id_k = mask(value)

    @property
    def customer_id(self):
        return self.finicity_customer.customer_id

    def ping(self):
        try:
            finicity_api().get_customer(self.customer_id)
        except FinicityResponseError:
            return False
        return True


@receiver(pre_softdelete, sender=Startup)
def cascade_soft_delete(sender, instance, using, **kwargs):
    diff = instance.get_field_diff('deleted')
    if diff and diff[0] is None:
        startup_soft_delete_cascade.delay(instance.pk)


@receiver(models.signals.pre_delete, sender=StartupStripe)
def remove_startup_stripe(sender, instance, using=None, **kwargs):
    if instance.is_completed:
        stripe.OAuth.deauthorize(client_id=STRIPE_CLIENT_ID, stripe_user_id=instance.stripe_user_id)


@receiver(models.signals.pre_delete, sender=StartupXero)
def remove_startup_xero(sender, instance, using=None, **kwargs):
    if instance.ping():
        # Since your application will have long term access to an organisation, an end
        # user may want to revoke access to an application. This can be done inside the
        # Xero application (via the Add-ons settings screen
        # (Settings > General Settings > Add-ons).
        # So, with Xero API we cannot revoke token at this moment.
        pass
    instance.delete_referred_kpis()


@receiver(models.signals.post_delete, sender=StartupFinicity)
def remove_startup_finicity(sender, instance, using=None, **kwargs):
    user = instance.finicity_customer.user
    instance.finicity_customer.delete(using=using)
    StartupFinicityCustomer.create_for_user(user, using=using)


@receiver(models.signals.post_save, sender=settings.AUTH_USER_MODEL)
def add_finicity_customer(sender, instance, created, raw, using=None, **kwargs):
    if created:
        StartupFinicityCustomer.create_for_user(instance, using=using)


@receiver(models.signals.post_delete, sender=StartupFinicityCustomer)
def remove_finicity_customer(sender, instance, using=None, **kwargs):
    try:
        finicity_api().delete_customer(instance.customer_id)
    except FinicityResponseError:
        pass
