from django import forms

from outset.accounts.models import ROLE_CHOICES
from outset.invitations.models import Invite
from .models import Startup


class StartupSettingsForm(forms.ModelForm):
    class Meta:
        model = Startup
        exclude = ('accelerator', )


class AddEmployeeForm(forms.Form):
    name = forms.CharField()
    email = forms.EmailField()
    role = forms.ChoiceField(choices=ROLE_CHOICES)

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(AddEmployeeForm, self).__init__(*args, **kwargs)

    def save(self):
        invite = Invite.objects.create(
            name=self.cleaned_data['name'],
            email=self.cleaned_data['email'],
            startup=self.user.startup,
            role=self.cleaned_data['role'],
            invited_by=self.user,
        )
        invite.send_mail()
