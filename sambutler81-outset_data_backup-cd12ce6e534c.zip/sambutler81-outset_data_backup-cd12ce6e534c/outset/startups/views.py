from __future__ import unicode_literals

from decimal import Decimal

import django_filters
from django.db.models import Sum, Prefetch
from rest_framework import filters, serializers, response, status, viewsets
from rest_framework.decorators import detail_route
from rest_framework.response import Response
from rest_framework.settings import api_settings

from outset.accounts.models import User
from outset.invitations.serializers import InviteStartupTeamMemberSerializer
from outset.kpis.consts import VALUATION_KPI

from .filters import StartupFilter
from .models import Startup
from .permissions import IsStartupFounderSelfOrAcceleratorTeamMemberSelfSelfOrReadOnly
from .serializers import (
    NewStartupSerializer, StartupSerializer, DataIntegrationShowSerializer,
    StartupXeroSerializer, StartupXeroCompleteSerializer,
    StartupStripeSerializer, StartupStripeCompleteSerializer,
    StartupFinicityLoginFormSerializer, StartupFinicitySerializer,
    StartupXeroAccountSerializer, StartupXeroSelectAccountsSerializer,
)


class StartupViewSet(viewsets.ModelViewSet):
    queryset = Startup.objects.with_todo_counts().with_team_member_counts().select_related(
            'cohort__accelerator',
        ).prefetch_related(
            Prefetch('users', queryset=User.objects.filter(is_active=True).order_by('first_name', 'last_name')),
            'finicity',
            'stripe',
            'xero',
        ).order_by('name')
    serializer_class = StartupSerializer
    permission_classes = (
        api_settings.DEFAULT_PERMISSION_CLASSES + [IsStartupFounderSelfOrAcceleratorTeamMemberSelfSelfOrReadOnly]
    )
    filter_backends = (django_filters.rest_framework.DjangoFilterBackend, filters.OrderingFilter, filters.SearchFilter)
    filter_class = StartupFilter
    search_fields = ('name',)
    ordering_fields = ('name', 'todo_count', 'team_member_count')

    def get_queryset(self):
        return self.queryset.available_to_user(self.request.user)

    def get_serializer_class(self):
        if self.action == 'create':
            return NewStartupSerializer
        return self.serializer_class

    def create(self, request, *args, **kwargs):
        # serializer for creation
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)

        # because there is some bug in datetime to date instance serialization do it hack
        instance = serializer.instance
        instance.incorporation_date = instance.incorporation_date.date()
        # use serializer for retrieve (with some simple hack)
        self.action = 'retrieve'
        retrieve_serializer = self.get_serializer(instance)
        headers = self.get_success_headers(retrieve_serializer.data)
        return Response(retrieve_serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    @detail_route(methods=['post'], serializer_class=InviteStartupTeamMemberSerializer)
    def invite(self, request, pk=None):
        """
        Create invite for Watcher/Founder/Employee
        """
        startup = self.get_object()
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(startup=startup)
        return Response(status=status.HTTP_201_CREATED)

    @detail_route(methods=['get'], serializer_class=serializers.Serializer)
    def portfolio_statistic(self, request, pk):
        instance = self.get_object()

        current_valuation = instance.kpis.filter(
            base__id=VALUATION_KPI
        ).with_value().aggregate(Sum('value'))['value__sum']

        default = Decimal(0)
        ownership = instance.ownership or default
        amount_invested = instance.amount_invested or default
        initial_valuation = instance.initial_valuation or default
        current_valuation = current_valuation or default

        statistic = [
            ('Amount Invested',   round(amount_invested)),
            ('Average Ownership', round(ownership, 2)),
            ('Initial Valuation', round(initial_valuation)),
            ('Current Valuation', round(current_valuation)),
            ('Gain/Loss',         round(current_valuation * ownership / 100 - amount_invested)),
        ]
        return Response(data=[{'text': k, 'count': v} for k, v in statistic])

    @detail_route(methods=['post'], serializer_class=DataIntegrationShowSerializer)
    def data_integration_show(self, request, pk):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(data=serializer.data)

    @detail_route(methods=['post', 'delete'], serializer_class=StartupStripeSerializer)
    def stripe_integration(self, request, pk):
        startup = self.get_object()
        stripe = startup.stripe if hasattr(startup, 'stripe') else None
        if request.method.lower() == 'delete':
            if stripe is None:
                return response.Response(status=status.HTTP_404_NOT_FOUND)
            stripe.delete()
            return response.Response(status=status.HTTP_204_NO_CONTENT)
        serializer = self.get_serializer(stripe, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['post'], serializer_class=StartupStripeCompleteSerializer)
    def stripe_integration_complete(self, request, pk):
        startup = self.get_object()
        serializer = self.get_serializer(startup.stripe if hasattr(startup, 'stripe') else None, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['post', 'delete'], serializer_class=StartupXeroSerializer)
    def xero_integration(self, request, pk):
        startup = self.get_object()
        xero = startup.xero if hasattr(startup, 'xero') else None
        if request.method.lower() == 'delete':
            if xero is None:
                return response.Response(status=status.HTTP_404_NOT_FOUND)
            xero.delete()
            return response.Response(status=status.HTTP_204_NO_CONTENT)
        serializer = self.get_serializer(xero, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['post'], serializer_class=StartupXeroCompleteSerializer)
    def xero_integration_complete(self, request, pk):
        startup = self.get_object()
        serializer = self.get_serializer(startup.xero if hasattr(startup, 'xero') else None, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['get'], serializer_class=StartupXeroAccountSerializer)
    def xero_integration_accounts(self, request, pk):
        startup = self.get_object()
        serializer = self.get_serializer(startup.xero if hasattr(startup, 'xero') else None, data=request.data)
        serializer.is_valid(raise_exception=True)
        return response.Response(serializer.data)

    @detail_route(methods=['post'], serializer_class=StartupXeroSelectAccountsSerializer)
    def xero_integration_select_accounts(self, request, pk):
        startup = self.get_object()
        serializer = self.get_serializer(startup.xero if hasattr(startup, 'xero') else None, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['post', 'delete'], serializer_class=StartupFinicitySerializer)
    def bank_integration(self, request, pk):
        startup = self.get_object()
        finicity = startup.finicity if hasattr(startup, 'finicity') else None
        if request.method.lower() == 'delete':
            if finicity is None:
                return response.Response(status=status.HTTP_404_NOT_FOUND)
            finicity.delete()
            return response.Response(status=status.HTTP_204_NO_CONTENT)
        serializer = self.get_serializer(finicity, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)

    @detail_route(methods=['post'], serializer_class=StartupFinicityLoginFormSerializer)
    def bank_integration_login_form(self, request, pk):
        startup = self.get_object()
        serializer = self.get_serializer(startup.finicity if hasattr(startup, 'finicity') else None, data=request.data)
        serializer.context['startup'] = startup
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return response.Response(serializer.data)
