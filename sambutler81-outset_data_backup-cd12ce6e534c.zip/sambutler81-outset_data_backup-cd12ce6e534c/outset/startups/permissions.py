from outset.accounts.models import User
from outset.permissions import IsModelSelfOrReadOnly

from .models import Startup


class IsStartupFounderSelfOrAcceleratorTeamMemberSelfSelfOrReadOnly(IsModelSelfOrReadOnly):
    model = Startup

    def has_create_permission(self, request, view):
        return request.user.accelerator_id is not None and request.user.role in (User.FOUNDER_ROLE, User.ADMIN_ROLE)

    def has_update_permission(self, request, view, obj):
        return (
            request.user.startup_id == obj.id and request.user.role == User.FOUNDER_ROLE or
            self.has_create_permission(request, view)
        )

    def has_extra_object_permission(self, request, view, obj):
        return True
