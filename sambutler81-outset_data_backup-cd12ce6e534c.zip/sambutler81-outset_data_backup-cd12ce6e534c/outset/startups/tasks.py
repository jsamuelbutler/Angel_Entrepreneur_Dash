from __future__ import absolute_import

from outset import celery_app
from celery.utils.log import get_task_logger


logger = get_task_logger(__name__)


@celery_app.task
def startup_soft_delete_cascade(pk):
    logger.info('Starting startup_soft_delete_cascade({})...'.format(pk))

    from safedelete.config import SOFT_DELETE_CASCADE
    from outset.startups.models import Startup

    startup = Startup.objects.all_with_deleted().filter(pk=pk).first()
    if startup:
        logger.info('Cascade soft delete: {}'.format(startup))
        startup.delete(force_policy=SOFT_DELETE_CASCADE)
