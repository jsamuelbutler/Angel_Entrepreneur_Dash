from django.db.models import Count
from django.db.models.query import Q
from safedelete.managers import SafeDeleteQueryset, SafeDeleteManager

from outset.todos.query import WithToDoCountsQuerySetMixin


class StartupQuerySet(WithToDoCountsQuerySetMixin, SafeDeleteQueryset):
    todo_field = 'startup_id'

    def available_to_user(self, user):
        if user.is_anonymous():
            return self.none()
        account_type = user.account_type
        if account_type in (1, 2, 3):
            q = Q(pk=user.startup_id) | Q(cohort__accelerator=user.accelerator_id)
        elif account_type in (4, 5):
            q = Q(pk__in=self.model.objects.filter(users=user).values('id'))
        else:
            q = Q(id__in=user.companies_view.values('startup__id'))
        return self.filter(q)

    def with_team_member_counts(self):
        return self.annotate(team_member_count=Count('users', distinct=True))


class StartupManager(SafeDeleteManager):
    _queryset_class = StartupQuerySet

    def available_to_user(self, user):
        return self.get_queryset().available_to_user(user)

    def with_todo_counts(self):
        return self.get_queryset().with_todo_counts()

    def with_team_member_counts(self):
        return self.get_queryset().with_team_member_counts()

