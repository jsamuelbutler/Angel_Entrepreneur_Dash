from __future__ import absolute_import, unicode_literals

from datetime import timedelta

from django.utils.timezone import now

from .models import StartupFinicityTemp


def remove_old_temp_finicity():
    StartupFinicityTemp.objects.filter(created__lt=now()-timedelta(days=1)).delete()
