from __future__ import unicode_literals

from itertools import chain

from django.db.models import Manager, DEFERRED


def model_to_dict(instance, fields=None, exclude=None):
    """
    Returns a dict containing the data in ``instance``.

    ``fields`` is an optional list of field names. If provided, only the named
    fields will be included in the returned dict.

    ``exclude`` is an optional list of field names. If provided, the named
    fields will be excluded from the returned dict, even if they are listed in
    the ``fields`` argument.
    """
    opts = instance._meta
    data = {}
    for f in chain(opts.concrete_fields, opts.private_fields, opts.many_to_many):
        if fields and f.name not in fields:
            continue
        if exclude and f.name in exclude:
            continue
        data[f.name] = f.value_from_object(instance)
    return data


class ModelDiffMixin(object):
    """
    A model mixin that tracks model fields' values and provide some useful api
    to know what fields have been changed.

    Usage:
    >>> from django.db import models
    >>> class Place(ModelDiffMixin, models.Model): pass
    >>> p = Place()
    >>> p.has_changed
    False
    >>> p.changed_fields
    []
    >>> p.rank = 42
    >>> p.has_changed
    True
    >>> p.changed_fields
    ['rank']
    >>> p.diff
    {'rank': (0, 42)}
    >>> p.categories = [1, 3, 5]
    >>> p.diff
    {'categories': (None, [1, 3, 5]), 'rank': (0, 42)}
    >>> p.get_field_diff('categories')
    (None, [1, 3, 5])
    >>> p.get_field_diff('rank')
    (0, 42)
    >>>
    """

    _initial = {}

    @classmethod
    def from_db(cls, db, field_names, values):
        # Default implementation of from_db() (subject to change and could
        # be replaced with super()).
        if len(values) != len(cls._meta.concrete_fields):
            values = list(values)
            values.reverse()
            values = [
                values.pop() if f.attname in field_names else DEFERRED
                for f in cls._meta.concrete_fields
                ]
        instance = cls(*values)
        instance._state.adding = False
        instance._state.db = db

        # customization to store the original field values on the instance
        instance._initial = dict(zip(field_names, values))

        return instance

    @property
    def diff(self):
        d1 = self._initial
        d2 = self._dict
        diffs = [(k, (v, d2[k])) for k, v in d1.items() if k in d2 and v != d2[k]]
        return dict(diffs)

    @property
    def has_changed(self):
        return bool(self.diff)

    @property
    def changed_fields(self):
        return self.diff.keys()

    def get_field_diff(self, field_name):
        """
        Returns a diff for field if it's changed and None otherwise.
        """
        return self.diff.get(field_name, None)

    def save(self, *args, **kwargs):
        """
        Saves model and set initial state.
        """
        super(ModelDiffMixin, self).save(*args, **kwargs)
        self._initial = self._dict

    @property
    def _dict(self):
        return model_to_dict(self, fields=[field.name for field in self._meta.fields])


class FilteredManagerMixin(object):
    def __init__(self, **kwargs):
        super(FilteredManagerMixin, self).__init__()
        self.kwargs = kwargs

    def get_queryset(self):
        qs = super(FilteredManagerMixin, self).get_queryset()
        if self.kwargs:
            return qs.filter(**self.kwargs)
        return qs


class FilteredManager(FilteredManagerMixin, Manager):
    pass
