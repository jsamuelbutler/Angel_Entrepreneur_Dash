FRONTEND
^^^^^^^^
Install YARN ::

  $ curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
  $ echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
  $ sudo apt-get update && sudo apt-get install yarn

Install dependencies ::

  $ yarn install

To create DLL file ::

  $ yarn run createDLL

DEV building project(HOT RELOAD) ::

  $ yarn run dev


outset
==============================

Quantifying Pre Revenue Startups


LICENSE: BSD

Basic Commands
--------------

Setting Up Your Users
^^^^^^^^^^^^^^^^^^^^^

To create a **normal user account**, just go to Sign Up and fill out the form. Once you submit it, you'll see a "Verify Your E-mail Address" page. Go to your console to see a simulated email verification message. Copy the link into your browser. Now the user's email should be verified and ready to go.

To create an **superuser account**, use this command::

    $ python manage.py createsuperuser

For convenience, you can keep your normal user logged in on Chrome and your superuser logged in on Firefox (or similar), so that you can see how the site behaves for both kinds of users.

Test coverage
^^^^^^^^^^^^^

To run the tests, check your test coverage, and generate an HTML coverage report::

    $ coverage run manage.py test
    $ coverage html
    $ open htmlcov/index.html

Running end to end integration tests
------------------------------------

N.B. The integration tests will not run on Windows.

To install the test runner::

  $ pip install hitch

To run the tests, enter the outset/tests directory and run the following commands::

  $ hitch init

Then run the stub test::

  $ hitch test stub.test

This will download and compile python, postgres and redis and install all python requirements so the first time it runs it may take a while.

Subsequent test runs will be much quicker.

The testing framework runs Django, Celery (if enabled), Postgres, HitchSMTP (a mock SMTP server), Firefox/Selenium and Redis.


Setting up dev environment
--------------------------

Angel.co account
^^^^^^^^^^^^^^^^

Go to https://angel.co/api and create an app. You should paste your docker machine IP as `Main URI` and 'Redirect URI' must be like::
  <your-docker-IP>/social/complete/angel/
You will get an email with secret and key.
Create file config/local_extra.py and paste them in following format

::
  SOCIAL_AUTH_ANGEL_KEY = '8527945dba16206bb7eb326c75e712b18810604b51989bdc'
  SOCIAL_AUTH_ANGEL_SECRET = '73094303c1879f76d0ba011a2294b96ad8f0d71257411a8a'

Frontend
^^^^^^^^

Install grunt dependencies ::

  $ npm install

To install bower dependencies and put them in specified files ::

  $ grunt install

There is a special view on ``/base/`` that renders base template


Docker
^^^^^^

Getting Up and Running with Docker
==================================

.. index:: Docker

The steps below will get you up and running with a local development environment.

Prerequisites
--------------

* docker
* docker-machine
* docker-compose
* virtualbox

If you don't already have these installed, you can get them at:

* https://github.com/docker/toolbox/releases
* https://www.virtualbox.org/wiki/Downloads

Go to the Root of your Project
------------------------------

All of these commands assume you are in the root of your generated project.

Create the Machine
-------------------

::

    $ docker-machine create --driver virtualbox default

**Note:** If you want to have more than one docker development environment, then
name them accordingly. Instead of 'default' you might have 'dev', 'myproject',
'djangopackages', et al. 'default' will play nicely with Kitematic though.

Make the new machine the active unit
-------------------------------------

This tells our computer that all future commands are specifically for the just
created machine. Using the ``eval`` command we can switch machines as needed.

::

    $ eval "$(docker-machine env default)"

Get the IP Address
--------------------

Acquiring the IP Address is good for two reasons:

1. Confirms that the machine is up and running.
2. Tells us the IP address where our Django project is being served.

::

    $ docker-machine ip default
    123.456.789.012

Saving changes
--------------

If you are using OS X or Windows, you need to create a /data partition inside the
virtual machine that runs the docker deamon in order make all changes persistent.
If you don't do that your /data directory will get wiped out on every reboot.

To create a persistent folder, log into the virtual machine by running:

::

    $ docker-machine ssh default
    $ sudo su
    $ echo 'ln -sfn /mnt/sda1/data /data' >> /var/lib/boot2docker/bootlocal.sh


In case you are wondering why you can't use a host volume to keep the files on
your mac: As of `boot2docker` 1.7 you'll run into permission problems with mounted
host volumes if the container creates his own user and chown's the directories
on the volume. Postgres is doing that, so we need this quick fix to ensure that
all development data persists.

Build the Stack
---------------

This can take a while, especially the first time you run this particular command
on your development system.

::
    $ docker-compose build

Boot the System
------------------------------

This brings up both Django and PostgreSQL. The first time it is run it might
take a while to get started, but subsequent runs will occur quickly.

::
    $ docker-compose up

If you want to run the entire system in production mode, then run:

::
    $ docker-compose -f staging.yml up

If you want to run the stack in detached mode (in the background), use the ``-d`` argument:

::
    $ docker-compose up -d

Running bash commands (i.e. management commands)
----------------------------------------------------

This is done using the ``docker-compose run`` command. In the following examples
we specify the ``django`` container as the location to run our management commands.

Example:
::

    $ docker-compose run django python manage.py migrate
    $ docker-compose run django python manage.py createsuperuser

Start client
----------------------------------------------------

Example:
::

    $ cd public
    $ npm install
    $ npm start