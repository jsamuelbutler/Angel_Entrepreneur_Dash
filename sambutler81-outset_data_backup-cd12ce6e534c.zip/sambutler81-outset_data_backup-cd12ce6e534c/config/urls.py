from __future__ import unicode_literals

from django.conf import settings
from django.conf.urls import include, url
from django.contrib import admin
from django.views.generic import TemplateView

from outset.accelerators.urls import router as accelerators_router
from outset.accounts.urls import router as accounts_router
from outset.accounts.views import CurrentUserAPIView
from outset.billing.urls import router as billing_router
from outset.billing.views import CashAPIView
from outset.doc.views import get_swagger_view
from outset.finicity.urls import router as finicity_router
from outset.oauth2provider.urls import router as oauth2_router
from outset.notes_and_docs.urls import router as docs_router
from outset.invitations.urls import router as invites_router
from outset.kpis.urls import router as kpi_router
from outset.activities.urls import router as activities_router
from outset.todos.urls import router as todos_router
from outset.startups.urls import router as startups_router
from outset.updates.urls import router as updates_router


react = TemplateView.as_view(template_name='react.html')


urlpatterns = [
    url(r'404^$', TemplateView.as_view(template_name='404.html'), name="404"),
    url(r'500^$', TemplateView.as_view(template_name='500.html'), name="500"),

    # Django Admin
    url(r'^admin/', include(admin.site.urls)),

    # RESTful docs
    url(r'^api_docs/$', get_swagger_view(title='Outset API')),
    url(r'^api_docs_new/$', TemplateView.as_view(template_name='doc/index.html')),

    # API docs authentication
    url(r'api_docs/', include('outset.billing.auth_views', namespace='rest_framework')),

    # User management
    url(r'^', include('outset.billing.urls')),
    url(r'^', include('outset.notes_and_docs.urls', namespace='notes_and_docs')),

    url(r'^oauth/', include('outset.oauth2provider.urls', namespace='oauth2_provider')),

    url(r'^api/me/$', CurrentUserAPIView.as_view(), name='me'),
    url(r'^api/me/cash/$', CashAPIView.as_view()),
    url(r'^api/', include(accounts_router.urls)),
    url(r'^api/', include(accelerators_router.urls)),
    url(r'^api/', include(startups_router.urls)),
    url(r'^api/', include(todos_router.urls)),
    url(r'^api/', include(invites_router.urls)),
    url(r'^api/', include(kpi_router.urls)),
    url(r'^api/', include(activities_router.urls)),
    url(r'^api/', include(updates_router.urls)),
    url(r'^api/', include(billing_router.urls)),
    url(r'^api/', include(docs_router.urls)),
    url(r'^api/', include(finicity_router.urls)),
    url(r'^api/', include(oauth2_router.urls)),

    url(r'', react, name="react"),
    url(r'^login?$', react, name='login'),
    url(r'^signup?$', react, name='signup'),
    url(r'^signup/invite/(?P<invite>[^/]+)$', react, name='signup-invite'),
    url(r'^change-password?$', react, name='change_password'),
    url(r'^activate/(?P<token>[0-9A-Za-z_\-]+)$', react, name='activate'),
    url(r'^logout$', react, name='logout'),
    url(r'^require_email$', react, name='require_email'),
    url(r'^password_change$', react, name='password_change'),
    url(r'^password_change/done$', react, name='password_change_done'),
    url(r'^password_reset$', react, name='password_reset'),
    url(r'^password_reset/done$', react, name='password_reset_done'),
    url(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})$', react, name='password_reset_confirm'),
    url(r'^reset/done$', react, name='password_reset_complete'),
    url(r'^unsubscribe/(?P<token>.*)$', react, name='unsubscribe'),
]

if settings.DEBUG:
    import debug_toolbar
    from django.conf.urls.static import static

    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += [
        # Connect django-debug-toolbar urls
        url(r'^__debug__/', include(debug_toolbar.urls)),
    ]
