import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button } from '@sketchpixy/rubix'
import EventEmitter from 'wolfy87-eventemitter'
import { I18n } from 'react-redux-i18n'

const EE = new EventEmitter()

class MessagesBox extends Component {
  constructor (props) {
    super(props)
    this.state = {
      showModal: false,
      title: I18n.t('messageBox.title'),
      message: '',
      isChecked: false,
      question: '',
      type: null
    }
  }

  init (title, message, param) {
    this.setState({ showModal: true, title, message })
    if (param) this.setState({ question: param.question, type: param.type })
    return new Promise((resolve, reject) => {
      EE.addListener('yesEvent', () => { this.refs.MessageBoxRef && this.setState({ showModal: false }, () => resolve(this.state.isChecked)) })
      EE.addListener('noEvent', () => { this.refs.MessageBoxRef && this.setState({ showModal: false }, () => reject()) })
    })
  }
  resolveEvent () { EE.emitEvent('yesEvent') }
  rejectEvent () { EE.emitEvent('noEvent') }
  onChangeNote () { this.setState({isChecked: !this.state.isChecked}) }

  render () {
    const CHECK_BUTTON = (
      <label className="message-box control control--checkbox">{this.state.question}
        <input
          type="checkbox"
          checked={this.state.isChecked}
          onChange={::this.onChangeNote}/>
        <div className="control__indicator"/>
      </label>
    )
    return (
      <Modal show={this.state.showModal} onHide={::this.rejectEvent} className="messageBox-component" ref="MessageBoxRef">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title> { this.state.title }</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <span className={this.state.type ? 'messages-with-check' : ''}>
            { this.state.message }
          </span>
          <span>
            {this.state.type ? CHECK_BUTTON : ''}
          </span>
        </Modal.Body>
        <Modal.Footer>
          <Button className="common-default-button left common-apply-button" onClick={::this.resolveEvent}>{I18n.t('messageBox.yesButton')}</Button>
          <Button className="default-outline-button common-close-button" bsStyle="link" onClick={::this.rejectEvent}>{I18n.t('messageBox.noButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
export default connect(null, null, null, {withRef: true})(MessagesBox)
