/* global localStorage */
import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncPatchMe, asyncPatchAccelerator, asyncStartDataIntegrationShow, asyncStartUpXeroIntegration, asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpStripeIntegration } from '../../../actions'
import PropTypes from 'prop-types'
import BankForm from '../../pages/data/dialogs/bankForm/'
import RenderForm from '../../pages/data/dialogs/renderForm/'

class WelcomeConnect extends Component {
  constructor (props) {
    super(props)
    this.state = {
      showModal: false,
      title: I18n.t('messageBox.title'),
      message: '',
      acceleratorName: '',
      firstName: '',
      lastName: '',
      mainErrors: []
    }
  }
  shouldComponentUpdate (props, state) { return this.state !== state || this.props.user !== props.user }

  connectStripe () { this.props.asyncStartUpStripeIntegration(null, null, this.props.user.startup) }
  connectXero () { this.props.asyncStartUpXeroIntegration(null, null, this.props.user.startup) }
  openBankFormModal () { this.refs.bankForm.getWrappedInstance().open() }
  openNextForm () { this.refs.renderForm.getWrappedInstance().open() }

  close () { this.setState({showModal: false}); localStorage.setItem('welcomeConnect', true) }
  open () { this.setState({showModal: true}) }
  dontShow () { this.props.asyncStartDataIntegrationShow(null, ::this.close, this.props.user.startup) }
  render () {
    return (
      <Modal show={this.state.showModal} onHide={::this.close} className="welcomeConnect-component">
        <Modal.Header>
          <Modal.Title> {I18n.t('messageBox.welcome')}</Modal.Title>
          <span>Connect all your data so that you can view your company performance in real-time.</span>
        </Modal.Header>
        <Modal.Body>
          {!(this.props.startup.stripe_data) ? <div><h4>- Click here to connect to <a onClick={!(this.props.startup.stripe_data) && ::this.connectStripe}>Stripe</a></h4></div> : null}
          {!(this.props.startup.xero_data) ? <div><h4>- Click here to connect to <a onClick={!(this.props.startup.xero_data) && ::this.connectXero}>Xero</a></h4></div> : null}
          {!(this.props.startup.bank_data) ? <div><h4>- Click here to connect to your <a onClick={!(this.props.startup.bank_data) && ::this.openBankFormModal}>bank</a></h4></div> : null}
        </Modal.Body>
        <Modal.Footer>
          <div className="default-outline-button common-close-button">
            <Button onClick={::this.close} bsStyle="link" className="common-default-close-button common-apply-button">{I18n.t('common.close')}</Button>
            <a onClick={::this.dontShow} className="dont-show common-close-button">Don't show me this again</a>
          </div>
        </Modal.Footer>
        <BankForm startup={this.props.user.startup} openNextForm={::this.openNextForm} ref="bankForm"/>
        <RenderForm startup={this.props.user.startup} ref="renderForm"/>
      </Modal>
    )
  }
}

WelcomeConnect.propTypes = {
  asyncPatchAccelerator: PropTypes.func.isRequired,
  asyncPatchMe: PropTypes.func.isRequired,
  user: PropTypes.shape({
    accelerator: PropTypes.any
  })
}
function mapStateToProps ({app, startups}) { return { user: app.user, startup: startups.startup } }
export default connect(mapStateToProps, {asyncPatchMe, asyncPatchAccelerator, asyncStartDataIntegrationShow, asyncStartUpXeroIntegration, asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpStripeIntegration}, null, {withRef: true})(WelcomeConnect)
