import './style'
import React from 'react'
import { Grid, Row, Col } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

const AccessDenied = () => {
  return (
    <div className="accessDenied-component common-page-component">
      <Grid className="common-lower-width">
        <Row>
          <Col>
            <div className="info-block common-warning">
              <p className="titles">{I18n.t('accessDenied.whoops')}<br/>
                <span> {I18n.t('accessDenied.title')} </span>
              </p>
              <span className="message">
                {I18n.t('accessDenied.pageAccess')}
              </span>
            </div>
          </Col>
        </Row>
        <div className="common-container-img">
          <div className="common-not-found-pet adaptive-mascot"/>
        </div>
      </Grid>
    </div>
  )
}
export default AccessDenied
