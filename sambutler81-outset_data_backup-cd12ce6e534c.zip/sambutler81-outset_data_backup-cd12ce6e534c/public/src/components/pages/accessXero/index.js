/* global localStorage */
import React, {Component} from 'react'
import { connect } from 'react-redux'
import './style'
import { Row, Col, Grid, Button, PanelContainer, Panel, PanelBody } from '@sketchpixy/rubix'
import { asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpXeroIntegrationSelectAccounts } from '../../../actions'
import { itExist, truncateString } from '../../../utils/helpers'
import { history } from '../../../store'
import MessageBoxAlert from '../../dialogs/messageBoxAlert/'

class AccessXero extends Component {
  constructor (props) {
    super(props)
    this.state = { ids: [] }
    if (localStorage.getItem('xero') && localStorage.getItem('xero') === this.props.location.query.oauth_verifier) {
      this.props.asyncStartUpXeroIntegrationAccounts(null, null, this.props.app.user.startup)
    } else {
      localStorage.setItem('xero', this.props.location.query.oauth_verifier)
      this.props.asyncStartUpXeroIntegrationComplete(null, null, this.props.app.user.startup, this.props.location.query.oauth_verifier, () => { this.props.asyncStartUpXeroIntegrationAccounts(null, null, this.props.app.user.startup) })
    }
  }

  selectAccounts (id) {
    const ids = this.state.ids
    if (ids.indexOf(id) !== -1) {
      ids.splice(ids.indexOf(id), 1)
    } else {
      ids.push(id)
    }
    this.setState({ids})
  }

  applyAccount () {
    this.props.asyncStartUpXeroIntegrationSelectAccounts(null, () => {
      this.refs.messageBoxAlert.getWrappedInstance().init('Information', 'We\'re working hard to gather all this data for you, but it\'s going to take a while.  Please check back in about [how ever long you think] to see if we\'ve been able to populate your graphs.')
        .then(() => { history.push('/data') })
        .catch(() => { history.push('/data') })
    }, this.props.app.user.startup, this.state.ids)
  }

  render () {
    const TEAM_BODY = (
      <Row>
        {
          this.props.accountsXero.map((user, index) => {
            return (
              <Col key={index} sm={6} className="mdComp lgComp xsComp common-half-padding-child">
                <PanelContainer className={`${this.state.ids.indexOf(user.accountID) !== -1 ? 'acc-border-green' : 'acc-border'} common-cursor-pointer`}>
                  <Panel className="team-panel" onClick={() => { ::this.selectAccounts(user.accountID) }}>
                    <PanelBody>
                      <Row>
                        <Col xs={12}>
                          <div className="user-name" title={user.name}>{truncateString(user.name, 30)}</div>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs={12}>
                          <span className="specialization" title={user.description}>{truncateString(user.description, 100)}</span>
                        </Col>
                      </Row>
                    </PanelBody>
                  </Panel>
                </PanelContainer>
              </Col>
            )
          })
        }
      </Row>
    )

    const TEAM_EMPTY = (
      <div>
        <div className="common-container-img">
          <div className="gears-pet"/>
          <p>List account is empty</p>
          <span>Get Started by adding xero account so you can work with them and try again</span>
          <br/>
          <a href="/data">Go to connect</a>
        </div>
      </div>
    )

    return (
      <div className="accessXero-component">
        <div>
          {itExist(this.props.accountsXero) ? <h3 className="text-center info-block">Please select which accounts from Xero you would like to use to calculate Customer Acquisition Cost.</h3> : null}
        </div>
        <div className="common-page-component common-wrap-half-padding">
          <Grid className="accessXero-page">
            { itExist(this.props.accountsXero) ? TEAM_BODY : TEAM_EMPTY }
          </Grid>
        </div>
        <div>
          {itExist(this.props.accountsXero) ? <Button disabled={this.state.ids.length <= 0} className="applyBtn common-default-button" onClick={::this.applyAccount}>Apply Account</Button> : null }
        </div>
        <MessageBoxAlert ref="messageBoxAlert"/>
      </div>
    )
  }
}
function mapStateToProps ({app, startups}) { return {app, accountsXero: startups.accountsXero} }
export default connect(mapStateToProps, {asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpXeroIntegrationSelectAccounts})(AccessXero)
