import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Grid, Col } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncEmailConfirm } from '../../../../actions'
import PropTypes from 'prop-types'

class Activate extends Component {
  componentDidMount () { this.props.asyncEmailConfirm(null, this.props.params.token) }

  render () {
    return (
      <div className="activate-component">
        <Grid className="common-lower-width">
          <Row>
            <Col>
              <div className="info-block common-warning">
                <p className="titles">{I18n.t('auth.activate.title')}</p>
                <span className="message">{I18n.t('auth.activate.accountActivated')}</span>
              </div>
            </Col>
          </Row>
          <div className="common-container-img">
            <div className="activated-pet adaptive-mascot"/>
          </div>
        </Grid>
        <div className="footerr">
          <a href="mailto:support@outset.vc">{I18n.t('signUp.emailSupport')}</a>
          <a>{I18n.t('signUp.privacy')}</a>
          <a className="last-stick">{I18n.t('signUp.terms')}</a>
          <div className="all-rights">
            {I18n.t('login.footerRights')}
          </div>
        </div>
      </div>
    )
  }
}
Activate.propTypes = { asyncEmailConfirm: PropTypes.func }
export default connect(null, { asyncEmailConfirm })(Activate)
