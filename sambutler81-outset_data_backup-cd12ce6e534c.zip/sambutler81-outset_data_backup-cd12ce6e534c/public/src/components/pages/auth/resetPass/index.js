import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Grid, Panel, PanelBody, PanelHeader, PanelContainer, PanelFooter, Form, FormGroup, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import TemplateInput, { ValidatorError } from '../../../common/templateInput/'
import { ValidatorUserPassword, ValidatorUserPasswordTwice } from '../../../../utils/validators'
import { asyncResetPasswordConfirm } from '../../../../actions'

class Reset extends Component {
  constructor (props) {
    super(props)
    this.state = {
      password: '',
      repeatPassword: '',
      passwordError: '',
      authMessage: '',
      authState: 'login',
      mainErrors: [],
      UIDB64: this.props.params.id && this.props.params.id,
      token: this.props.params.token && this.props.params.token
    }
  }

  onSubmitButtonClick () { this.props.asyncResetPasswordConfirm(null, this.state.UIDB64, this.state.token, this.state.password) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }

  render () {
    return (
      <div className="resetPass-component">
        <Grid fluid className="auth common-res-pass">
          <Row className="auth__row">
            <div className="page">
              <div>
                <div className="header">
                  <div className="logo-login"/>
                </div>
                <Row>
                  <Col>
                    <div className="container-form">
                      <div className="logo-login-pet" />
                      <PanelContainer controls={false} >
                        <Panel className="login-form">
                          <PanelHeader>
                            <span> {I18n.t('reset.resetTitle')}</span>
                          </PanelHeader>
                          <PanelBody >
                            <Form >
                              <FormGroup>
                                <TemplateInput
                                  type="login-password"
                                  group="main"
                                  name="password"
                                  className="login-form-input"
                                  placeholder={I18n.t('reset.password')}
                                  value={this.state.password}
                                  fieldTwice={this.refs.repeatPassword}
                                  onChange={::this.fnChange}
                                  fnValidator={ValidatorUserPassword}
                                  required="required"/>
                              </FormGroup>
                              <FormGroup>
                                <TemplateInput
                                  ref="repeatPassword"
                                  type="login-password"
                                  group="main"
                                  name="repeatPassword"
                                  className="login-form-input"
                                  placeholder={I18n.t('reset.repeatPass')}
                                  value={this.state.repeatPassword}
                                  onChange={::this.fnChange}
                                  fnValidator={ValidatorUserPasswordTwice}
                                  required="required"/>
                              </FormGroup>
                              <div className="login-fail">{this.state.authMessage}</div>
                              <Button disabled={this.state.mainErrors.length !== 0} className="login-button" outlined onClick={::this.onSubmitButtonClick}>{I18n.t('reset.changeButton')}</Button>
                            </Form>
                          </PanelBody>
                          <PanelFooter className="common-panel-footer-margin"/>
                        </Panel>
                      </PanelContainer>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Row>
        </Grid>
        <div className="footerr">
          <a href="mailto:support@outset.vc">{I18n.t('reset.emailSupport')}</a>
          <a href="privacy" >{I18n.t('reset.privacy')}</a>
          <a href="terms" className="last-stick">{I18n.t('reset.terms')}</a>
          <div className="all-rights">
            {I18n.t('reset.footerRights')}
          </div>
        </div>
      </div>
    )
  }
}

Reset.propTypes = {
  params: PropTypes.shape({
    id: PropTypes.string.isRequired,
    token: PropTypes.string.isRequired
  }),
  asyncResetPasswordConfirm: PropTypes.func.isRequired
}
function mapStateToProps ({auth}) { return {auth} }
export default connect(mapStateToProps, {asyncResetPasswordConfirm})(Reset)
