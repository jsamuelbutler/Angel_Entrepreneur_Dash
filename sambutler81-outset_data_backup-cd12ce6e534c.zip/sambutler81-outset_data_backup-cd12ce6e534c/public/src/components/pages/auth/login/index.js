import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Grid, PanelFooter, Panel, PanelBody, PanelHeader, PanelContainer, Form, FormGroup, Button, Icon } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import PrivacyModal from '../../../dialogs/policy/privacy'
import TermsModal from '../../../dialogs/policy/terms'
import PropTypes from 'prop-types'
import { ValidatorEmail, ValidatorUserPassword, ValidatorUserPasswordTwice } from '../../../../utils/validators'
import { asyncLoginUser, asyncRegisterUser, asyncResetPassword, actionResetAuthState, asyncSocial } from '../../../../actions'
import TemplateInput, { ValidatorError } from '../../../common/templateInput/'

class Login extends Component {
  constructor (props) {
    super(props)
    this.state = {
      email: '',
      password: '',
      repeatPassword: '',
      authMessage: '',
      authState: 'login',
      mainErrors: [],
      title: I18n.t('login.logInTitle'),
      buttonTitle: I18n.t('login.logInButton')
    }
  }

  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }

  fnPrivacyModal () { this.refs.privacyModal.getWrappedInstance().open() }
  fnTermsModal () { this.refs.termsModal.getWrappedInstance().open() }

  linkedInSocial () { this.props.asyncSocial(null, () => {}, 'linkedin-oauth2') }
  googleSocial () { this.props.asyncSocial(null, () => {}, 'google-oauth2') }

  onSubmitKeyUp (e) {
    if (e.keyCode === 13) {
      e.preventDefault()
      this.onSubmitButtonClick()
    }
  }

  onSubmitButtonClick () {
    switch (this.state.authState) {
      case 'login':
        return (this.props.asyncLoginUser(null, this.state.email, this.state.password))
      case 'signin':
        return (this.props.asyncRegisterUser(null, this.state.password, null, null, null, this.state.email))
      case 'reset':
        return this.props.asyncResetPassword(null, this.state.email)
    }
  }

  fnClear () {
    this.refs.email && this.refs.email.getWrappedInstance().fnClearText()
    this.refs.password && this.refs.password.getWrappedInstance().fnClearText()
    this.refs.repPass1 && this.refs.repPass1.getWrappedInstance().fnClearText()
    this.refs.repPass2 && this.refs.repPass2.getWrappedInstance().fnClearText()
  }

  fnSignInForm () {
    if (this.state.authState === 'login') {
      this.setState({
        authState: 'signin',
        title: I18n.t('login.signUpTitle'),
        buttonTitle: I18n.t('login.createAccButton'),
        password: '',
        repeatPassword: '',
        mainErrors: []
      }, this.fnClear)
    } else {
      this.setState({
        authState: 'login',
        title: I18n.t('login.logInTitle'),
        buttonTitle: I18n.t('login.logInButton'),
        password: '',
        mainErrors: []
      }, this.fnClear)
    }
  }

  asyncResetPasswordForm () {
    this.setState({
      authState: 'reset',
      title: I18n.t('login.resetPassTitle'),
      buttonTitle: I18n.t('login.resetPassButton'),
      mainErrors: []
    }, this.fnClear)
  }

  fnBackToLogin () {
    this.props.actionResetAuthState()
    this.fnSignInForm()
  }

  emailResetSentContent () {
    return (
      <div>
        <div className="header">
          <div className="logo-login"/>
        </div>
        <div className="info-message">
          {I18n.t('login.resetPassSuccess')}
          {I18n.t('login.checkEmail')}
        </div>
        <div className="info-message-footer" onClick={::this.fnBackToLogin}>
          <Icon glyph="icon-feather-arrow-left" /> {I18n.t('login.backToLogIn')}
        </div>
      </div>
    )
  }

  emailSentContent () {
    return (
      <div>
        <div className="header">
          <div className="logo-login"/>
        </div>
        <div className="info-message">
          {I18n.t('login.infoMessageSuccess')}
          {I18n.t('login.checkEmail')}
        </div>
        <div className="info-message-footer" onClick={::this.fnBackToLogin}>
          <Icon glyph="icon-feather-arrow-left" /> {I18n.t('login.backToLogIn')}
        </div>
      </div>
    )
  }

  emailFieldContent () {
    return (
      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
        <TemplateInput
          ref="email"
          type="login-email"
          group="main"
          name="email"
          className="login-form-input"
          placeholder={I18n.t('login.email')}
          value={this.state.email}
          onChange={::this.fnChange}
          fnValidator={ValidatorEmail}
          required="required"/>
      </FormGroup>
    )
  }

  passwordFieldContent () {
    return (
      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
        <TemplateInput
          ref="password"
          type="login-password"
          group="main"
          name="password"
          className="login-form-input"
          placeholder={I18n.t('login.password')}
          value={this.state.password}
          onChange={::this.fnChange}
          fnValidator={ValidatorUserPassword}
          required="required"/>
      </FormGroup>
    )
  }

  repeatPasswordFieldContent () {
    return (
      <div>
        <FormGroup onKeyUp={::this.onSubmitKeyUp}>
          <TemplateInput
            ref="repPass1"
            type="login-password"
            group="main"
            name="password"
            className="login-form-input"
            placeholder={I18n.t('login.password')}
            value={this.state.password}
            fieldTwice={this.refs.repPass2}
            onChange={::this.fnChange}
            fnValidator={ValidatorUserPassword}
            required="required"/>
        </FormGroup>
        <FormGroup onKeyUp={::this.onSubmitKeyUp}>
          <TemplateInput
            ref="repPass2"
            type="login-password"
            group="main"
            name="repeatPassword"
            className="login-form-input"
            placeholder={I18n.t('login.passwordRepeat')}
            value={this.state.repeatPassword}
            onChange={::this.fnChange}
            fnValidator={ValidatorUserPasswordTwice}
            required="required"/>
        </FormGroup>
      </div>
    )
  }

  render () {
    const LOGIN = (
      <div>
        <div className="header-spinner"/>
        <div className="header">
          <div className="logo-login"/>
        </div>
        <Row>
          <Col>
            <div className="container-form">
              <div className="logo-login-pet" />
              <PanelContainer controls={false} >
                <Panel className="login-form">
                  <PanelHeader>
                    <span> {this.state.title}</span>
                  </PanelHeader>
                  <PanelBody >
                    <Form >
                      { ::this.emailFieldContent() }
                      { this.state.authState === 'login' ? ::this.passwordFieldContent() : (this.state.authState === 'signin' ? ::this.repeatPasswordFieldContent() : null) }
                      <div className="forget-password" >{this.state.authState === 'reset' ? I18n.t('login.resetPassMessage') : ''}</div>
                      <div className="forget-password" onClick={::this.asyncResetPasswordForm}>{this.state.authState === 'login' ? I18n.t('login.forgotPassMessage') : ''}</div>
                      <div className="login-fail">{this.state.authMessage}</div>
                      <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="login-button" outlined onClick={::this.onSubmitButtonClick}>{this.state.buttonTitle}</Button>
                      <div className="create-account" onClick={::this.fnSignInForm}>{this.state.authState === 'login' ? I18n.t('login.createAccMessage') : I18n.t('login.haveAccQuestMessage')}</div>
                    </Form>
                  </PanelBody>
                  <PanelFooter>
                    <div className="word-line">{I18n.t('login.or')}</div>
                    <div className="container-footer">
                      <Row>
                        <Col xs={12} className="footer-login">
                          <div onClick={::this.linkedInSocial} title="Linked-In" className="linked-in" />
                          <div onClick={::this.googleSocial} title="Google" className="google" />
                        </Col>
                      </Row>
                    </div>
                  </PanelFooter>
                </Panel>
              </PanelContainer>
            </div>
          </Col>
        </Row>
      </div>
      )
    return (
      <div className="login-component">
        <Grid fluid className="auth">
          <Row className="auth__row">
            <Col xs={12}>
              <div className="page">
                {(this.props.auth.status !== 'email_sent') ? (this.props.auth.status === 'email_reset_sent' ? ::this.emailResetSentContent() : LOGIN) : this.emailSentContent()}
              </div>
            </Col>
          </Row>
        </Grid>
        <div className="footerr">
          <a href="mailto:support@outset.vc">{I18n.t('login.emailSupport')}</a>
          <a onClick={::this.fnPrivacyModal}>{I18n.t('login.privacy')}</a>
          <a onClick={::this.fnTermsModal} className="last-stick">{I18n.t('login.terms')}</a>
          <div className="all-rights">
            {I18n.t('login.footerRights')}
          </div>
        </div>
        <PrivacyModal ref="privacyModal"/>
        <TermsModal ref="termsModal"/>
      </div>
    )
  }
}

Login.propTypes = {
  auth: PropTypes.shape({
    status: PropTypes.string
  }),
  asyncLoginUser: PropTypes.func.isRequired,
  asyncRegisterUser: PropTypes.func.isRequired,
  asyncResetPassword: PropTypes.func.isRequired,
  actionResetAuthState: PropTypes.func.isRequired
}

function mapStateToProps ({auth, network}) { return {auth, networkActive: network.networkActive} }
export default connect(mapStateToProps, {asyncLoginUser, asyncRegisterUser, asyncResetPassword, actionResetAuthState, asyncSocial})(Login)
