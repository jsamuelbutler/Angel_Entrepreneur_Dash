/* global localStorage */
import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Grid, Panel, PanelBody, PanelFooter, PanelHeader, PanelContainer, Form, FormGroup, Button, Icon } from '@sketchpixy/rubix'
import { ValidatorUserName, ValidatorUserPassword, ValidatorUserPasswordTwice } from '../../../../utils/validators'
import TemplateInput, { ValidatorError } from '../../../common/templateInput/'
import { fnGoToLoginScreen } from '../../../../utils/helpers'
import { asyncRegisterUser, asyncSocial } from '../../../../actions'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'

class RegistrationInvite extends Component {
  constructor (props) {
    super(props)
    localStorage.setItem('loggedin', false); this.props.actionClearStore()
    this.state = {
      firstName: '',
      lastName: '',
      firstNameError: '',
      lastNameError: '',
      password: '',
      repeatPassword: '',
      passwordError: '',
      authMessage: '',
      authState: 'login',
      mainErrors: []
    }
  }

  linkedInSocial () { this.props.asyncSocial(null, () => {}, 'linkedin-oauth2', this.props.params.token) }
  googleSocial () { this.props.asyncSocial(null, () => {}, 'google-oauth2', this.props.params.token) }

  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  onSubmitButtonClick () { this.props.asyncRegisterUser(null, this.state.password, this.props.params.token, this.state.firstName, this.state.lastName) }
  onSubmitKeyUp (e) {
    if (e.keyCode === 13) {
      e.preventDefault()
      this.onSubmitButtonClick()
    }
  }

  render () {
    const LOGIN = (
      <div>
        <div className="header-spinner"/>
        <div className="header common-reg-invite">
          <div className="logo-login"/>
        </div>
        <Row>
          <Col>
            <div className="container-form">
              <div className="logo-login-pet" />
              <PanelContainer controls={false} >
                <Panel className="login-form">
                  <PanelHeader>
                    <span> {I18n.t('invite.regTitle')}</span>
                  </PanelHeader>
                  <PanelBody >
                    <Form >
                      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
                        <TemplateInput
                          type="login-text"
                          group="main"
                          name="firstName"
                          className="login-form-input"
                          placeholder={I18n.t('invite.firstName')}
                          value={this.state.firstName}
                          onChange={::this.fnChange}
                          fnValidator={ValidatorUserName}
                        />
                      </FormGroup>
                      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
                        <TemplateInput
                          type="login-text"
                          group="main"
                          name="lastName"
                          className="login-form-input"
                          placeholder={I18n.t('invite.lastName')}
                          value={this.state.lastName}
                          onChange={::this.fnChange}
                          fnValidator={ValidatorUserName}
                        />
                      </FormGroup>
                      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
                        <TemplateInput
                          type="login-password"
                          group="main"
                          name="password"
                          className="login-form-input"
                          placeholder={I18n.t('invite.password')}
                          value={this.state.password}
                          fieldTwice={this.refs.repeatPass}
                          onChange={::this.fnChange}
                          fnValidator={ValidatorUserPassword}
                          required="required"/>
                      </FormGroup>
                      <FormGroup onKeyUp={::this.onSubmitKeyUp}>
                        <TemplateInput
                          ref="repeatPass"
                          type="login-password"
                          group="main"
                          name="repeatPassword"
                          className="login-form-input"
                          placeholder={I18n.t('invite.repeatPass')}
                          value={this.state.repeatPassword}
                          onChange={::this.fnChange}
                          fnValidator={ValidatorUserPasswordTwice}
                          required="required"/>
                      </FormGroup>
                      <div className="login-fail">{this.state.authMessage}</div>
                      <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="login-button" outlined onClick={::this.onSubmitButtonClick} >{I18n.t('invite.signUpButton')}</Button>
                    </Form>
                  </PanelBody>
                  <PanelFooter>
                    <div className="word-line">{I18n.t('login.or')}</div>
                    <div className="container-footer">
                      <Row>
                        <Col xs={12} className="footer-login">
                          <div onClick={::this.linkedInSocial} title="Linked-In" className="linked-in" />
                          <div onClick={::this.googleSocial} title="Google" className="google" />
                        </Col>
                      </Row>
                    </div>
                  </PanelFooter>
                </Panel>
              </PanelContainer>
            </div>
          </Col>
          <Col>
            <div className="info-message-footer" onClick={fnGoToLoginScreen}>
              <Icon glyph="icon-feather-arrow-left" /> {I18n.t('login.backToLogIn')}
            </div>
          </Col>
        </Row>
      </div>
    )
    return (
      <div className="registrationInvite-component">
        <Grid fluid>
          <Row>
            <div className="page">
              { LOGIN }
            </div>
          </Row>
        </Grid>
        <div className="footerr">
          <a href="mailto:support@outset.vc">{I18n.t('invite.emailSupport')}</a>
          <a href="privacy">{I18n.t('invite.privacy')}</a>
          <a href="terms" className="last-stick">{I18n.t('invite.terms')}</a>
          <div className="all-rights">
            {I18n.t('invite.footerRights')}
          </div>
        </div>
      </div>
    )
  }
}

RegistrationInvite.propTypes = {
  params: PropTypes.shape({
    token: PropTypes.string.isRequired
  }),
  asyncRegisterUser: PropTypes.func.isRequired
}

function mapStateToProps ({network}) { return {networkActive: network.networkActive} }

export default connect(mapStateToProps, {asyncRegisterUser, asyncSocial})(RegistrationInvite)
