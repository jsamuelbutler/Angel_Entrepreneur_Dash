import './style'
import { connect } from 'react-redux'
import React, { Component } from 'react'
import { history } from '../../../store'

class Api extends Component {
  componentDidMount () { !this.props.app.user.viewApi && history.push('/portfolioManagement') }
  componentWillReceiveProps () { !this.props.app.user.viewApi && history.push('/portfolioManagement') }
  render () {
    return (
      <div className="API-component common-page-component">
        <iframe className="iframe" src={`https://app.outset.vc/api_docs_new/`}/>
      </div>
    )
  }
}
function mapStateToProps ({app}) { return {app} }
export default connect(mapStateToProps)(Api)

