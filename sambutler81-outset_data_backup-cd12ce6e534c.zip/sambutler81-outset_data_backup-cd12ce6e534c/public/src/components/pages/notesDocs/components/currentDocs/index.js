import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Grid, Panel, PanelBody, Icon, PanelHeader, PanelFooter, PanelContainer, Button } from '@sketchpixy/rubix'
import AddDoc from './../../dialogs/addDocNote/'
import AddFolder from './../../dialogs/addFolder/'
import EditFile from './../../dialogs/editFile/'
import MessageBox from '../../../../dialogs/messageBox/'
import { asyncGetDocsAll, asyncGetDocs, asyncDeleteDocs } from '../../../../../actions'
import { I18n } from 'react-redux-i18n'
import { Scrollbars } from 'react-custom-scrollbars'
import { itExist, getFileType } from '../../../../../utils/helpers'
import moment from 'moment'

class CurrentDocs extends Component {

  constructor (props) {
    super(props)
    this.state = {
      status: null,
      searchIsActive: false,
      file: null,
      searchText: '',
      companyFilePath: [{title: '/', startup: this.props.data.id}],
      selectedItem: null,
      companyFiles: null,
      companyId: null
    }
  }
  launchAddDoc (company, folder) { this.refs.addDoc.getWrappedInstance().open(company, folder) }
  launchAddFolder (company, folder) { this.refs.addFolder.getWrappedInstance().open(company, folder, this.state.companyId) }
  launchEditFile (file) { this.refs.editFile.getWrappedInstance().open(file) }
  launchDeleteFile () {
    this.refs.messageBox.getWrappedInstance().init(
      `Delete File`,
      `${I18n.t('manageFunds.removeMemberEnd')} ${this.state.file.title}?`
    )
    .then(() => {
      this.props.asyncDeleteDocs(null, this.state.file.id, this.state.file.startup)
      this.setState({file: null, selectedItem: null})
    })
    .catch(() => {})
  }
  fnClickFile (file, fileType, companyId) {
    this.doubleClickCalled = true
    if (fileType === 'dir') {
      this.props.asyncGetDocsAll(null, null, file.id, file.startup)
      this.state.companyFilePath.push(file)
      this.setState({file: null, selectedItem: null})
    } else if (fileType === 'file') {
      this.setState({companyId, file, selectedItem: (this.state.selectedItem !== file.id) && (file.parent !== null) ? file.id : null})
    }
  }
  fnOpenHeadFolder (folder, idxf, companyId) {
    let tmpArray = this.state.companyFilePath
    if (tmpArray.length !== idxf + 1) {
      tmpArray.splice(idxf + 1, Number.MAX_VALUE)
      this.setState({file: null, selectedItem: null, companyFilePath: tmpArray})
      if (idxf === 0) {
        this.props.asyncGetDocsAll(null, null, null, companyId)
      } else { this.props.asyncGetDocsAll(null, null, folder.id, companyId) }
    }
  }
  toggleSearch () {
    if (this.state.searchIsActive && this.state.searchText) { this.props.asyncGetDocsAll(null, null, null, this.props.data.id, ''); this.setState({companyFilePath: [{title: '/'}]}) } // required, cohort, parent, startup, search, extension, type)
    this.setState({searchIsActive: !this.state.searchIsActive, searchText: ''})
  }
  handleSearch (event) {
    const VALUE = event.target.value
    this.setState({searchText: VALUE, companyFilePath: [{title: '/'}]})
    window.clearTimeout(this.searchEvent)
    this.searchEvent = window.setTimeout(() => {
      if (VALUE.length >= 1) this.props.asyncGetDocsAll(null, null, null, this.props.data.id, VALUE)
      else this.props.asyncGetDocsAll(null, null, null, this.props.data.id, '')
    }, 300)
  }

  render () {
    let generateCompany = itExist(this.props.listFolders) ? this.props.listFolders.map((file, idxFl) => {
      let selectedFile = this.state.selectedItem === file.id ? 'selected' : ''
      return (
        <Col key={idxFl} xs={4}>
          <a href={file.google_link || file.link} target="_blank">
            <div className={`files ${selectedFile}`} onMouseDown={() => ::this.fnClickFile(file, file.type, this.props.data.id)} key={idxFl}>
              <div className="img-column">
                <div className={file.type === 'file' ? getFileType(file.extension) : file.type}/>
              </div>
              {
                file.type === 'dir' ? (
                  <div className="description-column-folder">
                    <div className="file-title noselect" title={file.title}>{file.title}</div>
                    <div className={`files-count ${!file.files ? 'zero' : ''} ${file.is_new ? 'folder-new' : ''} noselect`}>{!file.is_new ? file.files : 'NEW'}</div>
                  </div>
                  ) : (
                    <div className="description-column noselect">
                      <div className="file-title">{file.title}</div>
                      <div className="file-uploaded-folder">{I18n.t('noteDocs.uploadedBy')} &nbsp;{file.uploaded_by && file.uploaded_by.recognize}</div>
                      <div className="file-date">{I18n.t('noteDocs.on')} &nbsp;{ moment(file.uploaded).format('MMM Do YYYY')}</div>
                      {file.is_new ? <div className="file-new" >NEW</div> : ''}
                    </div>
                  )
              }
            </div>
          </a>
        </Col>)
    }) : <div className="no-files-yet">{I18n.t('noteDocs.noFiles')}</div>
    const searchPanel = () => {
      let showPanel = this.state.selectedItem && this.state.companyId === this.props.data.id ? '' : 'hide'
      let toolsPanel = (
        <div className={`tools-panel ${showPanel}`}>
          <Icon className="buttons open-button" onClick={() => ::this.launchEditFile(this.state.file)} glyph="fa fa-pencil"/>
          <Icon className="buttons remove-button" onClick={::this.launchDeleteFile} glyph="fa fa-trash"/>
        </div>
      )
      let content
      if (!this.state.searchIsActive) {
        content = (
          <div>
            <div className="header-todos">
              <span className="todos-name" title={this.props.data.name}>{this.props.data.name ? this.props.data.name : 'DOCS'}</span>{this.state.status}
            </div>
            {toolsPanel}
            <Icon className="common-search-docs-btn search-button-todos" glyph="fa fa-search" title={I18n.t('common.search')} onClick={::this.toggleSearch}/>
          </div>
        )
      } else {
        content = (
          <div>
            {toolsPanel}
            <input className="search-docs-input" value={this.state.searchText} onChange={::this.handleSearch} autoFocus placeholder={I18n.t('common.search')}/>
            <Icon className="common-search-docs-btn" glyph="fa fa-times" title={I18n.t('common.hide')} onClick={::this.toggleSearch}/>
          </div>
        )
      }
      return content
    }
    let listDocs = (
      <Scrollbars
        autoHide
        autoHideTimeout={700}
        renderTrackHorizontal={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
        renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" style={{display: 'none'}}/>}
        ref="scrollbars" className="blur-layout">
        {generateCompany}
      </Scrollbars>
    )
    let classCompany = this.props.itCompany ? 'notesDocs-company notesDocs-company-file' : ''
    let classCompanyContainer = this.props.itCompany ? 'height' : ''
    let classCompanyPanel = this.props.itCompany ? 'updates-table-file height' : ''
    return (
      <Col xs={12} sm={12} md={this.props.fullWidth ? 12 : 6} key={this.props.index} className={`${classCompany} common-half-padding-child`}>
        <PanelContainer className={`notes-docs-panel ${classCompanyContainer}`}>
          <Panel className={classCompanyPanel}>
            <PanelHeader className="White common-tile" title={this.props.data.name}>
              {searchPanel()}
            </PanelHeader>
            <PanelBody className="notesDocs-accelerator-file">
              <div className="container-folder-path">
                <table>
                  <tbody>
                    <tr>
                      <td>
                        <ul className="list-history">
                          {
                            this.state.companyFilePath.map((item, i) => {
                              return (
                                <li key={i} onClick={() => { ::this.fnOpenHeadFolder(item, i, this.props.data.id) }}>
                                  <span className={`folder-path ${i === this.state.companyFilePath.length - 1 ? '-active' : ''}`}>
                                    <div className="wrap">{i === 0 ? (<div className="home-ico" title="Root folder"/>) : (<p>{item.title}</p>)}</div>
                                  </span>
                                </li>
                              )
                            })
                          }
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <Grid>
                <Row>
                  <div className="file-container">
                    {listDocs}
                  </div>
                </Row>
              </Grid>
            </PanelBody>
            <PanelFooter>
              <Row>
                <Col xs={12}>
                  { this.props.role !== 'employee' ? <Button className="common-default-button width-100-btn right" disabled={this.state.companyFilePath.length <= 1 || this.state.searchIsActive} onClick={() => ::this.launchAddDoc(this.props.data, this.state.companyFilePath[this.state.companyFilePath.length - 1])}><Icon glyph="fa fa-plus"/>{I18n.t('noteDocs.addNotesDocsButton')}</Button> : null }
                  { this.props.role !== 'employee' ? <Button className="common-default-button width-100-btn right" disabled={this.state.searchIsActive} onClick={() => ::this.launchAddFolder(this.state.companyFilePath[this.state.companyFilePath.length - 1])}><Icon glyph="fa fa-plus"/>{I18n.t('noteDocs.addFolderButton')}</Button> : null }
                </Col>
              </Row>
            </PanelFooter>
          </Panel>
        </PanelContainer>
        <AddDoc ref="addDoc" />
        <AddFolder ref="addFolder" />
        <EditFile ref="editFile" />
        <MessageBox ref="messageBox" />
      </Col>
    )
  }
}
export default connect(null, { asyncGetDocsAll, asyncGetDocs, asyncDeleteDocs })(CurrentDocs)
