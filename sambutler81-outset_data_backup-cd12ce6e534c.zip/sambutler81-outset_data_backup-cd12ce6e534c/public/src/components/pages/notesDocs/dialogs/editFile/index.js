import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { ValidatorFolderName } from '../../../../../utils/validators'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { asyncPatchDocs } from '../../../../../actions'

class EditFile extends Component {
  constructor (props) {
    super(props)
    this.state = {
      company: null,
      title: '',
      file: null,
      parent: null,
      mainErrors: [],
      showModal: false,
      uploadedFile: null,
      valueDocType: 0
    }
    this.startups = []
  }

  close () { this.setState({showModal: false}) }
  open (file) {
    this.setState({showModal: true, file, title: file.title})
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  fnChangeFile () {
    this.props.asyncPatchDocs(null, ::this.close, this.state.file.id, this.state.file.startup, this.state.title) // required, UID, startup, title, parent, data
  }
  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="addDocNote-component">
        <Modal.Header closeButton>
          <Modal.Title>Edit File</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Form>
              <Col xs={12}>
                <FormGroup>
                  <TemplateInput
                    type="text"
                    group="main"
                    placeholder="Title"
                    name="title"
                    className="input-form"
                    value={this.state.title}
                    onChange={::this.fnChange}
                    fnValidator={ValidatorFolderName}
                    required="required"/>
                </FormGroup>
              </Col>
            </Form>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} onClick={::this.fnChangeFile} className="common-default-button common-apply-button left-m">Change</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addDocNote.closeButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
function mapStateToProps ({network}) { return {network} }
export default connect(mapStateToProps, {asyncPatchDocs}, null, { withRef: true })(EditFile)
