import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import MessageBox from '../../../../dialogs/messageBox/'
import { asyncGoogleUnSync } from '../../../../../actions'

class GoogleLink extends Component {
  constructor (props) {
    super(props)
    this.state = {
      link: '',
      mainErrors: [],
      showModal: false,
      data: null,
      companyId: null,
      company: '',
      syncBy: '',
      email: '',
      syncGoogleByAccountType: null,
      accountType: null,
      role: null
    }
    this.fnUnsync = null
  }

  close () { this.setState({showModal: false}) }
  open (accountType, syncBy, email, role, fnCallbackUnsync) { this.setState({showModal: true, role, accountType, syncBy, email}); this.fnUnsync = fnCallbackUnsync }
  onUnSyncButtonClick () { this.fnUnsync(); this.setState({showModal: false}) }
  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="link-component">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('addLink.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col xs={12}>
              <div className="google-disk-center"/>
              <div className="article-center">Notes & Docs synchronized with Google Drive</div>
              <div className="synchronized"><span>Synchronized by:</span> {this.state.syncBy}</div>
              <div className="google-account"><span>Google account:</span> {this.state.email}</div>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.props.networkActive} className="common-default-button common-apply-button left-m" onClick={::this.onUnSyncButtonClick}>{I18n.t('addLink.linkButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addLink.closeButton')}</Button>
        </Modal.Footer>
        <MessageBox ref="messageBox" />
      </Modal>
    )
  }
}

function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncGoogleUnSync }, null, {withRef: true})(GoogleLink)
