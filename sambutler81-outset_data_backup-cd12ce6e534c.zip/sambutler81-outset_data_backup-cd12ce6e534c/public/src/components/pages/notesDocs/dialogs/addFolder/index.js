import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncAddFolder } from '../../../../../actions'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorFolderName } from '../../../../../utils/validators'

class AddFolder extends Component {
  constructor (props) {
    super(props)
    this.state = {
      folderName: '',
      mainErrors: [],
      showModal: false,
      startup: null,
      parent: null
    }
  }
  close () { this.setState({showModal: false}) }
  open (folder) { this.setState({showModal: true, startup: folder.startup, parent: folder.id}) }
  onAddButtonClick () { this.props.asyncAddFolder(null, ::this.close, this.state.startup, this.state.parent, this.state.folderName) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="addFolder-component">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('addFolder.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col xs={12}>
              <Form>
                <FormGroup>
                  <TemplateInput
                    type="text"
                    group="main"
                    name="folderName"
                    className="input-form"
                    placeholder={I18n.t('addFolder.folderName')}
                    value={this.state.folderName}
                    onChange={::this.fnChange}
                    fnValidator={ValidatorFolderName}
                    required="required"/>
                </FormGroup>
              </Form>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button left-m" onClick={::this.onAddButtonClick}>{I18n.t('addFolder.addButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addFolder.closeButton')}</Button>
        </Modal.Footer>
      </Modal >
    )
  }
}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, {asyncAddFolder}, null, { withRef: true })(AddFolder)
