import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import Select from 'react-select-plus'
import Dropzone from 'react-dropzone'
import { I18n } from 'react-redux-i18n'
import { ValidatorDescription, ValidatorFolderName } from '../../../../../utils/validators'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { truncateString } from '../../../../../utils/helpers'
import { asyncAddDocs, asyncAddNote } from '../../../../../actions'

class AddDoc extends Component {
  constructor (props) {
    super(props)
    this.state = {
      name: '',
      company: null,
      notes: '',
      title: '',
      parent: null,
      mainNoteErrors: [],
      foldersListValue: null,
      companyListValue: null,
      showModal: false,
      uploadedFile: null,
      valueDocType: 0
    }
    this.startups = []
    this.listTypeDoc = [
      {value: 0, label: 'Document'},
      {value: 1, label: 'Note'}
    ]
  }

  close () { this.setState({showModal: false}) }
  open (company, folder) {
    this.setState({showModal: true, company: null, startup: folder.startup, parent: folder.id, mainNoteErrors: [], uploadedFile: null, title: '', notes: ''})
    if (company.id) { this.setState({company: company}) }
    this.props.startups.length && (this.startups = this.updateSelectOptions(this.props.startups))
  }
  updateSelectOptions (arrIn, arrOut = []) { arrIn.map((obj, index) => { arrOut.push({value: index, label: obj.recognize || obj.name, id: obj.id}) }); return arrOut }
  fnRemoveUploadFile () { this.setState({uploadedFile: null}) }
  updateValue (value) { this.setState({valueDocType: value, mainNoteErrors: [], uploadedFile: null, title: '', notes: ''}) }
  fnChangeCompany (value) { this.setState({companyListValue: value}) }
  fnUploadDoc (file) { file[0].shortName = truncateString(file[0].name, 20); this.setState({uploadedFile: file[0]}) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  fnAddDoc () {
    this.state.valueDocType.value
      ? this.props.asyncAddNote(null, ::this.close, this.state.parent, this.state.title, this.state.notes) // required, fnCloseDialog, UID, title, text
      : this.props.asyncAddDocs(null, ::this.close, this.state.startup, this.state.parent, this.state.uploadedFile) // required, fnCloseDialog, startup, title, parent, data
  }
  render () {
    const NOTE_FIELD = (
      <Col xs={12}>
        <FormGroup>
          <TemplateInput
            type="text"
            group="mainNote"
            placeholder="Title"
            name="title"
            className="input-form"
            value={this.state.title}
            onChange={::this.fnChange}
            fnValidator={ValidatorFolderName}
            required="required"/>
        </FormGroup>
        <FormGroup>
          <TemplateInput
            type="textarea"
            group="mainNote"
            name="notes"
            className="textarea-form max-width no-resize"
            placeholder={I18n.t('editToDos.description')}
            value={this.state.notes}
            onChange={::this.fnChange}
            fnValidator={ValidatorDescription}
            required="required"/>
        </FormGroup>
      </Col>
    )
    const DOCS_FIELDS = (
      <Col xs={12}>
        <Dropzone onDrop={::this.fnUploadDoc} className="upload-drop-button"/>
        <div className="flex-box-add-note-docs">
          <Button bsStyle="link" className="upload-button">{I18n.t('addDocNote.uploadButton')}</Button>
          <div className="wrap-file-info">
            <div className={this.state.uploadedFile ? 'remove-file' : ''} onClick={::this.fnRemoveUploadFile}/>
            <span className="span-notedocs-upload-file uploaded-file">{this.state.uploadedFile ? this.state.uploadedFile.shortName : I18n.t('addDocNote.uploadDoc')}</span>
          </div>
        </div>
      </Col>
    )
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="addDocNote-component">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('addDocNote.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Form>
              <Col xs={12}>
                <FormGroup>
                  <Select
                    name="form-field-name"
                    value={this.state.valueDocType}
                    onChange={::this.updateValue}
                    placeholder={I18n.t('addDocNote.selectorDocs')}
                    options={this.listTypeDoc}
                    searchable={false}
                    clearable={false}
                    />
                </FormGroup>
              </Col>
              {!this.state.valueDocType.value ? DOCS_FIELDS : NOTE_FIELD}
              {!this.state.company ? (
                <Col xs={12}>
                  <FormGroup>
                    <Select
                      name="form-field-name"
                      value={this.state.companyListValue}
                      placeholder={I18n.t('addDocNote.selectorComp')}
                      options={this.startups}
                      onChange={::this.fnChangeCompany}
                      searchable={false}
                      clearable
                    />
                  </FormGroup>
                </Col>
                ) : ''
              }
            </Form>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.state.mainNoteErrors.length !== 0 || this.props.networkActive || (!this.state.valueDocType.value && !this.state.uploadedFile)} onClick={::this.fnAddDoc} className="common-default-button common-apply-button left-m">{I18n.t('addDocNote.addButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addDocNote.closeButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
function mapStateToProps ({startups, network}) { return {startups: startups.startups, networkActive: network.networkActive} }
export default connect(mapStateToProps, {asyncAddDocs, asyncAddNote}, null, { withRef: true })(AddDoc)
