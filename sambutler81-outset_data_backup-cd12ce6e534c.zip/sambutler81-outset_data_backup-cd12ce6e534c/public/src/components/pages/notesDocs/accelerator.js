import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Grid, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import CurrentDocs from './components/currentDocs'
import MessageBox from '../../dialogs/messageBox/'
import GoogleLink from './dialogs/link/'
import { asyncGetDocsAll, asyncGetDocsStatistic, asyncGoogleSyncComplete, asyncGoogleSync, asyncGoogleUnSync } from '../../../actions'
import { itExist } from '../../../utils/helpers'
import Dashboard from '../../common/dashboard'
import PropTypes from 'prop-types'
import {ACCOUNTS_TYPES} from '../../../constants/'

class NotesDocs extends Component {
  constructor (props) {
    super(props)
    this.state = {
      company: itExist(this.props.docs.startups) ? this.props.docs.startups : [],
      listFolders: [],
      searchIsActive: false,
      searchText: ''
    }
    this.doubleClickCalled = false
  }
  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) {
    let listFolders
    let primarylistFolders = []
    itExist(props.docs.startups) && this.setState({company: props.docs.startups})
    itExist(props.docs.startups) && props.docs.startups.map((company) => { primarylistFolders.push(company.docs) }) && (listFolders = primarylistFolders.slice())
    this.setState({listFolders})
    this.props.app.activeFund !== props.app.activeFund && this.initComponent(props)
  }
  initComponent (props) { props.app.activeFund && props.asyncGetDocsStatistic(null) && props.asyncGetDocsAll(null, props.app.activeFund.id) }
  onUnSyncButtonClick () {
    this.refs.messageBox.getWrappedInstance().init(
      `Unsynchronize Google Drive`,
      `${I18n.t('addLink.messageBox')} ${this.props.app.user.googleDrive}?`,
      {type: 'chekButton', question: 'Remove Syncronized Folders with Google Drive'}
    )
      .then((resp) => { this.props.asyncGoogleUnSync(null, resp ? 1 : 0) })
      .catch(() => {})
  }
  redirectToGoogle (link) { window.location = link.redirect } // accountType, syncBy, email, role, fnCallbackUnsync
  launchLink () { this.props.app.user.googleDrive ? this.refs.googleLink.getWrappedInstance().open(this.props.app.user.account_type, this.props.app.user.recognize, this.props.app.user.googleDrive, this.props.app.user.role, ::this.onUnSyncButtonClick) : this.props.asyncGoogleSync(true, ::this.redirectToGoogle, this.props.location.pathname) }
  render () {
    const GOOGLE_DISK_BUTTON = (<div className="google-drive-link" >{this.props.app.user.googleDrive ? <Button className="common-white-button google-button-sync" onClick={::this.launchLink}><div className="google-disk"/><span>Google Disk Info</span></Button> : <Button className="common-white-button google-button" onClick={::this.launchLink}> {I18n.t('noteDocs.syncGoogle')}</Button>}</div>)
    const DOCS_COMPANY = itExist(this.state.company) ? this.state.company.map((itemCompany, indexCompany) => {
      return <CurrentDocs key={indexCompany} data={{...itemCompany}} listFolders={this.state.listFolders[indexCompany]} role={this.props.app.user.role} accountType={this.props.app.user.account_type} index={indexCompany}/>
    }) : null
    const DASHBOARD_NOTES = this.props.docs.statistics.length ? (
      <div>
        <Col xs={12} sm={12} md={3} className="common-half-padding-child">
          <Dashboard text={I18n.t('noteDocs.updatesThisWeek')} count={this.props.docs.statistics[0].count} />
        </Col>
        <Col xs={12} sm={12} md={3} className="common-half-padding-child">
          <Dashboard text={I18n.t('noteDocs.uploadsThisWeek')} count={this.props.docs.statistics[1].count} />
        </Col>
      </div>
    ) : ''
    const DOCS_EMPTY = (
      <div>
        <div className="common-container-long-img">
          <div className="common-docs-pet adaptive-mascot" />
          <p>{I18n.t('noteDocs.noDocs')}</p>
          <span>{I18n.t('noteDocs.noDocs2')}</span>
        </div>
      </div>
    )
    return (
      <div className="common-wrap-half-padding">
        <Grid className="notesDocs-component common-page-component">
          <Row>
            {(ACCOUNTS_TYPES.ACCELERATOR_ADMIN === this.props.app.user.account_type || ACCOUNTS_TYPES.ACCELERATOR_FOUNDER === this.props.app.user.account_type || ACCOUNTS_TYPES.COMPANY_FOUNDER === this.props.app.user.account_type) ? GOOGLE_DISK_BUTTON : ''}
            <div className="flex-box-note-docs">
              <Col sm={6} xs={6} md={3} />
            </div>
            {this.state.company.length ? DASHBOARD_NOTES : ''}
          </Row>
          <Row>
            {!DOCS_COMPANY ? DOCS_EMPTY : DOCS_COMPANY}
          </Row>
        </Grid>
        <MessageBox ref="messageBox" />
        <GoogleLink ref="googleLink" />
      </div>
    )
  }
}
NotesDocs.propTypes = {
  app: PropTypes.shape({
    activeFund: PropTypes.object
  }),
  docs: PropTypes.shape({
    docs: PropTypes.array
  })
}
function mapStateToProps ({app, docs}) { return {app, docs} }
export default connect(mapStateToProps, { asyncGetDocsAll, asyncGetDocsStatistic, asyncGoogleSyncComplete, asyncGoogleSync, asyncGoogleUnSync })(NotesDocs)
