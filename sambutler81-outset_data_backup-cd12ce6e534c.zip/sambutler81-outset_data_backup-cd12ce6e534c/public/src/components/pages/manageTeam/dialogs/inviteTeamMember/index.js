import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import TagsInput from 'react-tagsinput'
import Select from 'react-select-plus'
import { asyncStartUpInvite, asyncAddAcceleratorsInvite } from '../../../../../actions'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorMessage } from '../../../../../utils/validators'
import { ACCOUNTS_TYPES } from '../../../../../constants'
import PropTypes from 'prop-types'

const initState = {
  emails: [],
  message: '',
  companyId: null,
  fundId: null,
  mainErrors: [],
  showModal: false
}

class InviteTeamMember extends Component {
  constructor (props) {
    super(props)
    this.roles = []
    switch (this.props.app.user.account_type) {
      case ACCOUNTS_TYPES.ACCELERATOR_ADMIN: {
        this.roles.push({value: 'employee', label: 'Employee', id: 3})
        break
      }
      case ACCOUNTS_TYPES.ACCELERATOR_FOUNDER: {
        this.roles.push({value: 'employee', label: 'Employee', id: 3})
        this.roles.push({value: 'admin', label: 'Admin', id: 2})
        break
      }
      case ACCOUNTS_TYPES.COMPANY_FOUNDER: {
        this.roles.push({value: 'employee', label: 'Employee', id: 5})
        break
      }
    }

    this.state = {
      ...initState,
      roleSelect: this.roles[0]
    }
  }

  close () { this.setState({...initState, roleSelect: this.roles[0]}) }
  open (fundId, companyId) { this.setState({showModal: true, fundId, companyId}) }
  onInviteButtonClick () {
    this.state.companyId
      ? this.props.asyncStartUpInvite(null, ::this.close, this.state.companyId, this.state.emails.join(','), this.state.roleSelect.value, this.state.message)
      : this.state.fundId && this.props.asyncAddAcceleratorsInvite(null, ::this.close, this.state.fundId, this.state.emails.join(','), this.state.roleSelect.value, this.state.message)
  }
  updateRole (value) { this.setState({roleSelect: value}) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  handleChange (emails) { this.setState({emails}) }
  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="inviteTeamMember-component common-modal">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('inviteTeamMember.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <FormGroup>
              <span className="common-italic">Separate Email Addresses Using a Space Between Them</span>
              <TagsInput value={this.state.emails}
                onChange={::this.handleChange}
                addOnBlur
                addKeys={[9, 13, 32]}
                className = "input-invite-email"
                tagProps = {{className: 'input-invite-email-tag', classNameRemove: 'input-invite-email-tag-remove'}}
                inputProps={{className: 'react-tagsinput-input', placeholder: I18n.t('inviteTeamMember.email')}}
                validationRegex={/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/}
                required="required"
              />
            </FormGroup>
            <FormGroup>
              <Select
                name="form-role"
                value={this.state.roleSelect}
                onChange={::this.updateRole}
                options={this.roles}
                placeholder={I18n.t('editTeamMember.role')}
                searchable={false}
                clearable={false}
              />
            </FormGroup>
            <FormGroup>
              <TemplateInput
                type="textarea"
                group="main"
                name="message"
                className="textarea-form max-width no-resize"
                placeholder={I18n.t('inviteTeamMember.message')}
                value={this.state.message}
                onChange={::this.fnChange}
                fnValidator={ValidatorMessage}
                required="required"/>
            </FormGroup>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={!this.state.emails.length || this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onInviteButtonClick}>{I18n.t('inviteTeamMember.inviteButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('inviteTeamMember.closeButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}

InviteTeamMember.propTypes = {
  asyncStartUpInvite: PropTypes.func.isRequired,
  asyncAddAcceleratorsInvite: PropTypes.func.isRequired
}
function mapStateToProps ({network, app}) { return {networkActive: network.networkActive, app} }
export default connect(mapStateToProps, { asyncStartUpInvite, asyncAddAcceleratorsInvite }, null, { withRef: true })(InviteTeamMember)
