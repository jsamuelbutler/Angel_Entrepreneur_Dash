import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncDeleteTeamMember } from '../../../../../actions'
import PropTypes from 'prop-types'

class DeleteTeamMember extends Component {
  constructor (props) {
    super(props)
    this.state = {
      showModal: false,
      userName: '',
      userId: null
    }
    this.callback = () => {}
  }

  close () { this.setState({showModal: false}) }
  open (userName, userId) { this.setState({showModal: true, userId, userName}) }
  fnConfirm () { this.props.asyncDeleteTeamMember(null, this.state.userId, ::this.close) }

  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="deleteTeamMember-component common-modal">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('deleteTeamMember.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <FormGroup>
              <p className="text-center">{I18n.t('deleteTeamMember.questionStart')} <b><i>{this.state.userName}</i></b> {I18n.t('deleteTeamMember.questionEnd')}</p>
            </FormGroup>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button className="common-default-button common-apply-button" disabled={this.props.networkActive} onClick={::this.fnConfirm}>{I18n.t('deleteTeamMember.confirmButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('deleteTeamMember.cancelButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
DeleteTeamMember.propTypes = {asyncDeleteTeamMember: PropTypes.func.isRequired}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, {asyncDeleteTeamMember}, null, { withRef: true })(DeleteTeamMember)
