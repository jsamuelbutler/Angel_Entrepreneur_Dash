import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button, Icon } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncGetInviteAll, asyncDeleteInvite, asyncResendInvite } from '../../../../../actions'
import { Scrollbars } from 'react-custom-scrollbars'
import MessageBox from '../../../../dialogs/messageBox'
import PropTypes from 'prop-types'

class InviteTeamMember extends Component {
  constructor (props) {
    super(props)
    this.state = {
      emails: [],
      message: '',
      companyId: null,
      fundId: null,
      mainErrors: [],
      showModal: false
    }
  }
  componentWillReceiveProps (nextProps) {
    nextProps.invites.list && (nextProps.invites.list !== this.props.invites.list) && this.initComponent()
  }
  close () { this.setState({showModal: false}) }
  open () { this.props.asyncGetInviteAll(null) }
  initComponent () { this.setState({showModal: true}) }
  removeInvite (id) {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('inviteTeamMember.removeInviteTitle'), I18n.t('inviteTeamMember.removeInviteMessage'))
      .then(() => { this.props.asyncDeleteInvite(null, id) })
      .catch(() => {})
  }
  resendInvite (id) { this.props.asyncResendInvite(null, id) }

  render () {
    const list = this.props.invites.list.filter(item => !item.accepted)
    const content = list.map((item, index) => {
      return (
        <tr key={index} className="common-cursor-pointer">
          <td>{item.email}
            <span>
              {!item.accepted ? <Icon onClick={() => ::this.removeInvite(item.id)} className="common-search-btn" glyph="fa fa-times" title={I18n.t('common.remove')}/> : null}
              {!item.accepted ? <Icon onClick={() => ::this.resendInvite(item.id)} className="common-search-btn resend" glyph="fa fa-repeat" title={I18n.t('common.resend')}/> : null}
            </span>
          </td>
        </tr>
      )
    })
    const wrap = (
      <Scrollbars
        autoHide
        autoHideTimeout={700}
        renderTrackHorizontal={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
        renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" style={{display: 'none'}}/>}
        ref="scrollbars">
        <table>
          <tbody>
            {content}
          </tbody>
        </table>
      </Scrollbars>
    )
    return (
      <div>
        <Modal lg show={this.state.showModal} onHide={::this.close} className="invitesListTeamMember-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('inviteTeamMember.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="list-users common-main-table">
              {list.length === 0 ? <div className="wrap-empty-list">Invite list is empty</div> : wrap}
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('inviteTeamMember.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
        <MessageBox ref="messageBox"/>
      </div>
    )
  }
}

InviteTeamMember.propTypes = {
  asyncGetInviteAll: PropTypes.func.isRequired,
  asyncResendInvite: PropTypes.func.isRequired,
  asyncDeleteInvite: PropTypes.func.isRequired
}
function mapStateToProps ({invites, app}) { return {invites, app} }
export default connect(mapStateToProps, { asyncGetInviteAll, asyncDeleteInvite, asyncResendInvite }, null, { withRef: true })(InviteTeamMember)
