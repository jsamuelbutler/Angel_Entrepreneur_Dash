import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorUserName } from '../../../../../utils/validators'
import { ACCOUNTS_TYPES } from '../../../../../constants'
import TagsInput from 'react-tagsinput'
import Select from 'react-select-plus'

class EditTeamMember extends Component {
  constructor (props) {
    super(props)
    this.state = {
      firstName: '',
      lastName: '',
      roleInCompany: '',
      userTag: [],
      userId: '',
      role: null,
      roleSelect: null,
      tags: [],
      accType: null,
      typeId: null,
      mainErrors: [],
      hideTagInput: false,
      showModal: false
    }
    this.callback = () => {}
    this.selectRolesAcc = [
      {label: 'Admin', value: 0, name: 'admin', disabled: this.props.app.user.account_type === ACCOUNTS_TYPES.ACCELERATOR_ADMIN},
      {label: 'Employee', value: 1, name: 'employee'}
    ]
    this.selectRolesCompany = [
      {label: 'Founder', value: 0, name: 'founder'},
      {label: 'Employee', value: 1, name: 'employee'}
    ]
  }

  close () { this.setState({showModal: false}) }
  open (fnCallback, typeId, accType, userId, firstName, lastName, roleInCompany, role, tags) {
    let currentRole = null
    switch (role) {
      case 'founder': currentRole = this.state.accType > 3 ? this.selectRolesCompany[0] : {label: 'Founder', name: 'founder'}
        break
      case 'admin': currentRole = this.state.accType > 3 ? null : this.selectRolesAcc[0]
        break
      case 'employee': currentRole = this.state.accType > 3 ? this.selectRolesCompany[1] : this.selectRolesAcc[1]
        break
    }
    this.setState({showModal: true, typeId, accType, userId, firstName: firstName || '', lastName: lastName || '', roleInCompany: roleInCompany || '', role: currentRole, roleSelect: currentRole, tags: tags.length ? tags.split(',') : []})
    this.callback = fnCallback
  }
  onInviteButtonClick () { !(this.props.app.user.account_type === ACCOUNTS_TYPES.ACCELERATOR_ADMIN && this.state.roleSelect.name === 'admin') && this.state.mainErrors.length === 0 ? this.callback(null, ::this.close, this.state.userId, this.state.firstName, this.state.lastName, this.state.roleInCompany, this.state.roleSelect.name, this.state.tags.join(',')) : '' }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  handleChange (tags) { this.setState({tags}) }
  renderTagInput ({addTag, ...props}) { return (<span className="plus-circle"><input type="text" {...props} /></span>) }
  updateRole (value) { this.setState({roleSelect: value}) }
  render () {
    const DISABLE_FIELD = !this.state.typeId && ((this.state.accType === 2 || this.state.accType === 4) && (this.state.role.name === 'founder' || this.state.role.name === 'admin'))
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="editTeamMember-component common-modal">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('editTeamMember.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col xs={12} className="edit-margin-bottom">
              <Form>
                <FormGroup>
                  <label className="label">{I18n.t('editTeamMember.firstNameLabel')}</label>
                  <TemplateInput
                    type="text"
                    group="main"
                    name="firstName"
                    disable={DISABLE_FIELD}
                    className="input-form edit-modal edit-modal-name"
                    placeholder={I18n.t('editTeamMember.firstName')}
                    value={this.state.firstName}
                    onChange={::this.fnChange}
                    fnValidator={ValidatorUserName}/>
                </FormGroup>
                <FormGroup>
                  <label className="label">{I18n.t('editTeamMember.lastNameLabel')}</label>
                  <TemplateInput
                    type="text"
                    group="main"
                    name="lastName"
                    disable={DISABLE_FIELD}
                    className="input-form edit-modal edit-modal-name"
                    placeholder={I18n.t('editTeamMember.lastName')}
                    value={this.state.lastName}
                    onChange={::this.fnChange}
                    fnValidator={ValidatorUserName}/>
                </FormGroup>
                <FormGroup>
                  <label className="label">{I18n.t('editTeamMember.specTitle')}</label>
                  <TemplateInput
                    type="text"
                    group="main"
                    name="roleInCompany"
                    className="input-form edit-modal edit-modal-name"
                    placeholder={I18n.t('editTeamMember.specMessage')}
                    value={this.state.roleInCompany}
                    onChange={::this.fnChange}
                    fnValidator={ValidatorUserName}/>
                </FormGroup>
                <FormGroup>
                  <label className="label">{I18n.t('editTeamMember.role')}</label>
                  <Select
                    name="form-role"
                    value={this.state.roleSelect}
                    onChange={::this.updateRole}
                    disabled={this.state.typeId || ((this.state.accType === 2 || this.state.accType === 4) && (this.state.role.name === 'founder' || this.state.role.name === 'admin'))}
                    options={this.state.accType > 3 ? this.selectRolesCompany : this.selectRolesAcc}
                    placeholder={I18n.t('editTeamMember.role')}
                    searchable={false}
                    clearable={false}
                  />
                </FormGroup>
                <FormGroup>
                  <label className="label">{I18n.t('editTeamMember.tagsTitle')}</label>
                  <div className="add-tag-container" title={I18n.t('editTeamMember.tagsInput')}>
                    <span className="common-italic">Separate Tags Using a Space Between Them</span>
                    <TagsInput
                      value={this.state.tags}
                      onChange={::this.handleChange}
                      addOnBlur
                      addKeys={[9, 13, 32]}
                      className="input-add-tag-team"
                      tagProps={{className: 'input-invite-email-tag', classNameRemove: 'input-invite-email-tag-remove'}}
                      inputProps={{className: 'react-tagsinput-input plus-circle', placeholder: I18n.t('editTeamMember.addTags')}}
                      renderInput={::this.renderTagInput}
                    />
                  </div>
                </FormGroup>
              </Form>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onInviteButtonClick}>{I18n.t('editTeamMember.saveButton')}</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('editTeamMember.cancelButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
function mapStateToProps ({network, app}) { return {networkActive: network.networkActive, app} }
export default connect(mapStateToProps, null, null, { withRef: true })(EditTeamMember)
