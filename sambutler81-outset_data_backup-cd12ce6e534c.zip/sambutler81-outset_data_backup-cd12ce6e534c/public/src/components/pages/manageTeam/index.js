import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Grid, Icon, Button, PanelContainer, Panel, PanelBody } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import { asyncGetTeamMemberAll, asyncPatchTeamMember } from '../../../actions'
import { itExist } from '../../../utils/helpers'
import InviteModal from './dialogs/inviteTeamMember/'
import InvitesListTeamMember from './dialogs/invitesListTeamMember/'
import EditModal from './dialogs/editTeamMember/'
import DeleteModal from './dialogs/deleteTeamMember/'
import { ACCOUNTS_NAMES } from '../../../constants'

class ManageTeam extends Component {

  componentDidMount () { this.props.asyncGetTeamMemberAll(null, this.props.app.user.accelerator, null, '-todo_count') }
  fnInviteEmployee () { this.props.app.user.accelerator ? this.refs.inviteModal.getWrappedInstance().open(this.props.app.user.accelerator) : this.refs.inviteModal.getWrappedInstance().open(null, this.props.app.user.startup) }
  fnInvitesListTeamMember () { this.props.app.user.accelerator ? this.refs.invitesListTeamMember.getWrappedInstance().open(this.props.app.user.accelerator) : this.refs.invitesListTeamMember.getWrappedInstance().open(null, this.props.app.user.startup) }
  fnEditEmployee (typeId, userId, firstName, lastName, spec, role, tag) { this.refs.editModal.getWrappedInstance().open(this.props.asyncPatchTeamMember, typeId, this.props.app.user.account_type, userId, firstName, lastName, spec, role, tag) }
  fnRemoveEmployee (userId, name) {
    this.refs.deleteModal.getWrappedInstance().open(name, userId)
  }
  fnSettingsButton (user) {
    let classEditButton = 'buttons edit-button'
    let classDeleteButton = 'buttons delete-button'
    if (user.id === this.props.app.user.id || ((this.props.app.user.account_type === 2 || this.props.app.user.account_type === 4) && (user.role === 'founder' || user.role === 'admin'))) {
      classEditButton = 'buttons edit-button-only'
      classDeleteButton = 'buttons hide-button'
    }
    return (
      <div>
        <Icon title={I18n.t('editTeamMember.title')} className={classEditButton} onClick={() => { ::this.fnEditEmployee(user.id === this.props.app.user.id, user.id, user.first_name, user.last_name, user.role_in_company, user.role, user.tags) }} glyph="fa fa-cog"/>
        <Icon title={I18n.t('deleteTeamMember.title')} className={classDeleteButton} onClick={() => { ::this.fnRemoveEmployee(user.id, user.recognize) }} glyph="fa fa-times"/>
      </div>

    )
  }
  render () {
    const TEAM_EMPTY = (
      <div>
        <div className="common-container-img">
          <div className="gears-pet"/>
          <p>{I18n.t('teamMember.noTeamMember')}</p>
          <span>{I18n.t('teamMember.noTeamMember2')}</span>
          <br/>
          <Button className="common-white-button" onClick={::this.fnInviteEmployee}><Icon glyph="fa fa-plus"/> {I18n.t('teamMember.addTeamMemberButton')}</Button>
        </div>
      </div>
    )
    const TEAM_BODY = (
      <Row>
        {
          this.props.teamMembers.startupMembers.map((user, index) => {
            return (
              <Col key={index} sm={6} className="mdComp lgComp xsComp common-half-padding-child">
                <PanelContainer>
                  <Panel className="team-panel">
                    <PanelBody>
                      <div>
                        {user.role === ACCOUNTS_NAMES.ACCELERATOR_FOUNDER ? <div className="admin-crown" /> : null}
                        {this.fnSettingsButton(user)}
                      </div>
                      <Row>
                        <Col xs={12}>
                          <div className="user-name" title={user.recognize}>{user.recognize}</div>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs={12}>
                          <span className="specialization">{user.role_in_company.length ? user.role_in_company : I18n.t('teamMember.noRole')}</span>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs={12} className="tags-wrapper">
                          <span className="tags" title={user.tags.length ? user.tags.split(',').map((tag) => { return (` #${tag}`) }) : ''}>{user.tags.length ? ` #${user.tags.split(',').slice(0, 3).join(' #')}` : ''}<span className="manage-tags-more">{user.tags.length ? (user.tags.split(',').length - 3 < 1) ? '' : ` and ${user.tags.split(',').length - 3} more` : ''}</span></span>
                        </Col>
                      </Row>
                    </PanelBody>
                  </Panel>
                </PanelContainer>
              </Col>
            )
          })
        }
      </Row>
    )
    return (
      <div className="manageTeam-component common-page-component common-wrap-half-padding">
        <Grid className="manage-team-page">
          <Row className="row-padding">
            <Col xs={12} className="xsButton common-half-padding-child common-half-padding-child-button flex-box-team-member">
              <Button className="common-default-button right add-team-member-button" onClick={::this.fnInviteEmployee}>
                <Icon glyph="fa fa-plus"/> {I18n.t('teamMember.addTeamMemberButton')}
              </Button>
              <Button className="common-default-close-button invites-btn add-team-member-button" onClick={::this.fnInvitesListTeamMember}>
                {I18n.t('teamMember.listInvites')}
              </Button>
            </Col>
          </Row>
          { itExist(this.props.teamMembers.startupMembers) ? TEAM_BODY : TEAM_EMPTY }
          <InviteModal ref="inviteModal"/>
          <InvitesListTeamMember ref="invitesListTeamMember"/>
          <EditModal ref="editModal"/>
          <DeleteModal ref="deleteModal"/>
        </Grid>
      </div>
    )
  }
}

ManageTeam.propTypes = {
  app: PropTypes.shape({
    user: PropTypes.shape({
      account_type: PropTypes.number.isRequired,
      accelerator: PropTypes.number,
      startup: PropTypes.number
    })
  }),
  teamMembers: PropTypes.shape({
    startupMembers: PropTypes.array
  }),
  asyncGetTeamMemberAll: PropTypes.func.isRequired,
  asyncPatchTeamMember: PropTypes.func.isRequired
}

function mapStateToProps ({app, teamMembers}) { return {app, teamMembers} }
export default connect(mapStateToProps, { asyncGetTeamMemberAll, asyncPatchTeamMember })(ManageTeam)
