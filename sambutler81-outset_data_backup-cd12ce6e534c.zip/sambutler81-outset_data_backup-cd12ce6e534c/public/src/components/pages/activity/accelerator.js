import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Grid, Col } from '@sketchpixy/rubix'
import CurrentActivity from './components/currentActivity/'
import { I18n } from 'react-redux-i18n'
import { asyncGetActivitiesStatistic, asyncGetCohortActivities } from '../../../actions'
import { itExist } from '../../../utils/helpers'
import Dashboard from '../../common/dashboard'
import PropTypes from 'prop-types'

class Accelerator extends Component {
  constructor (props) {
    super(props)
    this.activities = this.props.activities
  }

  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) {
    this.activities = {data: [], statistic: [], startups: []}
    props.app.activeFund !== this.props.app.activeFund && this.initComponent(props)
    itExist(props.activities.startups) && (this.activities = props.activities)
  }

  initComponent (props) {
    if (props.app.activeFund && props.app.activeFund.id) {
      props.asyncGetActivitiesStatistic(null, props.app.activeFund.id)
      props.asyncGetCohortActivities(null, props.app.activeFund.id)
    }
  }

  dashboardContent (item, index) {
    return (
      <Col xs={12} sm={6} md={4} lg={2} key={index} className="common-half-padding-child">
        <Dashboard text={item.text} count={item.count} />
      </Col>
    )
  }

  activityEmptyContent () {
    return (
      <div>
        <Row>
          <Col xs={12} >
            <div className="common-container-img">
              <div className="common-chart-pet adaptive-mascot"/>
              <p>{I18n.t('activity.noActivity')}</p>
              <span>{I18n.t('activity.noActivity2')}</span>
            </div>
          </Col>
        </Row>
      </div>
    )
  }

  render () {
    const DASHBOARD = itExist(this.activities.statistic) && this.activities.statistic.map(::this.dashboardContent)
    const COMPANY_ACTIVITIES = itExist(this.activities.startups) && this.activities.startups.map((item, index) => <CurrentActivity key={index} currentActivity={{...item}} />)
    const ACTIVITY_EMPTY = ::this.activityEmptyContent()
    return (
      <div className="activity-component common-page-component common-wrap-half-padding">
        <Grid>
          <Row>
            {this.activities.startups.length ? DASHBOARD : null}
          </Row>
          <Row>
            {this.activities.startups.length ? COMPANY_ACTIVITIES : ACTIVITY_EMPTY}
          </Row>
        </Grid>
      </div>
    )
  }
}

Accelerator.propTypes = {
  app: PropTypes.shape({
    activeFund: PropTypes.shape({
      id: PropTypes.number.isRequired
    })
  }),
  activities: PropTypes.shape({
    data: PropTypes.array.isRequired,
    statistic: PropTypes.array.isRequired
  }),
  asyncGetActivitiesStatistic: PropTypes.func,
  asyncGetCohortActivities: PropTypes.func.isRequired
}

function mapStateToProps ({app, activities}) { return {app, activities} }
export default connect(mapStateToProps, { asyncGetActivitiesStatistic, asyncGetCohortActivities })(Accelerator)
