import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Panel, PanelHeader, PanelBody, PanelContainer, Icon } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import Waypoint from 'react-waypoint'
import { asyncGetActivitiesAll } from '../../../../../actions'
import { Scrollbars } from 'react-custom-scrollbars'
import ActivityPreview from '../../dialogs/previewActivity/'
import PropTypes from 'prop-types'

class CurrentActivity extends Component {
  constructor (props) {
    super(props)
    this.state = {
      currentActivity: this.props.currentActivity,
      searchIsActive: false,
      searchText: '',
      paginationRequest: 1
    }
  }

  activityPreviewOpen (item) { this.refs.activityPreview.getWrappedInstance().open(item.html, item.cls) }

  handleWaypointEnter (data, current, dataPrevious) {
    if (current.currentPosition === 'above' && current.previousPosition === 'inside') {
      let currentActivity = this.state.currentActivity
      currentActivity.currentDate = data.created
      this.setState({currentActivity})
    }
    if (current.currentPosition === 'inside' && current.previousPosition === 'above') {
      let currentActivity = this.state.currentActivity
      currentActivity.currentDate = dataPrevious.created
      this.setState({currentActivity})
    }
  }

  handleWaypointLeave (data, current, dataPrevious) {
    if (current.currentPosition === 'above' && current.previousPosition === 'inside') {
      let currentActivity = this.state.currentActivity
      currentActivity.currentDate = data.created
      this.setState({currentActivity})
    }
    if (current.currentPosition === 'inside' && current.previousPosition === 'above') {
      let currentActivity = this.state.currentActivity
      currentActivity.currentDate = dataPrevious.created
      this.setState({currentActivity})
    }
  }

  toggleSearch () {
    if (this.state.searchIsActive) this.props.asyncGetActivitiesAll(null, null, this.state.currentActivity.startup.id, '')
    this.setState({searchIsActive: !this.state.searchIsActive, searchText: ''})
  }

  handleSearch (event) {
    const VALUE = event.target.value
    this.setState({searchText: VALUE})
    window.clearTimeout(this.searchEvent)
    this.searchEvent = window.setTimeout(() => {
      if (VALUE.length >= 1) this.props.asyncGetActivitiesAll(null, null, this.state.currentActivity.startup.id, VALUE)
      else this.props.asyncGetActivitiesAll(null, null, this.state.currentActivity.startup.id, '')
    }, 300)
  }
  handleScroll (e) {
    if (!this.state.searchIsActive && (e.scrollTop + e.clientHeight + 100 > e.scrollHeight) && this.props.currentActivity.next && (this.state.paginationRequest < parseInt(this.props.currentActivity.next.match(/[?&]page=(\d+)/i)[1]))) {
      this.setState({paginationRequest: this.props.currentActivity.next.match(/[?&]page=(\d+)/i)[1]})
      this.props.asyncGetActivitiesAll(null, null, this.props.currentActivity.startup.id, null, this.props.currentActivity.next.match(/[?&]page=(\d+)/i)[1]) // required, cohort, startup, search, page
    }
  }

  render () {
    let GENERATE_COMPANY
    if (this.props.currentActivity.activity.length) {
      GENERATE_COMPANY = this.props.currentActivity.activity.map((item, index) => {
        const GENERATE_ACTIVITIES = item.data.map((itemAct, index) => {
          return (
            <tr onClick={() => ::this.activityPreviewOpen(itemAct)} title={I18n.t('activity.view')} key={index} className="common-cursor-pointer">
              <td className={itemAct.cls}><span className="nowrap">{`${itemAct.html}`}</span></td>
            </tr>
          )
        })
        return (
          <div key={index} className="common-main-table">
            <Waypoint
              onEnter={(currentPosition) => ::this.handleWaypointEnter(item, currentPosition, this.props.currentActivity.activity[index !== 0 ? index - 1 : 0])}
              onLeave={(currentPosition) => ::this.handleWaypointLeave(item, currentPosition, this.props.currentActivity.activity[index !== 0 ? index - 1 : 0])}>
              <div className="common-headers-in-table">
                <Col sm={12} className="title">{item.created}</Col>
              </div>
            </Waypoint>
            <table className="layout">
              <tbody>
                {GENERATE_ACTIVITIES}
              </tbody>
            </table>
          </div>
        )
      })
    } else {
      GENERATE_COMPANY = (
        <div className="common-img-container">
          <div className="common-empty-todos-pet" />
          <p>{this.state.searchText.length ? I18n.t('activity.searchNotFound') : I18n.t('activity.searchEmpty')}</p>
        </div>
      )
    }

    const searchPanel = () => {
      let content
      if (!this.state.searchIsActive) {
        content = (
          <div>
            <div className="header-activity">
              <span className="activity-name">{this.props.currentActivity.startup.name}</span>{this.props.currentActivity.created}
            </div>
            {this.props.currentActivity.activity.length ? <Icon className="common-search-btn search-button-activity" glyph="fa fa-search" title={I18n.t('common.search')} onClick={::this.toggleSearch}/> : ''}
          </div>
        )
      } else {
        content = (
          <div>
            <input className="search-input" value={this.state.searchText} onChange={::this.handleSearch} autoFocus placeholder={I18n.t('common.search')}/>
            <Icon className="common-search-btn search-button-activity" glyph="fa fa-times" title={I18n.t('common.hide')} onClick={::this.toggleSearch}/>
          </div>
        )
      }
      return content
    }
    const STATUS = this.props.type === 'company'
    return (
      <Col sm={12} md={STATUS ? 12 : 6} className="currentActivity-component common-half-padding-child">
        <PanelContainer className={STATUS ? 'currentActivity-company height' : ''}>
          <Panel className={STATUS ? 'currentActivity-company height' : 'common-panel-activity'}>
            <PanelHeader>
              <Col xs={12}>
                {searchPanel()}
              </Col>
            </PanelHeader>
            <PanelBody>
              <Scrollbars
                autoHide
                autoHideTimeout={700}
                renderTrackHorizontal={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
                renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" style={{display: 'none'}}/>}
                onScrollFrame={::this.handleScroll}
                ref="scrollbars">
                { GENERATE_COMPANY }
              </Scrollbars>
            </PanelBody>
          </Panel>
        </PanelContainer>
        <ActivityPreview ref="activityPreview"/>
      </Col>
    )
  }
}

CurrentActivity.propTypes = {
  currentActivity: PropTypes.shape({
    data: PropTypes.shape({
      results: PropTypes.array
    })
  }),
  type: PropTypes.string,
  activities: PropTypes.shape({
    data: PropTypes.array.isRequired,
    statistic: PropTypes.array
  }),
  asyncGetActivitiesStatistic: PropTypes.func,
  asyncGetActivitiesAll: PropTypes.func.isRequired
}

export default connect(null, {asyncGetActivitiesAll})(CurrentActivity)

