import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Grid, Col } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncGetActivitiesStatistic, asyncGetActivitiesAll } from '../../../actions'
import Dashboard from '../../common/dashboard'
import CurrentActivity from './components/currentActivity/'
import PropTypes from 'prop-types'

const ACTIVITY_EMPTY = (
  <div>
    <div className="common-container-img">
      <div className="common-chart-pet adaptive-mascot"/>
      <p>{I18n.t('activity.noActivity')}</p>
      <span>{I18n.t('activity.noActivity2')}</span>
    </div>
  </div>
)

class Company extends Component {

  componentDidMount () {
    this.props.asyncGetActivitiesStatistic(null, null, this.props.app.user.startup)
    this.props.asyncGetActivitiesAll(null, null, this.props.app.user.startup)
  }
  shouldComponentUpdate (props) { return props.app.user !== this.props.app.user || props.activities !== this.props.activities }
  render () {
    const DASHBOARD = this.props.activities.statistic && this.props.activities.statistic.length ? this.props.activities.statistic.map((item, index) => {
      return (
        <Col xs={12} sm={6} md={4} lg={2} key={index} className="common-half-padding-child">
          <Dashboard text={item.text} count={item.count}/>
        </Col>
      )
    }) : null
    const COMPANY_ACTIVITIES = this.props.activities.startups[0] ? <CurrentActivity type="company" currentActivity={{...this.props.activities.startups[0]}} /> : null

    return (
      <div className="activity-component common-height activity-company common-page-component common-wrap-half-padding">
        <Grid>
          <Row>
            {!DASHBOARD ? null : DASHBOARD}
          </Row>
          <Row className="activity-list">
            {!COMPANY_ACTIVITIES ? ACTIVITY_EMPTY : COMPANY_ACTIVITIES}
          </Row>
        </Grid>
      </div>
    )
  }
}

Company.propTypes = {
  app: PropTypes.shape({
    user: PropTypes.shape({
      startup: PropTypes.number
    })
  }),
  activities: PropTypes.shape({
    data: PropTypes.array.isRequired,
    statistic: PropTypes.array
  }),
  asyncGetActivitiesStatistic: PropTypes.func,
  asyncGetActivitiesAll: PropTypes.func.isRequired
}

function mapStateToProps ({app, activities}) { return {app, activities} }
export default connect(mapStateToProps, {asyncGetActivitiesStatistic, asyncGetActivitiesAll})(Company)
