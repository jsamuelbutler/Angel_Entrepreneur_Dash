import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

class ActivityPreview extends Component {
  constructor (props) {
    super(props)
    this.state = {
      cls: '',
      description: ''
    }
  }

  open (description, cls) {
    this.setState({
      showModal: true,
      description,
      cls
    })
  }
  close () { this.setState({showModal: false}) }
  render () {
    return (
      <Modal show={this.state.showModal} onHide={::this.close} className="previewActivity-component">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('previewAccelerator.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className={`${this.state.cls} common-span-margin activity-description`} name="name">{this.state.description}</div>
        </Modal.Body>
        <Modal.Footer>
          <Button className="common-default-close-button center common-close-button" onClick={::this.close}>{I18n.t('previewAccelerator.closeButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
export default connect(null, null, null, {withRef: true})(ActivityPreview)
