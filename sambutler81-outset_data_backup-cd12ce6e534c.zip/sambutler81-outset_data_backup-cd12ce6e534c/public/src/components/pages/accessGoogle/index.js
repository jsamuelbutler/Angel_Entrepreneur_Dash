import './style'
import React, { Component } from 'react'
import { Grid, Row, Col, PanelContainer, Panel, PanelBody, PanelHeader } from '@sketchpixy/rubix'
import { asyncGoogleSyncComplete } from '../../../actions'
import { connect } from 'react-redux'
import { history } from '../../../store'

class AccessGoogle extends Component {
  constructor (props) {
    super(props)
    this.state = { status: null }
  }
  componentDidMount () { !this.props.location.query.error ? this.props.asyncGoogleSyncComplete(null, ::this.redirectToHome, this.props.location.query.state, this.props.location.query.code) : ::this.redirectToHome({redirect: this.props.location.query.state}) }
  redirectToHome (link) { link.error ? (this.setState({status: true}), setTimeout(() => { history.push('/notesDocs') }, 3000)) : setTimeout(() => { history.push('/notesDocs') }, 2000) }

  render () {
    const ACCESS_SUCCESS = (
      <div className="container-sync-icon">
        <div className="outset-sync"/>
        <div className="reloadDouble"/>
        <div className="google-sync"/>
      </div>
    )
    const ACCESS_DENIED = <span>Access Denied</span>
    const ACCOUNT_REG = <span className="already-msg">Ops, error</span>
    return (
      <div className="accessGoogle-component common-page-component">
        <Grid className="common-lower-width">
          <Row>
            <Col>
              <PanelContainer className="accessGoogle-panel">
                <Panel>
                  <PanelHeader><span>Connecting to Google Drive</span></PanelHeader>
                  <PanelBody>
                    {this.state.status
                      ? ACCOUNT_REG
                      : !this.props.location.query.error
                        ? ACCESS_SUCCESS
                        : ACCESS_DENIED
                    }
                  </PanelBody>
                </Panel>
              </PanelContainer>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
export default connect(null, { asyncGoogleSyncComplete })(AccessGoogle)
