import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Icon, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import AddNewFund from './dialogs/addNewFund/'
import PropTypes from 'prop-types'
import FundsForm from './components/fundsForm/'
import FundsFormEmpty from './components/fundsFormEmpty/'
import CompanyContents from './components/companyContents/'

class ManageFunds extends Component {
  shouldComponentUpdate (props) { return props.app !== this.props.app || props.cohorts !== this.props.cohorts }
  launchAddNewFundModal () { this.refs.addNewFund.getWrappedInstance().open() }

  render () {
    const FUNDS_EMPTY = (
      <div>
        <Row>
          <Col xs={12} >
            <div className="common-container-img">
              <div className="common-not-found-pet adaptive-mascot"/>
              <p>{I18n.t('manageFunds.fundsEmpty')}</p>
              <span>{I18n.t('manageFunds.fundsGetStarted')}</span>
              <br/>
              { this.props.app.user.role !== 'employee' ? <Button className="common-white-button" onClick={::this.launchAddNewFundModal}><Icon glyph="fa fa-plus"/> {I18n.t('manageFunds.addFundButton')}</Button> : null }
            </div>
          </Col>
        </Row>
      </div>
    )
    return (
      <div className="manageFunds-component common-page-component">
        {!this.props.app.activeFund || this.props.cohorts.length === 0 ? <FundsFormEmpty /> : <FundsForm />}
        {!this.props.app.activeFund || this.props.cohorts.length === 0 ? FUNDS_EMPTY : <CompanyContents userType={this.props.app.user.account_type}/>}
        <AddNewFund ref="addNewFund"/>
      </div>
    )
  }
}

ManageFunds.propTypes = {
  cohorts: PropTypes.array.isRequired,
  app: PropTypes.shape({
    activeFund: PropTypes.object
  })
}
function mapStateToProps ({app, cohorts}) { return {app, cohorts: cohorts.data} }
export default connect(mapStateToProps)(ManageFunds)
