import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorFundName, ValidatorDate } from '../../../../../utils/validators'
import { asyncAddCohort } from '../../../../../actions'

class AddNewFund extends Component {
  constructor (props) {
    super(props)
    this.state = {
      fundName: '',
      dateFirst: null,
      dateLast: null,
      mainErrors: [],
      mainDateErrors: [],
      showModal: false
    }
  }

  close () { this.setState({showModal: false, fundName: '', dateFirst: null, dateLast: null, mainErrors: []}) }
  open () { this.setState({showModal: true}) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  fnInviteButtonClick () { this.props.asyncAddCohort(null, ::this.close, this.props.app.user.accelerator, this.state.fundName, !this.state.dateFirst ? null : this.state.dateFirst, !this.state.dateLast ? null : this.state.dateLast) }

  render () {
    return (
      <div>
        <Modal lg show={this.state.showModal} onHide={::this.close} className="addNewFund-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('addFund.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col xs={12}>
                <Form>
                  <FormGroup>
                    <TemplateInput
                      type="text"
                      group="main"
                      name="fundName"
                      className="input-form"
                      placeholder={I18n.t('addFund.nameFund')}
                      value={this.state.fundName}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorFundName}
                      required="required"/>
                  </FormGroup>
                  <FormGroup>
                    <div className="common-date-picker-form"><span>{I18n.t('addFund.startDate')}</span>
                      <TemplateInput
                        type="date"
                        group="mainDate"
                        name="dateFirst"
                        value={this.state.dateFirst}
                        valueTwice={this.state.dateLast}
                        onChange={::this.fnChange}
                        fnValidator={ValidatorDate}
                      />
                    </div>
                  </FormGroup>
                  <FormGroup>
                    <div className="common-date-picker-form"><span>{I18n.t('addFund.endDate')}</span>
                      <TemplateInput
                        type="date"
                        group="mainDate"
                        name="dateLast"
                        value={this.state.dateLast}
                        valueTwice={this.state.dateFirst}
                        onChange={::this.fnChange}
                        fnValidator={ValidatorDate}/>
                    </div>
                  </FormGroup>
                </Form>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.fnInviteButtonClick}>{I18n.t('addFund.saveButton')}</Button>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addFund.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
function mapStateToProps ({app, network}) { return {app, networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncAddCohort }, null, { withRef: true })(AddNewFund)
