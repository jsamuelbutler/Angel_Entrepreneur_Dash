import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import Select from 'react-select-plus'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorCompanyName, ValidatorAmountInvest, ValidatorOwnership } from '../../../../../utils/validators'
import { asyncPatchStartUp } from '../../../../../actions'
import PropTypes from 'prop-types'

class EditCompany extends Component {
  constructor (props) {
    super(props)
    this.state = {
      amountInvested: '',
      ownership: '',
      companyName: '',
      securityType: null,
      message: '',
      mainErrors: [],
      showModal: false,
      id: null
    }
    this.securityTypes = [
      {label: 'Common Stock', value: 0},
      {label: 'Preferred Stock', value: 1},
      {label: 'Convertible Note', value: 2},
      {label: 'Safe', value: 3},
      {label: 'Warrant', value: 4}
    ]
  }

  close () { this.setState({showModal: false}) }
  open (e, id, companyName, amountInvested, securityType, ownership) {
    let tmpSecurityType = this.securityTypes.filter(type => type.label.toLowerCase() === securityType)
    this.setState({showModal: true, id, companyName, amountInvested: String(amountInvested), securityType: tmpSecurityType ? tmpSecurityType[0] : null, ownership: String(ownership)})
  }
  onUpdateButtonClick () {
    this.state.mainErrors.length === 0
      ? this.props.asyncPatchStartUp(
        true,
        null,
        ::this.close,
        this.state.id,
        null,
        this.state.companyName,
        null,
        null,
        null,
        null,
        this.state.amountInvested === 'null' ? null : this.state.amountInvested,
        this.state.securityType.label.toLowerCase(),
        this.state.ownership === 'null' ? null : this.state.ownership)
      : ''
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  handleChange (emails) { this.setState({emails: emails, inviteFounders: { emails: emails.join(','), role: 'founder', message: this.state.message }}) }
  updateSecurityType (value) { this.setState({securityType: value}) }
  render () {
    return (
      <div>
        <Modal lg show={this.state.showModal} onHide={::this.close} className="editCompany-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('editCompany.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col xs={12}>
                <Form>
                  <FormGroup>
                    <label className="label">{I18n.t('editCompany.nameCompanyLabel')}</label>
                    <TemplateInput
                      type="text"
                      group="main"
                      placeholder={I18n.t('editCompany.nameCompany')}
                      name="companyName"
                      className="input-form"
                      value={this.state.companyName}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorCompanyName}
                      required="required"/>
                  </FormGroup>
                  <FormGroup>
                    <label className="label">{I18n.t('editCompany.amountInvestedLabel')}</label>
                    <TemplateInput
                      type="number"
                      group="main"
                      placeholder={I18n.t('editCompany.amountInvested')}
                      name="amountInvested"
                      className="input-form"
                      value={this.state.amountInvested}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorAmountInvest}
                      required="required"/>
                  </FormGroup>
                  <FormGroup>
                    <label className="label">{I18n.t('editCompany.secureTypeLabel')}</label>
                    <Select
                      name="form-field-name2"
                      value={this.state.securityType}
                      onChange={::this.updateSecurityType}
                      options={this.securityTypes}
                      placeholder={I18n.t('editCompany.securityType')}
                      searchable={false}
                      clearable
                    />
                  </FormGroup>
                  <FormGroup>
                    <label className="label">{I18n.t('editCompany.ownership')}</label>
                    <TemplateInput
                      type="number"
                      group="main"
                      placeholder={I18n.t('editCompany.ownership')}
                      name="ownership"
                      className="input-form"
                      value={this.state.ownership}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorOwnership}
                      required="required"/>
                  </FormGroup>
                </Form>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onUpdateButtonClick}>{I18n.t('editCompany.updateButton')}</Button>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('editCompany.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
EditCompany.propTypes = {
  asyncPatchStartUp: PropTypes.func.isRequired
}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncPatchStartUp }, null, { withRef: true })(EditCompany)
