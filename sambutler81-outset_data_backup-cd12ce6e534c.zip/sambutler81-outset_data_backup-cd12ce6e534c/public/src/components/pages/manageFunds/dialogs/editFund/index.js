import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import {Row, Col, Modal, Button, Form, FormGroup} from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorFundName, ValidatorDate } from '../../../../../utils/validators'
import { asyncPatchCohort } from '../../../../../actions'

class EditFund extends Component {
  constructor (props) {
    super(props)
    this.state = {
      fundName: '',
      message: '',
      dateFirst: null,
      dateLast: null,
      mainErrors: [],
      mainDateErrors: [],
      showModal: false,
      accelerator: null,
      id: null,
      displayErrorDate: false
    }
  }

  close () { this.setState({showModal: false}) }
  open (fundData) {
    this.setState({
      showModal: true,
      fundName: fundData.name,
      dateFirst: fundData.start_date,
      dateLast: fundData.end_date,
      accelerator: fundData.accelerator,
      id: fundData.id
    })
  }
  onInviteButtonClick () {
    this.props.asyncPatchCohort(null, ::this.close, this.state.id, this.state.accelerator, this.state.fundName, this.state.dateFirst, this.state.dateLast)
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }

  render () {
    return (
      <div>
        <Modal lg show={this.state.showModal} onHide={::this.close} className="editFund-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('editFund.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col xs={12}>
                <Form>
                  <FormGroup>
                    <TemplateInput
                      type="text"
                      group="main"
                      name="fundName"
                      className="input-form"
                      placeholder={I18n.t('editFund.nameFund')}
                      value={this.state.fundName}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorFundName}
                      required="required"/>
                  </FormGroup>
                  <FormGroup>
                    <div className="common-date-picker-form"><span>{I18n.t('editFund.startDate')}</span>
                      <TemplateInput
                        type="date"
                        group="mainDate"
                        name="dateFirst"
                        value={this.state.dateFirst}
                        valueTwice={this.state.dateLast}
                        onChange={::this.fnChange}
                        fnValidator={ValidatorDate}
                        />
                    </div>
                  </FormGroup>
                  <FormGroup>
                    <div className="common-date-picker-form"><span>{I18n.t('editFund.endDate')}</span>
                      <TemplateInput
                        type="date"
                        group="mainDate"
                        name="dateLast"
                        value={this.state.dateLast}
                        valueTwice={this.state.dateFirst}
                        onChange={::this.fnChange}
                        fnValidator={ValidatorDate}
                        />
                    </div>
                  </FormGroup>
                </Form>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button disabled={this.state.mainErrors.length !== 0 || this.state.mainDateErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onInviteButtonClick}>{I18n.t('editFund.saveButton')}</Button>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('editFund.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

EditFund.propTypes = {asyncPatchCohort: PropTypes.func.isRequired}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncPatchCohort }, null, { withRef: true })(EditFund)
