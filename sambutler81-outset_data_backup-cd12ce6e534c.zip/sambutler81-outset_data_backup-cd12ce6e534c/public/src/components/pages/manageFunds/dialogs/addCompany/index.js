import './style'
import React, { Component } from 'react'
import TagsInput from 'react-tagsinput'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import Select from 'react-select-plus'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorCompanyName, ValidatorMessage, ValidatorAmountInvest, ValidatorOwnership } from '../../../../../utils/validators'
import { asyncAddStartUp } from '../../../../../actions'
import PropTypes from 'prop-types'

const INIT_SATATE = {
  amountInvested: '',
  ownership: '',
  companyName: '',
  securityType: null,
  inviteFounders: {
    emails: '',
    role: 'founder',
    message: ''
  },
  emails: [],
  message: '',
  mainErrors: [],
  showModal: false,
  id: null
}

class AddCompany extends Component {
  constructor (props) {
    super(props)
    this.state = INIT_SATATE
    this.securityTypes = [
      {label: 'Common Stock', value: 0},
      {label: 'Preferred Stock', value: 1},
      {label: 'Convertible Note', value: 2},
      {label: 'Safe', value: 3},
      {label: 'Warrant', value: 4}
    ]
  }

  close () { this.setState({...INIT_SATATE, showModal: false}) }
  open (id) { this.setState({showModal: true, id}) }
  onInviteButtonClick () {
    this.state.mainErrors.length === 0
      ? this.props.asyncAddStartUp(
        null,
        ::this.close,
        this.state.id,
        this.state.companyName,
        this.state.amountInvested ? this.state.amountInvested : null,
        this.state.securityType ? this.state.securityType.label.toLowerCase() : null,
        this.state.ownership ? this.state.ownership : null,

        this.state.inviteFounders.emails.length ? this.state.inviteFounders : null)
      : ''
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  handleChange (emails) { this.setState({emails: emails, inviteFounders: { emails: emails.join(','), role: 'founder', message: this.state.message }}) }
  updateSecurityType (value) { this.setState({securityType: value}) }
  render () {
    return (
      <div>
        <Modal lg show={this.state.showModal} onHide={::this.close} className="addCompany-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('addCompany.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col xs={12}>
                <Form>
                  <FormGroup>
                    <TemplateInput
                      type="text"
                      group="main"
                      placeholder={I18n.t('addCompany.nameCompany')}
                      name="companyName"
                      className="input-form"
                      value={this.state.companyName}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorCompanyName}
                      required="required"/>
                  </FormGroup>
                  <FormGroup>
                    <TemplateInput
                      type="number"
                      group="main"
                      placeholder={I18n.t('addCompany.amountInvested')}
                      name="amountInvested"
                      className="input-form"
                      value={this.state.amountInvested}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorAmountInvest}/>
                  </FormGroup>
                  <FormGroup>
                    <Select
                      name="form-field-name2"
                      value={this.state.securityType}
                      onChange={::this.updateSecurityType}
                      options={this.securityTypes}
                      placeholder={I18n.t('addCompany.securityType')}
                      searchable={false}
                      clearable
                    />
                  </FormGroup>
                  <FormGroup>
                    <TemplateInput
                      type="number"
                      group="main"
                      placeholder={I18n.t('addCompany.ownership')}
                      name="ownership"
                      className="input-form"
                      value={this.state.ownership}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorOwnership}/>
                  </FormGroup>
                  <FormGroup>
                    <span className="common-italic">Separate Email Addresses Using a Space Between Them</span>
                    <TagsInput value={this.state.emails}
                      onChange={::this.handleChange}
                      addOnBlur
                      addKeys={[9, 13, 32]}
                      className = "input-invite-email"
                      tagProps = {{className: 'input-invite-email-tag', classNameRemove: 'input-invite-email-tag-remove'}}
                      inputProps={{className: 'react-tagsinput-input', placeholder: `${I18n.t('addCompany.inviteFounders')}`}}
                      validationRegex={/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/}
                    />
                  </FormGroup>
                  <FormGroup>
                    <TemplateInput
                      type="textarea"
                      group="main"
                      placeholder={I18n.t('addCompany.message')}
                      name="message"
                      className="textarea-form max-width no-resize"
                      value={this.state.message}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorMessage}/>
                  </FormGroup>
                </Form>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onInviteButtonClick}>{I18n.t('addCompany.addButton')}</Button>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('addCompany.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
AddCompany.propTypes = {
  asyncAddStartUp: PropTypes.func.isRequired
}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncAddStartUp }, null, { withRef: true })(AddCompany)
