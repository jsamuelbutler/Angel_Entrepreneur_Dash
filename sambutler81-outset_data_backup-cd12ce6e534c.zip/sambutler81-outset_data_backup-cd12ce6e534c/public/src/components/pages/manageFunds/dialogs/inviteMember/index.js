import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button, Form, FormGroup } from '@sketchpixy/rubix'
import TagsInput from 'react-tagsinput'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import { asyncStartUpInvite } from '../../../../../actions'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorMessage } from '../../../../../utils/validators'

const INIT_DATA = {
  emails: [],
  mainErrors: [],
  showModal: false,
  companyId: null,
  fundId: null,
  message: ''
}

class InviteMember extends Component {
  constructor (props) {
    super(props)
    this.state = {
      ...INIT_DATA
    }
  }
  handleChange (emails) {
    this.setState({emails})
  }
  close () { this.setState({...INIT_DATA, showModal: false}) }
  open (e, companyId, fundId) { e.preventDefault(); e.stopPropagation(); this.setState({showModal: true, companyId, fundId}) }
  onInviteButtonClick () { this.props.asyncStartUpInvite(null, ::this.close, this.state.companyId, this.state.emails.join(','), 'founder', this.state.message) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }

  render () {
    return (
      <div>
        <Modal show={this.state.showModal} onHide={::this.close} className="inviteMember-component common-modal">
          <Modal.Header closeButton title={I18n.t('common.close')}>
            <Modal.Title>{I18n.t('inviteTeamMember.title')}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col xs={12}>
                <Form>
                  <span>Separate Email Addresses Using a Space Between Them</span>
                  <TagsInput value={this.state.emails}
                    onChange={::this.handleChange}
                    addOnBlur
                    className = "input-invite-email"
                    addKeys={[9, 13, 32]}
                    tagProps = {{className: 'input-invite-email-tag', classNameRemove: 'input-invite-email-tag-remove'}}
                    inputProps={{className: 'react-tagsinput-input', placeholder: I18n.t('inviteTeamMember.email')}}
                    validationRegex={/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/}
                   />
                  <FormGroup>
                    <TemplateInput
                      type="textarea"
                      group="main"
                      name="message"
                      className="textarea-form max-width no-resize"
                      placeholder={I18n.t('inviteTeamMember.message')}
                      value={this.state.message}
                      onChange={::this.fnChange}
                      fnValidator={ValidatorMessage}
                      required="required"/>
                  </FormGroup>
                </Form>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button disabled={this.state.mainErrors.length !== 0 || this.props.networkActive} className="common-default-button common-apply-button" onClick={::this.onInviteButtonClick}>{I18n.t('inviteTeamMember.inviteButton')}</Button>
            <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>{I18n.t('inviteTeamMember.closeButton')}</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
InviteMember.propTypes = {asyncStartUpInvite: PropTypes.func.isRequired}
function mapStateToProps ({network}) { return {networkActive: network.networkActive} }
export default connect(mapStateToProps, { asyncStartUpInvite }, null, { withRef: true })(InviteMember)
