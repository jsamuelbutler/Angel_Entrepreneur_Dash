import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import {Col, Row, Panel, PanelBody, PanelHeader, PanelContainer, PanelFooter, Button, Icon} from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import numeral from 'numeral'
import MessageBox from '../../../../dialogs/messageBox/'
import InviteMember from '../../dialogs/inviteMember/'
import AddNewFund from '../../dialogs/addNewFund/'
import AddCompany from '../../dialogs/addCompany/'
import EditCompany from '../../dialogs/editCompany/'
import PropTypes from 'prop-types'
import { asyncStartUpDeactivate, asyncDeleteTeamMember } from '../../../../../actions'

class CompanyContents extends Component {

  constructor (props) {
    super(props)
    this.state = {
      panels: Array(this.props.startups.length).fill(false),
      fundsEmpty: false
    }
  }
  componentWillReceiveProps (props) { this.setState({panels: Array(props.startups.length).fill(false)}) }
  shouldComponentUpdate (props, state) { return state !== this.state || props.startups !== this.props.startups || props.cohorts !== this.props.cohorts || props.app !== this.props.app }

  fnAddCompany () { this.refs.addCompany.getWrappedInstance().open(this.props.app.activeFund.id || this.props.cohorts[0].id) }
  launchEditMode (i) {
    !this.state.panels[i] && this.state.panels.fill(false)
    const panels = this.state.panels.slice()
    panels[i] = !panels[i]
    this.setState({panels: panels})
  }
  fnDeactivateCompany (e, companyId, fundId) {
    e.preventDefault()
    e.stopPropagation()
    this.refs.messageBox.getWrappedInstance().init(
      I18n.t('manageFunds.confirmCompanyDeactivate'),
      I18n.t('manageFunds.confirmCompanyDeactivateWarn')
    )
    .then(() => { this.props.asyncStartUpDeactivate(null, companyId, fundId) })
    .catch(() => {})
  }
  render () {
    const COMPANY = this.props.startups.map((item, index) => {
      return (
        <Col xs={12} sm={12} md={6} lg={4} key={index} className="company-content common-half-padding-child">
          <PanelContainer controls={false} onClick={() => { this.props.app.user.role !== 'employee' && ::this.launchEditMode(index) }}>
            <Panel>
              <PanelHeader className="title">
                <span className="common-font-title title-company" title={item.name}>
                  {item.name}
                </span>
                <p className="invested" title={` ${numeral(item.amount_invested).format('$ 0.00 a')} ${I18n.t('manageFunds.invested')}`}>{item.amount_invested ? `${numeral(item.amount_invested).format('$ 0.00 a')} ${I18n.t('manageFunds.invested')}` : ''}</p>
              </PanelHeader>
              <PanelBody>
                {!item.amount_invested
                  ? <p className="not-invested" title={` ${numeral(item.amount_invested).format('$ 0.00 a')} ${I18n.t('manageFunds.invested')}`}>{` ${item.amount_invested ? numeral(item.amount_invested).format('$ 0.00 a') : 'Not'} ${I18n.t('manageFunds.invested')}`}</p>
                  : <div className={(this.state.panels[index] ? 'edit-mode clearfix' : '')}>
                    <Col xs={6} sm={6} className="ownership-mobile"><span className="ownership">{item.ownership}% {I18n.t('manageFunds.ownership')}</span></Col>
                    <Col xs={6} sm={6} ><span className="ownership-mobile-margin valuation">{` ${item.amount_invested && item.ownership ? numeral(item.amount_invested / (item.ownership / 100)).format('$ 0.00 a') : 'No'} ${I18n.t('manageFunds.value')}`}</span></Col>
                    <Col xs={12} className="ownership-mobile"><span className="security-type">{item.security_type}</span></Col>
                  </div>
                }
              </PanelBody>
              {this.state.panels[index] ? (
                <PanelFooter>
                  <Row>
                    <Col xs={12} >
                      {this.props.userType === 1 || this.props.userType === 2 ? <Button className="company-panel-footer-btn common-default-button left left-xs" onClick={(e) => ::this.refs.editCompany.getWrappedInstance().open(e, item.id, item.name, item.amount_invested, item.security_type, item.ownership)}>Edit</Button> : ''}
                      <Button className="company-panel-footer-btn common-default-button" onClick={(e) => ::this.refs.inviteMember.getWrappedInstance().open(e, item.id, item.cohort)}>{I18n.t('manageFunds.inviteButton')}</Button>
                      {this.props.userType === 1 || this.props.userType === 2 ? <Button className="footer-btn-margin-none company-panel-footer-btn common-default-close-button right-xs manage-funds-deactivate" bsStyle="link" onClick={(e) => ::this.fnDeactivateCompany(e, item.id, item.cohort)} >{I18n.t('manageFunds.deactivateButton')}</Button> : ''}
                    </Col>
                  </Row>
                </PanelFooter>
              ) : null}
            </Panel>
          </PanelContainer>
        </Col>
      )
    })
    const COMPANY_EMPTY = (
      <div>
        <Row>
          <Col xs={12} >
            <div className="common-container-img">
              <div className="common-not-found-pet adaptive-mascot"/>
              <p>{I18n.t('manageFunds.noCompany')}</p>
              <span>{I18n.t('manageFunds.companyGetStarted')}</span>
              <div className="control-icon-group">
                { this.props.app.user.role !== 'employee' ? <Button className="common-white-button" onClick={::this.fnAddCompany}><Icon glyph="fa fa-plus"/> {I18n.t('addCompany.title')}</Button> : null }
              </div>
              <br/>
            </div>
          </Col>
        </Row>
      </div>
    )
    return (
      <div className="companyContents-component common-wrap-half-padding clearfix">
        {this.props.startups.length ? COMPANY : COMPANY_EMPTY}
        <MessageBox ref="messageBox"/>
        <InviteMember ref="inviteMember"/>
        <AddNewFund ref="addNewFund"/>
        <AddCompany ref="addCompany"/>
        <EditCompany ref="editCompany"/>
      </div>
    )
  }
}

CompanyContents.propTypes = {
  startups: PropTypes.array.isRequired,
  cohorts: PropTypes.array.isRequired,
  asyncDeleteTeamMember: PropTypes.func.isRequired,
  asyncStartUpDeactivate: PropTypes.func.isRequired
}

function mapStateToProps ({app, cohorts, startups}) { return {app, cohorts: cohorts.data, startups: startups.startups} }

export default connect(mapStateToProps, {asyncStartUpDeactivate, asyncDeleteTeamMember})(CompanyContents)
