import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Grid, Row, Col, Panel, PanelBody, FormGroup, PanelHeader, Icon, PanelContainer, Button, ControlLabel } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import moment from 'moment'
import SelectCohort from '../../../../common/selectCohort/'
import { asyncDeleteCohort, asyncGetCohortAll, actionSetActiveFund, actionGetStartUpAllClean, actionSetStartUpToDosClean, actionSetStartUpUpdatesClean, actionSetStartUpNotesDocsClean, actionSetStartUpActivitiesClean } from '../../../../../actions'
import AddNewFund from '../../dialogs/addNewFund/'
import AddCompany from '../../dialogs/addCompany/'
import EditFund from '../../dialogs/editFund/'
import MessageBox from '../../../../dialogs/messageBox/'
import PropTypes from 'prop-types'

class FundsForm extends Component {

  componentDidMount () { this.props.asyncGetCohortAll(null) }
  getCohort () {
    let response = null
    this.props.cohorts.map(item => { if (this.props.app.activeFund && item.id === this.props.app.activeFund.id) { response = item } })
    return response
  }
  launchAddCompanyModal () { this.refs.addCompany.getWrappedInstance().open(this.props.app.activeFund.id || this.props.cohorts[0].id) }
  launchAddNewFundModal () { this.refs.addNewFund.getWrappedInstance().open() }
  launchRemoveFundModal () {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('manageFunds.removeFundTitle'), I18n.t('manageFunds.removeFundMessage'))
    .then(() => { this.props.asyncDeleteCohort(null, this.getCohort().id, true, ::this.setFund) })
    .catch(() => {})
  }
  setFund () { this.props.actionSetActiveFund(null); this.props.actionGetStartUpAllClean(); this.props.actionSetStartUpToDosClean(); this.props.actionSetStartUpActivitiesClean(); this.props.actionSetStartUpUpdatesClean(); this.props.actionSetStartUpNotesDocsClean() }

  launchEditFundModal () { this.refs.editFund.getWrappedInstance().open(this.getCohort()) }

  render () {
    const ADD_BUTTON = (
      <Col xs={12} sm={4} md={12} lg={3} className="text-right">
        <Button className="add-company-btn common-default-button right" onClick={::this.launchAddCompanyModal}>
          <Icon glyph="fa fa-plus"/> {I18n.t('manageFunds.addCompanyToFund')}
        </Button>
      </Col>
    )
    const FUNDS_PANEL_BODY = (
      <PanelBody>
        <Grid>
          <Row>
            <Col xs={12}>
              <div className="funds-form-wrap clearfix">
                <Col xs={12} sm={12} md={4} lg={3}>
                  <SelectCohort />
                </Col>
                <Col xs={12} sm={4} md={4} lg={3}>
                  <FormGroup className={`flex-box-manage-funds ${this.getCohort() && !this.getCohort().start_date ? 'hidden' : ''}`}>
                    <ControlLabel>{I18n.t('manageFunds.startDate')}:</ControlLabel>
                    {moment(this.getCohort() && this.getCohort().start_date).format('MMM Do YYYY')}
                  </FormGroup>
                </Col>
                <Col xs={12} sm={4} md={4} lg={3}>
                  <FormGroup className={`flex-box-manage-funds ${this.getCohort() && !this.getCohort().end_date ? 'hidden' : ''}`}>
                    <ControlLabel>{I18n.t('manageFunds.endDate')}:</ControlLabel>
                    {moment(this.getCohort() && this.getCohort().end_date).format('MMM Do YYYY')}
                  </FormGroup>
                </Col>
                { this.props.app.user.role !== 'employee' ? ADD_BUTTON : null }
              </div>
            </Col>
          </Row>
        </Grid>
      </PanelBody>
    )
    return (
      <div className="fundsForm-component">
        <PanelContainer className="funds-head-panel" noOverflow>
          <Panel>
            <PanelHeader>
              <Row>
                <Col xs={6} className="div-align-left">
                  <span className="common-font-title">{I18n.t('manageFunds.title')}</span>
                </Col>
                <Col xs={6} className="div-align-right">
                  <div className="control-icon-group">
                    {this.props.app.user.role !== 'employee' && this.props.cohorts.length !== 0 ? <Icon title={I18n.t('manageFunds.removeFund')} glyph="fa fa-trash" className="common-cursor-pointer" onClick={::this.launchRemoveFundModal}/> : null}
                    {this.props.app.user.role !== 'employee' && this.props.cohorts.length !== 0 ? <Icon title={I18n.t('editFund.title')} glyph="fa fa-pencil" className="common-cursor-pointer" onClick={::this.launchEditFundModal}/> : null}
                    {this.props.app.user.role !== 'employee' ? <Icon title={I18n.t('manageFunds.addFundButton')} glyph="fa fa-plus" className="common-cursor-pointer" onClick={::this.launchAddNewFundModal}/> : null}
                  </div>
                </Col>
              </Row>
            </PanelHeader>
            {this.props.cohorts.length !== 0 ? FUNDS_PANEL_BODY : null}
          </Panel>
          <AddCompany ref="addCompany"/>
          <AddNewFund ref="addNewFund"/>
          <EditFund ref="editFund"/>
          <MessageBox ref="messageBox"/>
        </PanelContainer>
      </div>
    )
  }
}

FundsForm.propTypes = {
  cohorts: PropTypes.array.isRequired,
  app: PropTypes.shape({
    activeFund: PropTypes.shape({
      id: PropTypes.number.isRequired
    })
  }),

  asyncGetCohortAll: PropTypes.func.isRequired,
  asyncDeleteCohort: PropTypes.func.isRequired
}

function mapStateToProps ({app, cohorts}) { return {app, cohorts: cohorts.data} }
export default connect(mapStateToProps, {asyncDeleteCohort, asyncGetCohortAll, actionSetActiveFund, actionGetStartUpAllClean, actionSetStartUpToDosClean, actionSetStartUpActivitiesClean, actionSetStartUpUpdatesClean, actionSetStartUpNotesDocsClean})(FundsForm)
