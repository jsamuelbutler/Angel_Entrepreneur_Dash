import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Panel, PanelHeader, Icon, PanelContainer } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import AddNewFund from '../../dialogs/addNewFund/'

class FundsFormEmpty extends Component {

  launchAddNewFundModal () { this.refs.addNewFund.getWrappedInstance().open() }

  render () {
    return (
      <div className="fundsFormEmpty-component">
        <PanelContainer className="funds-head-panel" noOverflow>
          <Panel>
            <PanelHeader>
              <Row>
                <Col xs={6} className="div-align-left">
                  <span className="common-font-title">{I18n.t('manageFunds.title')}</span>
                </Col>
                <Col xs={6} className="div-align-right">
                  <div className="control-icon-group">
                    <Icon title={I18n.t('manageFunds.addFundButton')} glyph="fa fa-plus" className="common-cursor-pointer" onClick={::this.launchAddNewFundModal}/>
                  </div>
                </Col>
              </Row>
            </PanelHeader>
          </Panel>
          <AddNewFund ref="addNewFund"/>
        </PanelContainer>
      </div>
    )
  }
}
export default connect()(FundsFormEmpty)
