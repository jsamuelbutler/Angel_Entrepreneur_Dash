import React, {Component} from 'react'
import { connect } from 'react-redux'
import './style'
import { Row, Col, Grid } from '@sketchpixy/rubix'
import { asyncStartUpStripeIntegrationComplete } from '../../../actions'
import { I18n } from 'react-redux-i18n'
import { history } from '../../../store'
import MessageBoxAlert from '../../dialogs/messageBoxAlert/'

class AccessStripe extends Component {
  componentDidMount () {
    if (this.props.location.query.code && this.props.location.query.scope) {
      this.props.asyncStartUpStripeIntegrationComplete(null, () => { history.push('/data') }, this.props.app.user.startup, this.props.location.query.code, this.props.location.query.scope)
    } else {
      this.refs.messageBoxAlert.getWrappedInstance().init('Information', 'We\'re working hard to gather all this data for you, but it\'s going to take a while.  Please check back in about [how ever long you think] to see if we\'ve been able to populate your graphs.')
        .then(() => { history.push('/data') })
        .catch(() => { history.push('/data') })
    }
  }

  render () {
    return (
      <div className="accessStripe-component">
        <Grid className="common-lower-width">
          <Row>
            <Col>
              <div className="info-block common-warning">
                <p className="titles">{I18n.t('accessStripe.title')}</p>
                <span className="message">{I18n.t('accessStripe.accountActivated')}</span>
              </div>
            </Col>
          </Row>
          <div className="common-container-img">
            <div className="activated-pet adaptive-mascot"/>
          </div>
        </Grid>
        <MessageBoxAlert ref="messageBoxAlert"/>
      </div>
    )
  }
}
function mapStateToProps ({app}) { return {app} }
export default connect(mapStateToProps, {asyncStartUpStripeIntegrationComplete})(AccessStripe)
