import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button, FormGroup } from '@sketchpixy/rubix'
import { asyncStartUpBankIntegrationLoginForm } from '../../../../../actions'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'
import { ValidatorTrue } from '../../../../../utils/validators'

class RenderForm extends Component {
  constructor (props) {
    super(props)
    this.state = {
      showModal: false,
      mainErrors: []
    }
    this.type = ''
  }

  close () { this.setState({showModal: false}) }
  open () { this.setState({showModal: true}) }
  addBank () {
    let questions = this.props.bankChallengeForm.map((item, index) => {
      switch (this.type) {
        case 'imageChoices': {
          return {
            text: item.text,
            answer: this.state[`${999}Image`]
          }
        }
        case 'text': {
          return {
            text: item.text,
            answer: this.state[`${index}Answer`]
          }
        }
        case 'image': {
          return {
            text: item.text,
            answer: this.state[`${index}Answer`]
          }
        }
        case 'choices': {
          return {
            choices: item.choices,
            text: item.text,
            answer: this.state[`${index}Answer`]
          }
        }
      }
    })
    const challenge = {questions}
    this.props.asyncStartUpBankIntegrationLoginForm(null, null, () => {
      this.refs.messageBoxAlert.getWrappedInstance().init('Information', 'We\'re working hard to gather all this data for you, but it\'s going to take a while.  Please check back in about [how ever long you think] to see if we\'ve been able to populate your graphs.', true)
        .then(() => { ::this.close() })
        .catch(() => { ::this.close() })
    }, this.props.app.user.startup, null, challenge, () => { this.props.bankChallengeForm.map((item, index) => { this.setState({[`${index}Answer`]: ''}) }) })
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }

  selectImage (event) { this.setState({[`${999}Image`]: event.target.dataset.value}) }

  render () {
    const CONTENT = this.props.bankChallengeForm.map((item, index) => {
      // TEXT
      if (item.text && Object.keys(item).length === 1) {
        this.type = 'text'
        return (
          <FormGroup key={index}>
            <label>{item.text}</label>
            <TemplateInput
              type="text"
              group="main"
              name={`${index}Answer`}
              className="input-form"
              placeholder={'Enter answer'}
              value={this.state[`${index}Answer`]}
              onChange={::this.fnChange}
              fnValidator={ValidatorTrue}
              required="required"/>
          </FormGroup>
        )
      }
      // IMAGE CHOICE
      if (item.imageChoices) {
        this.type = 'imageChoices'
        const images = item.imageChoices.map((img, index) => { return <img data-value={img.value} data-key={index} onClick={::this.selectImage} className={`imageChoices ${this.state[`${999}Image`] === img.value ? 'active' : ''}`} key={index} src={img.imageChoice}/> })
        return (
          <FormGroup key={index}>
            {item.image ? <div className="questionImage"><img src={item.image}/></div> : <label>{item.text}</label>}
            {images}
          </FormGroup>
        )
      }
      // IMAGE
      if (item.image) {
        this.type = 'image'
        return (
          <FormGroup key={index}>
            <img src={item.image}/>
            <label>{item.text}</label>
            <TemplateInput
              type="text"
              group="main"
              name={`${index}Answer`}
              className="input-form"
              placeholder={'Enter answer'}
              value={this.state[`${index}Answer`]}
              onChange={::this.fnChange}
              fnValidator={ValidatorTrue}
              required="required"/>
          </FormGroup>
        )
      }
      // CHOICE
      if (item.choices) {
        this.type = 'choices'
        const choices = item.choices.map(choice => { return {value: choice.value, label: choice.choice} })
        return (
          <FormGroup key={index}>
            <label>{item.text}</label>
            <TemplateInput
              type="select"
              group="main"
              name={`${index}Answer`}
              className="input-form"
              placeholder={'Choice answer'}
              value={this.state[`${index}Answer`]}
              options={choices}
              onChange={::this.fnChange}
              fnValidator={ValidatorTrue}
              required="required"/>
          </FormGroup>
        )
      }
    })
    return (
      <Modal show={this.state.showModal} onHide={::this.close} className="connectStripe-component">
        <Modal.Header closeButton>
          <Modal.Title>Introduction form</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {CONTENT}
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.state.mainErrors.length !== 0} className="common-default-button common-apply-button left" onClick={::this.addBank}>Ok</Button>
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>Close</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
function mapStateToProps ({app, startups}) { return {app, bankChallengeForm: startups.bankChallengeForm} }
export default connect(mapStateToProps, {asyncStartUpBankIntegrationLoginForm}, null, { withRef: true })(RenderForm)
