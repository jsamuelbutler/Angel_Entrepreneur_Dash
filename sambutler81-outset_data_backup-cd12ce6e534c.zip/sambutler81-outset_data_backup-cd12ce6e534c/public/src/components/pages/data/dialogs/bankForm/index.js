import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Modal, Button, FormGroup } from '@sketchpixy/rubix'
import { asyncStartUpBankIntegration, asyncStartUpBankInstitutions, asyncStartUpBankIntegrationLoginForm, actionStartUpBankIntegration } from '../../../../../actions'
import Select from 'react-select'
import { ValidatorTrue } from '../../../../../utils/validators'
import TemplateInput, { ValidatorError } from '../../../../common/templateInput/'

const initState = {
  showModal: false,
  userName: '',
  integration: null,
  firstName: '',
  lastName: '',
  mainErrors: [],
  generatedErrors: []
}

class BankForm extends Component {
  constructor (props) {
    super(props)
    this.state = {
      ...initState
    }
  }

  close () { this.setState({...initState}) }
  open () { this.setState({showModal: true}) }
  addBank () { this.props.asyncStartUpBankIntegration(null, null, this.props.app.user.startup, this.state.integration) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  changeIntegration (target) { this.setState({integration: target ? target.value : null}) }
  getOptions (input, callback) { this.props.asyncStartUpBankInstitutions(null, input, callback) }
  sendForm () {
    const data = this.props.bankCredentialsForm.map(item => {
      return {
        name: item.name,
        id: item.id,
        value: this.state[item.name]
      }
    })
    this.props.asyncStartUpBankIntegrationLoginForm(null, (openNext) => { ::this.close(); openNext && this.props.openNextForm() }, null, this.props.app.user.startup, data)
  }

  render () {
    const CONTENT_1 = (
      <div>
        <Select.Async
          name="form-field-name"
          value={this.state.integration}
          placeholder="Find or select your bank"
          onChange={::this.changeIntegration}
          loadOptions={::this.getOptions}
        />
      </div>
    )
    const CONTENT_2 = this.props.bankCredentialsForm.map((item, index) => {
      return (
        <FormGroup key={index}>
          <TemplateInput
            autocomplete="off"
            type={item.mask === 'false' ? `text` : `password`}
            group="generated"
            name={item.name}
            className="input-form"
            placeholder={item.description}
            value={this.state[item.name]}
            onChange={::this.fnChange}
            fnValidator={ValidatorTrue}
            required="required"/>
        </FormGroup>
      )
    })

    return (
      <Modal show={this.state.showModal} onHide={::this.close} className="connectStripe-component">
        <Modal.Header closeButton>
          <Modal.Title>Introduction form</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {this.props.bankCredentialsForm.length > 0 ? CONTENT_2 : CONTENT_1}
        </Modal.Body>
        <Modal.Footer>
          <Button disabled={this.props.bankCredentialsForm.length > 0 ? this.state.generatedErrors.length !== 0 : (this.state.mainErrors.length !== 0 || !this.state.integration)} className="common-default-button common-apply-button left" onClick={this.props.bankCredentialsForm.length > 0 ? ::this.sendForm : ::this.addBank}>Ok</Button>
          {this.props.bankCredentialsForm.length > 0 ? <Button className="common-default-button common-apply-button" bsStyle="link" onClick={() => ::this.props.actionStartUpBankIntegration({login_form: []}, 'SUCCESS')}>Back</Button> : null }
          <Button className="common-default-close-button common-close-button" bsStyle="link" onClick={::this.close}>Close</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
function mapStateToProps ({app, startups}) { return {app, bankCredentialsForm: startups.bankCredentialsForm} }
export default connect(mapStateToProps, {asyncStartUpBankIntegration, asyncStartUpBankInstitutions, asyncStartUpBankIntegrationLoginForm, actionStartUpBankIntegration}, null, { withRef: true })(BankForm)
