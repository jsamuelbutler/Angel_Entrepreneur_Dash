import React, {Component} from 'react'
import { connect } from 'react-redux'
import { Button, Col, Row, Icon } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import BankForm from './dialogs/bankForm/'
import RenderForm from './dialogs/renderForm/'
import { history } from '../../../store'
import MessageBox from '../../dialogs/messageBox/'
import MessageBoxAlert from '../../dialogs/messageBoxAlert/'

import './style'
import { asyncGetStartUp, asyncStartUpXeroIntegration, asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpStripeIntegration, asyncStartUpStripeDisIntegration, asyncStartUpXeroDisIntegration, asyncStartUpBankDisIntegration } from '../../../actions'

class DataOptions extends Component {
  componentDidMount () { !this.props.app.user.allow_connect && history.push('/portfolioManagement'); this.props.asyncGetStartUp(null, this.props.app.user.startup) }
  componentWillReceiveProps () { !this.props.app.user.allow_connect && history.push('/portfolioManagement') }
  connectStripe () { this.props.asyncStartUpStripeIntegration(null, () => this.props.asyncGetStartUp(null, this.props.app.user.startup), this.props.app.user.startup) }
  connectXero () { this.props.asyncStartUpXeroIntegration(null, () => this.props.asyncGetStartUp(null, this.props.app.user.startup), this.props.app.user.startup) }

  openBankFormModal () { this.refs.bankForm.getWrappedInstance().open() }
  openNextForm () { this.refs.renderForm.getWrappedInstance().open() }
  goKPI () { history.push('/portfolioManagement') }

  removeStripe () {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('dataPage.removeStripeTitle'), I18n.t('dataPage.removeStripeMessage'))
      .then(() => { this.props.asyncStartUpStripeDisIntegration(null, () => this.props.asyncGetStartUp(null, this.props.app.user.startup), this.props.app.user.startup) })
      .catch(() => {})
  }
  removeXero () {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('dataPage.removeXeroTitle'), I18n.t('dataPage.removeXeroMessage'))
      .then(() => { this.props.asyncStartUpXeroDisIntegration(null, () => this.props.asyncGetStartUp(null, this.props.app.user.startup), this.props.app.user.startup) })
      .catch(() => {})
  }
  removeBank () {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('dataPage.removeBankTitle'), I18n.t('dataPage.removeBankMessage'))
      .then(() => { this.props.asyncStartUpBankDisIntegration(null, () => this.props.asyncGetStartUp(null, this.props.app.user.startup), this.props.app.user.startup) })
      .catch(() => {})
  }
  render () {
    return (
      <div className="data-component empty">
        <div className="container-img">
          <h3 className="common-data-options-header">{I18n.t('dataPage.header')}</h3>
          <div>
            <div>
              <div className="common-box-data">
                <div className="common-question-data-options">{I18n.t('dataPage.noCompanies')}</div>
              </div>
            </div>
            <div/>
          </div>
          <div className="data-puzzle-h">
            <Row>
              <Col sm={4}>
                <div onClick={!(this.props.startup.stripe_data) && ::this.connectStripe} className="common-cursor-pointer stripe-h">
                  { this.props.startup.stripe_data ? <div title="Connected" className="check"/> : null}
                  { this.props.startup.stripe_data ? <div onClick={::this.removeStripe} title="Remove Stripe" className="remove"><Icon glyph="fa fa-times-circle"/></div> : null}
                </div>
              </Col>
              <Col sm={4}>
                <div onClick={!(this.props.startup.xero_data) && ::this.connectXero} className="common-cursor-pointer xero-h">
                  { this.props.startup.xero_data ? <div title="Connected" className="check"/> : null}
                  { this.props.startup.xero_data ? <div onClick={::this.removeXero} title="Remove Xero" className="remove"><Icon glyph="fa fa-times-circle"/></div> : null}
                </div>
              </Col>
              <Col sm={4}>
                <div onClick={!(this.props.startup.bank_data) && ::this.openBankFormModal} className="common-cursor-pointer bank-h">
                  { this.props.startup.bank_data ? <div title="Connected" className="check"/> : null}
                  { this.props.startup.bank_data ? <div onClick={::this.removeBank} title="Remove Bank" className="remove"><Icon glyph="fa fa-times-circle"/></div> : null}
                </div>
              </Col>
            </Row>
          </div>
        </div>
        <BankForm startup={this.props.app.user.startup} openNextForm={::this.openNextForm} ref="bankForm"/>
        <RenderForm startup={this.props.app.user.startup} ref="renderForm"/>
        <Button className="common-white-button center-block" onClick={::this.goKPI}>Go back</Button>
        <MessageBox ref="messageBox"/>
        <MessageBoxAlert ref="messageBoxAlert"/>
      </div>
    )
  }
}
function mapStateToProps ({app, startups}) { return {app, startup: startups.startup} }
export default connect(mapStateToProps, {asyncGetStartUp, asyncStartUpXeroIntegration, asyncStartUpXeroIntegrationComplete, asyncStartUpXeroIntegrationAccounts, asyncStartUpStripeIntegration, asyncStartUpStripeDisIntegration, asyncStartUpXeroDisIntegration, asyncStartUpBankDisIntegration})(DataOptions)
