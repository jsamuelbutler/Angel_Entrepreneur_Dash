import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import Select from 'react-select-plus'
import { asyncGetStartUpAll, actionSetActiveFund } from '../../../../../actions'

class SelectCohort extends Component {

  constructor (props) {
    super(props)
    this.state = {
      value: this.props.activeFund ? `c-${this.props.activeFund.id}` : null,
      options: []
    }
  }

  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) { if (this.props.activeFund !== props.activeFund || props.startups !== this.props.startups || props.cohorts !== this.props.cohorts) { ::this.initComponent(props) } }

  initComponent (props) {
    if (this.props.withCompany) {
      let options = []
      props.cohorts && props.cohorts.map(obj => {
        let startups = props.startups.filter(item => {
          return item.cohort === obj.id
        })
        options.push({value: `c-${obj.id}`, label: `${obj.name}`, id: obj.id, type: 'cohort'})
        startups.map(item => {
          options.push({value: `s-${item.id}`, label: `- ${item.name}`, id: item.id, type: 'startup', className: 'companySelectWrap'})
        })
      })
      props.cohorts && this.setState({options})
      props.activeFund && this.setState({value: `c-${props.activeFund.id}`})
    } else {
      props.cohorts && this.setState({options: props.cohorts.map(obj => { return {value: `c-${obj.id}`, label: obj.name, id: obj.id} })})
      props.activeFund && this.setState({value: `c-${props.activeFund.id}`})
    }
    props.activeFund && this.props.changeSelect('cohort', props.activeFund.id)
  }

  updateValue (value) {
    this.props.onChangeCohortStartup(value.type, value.id)
    this.setState({value: value.type === 'cohort' ? `c-${value.id}` : `s-${value.id}`})
    this.props.changeSelect(value.type, value.id)
    value.type !== 'cohort' ? this.props.asyncGetStartUpPortfolioStatistic && this.props.asyncGetStartUpPortfolioStatistic(null, value.id) : this.props.asyncGetPortfolioStatistic && this.props.asyncGetPortfolioStatistic(null, value.id)
    this.props.asyncGetYearsKPI && this.props.asyncGetYearsKPI(null, value.type === 'cohort' ? value.id : null, value.type === 'startup' ? value.id : null)
    this.props.asyncGetChartKPI && this.props.asyncGetChartKPI(null, value.type === 'cohort' ? value.id : null, value.type === 'startup' ? value.id : null, null, this.props.year)
    this.props.asyncGetYearsStatisticsKPI && this.props.asyncGetYearsStatisticsKPI(null, value.type === 'cohort' ? value.id : null, value.type === 'startup' ? value.id : null)
  }

  render () {
    return (
      <Select
        className="selectCohort-component form-field-name"
        name="form-field-name"
        value={this.state.value}
        onChange={::this.updateValue}
        placeholder={I18n.t('manageFunds.selectFunds')}
        options={this.state.options}
        searchable={false}
        clearable={false}/>
    )
  }
}

function mapStateToProps ({cohorts, startups, app}) { return {cohorts: cohorts.data, startups: startups.startupsAll, activeFund: app.activeFund} }
export default connect(mapStateToProps, {asyncGetStartUpAll, actionSetActiveFund})(SelectCohort)
