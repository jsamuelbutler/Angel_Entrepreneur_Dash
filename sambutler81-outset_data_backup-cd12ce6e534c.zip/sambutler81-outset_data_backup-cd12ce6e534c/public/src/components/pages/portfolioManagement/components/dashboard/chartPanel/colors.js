let index = 0
const list = [
  '#8bc34a',
  '#673ab7',
  '#cddc39',
  '#3f51b5',
  '#ffeb3b',
  '#2196f3',
  '#ffc107',
  '#9c27b0',
  '#ff9800',
  '#ff5722',
  '#795548',
  '#B71C1C',
  '#880E4F',
  '#4A148C',
  '#f44336',
  '#311B92',
  '#e91e63',
  '#1A237E',
  '#4caf50',
  '#01579B',
  '#E65100',
  '#006064',
  '#BF360C',
  '#009688',
  '#004D40',
  '#00bcd4',
  '#1B5E20',
  '#607d8b',
  '#33691E',
  '#03a9f4',
  '#827717',
  '#F57F17'
]
export default function* () {
  while (true) {
    yield list[index]
    index === list.length - 1 ? index = 0 : index++
  }
}
