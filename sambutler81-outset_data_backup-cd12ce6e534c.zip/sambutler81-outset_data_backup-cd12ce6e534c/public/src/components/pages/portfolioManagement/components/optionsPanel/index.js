import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import { asyncGetChartKPI, asyncGetPortfolioStatistic, asyncGetStartUpPortfolioStatistic, asyncGetYearsStatisticsKPI, asyncGetYearsKPI } from '../../../../../actions'
import { Row, Col, Grid, Panel, PanelBody, PanelContainer, Icon, Button, Form } from '@sketchpixy/rubix'
import NewKPIModal from '../../dialogs/assignNewKPI/'
import SelectCohort from '../selectCohortKPI/'
import { history } from '../../../../../store'
import PropTypes from 'prop-types'
import TemplateInput from '../../../../common/templateInput'
import { ValidatorTrue } from '../../../../../utils/validators'

class OptionsPanel extends Component {
  onChangeCohortStartup (type, data) { type === 'cohort' ? this.props.fnChangeStartupCohort(null, data) : this.props.fnChangeStartupCohort(data, null) }
  launchNewKPIModal () { this.refs.newKPIModal.getWrappedInstance().open() }
  render () {
    this.months = [
      {value: 0, label: 'January', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 0},
      {value: 1, label: 'February', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 1},
      {value: 2, label: 'March', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 2},
      {value: 3, label: 'April', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 3},
      {value: 4, label: 'May', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 4},
      {value: 5, label: 'June', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 5},
      {value: 6, label: 'July', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 6},
      {value: 7, label: 'August', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 7},
      {value: 8, label: 'September', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 8},
      {value: 9, label: 'October', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 9},
      {value: 10, label: 'November', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 10},
      {value: 11, label: 'December', disabled: this.props.year === new Date().getFullYear() && new Date().getMonth() <= 11}
    ]
    this.years = Array.apply(null, {length: 20}).map((item, index) => { return {value: new Date().getFullYear() - index, label: `${new Date().getFullYear() - index}`} })

    const COMPANY_PANEL = (
      <PanelContainer className="optionsPanel-component" noOverflow>
        <Panel>
          <PanelBody className="panel-body-portf">
            <Grid>
              <Row>
                <Col xs={3} className="company-dashboard-header first-btn">
                  {this.props.app.user.allow_connect ? <Button className="common-default-close-button left" onClick={() => history.push('/data')}>{I18n.t('portfolioManagement.connect')}</Button> : null}
                </Col>
                <Col sm={3} className="date-select">
                  <TemplateInput
                    type="select"
                    group="main"
                    name="year"
                    className="input-form"
                    placeholder={'Year'}
                    value={this.props.year}
                    options={this.years}
                    onChange={::this.props.fnChange}
                    fnValidator={ValidatorTrue}/>
                </Col>
                <Col sm={3}/>
                <Col sm={3} className="company-dashboard-header">
                  <Button className="common-default-button right" onClick={::this.launchNewKPIModal}>
                    <Icon glyph="fa fa-plus"/>
                    {I18n.t('portfolioManagement.assignKPIButton')}
                  </Button>
                </Col>
              </Row>
              <NewKPIModal year={this.props.year} scrollBottom={this.props.scrollBottom} cohort={this.props.cohort} startup={this.props.startup} ref="newKPIModal"/>
            </Grid>
          </PanelBody>
        </Panel>
        {this.props.app.user.role !== 'employee' ? <NewKPIModal year={this.props.year} scrollBottom={this.props.scrollBottom} cohort={this.props.cohort} startup={this.props.startup} ref="newKPIModal"/> : null}
      </PanelContainer>
    )
    const ADD_BUTTON_A = (
      <Button className="common-default-button new-kpi-button right button-portf-margin" onClick={::this.launchNewKPIModal}>
        <Icon glyph="fa fa-plus"/>
        {I18n.t('portfolioManagement.assignKPIButton')}
      </Button>
    )
    const ACCELERATOR_PANEL = (
      <PanelContainer className="optionsPanel-component" noOverflow>
        <Panel>
          <PanelBody className="panel-body-portf">
            <Grid>
              <Row className="portfolio-flex-box">
                <Col sm={3}>
                  <Form>
                    <SelectCohort changeSelect={::this.props.changeSelect} year={this.props.year} onChangeCohortStartup={::this.onChangeCohortStartup} withCompany={this.props.withCompany} asyncGetChartKPI={::this.props.asyncGetChartKPI} asyncGetYearsKPI={::this.props.asyncGetYearsKPI} asyncGetYearsStatisticsKPI={::this.props.asyncGetYearsStatisticsKPI} asyncGetPortfolioStatistic={::this.props.asyncGetPortfolioStatistic} asyncGetStartUpPortfolioStatistic={::this.props.asyncGetStartUpPortfolioStatistic}/>
                  </Form>
                </Col>
                <Col sm={3} className="date-select">
                  <TemplateInput
                    type="select"
                    group="main"
                    name="year"
                    className="input-form"
                    placeholder={'Year'}
                    value={this.props.year}
                    options={this.years}
                    onChange={::this.props.fnChange}
                    fnValidator={ValidatorTrue}/>
                </Col>
                <Col sm={3}/>
                <Col sm={3}>
                  {this.props.app.user.role !== 'employee' ? ADD_BUTTON_A : null}
                </Col>
              </Row>
            </Grid>
          </PanelBody>
        </Panel>
        {this.props.app.user.role !== 'employee' ? <NewKPIModal year={this.props.year} scrollBottom={this.props.scrollBottom} cohort={this.props.cohort} startup={this.props.startup} ref="newKPIModal"/> : null}
      </PanelContainer>
    )
    return (
      <div>{!this.props.app.user.accelerator ? (this.props.app.user.role !== 'employee' ? COMPANY_PANEL : null) : ACCELERATOR_PANEL}</div>
    )
  }
}

OptionsPanel.propTypes = {
  asyncGetChartKPI: PropTypes.func.isRequired,
  asyncGetYearsStatisticsKPI: PropTypes.func.isRequired,
  asyncGetPortfolioStatistic: PropTypes.func.isRequired
}
function mapStateToProps ({app}) { return {app} }
export default connect(mapStateToProps, {asyncGetChartKPI, asyncGetStartUpPortfolioStatistic, asyncGetPortfolioStatistic, asyncGetYearsStatisticsKPI, asyncGetYearsKPI})(OptionsPanel)
