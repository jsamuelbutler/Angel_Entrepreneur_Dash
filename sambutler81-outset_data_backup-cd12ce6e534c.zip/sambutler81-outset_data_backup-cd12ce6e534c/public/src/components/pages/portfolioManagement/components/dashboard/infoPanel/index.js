import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Panel, PanelBody, PanelHeader, PanelFooter, PanelContainer, Icon } from '@sketchpixy/rubix'
import PropTypes from 'prop-types'
import {I18n} from 'react-redux-i18n'
import MessagesBox from '../../../../../dialogs/messageBox/'
import ViewKPIModal from '../../../dialogs/viewKPI/'
import { asyncDeleteKPI } from '../../../../../../actions'
import colors from '../chartPanel/colors'
const colorGen = colors()

class InfoPanel extends Component {
  constructor (props) {
    super(props)
    this.state = {chartSelected: false}
  }
  launchViewKPIModal () {
    this.props.callback && this.props.callback(this.props.chart.id, this.state.chartSelected)
    !this.props.showMode
      ? this.refs.viewKPIModal.getWrappedInstance().open(this.props.chart)
      : this.props.callback ? this.setState({chartSelected: !this.state.chartSelected}) : null
  }
  fnRemoveCharts () { this.refs.messagesBox.getWrappedInstance().init(I18n.t('portfolioManagement.infoPanel.remove'), I18n.t('portfolioManagement.infoPanel.remove')).then(() => { this.props.asyncDeleteKPI(null, this.props.chart.id, this.props.cohort, this.props.startup, this.props.year) }) }
  render () {
    const CONTENT = (
      <div>
        <PanelBody className="info-panel" onClick={::this.launchViewKPIModal}>
          <span style={{color: colorGen.next().value}}>{this.props.chart.data.current}</span>
        </PanelBody>
        <PanelFooter>
          <Row>
            <Col xs={12}>
              <p className={this.props.chart.diffs.month.percent >= 0 ? 'up-arrow' : 'down-arrow'}><Icon glyph={this.props.chart.diffs.month.percent >= 0 ? 'fa fa-long-arrow-up' : 'fa fa-long-arrow-down'}/>{Math.abs(this.props.chart.diffs.month.percent)}%</p>
            </Col>
            <Col xs={12}>
              <p className="description">Since last month</p>
            </Col>
          </Row>
        </PanelFooter>
      </div>
    )
    const NO_DATA = (
      <div>
        <PanelBody className="empty-panel" onClick={::this.launchViewKPIModal}>
          <div className="empty-chart">{I18n.t('viewKPI.dataInsufficiently')}</div>
        </PanelBody>
      </div>
    )
    return (
      <PanelContainer className={`infoPanel-component ${this.state.chartSelected ? 'selected' : ''}`}>
        <Panel className="chart-panel">
          <PanelHeader>
            <Col xs={12}>
              <span title={this.props.chart.data.name}>{this.props.chart.data.name}</span>
            </Col>
            {!this.props.chart.is_default ? <Icon title={I18n.t('portfolioManagement.infoPanel.remove')} className="buttons delete-button" onClick={::this.fnRemoveCharts} glyph="fa fa-times"/> : ''}
          </PanelHeader>
          {this.props.chart.data.current ? CONTENT : NO_DATA}
        </Panel>
        <ViewKPIModal year={this.state.year} params={this.props.chart.manual.length ? [{label: this.props.chart.manual[0].name, value: this.props.chart.manual[0].id}] : []} color1={colorGen.next().value} lastEdited={this.props.chart.last_edited} listParams={[{id: this.props.chart.data.id, current: this.props.chart.data.current, name: this.props.chart.name}]} cohort={this.props.cohort} startup={this.props.startup} chart={this.props.chart} ref="viewKPIModal"/>
        <MessagesBox ref="messagesBox"/>
      </PanelContainer>
    )
  }
}

InfoPanel.propTypes = {
  chart: PropTypes.shape({
    id: PropTypes.number.isRequired,
    data: PropTypes.object.isRequired,
    is_default: PropTypes.bool.isRequired,
    diff_period: PropTypes.string,
    diffs: PropTypes.isRequired
  }),
  asyncDeleteKPI: PropTypes.func.isRequired
}
export default connect(null, { asyncDeleteKPI })(InfoPanel)
