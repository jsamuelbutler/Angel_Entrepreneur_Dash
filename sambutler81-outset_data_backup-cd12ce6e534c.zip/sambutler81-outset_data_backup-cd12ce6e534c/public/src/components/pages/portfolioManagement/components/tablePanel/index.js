import './style'
import React, {Component} from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import { Table, DropdownButton, MenuItem } from '@sketchpixy/rubix'
import { Scrollbars } from 'react-custom-scrollbars'
import PropTypes from 'prop-types'

class TablePanel extends Component {

  constructor (props) {
    super(props)
    this.state = { currentYear: this.props.yearIdx }
  }

  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) { this.initComponent(props) }

  initComponent (props) { props.KPI.years && this.setState({currentYear: !props.yearIdx ? props.KPI.years[0] : props.yearIdx}) }

  getCurrentYear (data, year) { return data.filter(item => { return item.year === year }) }
  getCurrentMonth (data, month) { return data.filter(item => { return item.month === month }) }
  getCurrentName (data, name) { const content = data.filter(item => { return item.name === name }); return content.length > 0 ? content : [{value: ''}] }
  getConvertMonth (month) {
    switch (month) {
      case 1: return 'January'
      case 2: return 'February'
      case 3: return 'March'
      case 4: return 'April'
      case 5: return 'May'
      case 6: return 'June'
      case 7: return 'July'
      case 8: return 'August'
      case 9: return 'September'
      case 10: return 'October'
      case 11: return 'November'
      case 12: return 'December'
    }
  }
  render () {
    let data = []
    let forecast = false
    if (this.props.KPI.yearsStatistics && this.state.currentYear) {
      let currentYear = this.getCurrentYear(this.props.KPI.yearsStatistics, this.state.currentYear)
      data = []
      for (let i = 1; i <= 12; i++) {
        let currentMonth = this.getCurrentMonth(currentYear, `${i}`)
        this.getCurrentMonth(currentYear, `${i}`).map(item => {
          if (item.name === 'Forecast') {
            forecast = true
          }
        })

        data.push({
          month: this.getConvertMonth(i),
          cashIn: this.getCurrentName(currentMonth, 'Cash In')[0].value,
          cashOut: this.getCurrentName(currentMonth, 'Cash Out')[0].value,
          netBurn: this.getCurrentName(currentMonth, 'Net Burn')[0].value,
          revenue: this.getCurrentName(currentMonth, 'Revenue')[0].value,
          forecast: this.getCurrentName(currentMonth, 'Forecast')[0].value,
          cashOnHand: this.getCurrentName(currentMonth, 'Cash on Hand')[0].value,
          daysToLive: this.getCurrentName(currentMonth, 'Days to Live')[0].value
        })
      }
    } else {

    }
    const ROWS = data.map((obj, index) => {
      return (
        <tr key={index}>
          <td>{obj.month}</td>
          <td>{obj.cashIn || '-'}</td>
          <td>{obj.cashOut || '-'}</td>
          <td>{obj.netBurn || '-'}</td>
          <td>{obj.cashOnHand || '-'}</td>
          <td>{obj.daysToLive || '-'}</td>
          <td>{obj.revenue || '-'}</td>
          {forecast ? <td>{obj.forecast || '-'}</td> : null}
        </tr>
      )
    }) || null
    const YEARS = this.props.KPI.years && this.props.KPI.years && this.props.KPI.years.map((year, index) => { return (<MenuItem key={index} eventKey={year}>{year}</MenuItem>) })
    return (
      <div className="table-content table-content-small">
        <div className="table-responsive">
          <Scrollbars
            autoHide
            autoHideTimeout={700}
            renderTrackVertical={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
            renderThumbVertical={props => <div {...props} className="thumb-horizontal" style={{display: 'none'}}/>}
            ref="scrollbars">
            <Table striped condensed hover>
              <thead className="table-statistic-header">
                <tr>
                  <th>
                    <DropdownButton id="drop-down-table" className="drop-down-table" bsStyle="link" value={this.state.currentYear} title={`${this.state.currentYear}`} onSelect={this.props.fnSelectYear}>
                      {YEARS}
                    </DropdownButton>
                  </th>
                  <th title={I18n.t('portfolioManagement.cashIn')}>{I18n.t('portfolioManagement.cashIn')}</th>
                  <th title={I18n.t('portfolioManagement.cashOut')}>{I18n.t('portfolioManagement.cashOut')}</th>
                  <th title={I18n.t('portfolioManagement.netBurn')}>{I18n.t('portfolioManagement.netBurn')}</th>
                  <th title={I18n.t('portfolioManagement.cashOnHand')}>{I18n.t('portfolioManagement.cashOnHand')}</th>
                  <th title={I18n.t('portfolioManagement.daysToLive')}>{I18n.t('portfolioManagement.daysToLive')}</th>
                  <th title={I18n.t('portfolioManagement.revenue')}>{I18n.t('portfolioManagement.revenue')}</th>
                  {forecast && <th title={I18n.t('portfolioManagement.forecast')}>{I18n.t('portfolioManagement.forecast')}</th>}
                </tr>
              </thead>
              <tbody className="scrollContent scrollContent-small">
                {ROWS}
              </tbody>
            </Table>
          </Scrollbars>
        </div>
      </div>
    )
  }
}
TablePanel.propTypes = {
  KPI: PropTypes.shape({
    yearsStatistics: PropTypes.array.isRequired
  }),
  years: PropTypes.shape({
    years: PropTypes.array.isRequired
  }),
  fnSelectYear: PropTypes.func.isRequired
}
function mapStateToProps ({KPI, app}) { return {KPI, app} }
export default connect(mapStateToProps)(TablePanel)
