import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import Highcharts from 'react-highcharts'
import HighchartsMore from 'highcharts-more'
HighchartsMore(Highcharts.Highcharts)
import { Col, Panel, PanelBody, PanelHeader, PanelContainer, Icon, Row, OverlayTrigger, Popover } from '@sketchpixy/rubix'
import ViewKPIModal from '../../../dialogs/viewKPI/'
import { getChartsConf } from '../../../dialogs/assignNewKPI/data/charts'
import Select from 'react-select-plus'
import { asyncDeleteKPI } from '../../../../../../actions'
import MessagesBox from '../../../../../dialogs/messageBox/'
import {I18n} from 'react-redux-i18n'
import PropTypes from 'prop-types'
import colors from './colors'
const colorGen = colors()

class ChartTemplatesPanel extends Component {

  constructor (props) {
    super(props)
    this.state = {
      selector1: this.props.chart.selects.length >= 1 ? this.props.chart.selects[0][0] : null,
      selectorsList1: this.props.chart.selects.length >= 1 ? this.props.chart.selects[0] : [],
      selector2: this.props.chart.selects.length >= 2 ? this.props.chart.selects[1][0] : null,
      selectorsList2: this.props.chart.selects.length >= 2 ? this.props.chart.selects[1] : [],
      chartSelected: false
    }
    this.listParams = []
  }

  componentWillReceiveProps (newProps) {
    if (this.props.chart !== newProps.chart) {
      this.setState({
        selector1: newProps.chart.selects.length >= 1 ? newProps.chart.selects[0][0] : null,
        selectorsList1: newProps.chart.selects.length >= 1 ? newProps.chart.selects[0] : [],
        selector2: newProps.chart.selects.length >= 2 ? newProps.chart.selects[1][0] : null,
        selectorsList2: newProps.chart.selects.length >= 2 ? newProps.chart.selects[1] : []
      })
    }
  }

  getParam (data) {
    return data.map(item => {
      return {
        label: item.name,
        value: item.id
      }
    })
  }

  fnChange (e, select) { this.setState({[select]: e.value}) }
  launchViewKPIModal () {
    this.props.callback && this.props.callback(this.props.chart.id, this.state.chartSelected)
    !this.props.showMode
      ? this.refs.viewKPIModal.getWrappedInstance().open(this.props.chart, this.state.selector1, this.state.selector2, this.state.selectorsList1, this.state.selectorsList2)
      : this.props.callback ? this.setState({chartSelected: !this.state.chartSelected}) : null
  }
  fnRemoveCharts () { this.refs.messagesBox.getWrappedInstance().init(I18n.t('portfolioManagement.chartPanel.remove'), I18n.t('portfolioManagement.chartPanel.sure')).then(() => { this.props.asyncDeleteKPI(null, this.props.chart.id, this.props.cohort, this.props.startup, this.props.year) }).catch(() => {}) }
  getConfigurationPanel (SCOPE, COMMON, type, chart) {
    let status = Array.isArray(SCOPE) && SCOPE.length
    let objectName1 = status ? (type ? (SCOPE && SCOPE.length ? (SCOPE[0].object_name ? SCOPE[0].object_name : null) : null) : (SCOPE[0].object_name ? SCOPE[0].object_name : null)) : null
    let objectType1 = status ? (type ? (SCOPE && SCOPE.length ? (SCOPE[0].object_type ? SCOPE[0].object_type : null) : null) : (SCOPE[0].object_type ? SCOPE[0].object_type : null)) : null
    let objectNameMsg1 = status ? (objectName1 && objectType1 ? (objectType1 === 'cohort' ? `Fund - ${objectName1}` : (objectType1 === 'startup' ? `Company - ${objectName1}` : '')) : '') : null
    let objectName2 = status ? (type ? (SCOPE && SCOPE.length ? (SCOPE[1].object_name ? SCOPE[1].object_name : null) : null) : null) : null
    let objectType2 = status ? (type ? (SCOPE && SCOPE.length ? (SCOPE[1].object_type ? SCOPE[1].object_type : null) : null) : null) : null
    let objectNameMsg2 = status ? (objectName2 && objectType2 ? (objectType2 === 'cohort' ? `Fund - ${objectName2}` : (objectType2 === 'startup' ? `Company - ${objectName2}` : '')) : '') : null
    this.listParams.push(SCOPE[0])
    type && this.listParams.push(SCOPE[1])
    // get params
    const params = this.getParam(this.props.chart.manual)
    return {
      ...COMMON,
      data1: status ? type ? SCOPE[0].data : SCOPE[0].data : [],
      data2: status ? type ? SCOPE[1].data : null : [],
      labels: status ? type ? SCOPE[0].axis : SCOPE[0].axis : [],
      name1: status ? type ? SCOPE[0].name : SCOPE[0].name : chart.name,
      name2: status ? type ? SCOPE[1].name : null : null,
      current1: status ? type ? SCOPE[0].current : SCOPE[0].current : null,
      current2: status ? type ? SCOPE[1].current : null : null,
      object_name1: status ? !type ? objectNameMsg1 : null : null,
      object_name2: status ? !type ? objectNameMsg2 : null : null,
      compare: type,
      color1: colorGen.next().value,
      color2: colorGen.next().value,
      params
    }
  }

  render () {
    const COMMON = {
      diffPeriod: 'Since last month',
      chartType: this.props.chart.chart_type,
      diff: this.props.chart.diffs.month.percent,
      showLabels: false
    }
    let contentData = null
    this.listParams = []
    if (this.props.chart.chart_type !== 'scatter') {
      if (this.props.chart.chart_type === 'stack_and_line') {
        let scope = this.props.chart.data.series
        scope.map(item => this.listParams.push({...item}))
        let line = scope.length > 0 && scope.splice(0, 1)[0]
        let array = [...scope]
        let status = true
        array.map(item => {
          let objectName = item.object_name ? item.object_name : null
          let objectType = item.object_type ? item.object_type : null
          let objectNameMsg = objectName && objectType ? (objectType === 'cohort' ? `Fund - ${objectName}` : (objectType === 'startup' ? `Company - ${objectName}` : '')) : ''

          status = item.data.length !== 0
          item['type'] = 'column'
          item['color'] = colorGen.next().value
          item['showInLegend'] = false
          item['name'] = `${item.name} | ${objectNameMsg}`
          delete item.axis
          delete item.sum_data
          delete item.current
        })
        let objectName = line.object_name ? line.object_name : null
        let objectType = line.object_type ? line.object_type : null
        let objectNameMsg = objectName && objectType ? (objectType === 'cohort' ? `Fund - ${objectName}` : (objectType === 'startup' ? `Company - ${objectName}` : '')) : ''
        // get params
        const params = this.getParam(this.props.chart.manual)
        contentData = {
          ...COMMON,
          data1: status ? array : [],
          data2: line.data || [],
          labels: null,
          name1: this.props.chart.name,
          name2: line.name,
          current1: null,
          current2: null,
          compare: false,
          object_name1: '',
          object_name2: objectNameMsg,
          color1: colorGen.next().value,
          color2: colorGen.next().value,
          params
        }
      } else {
        if (this.state.selector1 && this.state.selector2) {
          const SCOPE = this.props.chart.data[this.state.selector1][this.state.selector2]
          if (Array.isArray(this.props.chart.data[this.state.selector1][this.state.selector2]) && this.props.chart.data[this.state.selector1][this.state.selector2].length > 1) {
            contentData = this.getConfigurationPanel(SCOPE, COMMON, true, this.props.chart)
          } else { contentData = this.getConfigurationPanel(SCOPE, COMMON, false, this.props.chart) }
        } else if (this.state.selector1 || this.state.selector2) {
          if (this.state.selector1 && !this.state.selector2) {
            const SCOPE = this.props.chart.data[this.state.selector1]
            if (Array.isArray(this.props.chart.data[this.state.selector1]) && this.props.chart.data[this.state.selector1].length > 1) {
              contentData = this.getConfigurationPanel(SCOPE, COMMON, true, this.props.chart)
            } else { contentData = this.getConfigurationPanel(SCOPE, COMMON, false, this.props.chart) }
          } else if (!this.state.selector1 && this.state.selector2) {
            const SCOPE = this.props.chart.data[this.state.selector2]
            if (Array.isArray(this.props.chart.data[this.state.selector2]) && this.props.chart.data[this.state.selector2].length > 1) {
              contentData = this.getConfigurationPanel(SCOPE, COMMON, true, this.props.chart)
            } else { contentData = this.getConfigurationPanel(SCOPE, COMMON, false, this.props.chart) }
          }
        } else if (!this.state.selector1 && !this.state.selector2) {
          const SCOPE = this.props.chart.data.series
          if (this.props.chart.data.series && this.props.chart.data.series.length === 2) {
            contentData = this.getConfigurationPanel(SCOPE, COMMON, true, this.props.chart)
          } else {
            let status = Array.isArray(SCOPE) && SCOPE.length
            let objectName1 = status && SCOPE[0].object_name ? SCOPE[0].object_name : null
            let objectType1 = status && SCOPE[0].object_type ? SCOPE[0].object_type : null
            let objectNameMsg1 = status && objectName1 && objectType1 ? (objectType1 === 'cohort' ? `Fund - ${objectName1}` : (objectType1 === 'startup' ? `Company - ${objectName1}` : '')) : ''
            SCOPE && SCOPE.length && this.listParams.push(SCOPE[0])
            // get params
            const params = this.getParam(this.props.chart.manual)
            contentData = {
              ...COMMON,
              data1: status ? SCOPE[0].data : [],
              data2: null,
              labels: status ? SCOPE[0].axis : [],
              name1: status ? SCOPE[0].name : this.props.chart.name,
              name2: null,
              current1: status ? SCOPE[0].current : null,
              current2: null,
              object_name1: status ? objectNameMsg1 : null,
              object_name2: status ? '' : null,
              compare: false,
              color1: colorGen.next().value,
              color2: colorGen.next().value,
              params
            }
          }
        }
      }
    } else {
      let color = colorGen.next().value
      const SCOPE = this.props.chart.data
      let data = SCOPE.map(item => {
        return {
          data: [item.data],
          name: `${item.name}`,
          showInLegend: false,
          color: color
        }
      })
      this.listParams.push(SCOPE)
      // get params
      const params = this.getParam(this.props.chart.manual)
      contentData = {
        ...COMMON,
        data1: data || [],
        data2: null,
        labels: null,
        name1: this.props.chart.name,
        name2: null,
        current1: null,
        current2: null,
        compare: false,
        object_name1: null,
        object_name2: null,
        color1: color,
        color2: null,
        params
      }
    }
    let body = null
    let percent = null
    if (contentData && contentData.data1 && contentData.data1.length !== 0 || contentData && contentData.data2 && contentData.data2.length !== 0) {
      percent = (<Col xs={4} className="col-portf-float">
        <Row>
          <Col xs={12}>
            <div className={`arrow-portfolio ${contentData.diff > 0 ? 'up-arrow' : 'down-arrow'}`}><Icon glyph={contentData.diff > 0 ? 'fa fa-long-arrow-up' : 'fa fa-long-arrow-down'}/><div className="percent">{Math.abs(contentData.diff)}</div>%</div>
          </Col>
        </Row>
        <Row>
          <Col xs={12}>
            <div className="description">{contentData.diffPeriod}</div>
          </Col>
        </Row>
      </Col>)
      body = (
        <PanelBody onClick={::this.launchViewKPIModal}>
          <Highcharts config={getChartsConf(contentData.chartType, contentData.compare, contentData.labels, contentData.data1, contentData.data2, contentData.showLabels, 136, contentData.name1, contentData.name2, contentData.color1, contentData.color2, contentData.object_name1, contentData.object_name2)} />
        </PanelBody>
      )
    } else {
      body = (
        <PanelBody onClick={::this.launchViewKPIModal} className="empty-panel">
          <div className="empty-chart">{I18n.t('viewKPI.dataInsufficiently')}</div>
        </PanelBody>
      )
    }
    const CONFIG = this.props.chart.selects ? this.props.chart.selects.map((item, index) => {
      const OPTIONS = this.state[`selectorsList${index + 1}`] && this.state[`selectorsList${index + 1}`].map(option => { return {value: option, label: option} })
      return (
        <Row key={index}>
          <Col xs={12}>
            <strong>{I18n.t('portfolioManagement.select')} {index + 1}</strong>
            <Select
              className="config-select"
              name="form-field-name p"
              value={this.state[`selector${index + 1}`]}
              onChange={(e) => { this.fnChange(e, `selector${index + 1}`) }}
              placeholder={I18n.t('manageFunds.selectFunds')}
              options={OPTIONS}
              searchable={false}
              clearable={false}/>
          </Col>
        </Row>
      )
    }) : []
    let popover = this.props.chart.selects && this.props.chart.selects.length > 0 ? (
      <OverlayTrigger rootClose container={this} trigger="click" placement="bottom" overlay={<Popover id="popover-left-1" title="Configuration">{CONFIG}</Popover>}>
        <Icon title="Configuration" className={`buttons ${this.props.chart.is_default ? 'edit-button-single' : 'edit-button'}`} glyph="fa fa-cog"/>
      </OverlayTrigger>
    ) : ''
    let label = <Col xs={6} className="text-right"><span className="portfolio-text-overflow" title={`${contentData.name2} ${contentData.object_name2 ? `| ${contentData.object_name2}` : ''}`}><Icon style={{color: contentData.color2}} className="icon-forecast icon-margin" glyph="fa fa-stop"/>{contentData.name2}</span><div>{contentData.current2}</div></Col>
    return (
      <PanelContainer className={`chartPanel-component ${this.state.chartSelected ? 'selected' : ''}`}>
        <Panel className="chart-panel">
          <PanelHeader>
            <Col xs={6}><span className="portfolio-text-overflow" title={`${contentData.name1} ${contentData.object_name1 ? `| ${contentData.object_name1}` : ''}`}>{ this.props.chart.chart_type !== 'stack_and_line' ? <Icon style={{color: contentData.color1}} className="icon-revenue icon-margin" glyph="fa fa-stop"/> : ''}{contentData.name1}</span><p>{contentData.current1}</p></Col>
            { this.props.chart.chart_type !== 'stack_and_line' && this.props.chart.chart_type !== 'scatter' ? contentData.name2 ? label : percent : null }
            { popover }
            { this.props.app.user.role !== 'employee' && !this.props.chart.is_default ? <Icon title={I18n.t('portfolioManagement.chartPanel.remove')} className="buttons delete-button" onClick={::this.fnRemoveCharts} glyph="fa fa-times"/> : ''}
          </PanelHeader>
          {body}
        </Panel>
        <ViewKPIModal year={this.state.year} params={contentData.params} color1={contentData.color1} color2={contentData.color2} lastEdited={this.props.chart.last_edited} listParams={this.listParams} cohort={this.props.cohort} startup={this.props.startup} contentData={contentData} chart={this.props.chart} fnChange={::this.fnChange} selector1={this.state.selector1} selectorsList1={this.state.selectorsList1} selector2={this.state.selector2} selectorsList2={this.state.selectorsList2} config={getChartsConf(contentData.chartType, contentData.compare, contentData.labels, contentData.data1, contentData.data2, true, 350, contentData.name1, contentData.name2, contentData.color1, contentData.color2)} ref="viewKPIModal"/>
        <MessagesBox ref="messagesBox"/>
      </PanelContainer>
    )
  }
}

ChartTemplatesPanel.propTypes = {
  chart: PropTypes.shape({
    selects: PropTypes.array,
    id: PropTypes.number.isRequired,
    is_default: PropTypes.bool.isRequired,
    diff_period: PropTypes.number,
    diffs: PropTypes.shape({
      month: PropTypes.shape({
        percent: PropTypes.number
      })
    }),
    data: PropTypes.oneOfType([
      PropTypes.array,
      PropTypes.object
    ])
  }),
  chart_type: PropTypes.string,
  asyncDeleteKPI: PropTypes.func.isRequired
}
function mapStateToProps ({app}) { return {app} }
export default connect(mapStateToProps, {asyncDeleteKPI})(ChartTemplatesPanel)
