import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Grid } from '@sketchpixy/rubix'
import { asyncGetCohortAll, asyncGetDefinedKPI, asyncGetStartUpPortfolioStatistic, asyncGetChartKPI, asyncGetYearsStatisticsKPI, asyncGetYearsKPI, asyncGetStartUp, asyncGetStartUpAll } from '../../../actions'
import OptionsPanel from './components/optionsPanel/'
import TablePanel from './components/tablePanel/'
import ChartTemplatesPanel from './components/dashboard/chartPanel/'
import InfoPanel from './components/dashboard/infoPanel/'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import moment from 'moment'
import { ValidatorError } from '../../common/templateInput'

class PortfolioManagement extends Component {

  constructor (props) {
    super(props)
    const date = new Date()
    let resultDate = new Date(date.getFullYear(), date.getMonth(), 1)
    resultDate = new Date(moment(resultDate).subtract(1, 'days'))
    this.state = {
      yearIdx: null,
      cohort: null,
      mainErrors: [],
      startup: this.props.app.user ? this.props.app.user.startup : null,
      month: +resultDate.getMonth(),
      year: +resultDate.getFullYear(),
      type: 'cohort',
      select: null
    }
  }

  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) { this.props.app.user.startup !== props.app.user.startup && this.initComponent(props) }

  initComponent (props) {
    if (props.app.user && props.app.user.startup) {
      if (props.app.user.startup) {
        props.asyncGetStartUp('required', props.app.user.startup)
        props.asyncGetStartUpAll(null)
      } else {
        props.asyncGetStartUpAll('required', null, props.app.user.startup, '-todo_count, name')
        props.asyncGetStartUpAll('required', props.cohorts.data[0].id, props.app.user.startup, '-todo_count, name')
      }
      props.asyncGetDefinedKPI(null)
      props.asyncGetChartKPI(null, null, props.app.user.startup, null, this.state.year)
      props.asyncGetYearsKPI(null, null, props.app.user.startup)
      props.asyncGetYearsStatisticsKPI(null, null, props.app.user.startup)
    }
  }
  fnChangeStartupCohort (startup, cohort) { this.setState({startup, cohort}) }
  fnSelectYear (eventKey) { this.setState({yearIdx: eventKey}) }
  format (n, item) {
    const REG_EX = n.toString().replace(/(\d)(?=(\d{3})+(\.\d+)?$)/g, '$1,')
    return item.toUpperCase() === 'AVERAGE OWNERSHIP' ? `${REG_EX}%` : `$ ${REG_EX}`
  }
  changeSelect (type, select) {
    this.setState({type, select})
  }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}, () => { this.props.asyncGetChartKPI(null, null, this.props.app.user.startup, null, this.state.year) }) }
  render () {
    let content = (
      <div className="portfolioManagement-component empty">
        <div className="common-container-img">
          <div className="common-portfolio-pet adaptive-mascot"/>
          <h3 className="common-data-options-header">{I18n.t('portfolioManagement.dataEmpty.header')}</h3>
          <div>
            <div>
              <div className="common-box-data">
                <div className="common-question-data-options">{I18n.t('portfolioManagement.dataEmpty.noCompanies')}</div>
                <div className="common-question-data-options">{I18n.t('portfolioManagement.dataEmpty.showCompanies')}</div>
              </div>
            </div>
            <div/>
          </div>
        </div>
      </div>
    )
    if (this.props.KPI.list && this.props.KPI.years && this.props.KPI.yearsStatistics && this.props.KPI.defined) {
      if (this.props.KPI.list.length !== 0 && this.props.KPI.defined.length !== 0) {
        const KPI_PANELS = this.props.KPI.list.map((chart, index) => {
          if (!chart || !chart.data) { return '' }
          switch (chart.chart_type) {
            case 'line': break
            case 'area': break
            case 'stack': break
            case 'bar': break
            case 'column': break
            case 'number': break
            case 'scatter': break
            case 'bubble': break
            case 'bar_and_line': break
            case 'column_and_line': break
            case 'stack_and_line': break
            default: return ''
          }
          if (chart.selects > 0) {
            return ''
          } else {
            if (chart.chart_type !== 'number') {
              return (<Col className="chart-panel-wrap common-half-padding-child" sm={12} md={6} lg={4} key={index}><ChartTemplatesPanel cohort={this.state.cohort} startup={this.state.startup} chart={chart} year={this.state.year}/></Col>)
            } else {
              return (<Col className="chart-panel-wrap common-half-padding-child" sm={12} md={6} lg={4} key={index}><InfoPanel cohort={this.state.cohort} startup={this.state.startup} chart={chart} year={this.state.year}/></Col>)
            }
          }
        })
        content = (
          <div className="common-wrap-half-padding">
            <Grid className="portfolioManagement-component common-page-component">
              <Row>
                <Col xs={12} className="company-wrap-option-panel common-half-padding-child common-half-padding-child-button">
                  <OptionsPanel changeSelect={::this.changeSelect} year={this.state.year} fnChange={::this.fnChange} scrollBottom={this.props.scrollBottom} cohort={this.state.cohort} startup={this.state.startup} fnChangeStartupCohort={::this.fnChangeStartupCohort} withCompany/>
                </Col>
              </Row>
              <Row>
                <Col xs={12} className="common-half-padding-child">
                  {this.props.KPI.years.length !== 0 && this.props.KPI.yearsStatistics.length !== 0 ? <TablePanel yearIdx={this.state.yearIdx} fnSelectYear={::this.fnSelectYear}/> : null}
                </Col>
              </Row>
              <Row>
                {KPI_PANELS}
              </Row>
            </Grid>
          </div>
        )
      }
    }
    return content
  }
}

PortfolioManagement.propTypes = {
  KPI: PropTypes.shape({
    list: PropTypes.array,
    statistic: PropTypes.array
  }),
  asyncGetCohortAll: PropTypes.func.isRequired,
  asyncGetDefinedKPI: PropTypes.func.isRequired,
  asyncGetChartKPI: PropTypes.func.isRequired,
  asyncGetYearsKPI: PropTypes.func.isRequired,
  asyncGetYearsStatisticsKPI: PropTypes.func.isRequired,
  asyncGetStartUpPortfolioStatistic: PropTypes.func.isRequired
}

function mapStateToProps ({app, KPI}) { return {app, KPI} }
export default connect(mapStateToProps, {asyncGetCohortAll, asyncGetDefinedKPI, asyncGetStartUpPortfolioStatistic, asyncGetChartKPI, asyncGetYearsStatisticsKPI, asyncGetYearsKPI, asyncGetStartUp, asyncGetStartUpAll})(PortfolioManagement)
