import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import Charts from '../../data/chartsPreview'
import Highcharts from 'react-highcharts'
import { ButtonGroup, Button } from '@sketchpixy/rubix'
import PropTypes from 'prop-types'

function currentChartContent (type, period, compare = false) {
  switch (type) {
    case 'line': return Charts.line(period, compare)
    case 'bar': return Charts.bar(period, compare)
    case 'column': return Charts.column(period, compare)
    case 'stack': return Charts.stack(period, compare)
    case 'area': return Charts.area(period, compare)
    case 'scatter' : return Charts.scatter(period, compare)
    default: return Charts.line(period, compare)
  }
}
class ChartsPreview extends Component {
  shouldComponentUpdate (props) { return this.props.type !== props.type || this.props.period !== props.period || this.props.compare !== props.compare }
  render () {
    if (this.props.type === 'number' && this.props.compare) { this.props.onType('') }
    return (
      <div className="chartsPreview-component">
        <div>
          <p>{I18n.t('assignKPI.chartType')}</p>
          <ButtonGroup onClick={::this.props.onType}>
            <Button bsStyle="link" data-value="line" className={`group-button ${this.props.type === 'line' && 'active'}`}>{I18n.t('assignKPI.lineButton')}</Button>
            <Button bsStyle="link" data-value="bar" className={`group-button ${this.props.type === 'bar' && 'active'}`}>{I18n.t('assignKPI.barButton')}</Button>
            <Button bsStyle="link" data-value="column" className={`group-button ${this.props.type === 'column' && 'active'}`}>{I18n.t('assignKPI.columnButton')}</Button>
            <Button bsStyle="link" data-value="area" className={`group-button ${this.props.type === 'area' && 'active'}`}>{I18n.t('assignKPI.areaButton')}</Button>
            <Button bsStyle="link" data-value="stack" className={`group-button ${this.props.type === 'stack' && 'active'}`}>{I18n.t('assignKPI.stackButton')}</Button>
            <Button bsStyle="link" data-value="number" className={`group-button ${this.props.type === 'number' && 'active'}`} disabled={!!this.props.compare}>{I18n.t('assignKPI.numberButton')}</Button>
          </ButtonGroup>
        </div>
        <p>Example</p>
        <div className="kpi-charts">
          {this.props.type !== 'number' ? <Highcharts config={currentChartContent(this.props.type, this.props.period, this.props.compare)}/> : ''}
        </div>
      </div>
    )
  }
}
ChartsPreview.propTypes = {
  onType: PropTypes.func.isRequired,
  type: PropTypes.string.isRequired,
  period: PropTypes.string.isRequired
}
export default connect()(ChartsPreview)
