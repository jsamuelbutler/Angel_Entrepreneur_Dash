import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Grid, FormGroup, ControlLabel, ButtonGroup, Button } from '@sketchpixy/rubix'
import Select from 'react-select-plus'
import { I18n } from 'react-redux-i18n'

class DefinedKPI extends Component {

  render () {
    const DEFINED_OPTIONS = []
    const COMPARE_OPTIONS = []
    if (this.props.isCompany) {
      this.props.defined.map(item => {
        if (item.startup && item.startup.id === this.props.startup) {
          DEFINED_OPTIONS.push({value: `s-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'startup', disabled: this.props.compare === `s-${item.id}`})
          COMPARE_OPTIONS.push({value: `s-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'startup', disabled: this.props.kpi === `s-${item.id}`})
        }
      })
    } else {
      const COMPANY_LIST = []
      const DEFINED_OPTIONS_LOCAL = []
      const COMPARE_DEFINED_OPTIONS_LOCAL = []
      let cohortKPI = []
      let compareCohortKPI = []
      let cohortName = ''
      this.props.defined.map(item => {
        if (item.startup && COMPANY_LIST.indexOf(item.startup.id) === -1) { COMPANY_LIST.push(item.startup.id) }
        if (item.cohort && item.cohort.id === this.props.cohort) {
          !cohortName && (cohortName = item.cohort.name)
          cohortKPI.push({value: `c-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'cohort', disabled: this.props.compare === `c-${item.id}`})
          compareCohortKPI.push({value: `c-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'cohort', disabled: this.props.kpi === `c-${item.id}`})
        }
      })
      DEFINED_OPTIONS.push({
        label: 'CURRENT FUND',
        options: [{
          label: `${cohortName}`,
          options: cohortKPI
        }],
        className: 'wrap-options-group'
      })
      COMPARE_OPTIONS.push({
        label: 'CURRENT FUND',
        options: [{
          label: `${cohortName}`,
          options: compareCohortKPI
        }],
        className: 'wrap-options-group'
      })
      COMPANY_LIST.map(company => {
        let companyList = []
        let compareCompanyList = []
        let name = ''
        this.props.defined.map(item => {
          if (item.startup && item.startup.id === company) { !name && (name = item.startup.name); companyList.push({value: `s-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'startup', disabled: this.props.compare === `s-${item.id}`}) }
          if (item.startup && item.startup.id === company) { compareCompanyList.push({value: `s-${item.id}`, label: `${item.base.name}`, id: item.id, type: 'startup', disabled: this.props.kpi === `s-${item.id}`}) }
        })
        DEFINED_OPTIONS_LOCAL.push({
          label: `${name}`,
          options: companyList
        })
        COMPARE_DEFINED_OPTIONS_LOCAL.push({
          label: `${name}`,
          options: companyList
        })
      })
      DEFINED_OPTIONS.push({
        label: 'COMPANIES',
        options: DEFINED_OPTIONS_LOCAL,
        className: 'wrap-options-group'
      })
      COMPARE_OPTIONS.push({
        label: 'COMPANIES',
        options: COMPARE_DEFINED_OPTIONS_LOCAL,
        className: 'wrap-options-group'
      })
      this.props.defined.map(item => { (this.props.app.activeFund && this.props.app.activeFund.id === item.cohort || item.cohort === null) && COMPARE_OPTIONS.push({value: item.id, label: item.base.name, disabled: item.id === this.props.kpi}) })
    }
    return (
      <Grid className="definedKPI-component">
        <Row>
          <Col xs={12} sm={6}>
            <FormGroup>
              <ControlLabel>{I18n.t('assignKPI.KPI')}</ControlLabel>
              <Select
                name="form-field-name"
                value={this.props.kpi}
                onChange={this.props.onKPI}
                placeholder={I18n.t('assignKPI.selectorKPI')}
                options={DEFINED_OPTIONS}
              />
            </FormGroup>
          </Col>
          <Col xs={12} sm={6}>
            <FormGroup>
              <ControlLabel>{I18n.t('assignKPI.compareTo')}</ControlLabel>
              <Select
                name="form-field-name"
                value={this.props.compare}
                onChange={this.props.onCompare}
                placeholder={I18n.t('assignKPI.selectorNone')}
                options={COMPARE_OPTIONS}
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs={12} sm={7}>
            <p>{I18n.t('assignKPI.period')}</p>
            <ButtonGroup onClick={::this.props.onPeriod}>
              <Button bsStyle="link" data-value="weekly" className={`group-button ${this.props.period === 'weekly' && ' active'}`}>{I18n.t('assignKPI.weeklyButton')}</Button>
              <Button bsStyle="link" data-value="monthly" className={`group-button ${this.props.period === 'monthly' && ' active'}`}>{I18n.t('assignKPI.monthlyButton')}</Button>
              <Button bsStyle="link" data-value="quarterly" className={`group-button ${this.props.period === 'quarterly' && ' active'}`}>{I18n.t('assignKPI.quarterlyButton')}</Button>
            </ButtonGroup>
          </Col>
        </Row>
      </Grid>
    )
  }
}
function mapStateToProps ({app}) { return {app} }
export default connect(mapStateToProps, null, null, { withRef: true })(DefinedKPI)
