import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Col, Row, Grid, FormGroup, ControlLabel, ButtonGroup, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import TemplateInput from '../../../../../../common/templateInput/'
import { ValidatorNameKPI } from '../../../../../../../utils/validators'

class CustomKPI extends Component {

  render () {
    return (
      <Grid className="customKPI-component">
        <Row>
          <Col xs={12} sm={7}>
            <p>Is the KPI</p>
            <ButtonGroup>
              <Button onClick={::this.props.onProvider} data-value="%" bsStyle="link" className={`group-button ${this.props.provider === '%' && 'active'}`}>% {I18n.t('assignKPI.basedOnButton')}</Button>
              <Button onClick={::this.props.onProvider} data-value="#" bsStyle="link" className={`group-button ${this.props.provider === '#' && 'active'}`}># {I18n.t('assignKPI.basedOnButton')}</Button>
              <Button onClick={::this.props.onProvider} data-value="$" bsStyle="link" className={`group-button ${this.props.provider === '$' && 'active'}`}>$ {I18n.t('assignKPI.basedOnButton')}</Button>
            </ButtonGroup>
          </Col>
        </Row>
        <Row>
          < Col xs = {12} >
            <FormGroup>
              <ControlLabel>{I18n.t('assignKPI.nameKPI')}</ControlLabel>
              <TemplateInput
                type="text"
                group="custom"
                name="name"
                className="input-form"
                placeholder={'Enter KPI name'}
                value={this.props.name}
                onChange={::this.props.fnChange}
                fnValidator={ValidatorNameKPI}
                required="required"/>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs={12} sm={7}>
            <p>{I18n.t('assignKPI.period')}</p>
            <ButtonGroup onClick={::this.props.onPeriod}>
              <Button bsStyle="link" data-value="weekly" className={`group-button ${this.props.period === 'weekly' && ' active'}`}>{I18n.t('assignKPI.weeklyButton')}</Button>
              <Button bsStyle="link" data-value="monthly" className={`group-button ${this.props.period === 'monthly' && ' active'}`}>{I18n.t('assignKPI.monthlyButton')}</Button>
              <Button bsStyle="link" data-value="quarterly" className={`group-button ${this.props.period === 'quarterly' && ' active'}`}>{I18n.t('assignKPI.quarterlyButton')}</Button>
            </ButtonGroup>
          </Col>
        </Row>
      </Grid>
    )
  }
}
export default connect(null, null, null, { withRef: true })(CustomKPI)
