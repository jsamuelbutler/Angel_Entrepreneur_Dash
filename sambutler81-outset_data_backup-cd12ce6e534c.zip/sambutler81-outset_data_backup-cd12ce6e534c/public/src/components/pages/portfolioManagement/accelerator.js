import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Grid } from '@sketchpixy/rubix'
import { asyncGetCohortAll, asyncGetPortfolioStatistic, asyncGetDefinedKPI, asyncGetChartKPI, asyncGetYearsStatisticsKPI, asyncGetYearsKPI, asyncGetStartUp, asyncGetStartUpAll } from '../../../actions'
import OptionsPanel from './components/optionsPanel/'
import Dashboard from '../../common/dashboard'
import TablePanel from './components/tablePanel/'
import ChartTemplatesPanel from './components/dashboard/chartPanel/'
import InfoPanel from './components/dashboard/infoPanel/'
import { I18n } from 'react-redux-i18n'
import PropTypes from 'prop-types'
import moment from 'moment'
import { ValidatorError } from '../../common/templateInput'

class PortfolioManagement extends Component {

  constructor (props) {
    super(props)
    const date = new Date()
    let resultDate = new Date(date.getFullYear(), date.getMonth(), 1)
    resultDate = new Date(moment(resultDate).subtract(1, 'days'))
    this.state = {
      yearIdx: null,
      cohort: this.props.app.activeFund ? this.props.app.activeFund.id : null,
      startup: null,
      mainErrors: [],
      month: +resultDate.getMonth(),
      year: +resultDate.getFullYear(),
      type: 'cohort',
      select: null
    }
  }

  componentDidMount () { this.initComponent(this.props) }
  componentWillReceiveProps (props) { this.props.app.activeFund !== props.app.activeFund && this.initComponent(props) }
  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}, () => { this.checkDate(() => this.props.asyncGetChartKPI(null, this.state.type === 'cohort' ? this.state.select : null, this.state.type === 'startup' ? this.state.select : null, null, this.state.year)) }) }
  checkDate (fn) {
    if (this.state.year === new Date().getFullYear()) {
      const date = new Date()
      let resultDate = new Date(date.getFullYear(), date.getMonth(), 1)
      resultDate = new Date(moment(resultDate).subtract(1, 'days'))
      this.setState({year: +resultDate.getFullYear()}, () => fn && fn())
    } else {
      fn && fn()
    }
  }
  changeSelect (type, select) {
    this.setState({type, select})
  }
  initComponent (props) {
    if (props.app.activeFund === props.app.activeFund && props.app.activeFund && props.app.activeFund.id) {
      if (props.app.user.startup) {
        props.asyncGetStartUp('required', props.app.user.startup)
        props.asyncGetStartUpAll(null)
      } else {
        props.asyncGetStartUpAll('required', null, props.app.user.startup, '-todo_count, name')
        props.asyncGetStartUpAll('required', props.cohorts.data[0].id, props.app.user.startup, '-todo_count, name')
      }
      props.asyncGetCohortAll(null)
      props.asyncGetPortfolioStatistic(null, props.app.activeFund.id)
      props.asyncGetDefinedKPI(null)
      props.asyncGetChartKPI(null, props.app.activeFund.id, null, null, this.state.year)
      props.asyncGetYearsKPI(null, props.app.activeFund.id)
      props.asyncGetYearsStatisticsKPI(null, props.app.activeFund.id)
    }
  }

  fnSelectYear (eventKey) { this.setState({yearIdx: eventKey}) }
  fnChangeStartupCohort (startup, cohort) { this.setState({startup, cohort}) }
  format (n, item) {
    const REG_EX = n.toString().replace(/(\d)(?=(\d{3})+(\.\d+)?$)/g, '$1,')
    return item.toUpperCase() === 'AVERAGE OWNERSHIP' ? `${REG_EX}%` : `$ ${REG_EX}`
  }
  render () {
    let empty = (
      <div className="portfolioManagement-component empty">
        <div className="common-container-img">
          <div className="common-portfolio-pet adaptive-mascot"/>
          <h3 className="common-data-options-header">{I18n.t('portfolioManagement.dataEmpty.header')}</h3>
          <div>
            <div>
              <div className="common-box-data">
                <div className="common-question-data-options">{I18n.t('portfolioManagement.dataEmpty.noCompanies')}</div>
              </div>
            </div>
            <div/>
          </div>
        </div>
      </div>
    )
    let STATISTICS_BAR = []
    let KPI_PANELS = []
    if (this.props.cohorts.data && this.props.KPI.list && this.props.KPI.years && this.props.KPI.yearsStatistics && this.props.KPI.defined && this.props.KPI.statistic) {
      if (this.props.cohorts.data.length !== 0 && this.props.KPI.list.length !== 0 && this.props.KPI.defined.length !== 0 && this.props.KPI.statistic.length !== 0) {
        KPI_PANELS = this.props.KPI.list.map((chart, index) => {
          if (!chart || !chart.data) { return '' }
          switch (chart.chart_type) {
            case 'line': break
            case 'area': break
            case 'stack': break
            case 'bar': break
            case 'column': break
            case 'number': break
            case 'scatter': break
            case 'bubble': break
            case 'bar_and_line': break
            case 'column_and_line': break
            case 'stack_and_line': break
            default: return ''
          }
          if (chart.selects > 0) {
            return ''
          } else {
            if (chart.chart_type !== 'number') {
              return (<Col className="chart-panel-wrap common-half-padding-child" sm={12} md={6} lg={4} key={index}><ChartTemplatesPanel cohort={this.state.cohort} startup={this.state.startup} chart={chart} year={this.state.year} /></Col>)
            } else {
              return (<Col className="chart-panel-wrap common-half-padding-child" sm={12} md={6} lg={4} key={index}><InfoPanel cohort={this.state.cohort} startup={this.state.startup} chart={chart} year={this.state.year} /></Col>)
            }
          }
        })
        STATISTICS_BAR = this.props.KPI.statistic.map((panel, index) => { return (<Col xs={12} sm={12} md={4} lg={2} key={index} className="common-half-padding-child"> <Dashboard text={panel.text} sign={parseInt(panel.count) < 0 ? '-' : '+'} count={this.format(panel.count, panel.text)} /></Col>) })
      }
    }
    return (
      <div className="common-wrap-half-padding">
        <Grid className="portfolioManagement-component common-page-component">
          <Row>
            <div className="container-portfolio-dashboard">
              <Col className="hidden-lg-my" md={2} />
              {STATISTICS_BAR}
            </div>
          </Row>
          <Row>
            <Col xs={12} className="common-half-padding-child">
              <OptionsPanel changeSelect={::this.changeSelect} year={this.state.year} fnChange={::this.fnChange} scrollBottom={this.props.scrollBottom} cohort={this.state.cohort} startup={this.state.startup} fnChangeStartupCohort={::this.fnChangeStartupCohort} withCompany/>
            </Col>
          </Row>
          {this.props.KPI.years.length !== 0 && this.props.KPI.yearsStatistics.length !== 0 ? (
            <Row>
              <Col xs={12} className="common-half-padding-child">
                <TablePanel yearIdx={this.state.yearIdx} fnSelectYear={::this.fnSelectYear}/>
              </Col>
            </Row>) : null}
          <Row>
            <div>
              {KPI_PANELS.length ? KPI_PANELS : empty }
            </div>
          </Row>
        </Grid>
      </div>
    )
  }
}

PortfolioManagement.propTypes = {
  cohorts: PropTypes.shape({
    data: PropTypes.array.isRequired
  }),
  KPI: PropTypes.shape({
    list: PropTypes.array,
    yearsStatistics: PropTypes.array
  }),
  asyncGetCohortAll: PropTypes.func.isRequired,
  asyncGetPortfolioStatistic: PropTypes.func.isRequired,
  asyncGetDefinedKPI: PropTypes.func.isRequired,
  asyncGetChartKPI: PropTypes.func.isRequired,
  asyncGetYearsKPI: PropTypes.func.isRequired,
  asyncGetYearsStatisticsKPI: PropTypes.func.isRequired
}

function mapStateToProps ({app, cohorts, KPI}) { return {app, cohorts, KPI} }
export default connect(mapStateToProps, {asyncGetCohortAll, asyncGetPortfolioStatistic, asyncGetDefinedKPI, asyncGetChartKPI, asyncGetYearsStatisticsKPI, asyncGetYearsKPI, asyncGetStartUp, asyncGetStartUpAll})(PortfolioManagement)
