import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { ValidatorTrue } from '../../../../../utils/validators'
import TemplateInput from '../../../../common/templateInput'
import { Col, FormGroup, Grid, Row, Panel, PanelBody, PanelContainer } from '@sketchpixy/rubix'

class CreateAppPanel extends Component {
  render () {
    return (
      <div className="createAppPanel-component">
        <div>
          <h3 className="few-margin">{'Create new account'}</h3>
          <PanelContainer >
            <Panel className="settings-personal-panel">
              <PanelBody>
                <Grid>
                  <Row>
                    <Col xs={12} sm={12} lg={9} className="common-wrap-half-padding">
                      <Col xs={12} lg={6} className="common-half-padding-child">
                        <FormGroup>
                          <TemplateInput
                            type="text"
                            group="main"
                            name="redirect_uris"
                            className="input-form"
                            placeholder={'redirect_uris'}
                            value={this.props.redirect_uris}
                            onChange={::this.props.fnChange}
                            fnValidator={ValidatorTrue}
                            required="required"
                          />
                        </FormGroup>
                      </Col>
                      <Col xs={12} lg={6} className="common-half-padding-child">
                        <FormGroup>
                          <TemplateInput
                            type="text"
                            group="main"
                            name="name"
                            className="input-form"
                            placeholder={'name'}
                            value={this.props.name}
                            onChange={::this.props.fnChange}
                            fnValidator={ValidatorTrue}
                            required="required"/>
                        </FormGroup>
                      </Col>
                      <Col xs={12} lg={6} className="common-half-padding-child">
                        <FormGroup>
                          <TemplateInput
                            type="select"
                            group="main"
                            name="authorization_grant_type"
                            className="input-form"
                            options={[
                              {value: 'authorization-code', label: 'authorization-code'},
                              {value: 'password', label: 'password'},
                              {value: 'implicit', label: 'implicit'},
                              {value: 'client-credentials', label: 'client-credentials'}
                            ]}
                            placeholder={'authorization_grant_type'}
                            value={this.props.authorization_grant_type}
                            onChange={::this.props.fnChange}
                            fnValidator={ValidatorTrue}
                            required="required"/>
                        </FormGroup>
                      </Col>
                    </Col>
                  </Row>
                </Grid>
              </PanelBody>
            </Panel>
          </PanelContainer>
        </div>
      </div>
    )
  }
}

export default connect(null, null, null, {withRef: true})(CreateAppPanel)
