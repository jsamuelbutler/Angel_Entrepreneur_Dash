import './style'
import AccPreview from '../../dialogs/preview/'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Table, Panel, PanelBody, PanelContainer, Icon } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import MessageBox from '../../../../dialogs/messageBox/'
import { asyncDeleteOauthAccounts } from '../../../../../actions/'

class ApplicationsPanel extends Component {

  previewAcc (acc) { this.refs.accPreview.getWrappedInstance().open(acc) }
  launchRemoveApp (id) {
    this.refs.messageBox.getWrappedInstance().init(I18n.t('createApplication.removeAppTitle'), I18n.t('createApplication.removeAppMessage'))
      .then(() => { this.props.asyncDeleteOauthAccounts(null, () => {}, id) })
      .catch(() => {})
  }
  render () {
    let list = this.props.listAccounts && this.props.listAccounts.map((item, index) => {
      return (
        <tr className="common-cursor-pointer" key={index}>
          <td onClick={() => ::this.previewAcc(item)} className="text-center">{item.name}</td>
          <td onClick={() => ::this.previewAcc(item)} className="text-center">{item.client_type}</td>
          <td className="text-center"><Icon title="Remove" glyph="fa fa-trash" className="common-cursor-pointer" onClick={() => ::this.launchRemoveApp(item.id)}/></td>
        </tr>
      )
    })
    return (
      <div className="applicationsPanel-component">
        <div>
          <h3 className="few-margin">{'Applications'}</h3>
          <PanelContainer >
            <Panel className="settings-company-panel">
              <PanelBody>
                {list && list.length ? (<Table className="application-table" striped bordered hover>
                  <thead>
                    <tr>
                      <th title="Name">{I18n.t('createApplication.name')}</th>
                      <th title="Client ID">{I18n.t('createApplication.clientType')}</th>
                      <th/>
                    </tr>
                  </thead>
                  <tbody>
                    {list}
                  </tbody>
                </Table>) : <div className="text-center">Account list is empty</div>}
              </PanelBody>
            </Panel>
          </PanelContainer>
        </div>
        <MessageBox ref="messageBox"/>
        <AccPreview ref="accPreview"/>
      </div>
    )
  }

}
export default connect(null, {asyncDeleteOauthAccounts}, null, {withRef: true})(ApplicationsPanel)
