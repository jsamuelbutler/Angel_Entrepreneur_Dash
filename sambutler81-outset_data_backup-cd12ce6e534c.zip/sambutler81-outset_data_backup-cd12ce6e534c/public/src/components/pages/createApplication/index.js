import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import { Col, Grid, Row, Button } from '@sketchpixy/rubix'
import { asyncGetOauthAccounts, asyncPostOauthAccounts } from '../../../actions'
import { ValidatorError } from '../../common/templateInput/'
import ApplicationsPanel from './components/applicationsPanel/'
import CreateAppPanel from './components/createAppPanel/'
import MessageBox from '../../dialogs/messageBox/'
import PropTypes from 'prop-types'

class CreateApplication extends Component {
  constructor (props) {
    super(props)
    this.state = {
      authorization_grant_type: '',
      client_type: 'confidential',
      name: '',
      redirect_uris: '',
      mainErrors: []
    }
  }

  componentDidMount () { this.props.asyncGetOauthAccounts(null) }
  addAcc () {
    this.props.asyncPostOauthAccounts(null, null, this.state.redirect_uris, this.state.name, this.state.client_type, this.state.authorization_grant_type)
    this.setState({authorization_grant_type: '', name: '', redirect_uris: ''})
  }

  fnChange (value, name, status, group) { this.setState({status, [name]: value, [`${group}Errors`]: ValidatorError(name, status, this.state[`${group}Errors`])}) }
  render () {
    return (
      <div className="settings-component common-page-component common-wrap-half-padding">
        <div className="background-box"><span>{I18n.t('settings.pet')}</span></div>
        <MessageBox ref="messageBox"/>
        <Grid>
          <Row>
            <Col xs={12} sm={12} md={6} className="common-half-padding-child">
              <ApplicationsPanel
                listAccounts={this.props.listAccounts}/>
            </Col>
            <Col xs={12} sm={12} md={6} className="common-half-padding-child">
              <CreateAppPanel
                authorization_grant_type={this.state.authorization_grant_type}
                client_type={this.state.client_type}
                name={this.state.name}
                redirect_uris={this.state.redirect_uris}
                ref="personalPanel"
                fnChange={::this.fnChange}
              />
            </Col>
            <Col className="common-half-padding-child">
              <Button onClick={::this.addAcc} disabled={this.state.mainErrors.length !== 0} title={I18n.t('settings.saveButtonTitle')} className="common-default-button right common-apply-button">{I18n.t('settings.saveButton')}</Button>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}

CreateApplication.propTypes = {
  asyncGetOauthAccounts: PropTypes.func.isRequired,
  asyncPostOauthAccounts: PropTypes.func.isRequired
}

function mapStateToProps ({auth}) { return {listAccounts: auth.listAccounts} }
export default connect(mapStateToProps, { asyncGetOauthAccounts, asyncPostOauthAccounts })(CreateApplication)
