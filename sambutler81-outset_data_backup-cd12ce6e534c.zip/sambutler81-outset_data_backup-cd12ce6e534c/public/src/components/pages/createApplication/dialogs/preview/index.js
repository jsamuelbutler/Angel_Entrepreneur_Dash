import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Row, Col, Modal, Button } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

class AppPreview extends Component {
  constructor (props) {
    super(props)
    this.state = {
      authorization_grant_type: '',
      client_id: '',
      client_secret: '',
      client_type: '',
      name: '',
      redirect_uris: '',
      showModal: false
    }
  }

  open (acc) {
    this.setState({
      showModal: true,
      authorization_grant_type: acc.authorization_grant_type,
      client_id: acc.client_id,
      client_secret: acc.client_secret,
      client_type: acc.client_type,
      name: acc.name,
      redirect_uris: acc.redirect_uris
    })
  }
  close () { this.setState({showModal: false}) }
  render () {
    return (
      <Modal lg show={this.state.showModal} onHide={::this.close} className="preview-component">
        <Modal.Header closeButton title={I18n.t('common.close')}>
          <Modal.Title>{I18n.t('previewToDos.title')}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col xs={12}>
              <div className="app-preview-row">
                <div className="title-preview app-name-name">{I18n.t('previewAcc.name')}:</div>
                <div className="common-slim-text common-span-margin">{this.state.name}</div>
              </div>
              <div className="app-preview-row">
                <div className="title-preview app-description-name">{I18n.t('previewAcc.client_id')}:</div>
                <div className="common-slim-text common-span-margin">{this.state.client_id}</div>
              </div>
              <div className="app-preview-row">
                <div className="title-preview">{I18n.t('previewAcc.client_secret')}:</div>
                <span className="common-slim-text common-span-margin app-description">{this.state.client_secret}</span>
              </div>
              <div className="app-preview-row">
                <div className="title-preview">{I18n.t('previewAcc.client_type')}:</div>
                <span className="common-slim-text common-span-margin app-description">{this.state.client_type}</span>
              </div>
              <div className="app-preview-row">
                <div className="title-preview">{I18n.t('previewAcc.redirect_uris')}:</div>
                <span className="common-slim-text common-span-margin">{this.state.redirect_uris}</span>
              </div>
              <div className="app-preview-row">
                <div className="title-preview">{I18n.t('previewAcc.authorization_grant_type')}:</div>
                <span className="common-slim-text common-span-margin">{this.state.authorization_grant_type}</span>
              </div>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button className="common-default-close-button common-close-button center" onClick={::this.close}>{I18n.t('previewAcc.closeButton')}</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
export default connect(null, null, null, {withRef: true})(AppPreview)
