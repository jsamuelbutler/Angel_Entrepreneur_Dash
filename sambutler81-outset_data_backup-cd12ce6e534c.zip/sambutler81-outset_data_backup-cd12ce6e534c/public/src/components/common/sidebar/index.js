/* global localStorage */
import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Sidebar, SidebarNav, SidebarNavItem } from '@sketchpixy/rubix'
import { I18n, setLocale } from 'react-redux-i18n'
import PrivacyModal from '../../dialogs/policy/privacy'
import { history } from '../../../store'
import TermsModal from '../../dialogs/policy/terms'
import { ACCOUNTS_TYPES, LOCALE as locale } from '../../../constants'
import { actionClearStore } from '../../../actions'
import { Scrollbars } from 'react-custom-scrollbars'
import PropTypes from 'prop-types'

const currentLocale = localStorage.getItem('locale')

class SidebarContainer extends Component {

  constructor (props) {
    super(props)
    this.state = {
      headerLogo: '',
      headerName: '',
      locale: currentLocale
    }
  }

  componentDidMount () {
    window.setTimeout(() => { document.getElementById('body').className = `${document.getElementById('body').className} loaded` }, 0)
    this.getData(this.props)
    let el = document.querySelectorAll('.sidebar-nav-container li')
    for (let i = 0; i < el.length; i++) { el[i].setAttribute('title', el[i].querySelector('.name').innerText) }
    document.onclick = (e) => {
      let target = e.target || e.srcElement
      if (target.tagName === 'DIV' && target.id === 'stopClick') {
        document.getElementById('container').className = ''
        document.getElementById('navMenuButton').className = 'material--burger'
      }
      ((target.id !== 'switch-language-btn' && target.className !== 'short' && target.className !== 'full') && document.getElementById('switch-language-wrapper') && this.isSwitchLanguageOpen()) && (document.getElementById('switch-language-wrapper').className = '')
    }
    localStorage.setItem('loggedin', true)
    window.addEventListener('storage', (event) => { event.key === 'loggedin' && event.newValue === 'false' && this.handleClickLogout() })
  }
  componentWillReceiveProps (props) { this.getData(props) }

  getData (props) {
    if (props.user) {
      if (props.user.account_type === ACCOUNTS_TYPES.ACCELERATOR_FOUNDER || props.user.account_type === ACCOUNTS_TYPES.ACCELERATOR_ADMIN || props.user.account_type === ACCOUNTS_TYPES.ACCELERATOR_EMPLOYEE) {
        props.accelerator.id === props.user.accelerator && this.setState({headerLogo: props.accelerator.logo ? props.accelerator.logo : '', headerName: props.accelerator.name})
      }
      if (props.user.account_type === ACCOUNTS_TYPES.COMPANY_FOUNDER || props.user.account_type === ACCOUNTS_TYPES.COMPANY_EMPLOYEE) {
        props.startup.id === props.user.startup && this.setState({headerLogo: props.startup.logo ? props.startup.logo : '', headerName: props.startup.name})
      }
    }
  }
  isSidebarOpen () { return document.getElementById('container').className === '' }
  stateNavButton () { return document.getElementById('navMenuButton').className === 'material--burger' }
  isSwitchLanguageOpen () { return document.getElementById('switch-language-wrapper').className === 'open' }
  handleClickLogout () { localStorage.setItem('loggedin', false); this.props.actionClearStore(); history.push('/login') }

  handleClickHideMenu () {
    document.getElementById('container').className = ''
    document.getElementById('navMenuButton').className = 'material--burger'
  }
  handleClickShowMenu () {
    document.getElementById('container').className = this.isSidebarOpen() ? 'container-open' : ''
    document.getElementById('navMenuButton').className = this.stateNavButton() ? 'material--burger material--arrow' : 'material--burger'
    document.getElementById('switch-language-wrapper').className = ''
  }
  handleSwitchLanguage () { document.getElementById('switch-language-wrapper').className = this.isSwitchLanguageOpen() ? '' : 'open' }
  fnPrivacyModal () { this.refs.privacyModal.getWrappedInstance().open() }
  fnTermsModal () { this.refs.termsModal.getWrappedInstance().open() }
  handleChangeLanguage (locale) {
    this.setState({locale})
    this.props.setLocale(locale)
    localStorage.setItem('locale', locale)
    this.handleSwitchLanguage()
  }

  render () {
    const languageList = Object.keys(locale).map((item, i) => {
      return (
        <li key={i} className={item} title={locale[item].name} onClick={() => ::this.handleChangeLanguage(item)}>
          <span>{locale[item].name}</span>
        </li>
      )
    })
    const ROLE = this.props.app.user && this.props.app.user.account_type
    return (
      <div id="sidebar" className="sidebar sidebar-component">
        <div id="avatar" className="avatar">
          <div className="table-cell" title={this.state.headerName}>
            <div className="common-logo-main" title="Toggle sidebar" style={this.state.headerLogo ? {background: '#ddd url(' + `${this.state.headerLogo}` + ')'} : null} onClick={::this.handleClickShowMenu}/>
          </div>
        </div>
        <div id="sidebar-container" className="sidebar-container">
          <Scrollbars
            autoHide
            renderTrackVertical={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
            renderThumbVertical={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
            renderTrackHorizontal={props => <div {...props} className="track-horizontal" style={{display: 'none'}}/>}
            renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" style={{display: 'none'}}/>}
            ref="scrollbars">
            <Sidebar>
              <div className="sidebar-nav-container" onClick={::this.handleClickHideMenu}>
                <SidebarNav className="head-page nav-margin">
                  { ROLE === ACCOUNTS_TYPES.ACCELERATOR_FOUNDER ||
                  ROLE === ACCOUNTS_TYPES.ACCELERATOR_ADMIN ||
                  ROLE === ACCOUNTS_TYPES.ACCELERATOR_EMPLOYEE
                    ? <SidebarNavItem glyph="fa fa-rocket" name={I18n.t('sidebar.manageFunds')} href="/manageFunds"/> : <span />
                  }
                  <SidebarNavItem glyph="fa fa-heartbeat" name={I18n.t('sidebar.activity')} href="/activity"/>
                  <SidebarNavItem glyph="fa fa-check-square" name={I18n.t('sidebar.toDos')} href="/toDos"/>
                  <SidebarNavItem glyph="fa fa-file-text" name={I18n.t('sidebar.notesDocs')} href="/notesDocs"/>
                  <SidebarNavItem glyph="fa fa-retweet" name={I18n.t('sidebar.updates')} href="/updates"/>
                  <SidebarNavItem glyph="fa fa-bar-chart" name={I18n.t('sidebar.portfolioManagement')} href="/portfolioManagement"/>
                  { ROLE === ACCOUNTS_TYPES.ACCELERATOR_FOUNDER ||
                  ROLE === ACCOUNTS_TYPES.ACCELERATOR_ADMIN ||
                  ROLE === ACCOUNTS_TYPES.COMPANY_FOUNDER
                    ? <SidebarNavItem glyph="fa fa-users" name={I18n.t('sidebar.manageTeam')} href="/manageTeam" /> : <span />
                  }
                </SidebarNav>
                <SidebarNav className="footer-page">
                  <SidebarNavItem glyph="fa fa-cog" name={I18n.t('sidebar.settings')} href="/settings"/>
                  <SidebarNavItem glyph="fa fa-power-off" name={I18n.t('sidebar.logOut')} onClick={::this.handleClickLogout}/>
                </SidebarNav>
                <SidebarNav className="footer-doc">
                  <SidebarNavItem name={I18n.t('sidebar.privacy')} onClick={::this.fnPrivacyModal}/>
                  <SidebarNavItem name={I18n.t('sidebar.terms')} onClick={::this.fnTermsModal}/>
                  { (ROLE === ACCOUNTS_TYPES.ACCELERATOR_FOUNDER || ROLE === ACCOUNTS_TYPES.ACCELERATOR_ADMIN) && this.props.user.viewApi ? <SidebarNavItem name={I18n.t('sidebar.api')} href="/api"/> : <span />}
                </SidebarNav>
              </div>
              <div id="switch-language-btn" title={I18n.t('sidebar.changeLanguage')} className={this.state.locale} onClick={::this.handleSwitchLanguage} >
                <span className="short">{locale[this.state.locale].short}</span>
                <span className="full">{locale[this.state.locale].name}</span>
              </div>
            </Sidebar>
          </Scrollbars>
          <div id="switch-language-wrapper">
            <div className="switch-language-close">
              <i className="fa fa-times" id="switch-language-close" title="Close" onClick={::this.handleSwitchLanguage}/>
            </div>
            <ul id="switch-language">
              {languageList}
            </ul>
          </div>
        </div>
        <PrivacyModal ref="privacyModal"/>
        <TermsModal ref="termsModal"/>
      </div>
    )
  }
}

SidebarContainer.propTypes = {
  actionClearStore: PropTypes.func.isRequired,
  app: PropTypes.shape({
    user: PropTypes.shape({
      account_type: PropTypes.oneOfType([
        PropTypes.object.isRequired,
        PropTypes.number.isRequired
      ])
    })
  })
}

function mapStateToProps ({app, accelerators, startups}) { return { user: app.user, startups, accelerators, app, accelerator: accelerators.accelerator, startup: startups.startup } }
export default connect(mapStateToProps, {setLocale, actionClearStore})(SidebarContainer)
