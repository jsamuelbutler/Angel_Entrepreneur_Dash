import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Navbar, Col, Icon, Row } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'
import { asyncSetLoginScreen } from '../../../actions'
import { detectSwipe } from '../../../utils/helpers'
import PropTypes from 'prop-types'

class Header extends Component {

  componentDidMount () { detectSwipe('blur-layout') }
  shouldComponentUpdate (props) { return this.props.auth.loginScreen !== props.auth.loginScreen || this.props.title !== props.title || this.props.path !== props.path }

  isSidebarOpen () { return document.getElementById('container').className === '' }
  stateNavButton () { return document.getElementById('navMenuButton').className === 'material--burger' }

  handleClickMenu () {
    document.getElementById('container').className = this.isSidebarOpen() ? 'container-open' : ''
    document.getElementById('navMenuButton').className = this.stateNavButton() ? 'material--burger material--arrow' : 'material--burger'
  }

  render () {
    return (
      <div id="navbar" className="header-component">
        <Navbar fixedTop fluid id="rubix-nav-header" className="rubix-nav-header main-header">
          <div className="table-grid">
            <Row>
              <Col xs={2} sm={4} md={4} lg={3} className="column-left">
                <nav>
                  <div id="navMenuButton" title="Open/Close sidebar" className="material--burger" onClick={::this.handleClickMenu}>
                    <Icon glyph="fa fa-bars"/>
                  </div>
                </nav>
              </Col>
              <Col xs={8} sm={4} md={4} lg={6} className="column-center header-title">
                {this.props.title}
              </Col>
              <Col xsHidden sm={2} md={2} lg={2} className="column-right header-logo">
                <div className="screen text-right">
                  <a onClick={() => this.props.asyncSetLoginScreen(null, this.props.path)}> {I18n.t('header.setAsLoginScreen')}</a>
                </div>
              </Col>
              <Col xsHidden sm={2} md={2} lg={1} className="column-right2 header-logo">
                <div className="logo-box">
                  <a className="img-logo" href={this.props.auth.loginScreen} title={`${I18n.t('header.goToScreen')} ${this.props.auth.loginScreen}`}/>
                </div>
              </Col>
            </Row>
          </div>
          <div className="header-spinner"/>
        </Navbar>
      </div>
    )
  }
}

Header.propTypes = {
  title: PropTypes.string.isRequired,
  asyncSetLoginScreen: PropTypes.func.isRequired,
  auth: PropTypes.shape({
    loginScreen: PropTypes.string.isRequired
  }),
  path: PropTypes.string.isRequired
}

function mapStateToProps ({auth}) { return { auth } }
export default connect(mapStateToProps, { asyncSetLoginScreen })(Header)
