/* global clearTimeout, setTimeout */
import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { FormControl, InputGroup, Icon } from '@sketchpixy/rubix'
import DatePicker from 'react-bootstrap-date-picker'
import Select from 'react-select-plus'
import moment from 'moment'
import PropTypes from 'prop-types'

class TemplateInput extends Component {

  constructor (props) {
    super(props)
    this.state = {
      value: this.props.value,
      status: false,
      statusChanged: this.props.statusChanged || true,
      currentErrorMessage: '',
      valueTwice: null
    }
  }

  componentDidMount () {
    const validator = this.props.fnValidator ? this.props.fnValidator({value: this.state.value, valueTwice: this.state.valueTwice}) : {status: false, message: ''}
    if (!validator.status && this.props.required === 'required') { this.props.onChange(this.props.value, this.props.name, this.props.required === 'required' && !this.state.value, this.props.group) }
    document.querySelector('.main-date-picker') && document.querySelector('.main-date-picker').setAttribute('readonly', 'readonly')
  }
  componentWillReceiveProps (props) {
    this.setState({value: props.value})
    if (this.props.value !== props.value) {
      const validator = props.fnValidator ? this.props.fnValidator({value: props.value, valueTwice: this.state.valueTwice}) : {status: false, message: ''}
      if (validator.status && props.required === 'required') { props.onChange(props.value, props.name, validator.status && !props.value, props.group) }
    }
  }

  shouldComponentUpdate (props, state) { return props.options !== this.props.options || state.valueTwice !== this.state.valueTwice || state.currentErrorMessage !== this.state.currentErrorMessage || state.statusChanged !== this.state.statusChanged || state.status !== this.state.status || props.disable !== this.props.disable || props.className !== this.props.className || props.value !== this.props.value }

  isValidate () { return this.state.currentErrorMessage ? 'error' : '' }
  fnChangeValueTwice (valueTwice) { this.setState({valueTwice}, this.fnChangeValue) }
  fnClear () { this.setState({statusChanged: false, status: true}, () => { this.props.onChange(this.state.value, this.props.name, this.state.status, this.props.group) }) }
  fnClearText () { this.setState({statusChanged: true, status: true, value: '', currentErrorMessage: ''}, () => { this.props.onChange(this.state.value, this.props.name, this.state.status, this.props.group) }) }

  fnChangeValue (event = this.state.value) {
    let value
    if (this.props.type === 'select') {
      value = event ? event.value : null
    } else {
      value = typeof event === 'object' && event !== null && event !== undefined ? event.target.value : event !== null && event !== undefined ? event : ''
    }

    const validator = this.props.fnValidator ? this.props.fnValidator({value, valueTwice: this.state.valueTwice}) : {status: true, message: ''}
    let myStatus

    const func = () => {
      if (validator.status || this.props.required !== 'required' && !value) {
        this.props.required === 'required' && !value ? this.setState({currentErrorMessage: 'This field required!', status: true}) : this.setState({currentErrorMessage: '', status: false})
        this.props.required === 'required' && !value ? myStatus = true : myStatus = false
      } else {
        this.setState({currentErrorMessage: this.state.statusChanged ? validator.message : '', status: true})
        myStatus = true
      }
      this.props.onChange(value, this.props.name, myStatus, this.props.group)
      this.props.fieldTwice ? this.props.fieldTwice.refs.wrappedInstance.fnChangeValueTwice(value) : ''
    }

    !this.state.statusChanged ? this.setState({statusChanged: true}, () => {
      func()
    }) : func()
  }

  fnClearValue () { this.fnChangeValue('') }

  getLoginTemplate (type, icon) {
    return (
      <InputGroup>
        <InputGroup.Addon>
          <Icon glyph={icon} />
        </InputGroup.Addon>
        <FormControl
          type={type}
          placeholder={this.props.placeholder}
          className={`input-form ${::this.isValidate(this.state.currentErrorMessage)} ${this.props.className}`}
          value={this.state.value}
          onChange={::this.fnChangeValue}/>
      </InputGroup>
    )
  }

  render () {
    let content = ''
    switch (this.props.type) {
      case 'login-email': { content = this.getLoginTemplate('email', 'fa fa-user'); break }
      case 'login-text': { content = this.getLoginTemplate('text', 'fa fa-user'); break }
      case 'login-password': { content = this.getLoginTemplate('password', 'fa fa-lock'); break }
      case 'email':
      case 'number':
      case 'password':
      case 'text': {
        content = (
          <FormControl
            type={this.props.type}
            autocomplete={this.props.autocomplete || 'off'}
            disabled={this.props.disable}
            placeholder={this.props.placeholder}
            className={`${::this.isValidate()} ${this.props.className}`}
            value={this.state.value}
            onChange={::this.fnChangeValue}/>)
        break
      }
      case 'textarea': {
        content = (
          <FormControl
            componentClass={this.props.type}
            type={this.props.type}
            autocomplete={this.props.autocomplete || 'off'}
            placeholder={this.props.placeholder}
            className={`${::this.isValidate()} ${this.props.className}`}
            value={this.state.value}
            onChange={::this.fnChangeValue}/>)
        break
      }
      case 'select': {
        content = (
          <Select
            value={this.state.value}
            autocomplete={this.props.autocomplete || 'off'}
            placeholder={this.props.placeholder}
            options={this.props.options}
            onChange={::this.fnChangeValue}/>)
        break
      }
      case 'date': {
        content = (
          <DatePicker
            dateFormat = "MM-DD-YYYY"
            className={`main-date-picker ${::this.isValidate()} ${this.props.className}`}
            value={this.state.value}
            showTodayButton
            onClear={::this.fnClearValue}
            minDate={moment().format('DD-MM-YYYY')}
            maxDate={moment().format('DD-MM-YYYY')}
            onChange={::this.fnChangeValue} />)
        break
      }
    }
    return (
      <div className="templateInput-component">
        {content}
        <div className="error-validation-message">{this.state.currentErrorMessage}</div>
      </div>
    )
  }
}

TemplateInput.propTypes = {
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  placeholder: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  required: PropTypes.string,
  group: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  className: PropTypes.string,

  fnValidator: PropTypes.func,
  onChange: PropTypes.func.isRequired
}

export function ValidatorError (name, status, errors) {
  let err = errors
  if (status) { err.indexOf(name) === -1 ? err.push(name) : '' } else { err.indexOf(name) !== -1 ? err.splice(err.indexOf(name), 1) : '' }
  return err
}
export default connect(null, null, null, {withRef: true})(TemplateInput)
