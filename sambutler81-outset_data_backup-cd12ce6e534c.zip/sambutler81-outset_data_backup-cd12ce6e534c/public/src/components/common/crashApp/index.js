import './style'
import React from 'react'
import { Grid, Row, Col } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

const CrashApp = () => {
  return (
    <div className="crashApp-component">
      <Grid>
        <Row>
          <Col xs={12}>
            <div className="info-block common-warning">
              <p className="titles">{I18n.t('crashApp.title')}<br/>
                <span className="code-label"> {I18n.t('crashApp.code')} </span>
              </p>
              <span className="message">
                {I18n.t('crashApp.message')}, <a href="">{I18n.t('crashApp.reload')}</a>
              </span>
            </div>
          </Col>
        </Row>
        <div className="common-container-img">
          <div className="common-not-found-pet"/>
        </div>
      </Grid>
    </div>
  )
}
export default CrashApp
