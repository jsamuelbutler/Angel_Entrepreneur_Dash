import './style'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { I18n } from 'react-redux-i18n'
import Select from 'react-select-plus'
import { asyncGetStartUpAll, actionSetActiveFund } from '../../../actions'

class SelectCohort extends Component {

  constructor (props) {
    super(props)
    this.state = { options: [] }
  }
  componentWillReceiveProps (props) { this.setState({options: props.cohorts.map(obj => { return {value: obj.id, label: obj.name, id: obj.id} })}); props.activeFund !== this.props.activeFund && props.activeFund && this.updateValue({value: props.activeFund.id, label: props.activeFund.label, id: props.activeFund.id}, true) }
  updateValue (value, status) {
    !status && this.props.actionSetActiveFund(value)
    this.props.asyncGetStartUpAll(null, value.id, null, '-todo_count, name')

    this.props.asyncGetPortfolioStatistic && this.props.asyncGetPortfolioStatistic(null, value.id)
    this.props.asyncGetYearsKPI && this.props.asyncGetYearsKPI(null, value.id)
    this.props.asyncGetYearsStatisticsKPI && this.props.asyncGetYearsStatisticsKPI(null, value.id)
  }

  render () {
    return (
      <Select
        autofocus
        className="selectCohort-component form-field-name"
        name="form-field-name"
        value={this.props.activeFund ? this.props.activeFund.id : null}
        onChange={::this.updateValue}
        placeholder={I18n.t('manageFunds.selectFunds')}
        options={this.state.options}
        searchable={false}
        clearable={false}/>
    )
  }
}
function mapStateToProps ({cohorts, app}) { return {cohorts: cohorts.data, activeFund: app.activeFund} }
export default connect(mapStateToProps, {asyncGetStartUpAll, actionSetActiveFund})(SelectCohort)
