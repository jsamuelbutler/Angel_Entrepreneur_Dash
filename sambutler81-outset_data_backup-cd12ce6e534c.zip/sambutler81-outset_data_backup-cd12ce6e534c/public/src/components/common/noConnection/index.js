import './style'
import React from 'react'
import { Grid, Row, Col } from '@sketchpixy/rubix'
import { I18n } from 'react-redux-i18n'

const NoConnection = () => {
  return (
    <div className="noConnection-component">
      <Grid className="common-lower-width">
        <Row className="padding-crash-app">
          <Col xs={12}>
            <div className="info-lost common-warning">
              <p className="titles">{I18n.t('noConnection.title')}<br/>
                <span> {I18n.t('noConnection.code')} </span>
              </p>
              <span className="message">
                {I18n.t('noConnection.message')}
              </span>
            </div>
          </Col>
        </Row>
        <div className="common-container-img">
          <div className="common-not-found-pet"/>
        </div>
      </Grid>
    </div>
  )
}
export default NoConnection
