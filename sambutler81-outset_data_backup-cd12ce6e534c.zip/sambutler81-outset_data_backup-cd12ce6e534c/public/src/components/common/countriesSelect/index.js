import './style'
import React from 'react'
import { I18n } from 'react-redux-i18n'
import Select from 'react-select-plus'
import COUNTRIES from '../../../constants/countries'

const OPTIONS = COUNTRIES.map(item => {
  return {
    value: item.text,
    label: (
      <div>
        <span className={`flag-icon flag-icon-${item.id.toLowerCase()} flag-icon-squared`}/>
        <span className="flag-text flag-label">{item.text}</span>
      </div>
    )
  }
})

const CountriesSelect = (props) => {
  return (
    <div className="countriesSelect-component">
      <Select
        value={props.value}
        placeholder={I18n.t('settingsCompRole.countrySelector')}
        onChange={::props.onChange}
        options={OPTIONS}
        clearValueText={I18n.t('settingsCompRole.countrySelectorClearText')}
        resetValue=""
      />
    </div>
  )
}
export default CountriesSelect
