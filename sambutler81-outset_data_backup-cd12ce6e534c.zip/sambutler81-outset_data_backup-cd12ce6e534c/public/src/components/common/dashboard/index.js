import './style'
import React from 'react'
import { Panel, PanelHeader, PanelContainer } from '@sketchpixy/rubix'

const Dashboard = (props) => {
  let count = parseInt(props.count.toString().replace(/[^-0-9]/gim, ''))
  let value = count === 0 ? (props.count.toString().search(/-/gim) ? props.count.toString().replace(/-/gim, '') : props.count) : props.count

  return (
    <div className="dashboard-component">
      <PanelContainer controls={false} className="dashboard-head-panel">
        <Panel>
          <PanelHeader>
            <span title={props.text} className="common-text-14 dashboard-text uppercase ">
              {props.text}
            </span>
            <p title={props.count} className={`${count === 0 ? ' zero' : ''} dashboard-value`}>
              <span className={`${props.text.toUpperCase() === 'GAIN/LOSS' && props.sign === '-' ? 'common-text-red' : ''}`}>{value}</span>
            </p>
          </PanelHeader>
        </Panel>
      </PanelContainer>
    </div>
  )
}
export default Dashboard
