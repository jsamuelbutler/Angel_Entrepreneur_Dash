import './style'
import React from 'react'
import { ButtonToolbar, Button, Icon } from '@sketchpixy/rubix'

const ScrollTop = (props) => {
  return (
    <div className="scrollTop-component">
      <ButtonToolbar>
        <Button title="Scroll top" onClick={::props.scrollTop} bsStyle="green" rounded>
          <Icon glyph="fa fa-chevron-up"/>
        </Button>
      </ButtonToolbar>
    </div>
  )
}
export default ScrollTop
