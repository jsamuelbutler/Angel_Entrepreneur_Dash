import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/startups/startups.types'
import TYPE_TODOS from '../../store/todos/todos.types'
import TYPE_DOCS from '../../store/docs/docs.types'
import KPI_TYPE from '../../store/KPI/KPI.types'
import TYPE_UPDATES from '../../store/updates/updates.types'
import TYPE_ACTIVITIES from '../../store/activities/activities.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

export function actionGetStartUpAllClean () { return dispatch => dispatch({type: TYPE.GET_START_UP_BY_COHORT.TYPE, data: []}) }
export function actionSetStartUpActivitiesClean () { return {type: TYPE_ACTIVITIES.GET_ACTIVITIES_STARTUPS.TYPE, data: []} }

export function actionSetStartUpToDosClean () { return {type: TYPE_TODOS.START_UP_TODO.TYPE, data: []} }
export function actionSetStartUpUpdatesClean () { return {type: TYPE_UPDATES.GET_START_UP_UPDATES.TYPE, data: []} }
export function actionSetStartUpNotesDocsClean () { return {type: TYPE_DOCS.START_UP_DOCS.TYPE, data: []} }

function actionGetStartUpAllByCohort (data, id, status) { return {type: TYPE.GET_START_UP_BY_COHORT.TYPE, status, data, id} }
function actionGetStartUpAll (data, id, status) { return {type: TYPE.GET_START_UP_ALL.TYPE, status, data, id} }
function actionSetStartUpTodo (data, status) { return {type: TYPE_TODOS.START_UP_TODO.TYPE, status, data} }
function actionSetStartUpDocs (data, status) { return {type: TYPE_DOCS.START_UP_DOCS.TYPE, status, data} }
function actionSetStartUpUpdates (data, status) { return {type: TYPE_UPDATES.GET_START_UP_UPDATES.TYPE, status, data} }

export function asyncGetStartUpAll (required, UID, startup, ordering) {
  let params = UID ? { params: { cohort: UID, is_active: true, ordering } } : { params: { is_active: true, ordering } }
  return dispatch => getAxios(dispatch, required, TYPE.GET_START_UP_ALL)
  .get(`${BASE_URL}/startups/`, params)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionSetStartUpUpdates(response.data, STATUS.SUCCESS)); (UID ? (dispatch(actionGetStartUpAllByCohort(response.data, startup, STATUS.SUCCESS)), dispatch(actionSetStartUpTodo(response.data, STATUS.SUCCESS)), dispatch(actionSetStartUpDocs(response.data, STATUS.SUCCESS))) : dispatch(actionGetStartUpAll(response.data, startup, STATUS.SUCCESS))); dispatch(requestSuccessHandler(TYPE.GET_START_UP_ALL)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_START_UP_ALL, error)) })
}

function actionAddStartUp (data, status) { return {type: TYPE.ADD_START_UP.TYPE, status, data} }
export function asyncAddStartUp (required, fnCloseDialog, cohort, name, amountInvested, securityType, ownership, invites) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_START_UP)
  .post(`${BASE_URL}/startups/`, { cohort, name, amount_invested: amountInvested, securityType, ownership, invites })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionAddStartUp(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_START_UP)); dispatch(asyncGetStartUpAll(null, cohort)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_START_UP, error)) })
}

function actionGetStartUpDocs (data, status) { return {type: TYPE_DOCS.GET_START_UP_DOCS.TYPE, status, data} }
function actionGetStartUp (data, status) { return {type: TYPE.GET_START_UP.TYPE, status, data} }
export function asyncGetStartUp (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_START_UP)
  .get(`${BASE_URL}/startups/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetStartUp(response.data, STATUS.SUCCESS)); dispatch(actionGetStartUpDocs(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_START_UP)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_START_UP, error)) })
}

function actionPatchStartUp (data, status) { return {type: TYPE.PATCH_START_UP.TYPE, status, data} }
export function asyncPatchStartUp (status, required, fnCloseDialog, UID, website, name, logo, info, incorporationDate, country, amountInvested, securityType, ownership, initialValuation) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_START_UP)
  .patch(`${BASE_URL}/startups/${UID}/`, status ? {name, amount_invested: amountInvested, security_type: securityType, ownership, initial_valuation: initialValuation} : { website, name, logo, country, info, incorporation_date: incorporationDate })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchStartUp(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_START_UP)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_START_UP, error)); fnCloseDialog() })
}

function actionStartUpDeactivate (data, status) { return {type: TYPE.START_UP_DEACTIVATE.TYPE, status, data} }
export function asyncStartUpDeactivate (required, companyId, fundId) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_DEACTIVATE)
  .delete(`${BASE_URL}/startups/${companyId}/`)
  .then(() => { dispatch(actionStartUpDeactivate(companyId, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_DEACTIVATE)); dispatch(asyncGetStartUpAll(null, fundId)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_DEACTIVATE, error)) })
}

function actionGetStartUpPortfolioStatistic (data, status) { return {type: KPI_TYPE.GET_START_UP_PORTFOLIO_STATISTIC.TYPE, status, data} }
export function asyncGetStartUpPortfolioStatistic (required, UID) {
  return dispatch => getAxios(dispatch, required, KPI_TYPE.GET_START_UP_PORTFOLIO_STATISTIC)
  .get(`${BASE_URL}/startups/${UID}/portfolio_statistic/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetStartUpPortfolioStatistic(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(KPI_TYPE.GET_START_UP_PORTFOLIO_STATISTIC)) })
  .catch(error => { dispatch(requestErrorHandler(KPI_TYPE.GET_START_UP_PORTFOLIO_STATISTIC, error)) })
}

function actionStartUpInvite (data, status) { return {type: TYPE.START_UP_INVITE.TYPE, status, data} }
export function asyncStartUpInvite (required, fnCloseDialog, UID, emails, role, message) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_INVITE)
  .post(`${BASE_URL}/startups/${UID}/invite/`, { emails, role, message })
  .then(response => { dispatch(actionStartUpInvite(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_INVITE)); fnCloseDialog && fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_INVITE, error)) })
}

function actionStartUpStripeIntegration (data, status) { return {type: TYPE.START_UP_STRIPE_INTEGRATION.TYPE, status, data} }
export function asyncStartUpStripeIntegration (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_STRIPE_INTEGRATION)
    .post(`${BASE_URL}/startups/${UID}/stripe_integration/`)
    .then(response => { response.data.redirect && (document.location.href = response.data.redirect); dispatch(actionStartUpStripeIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_STRIPE_INTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_STRIPE_INTEGRATION, error)) })
}

function actionStartUpStripeDisIntegration (data, status) { return {type: TYPE.START_UP_STRIPE_DISINTEGRATION.TYPE, status, data} }
export function asyncStartUpStripeDisIntegration (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_STRIPE_DISINTEGRATION)
    .delete(`${BASE_URL}/startups/${UID}/stripe_integration/`)
    .then(response => { dispatch(actionStartUpStripeDisIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_STRIPE_DISINTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_STRIPE_DISINTEGRATION, error)) })
}

function actionStartUpStripeIntegrationComplete (data, status) { return {type: TYPE.START_UP_STRIPE_INTEGRATION_COMPLETE.TYPE, status, data} }
export function asyncStartUpStripeIntegrationComplete (required, fnCloseDialog, UID, code, state) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_STRIPE_INTEGRATION_COMPLETE)
    .post(`${BASE_URL}/startups/${UID}/stripe_integration_complete/`, {code, state})
    .then(response => { response.data.redirect && (document.location.href = response.data.redirect); dispatch(actionStartUpStripeIntegrationComplete(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_STRIPE_INTEGRATION_COMPLETE)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { fnCloseDialog && fnCloseDialog(); dispatch(requestErrorHandler(TYPE.START_UP_STRIPE_INTEGRATION_COMPLETE, error)) })
}

export function actionStartUpBankIntegration (data, status) { return {type: TYPE.START_UP_BANK_INTEGRATION.TYPE, status, data} }
export function asyncStartUpBankIntegration (required, fnCloseDialog, UID, institution) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_BANK_INTEGRATION)
    .post(`${BASE_URL}/startups/${UID}/bank_integration/`, { institution })
    .then(response => { dispatch(actionStartUpBankIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_BANK_INTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_BANK_INTEGRATION, error)) })
}

export function actionStartUpBankDisIntegration (data, status) { return {type: TYPE.START_UP_BANK_DISINTEGRATION.TYPE, status, data} }
export function asyncStartUpBankDisIntegration (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_BANK_DISINTEGRATION)
    .delete(`${BASE_URL}/startups/${UID}/bank_integration/`)
    .then(response => { dispatch(actionStartUpBankDisIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_BANK_DISINTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_BANK_DISINTEGRATION, error)) })
}

function actionStartUpBankIntegrationLoginForm (data, status) { return {type: TYPE.START_UP_BANK_INTEGRATION_LOGIN_FORM.TYPE, status, data} }
export function asyncStartUpBankIntegrationLoginForm (required, fnCloseDialog1, fnCloseDialog2, UID, credentials, challenge, clear) {
  let obj = {}
  credentials && (obj['credentials'] = credentials)
  challenge && (obj['challenge'] = challenge)
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_BANK_INTEGRATION_LOGIN_FORM)
    .post(`${BASE_URL}/startups/${UID}/bank_integration_login_form/`, obj)
    .then(response => { clear && clear(); dispatch(actionStartUpBankIntegrationLoginForm(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_BANK_INTEGRATION_LOGIN_FORM)); fnCloseDialog1 && (response.data && response.data.mfa_challenge ? fnCloseDialog1(true) : fnCloseDialog1(false)); fnCloseDialog2 && response.data && response.data.mfa_challenge === null && fnCloseDialog2() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_BANK_INTEGRATION_LOGIN_FORM, error)) })
}

function actionStartUpXeroIntegration (data, status) { return {type: TYPE.START_UP_XERO_INTEGRATION.TYPE, status, data} }
export function asyncStartUpXeroIntegration (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_XERO_INTEGRATION)
    .post(`${BASE_URL}/startups/${UID}/xero_integration/`, {})
    .then(response => { response.data.redirect && (document.location.href = response.data.redirect); dispatch(actionStartUpXeroIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_XERO_INTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_XERO_INTEGRATION, error)) })
}

function actionStartUpXeroDisIntegration (data, status) { return {type: TYPE.START_UP_XERO_DISINTEGRATION.TYPE, status, data} }
export function asyncStartUpXeroDisIntegration (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_XERO_DISINTEGRATION)
    .delete(`${BASE_URL}/startups/${UID}/xero_integration/`)
    .then(response => { dispatch(actionStartUpXeroDisIntegration(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_XERO_DISINTEGRATION)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_XERO_DISINTEGRATION, error)) })
}

function actionStartUpXeroIntegrationAccounts (data, status) { return {type: TYPE.START_UP_XERO_INTEGRATION_ACCOUNTS.TYPE, status, data} }
export function asyncStartUpXeroIntegrationAccounts (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_XERO_INTEGRATION_ACCOUNTS)
    .get(`${BASE_URL}/startups/${UID}/xero_integration_accounts/`, {})
    .then(response => { dispatch(actionStartUpXeroIntegrationAccounts(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_XERO_INTEGRATION_ACCOUNTS)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_XERO_INTEGRATION_ACCOUNTS, error)) })
}

function actionStartUpXeroIntegrationComplete (data, status) { return {type: TYPE.START_UP_XERO_INTEGRATION_COMPLETE.TYPE, status, data} }
export function asyncStartUpXeroIntegrationComplete (required, fnCloseDialog, UID, code, fn) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_XERO_INTEGRATION_COMPLETE)
    .post(`${BASE_URL}/startups/${UID}/xero_integration_complete/`, { code })
    .then(response => { dispatch(actionStartUpXeroIntegrationComplete(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_XERO_INTEGRATION_COMPLETE)); fnCloseDialog && fnCloseDialog(); fn && fn() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_XERO_INTEGRATION_COMPLETE, error)) })
}

function actionStartUpXeroIntegrationSelectAccounts (data, status) { return {type: TYPE.START_UP_XERO_INTEGRATION_SELECT_ACCOUNTS.TYPE, status, data} }
export function asyncStartUpXeroIntegrationSelectAccounts (required, fnCloseDialog, UID, accounts) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_XERO_INTEGRATION_SELECT_ACCOUNTS)
    .post(`${BASE_URL}/startups/${UID}/xero_integration_select_accounts/`, { accounts })
    .then(response => { dispatch(actionStartUpXeroIntegrationSelectAccounts(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_XERO_INTEGRATION_SELECT_ACCOUNTS)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_XERO_INTEGRATION_SELECT_ACCOUNTS, error)) })
}

function actionStartDataIntegrationShow (data, status) { return {type: TYPE.START_UP_DATA_INTEGRATION_SHOW.TYPE, status, data} }
export function asyncStartDataIntegrationShow (required, fnCloseDialog, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_DATA_INTEGRATION_SHOW)
    .post(`${BASE_URL}/startups/${UID}/data_integration_show/`)
    .then(response => { dispatch(actionStartDataIntegrationShow(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.START_UP_DATA_INTEGRATION_SHOW)); fnCloseDialog && fnCloseDialog() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_DATA_INTEGRATION_SHOW, error)) })
}

function actionStartUpBankInstitutions (data, status) { return {type: TYPE.START_UP_BANK_ISTITUTIONS.TYPE, status, data} }
export function asyncStartUpBankInstitutions (required, search, callback) {
  return dispatch => getAxios(dispatch, required, TYPE.START_UP_BANK_ISTITUTIONS)
    .get(`${BASE_URL}/bank-institutions/`, { params: {search, limit: 10} })
    .then(response => {
      dispatch(actionStartUpBankInstitutions(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.START_UP_BANK_ISTITUTIONS))
      const options = []
      response.data.results.map(item => { options.push({value: item.id, label: item.name}) })
      callback(callback(null, {
        options,
        complete: true
      }))
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.START_UP_BANK_ISTITUTIONS, error)) })
}
