/* global FormData */
import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE_ACCELERATORS from '../../store/accelerators/accelerators.types'
import TYPE_START_UP from '../../store/startups/startups.types'
import TYPE_APP from '../../store/app/app.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionUploadImagesAccelerator (data, id, status) { return {type: TYPE_ACCELERATORS.POST_UPLOAD_IMAGES_ACCELERATOR.TYPE, status, data, id} }
function actionUploadImagesStartUp (data, id, status) { return {type: TYPE_START_UP.POST_UPLOAD_IMAGES_START_UP.TYPE, status, data, id} }
function actionUploadImagesPersonal (data, status) { return {type: TYPE_APP.POST_UPLOAD_IMAGES.TYPE, status, data} }
export function fnUploadImages (required, file, type, id, width, height) {
  let data = new FormData()
  data.append('file', file)
  width && data.append('width', width)
  height && data.append('height', height)

  return dispatch => getAxios(dispatch, required, TYPE_APP.POST_UPLOAD_IMAGES)
  .post(`${BASE_URL}/auth/upload/`, data)
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    type === 'accelerator' && dispatch(actionUploadImagesAccelerator(response.data, id, STATUS.SUCCESS))
    type === 'personal' && dispatch(actionUploadImagesPersonal(response.data, STATUS.SUCCESS))
    type === 'startup' && dispatch(actionUploadImagesStartUp(response.data, id, STATUS.SUCCESS))
    dispatch(requestSuccessHandler(TYPE_APP.POST_UPLOAD_IMAGES))
  })
  .catch(error => { dispatch(requestErrorHandler(TYPE_APP.POST_UPLOAD_IMAGES, error)) })
}
