import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/cash/cash.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetCashAll (data, status) { return {type: TYPE.GET_CASH_ALL.TYPE, status, data} }
export function asyncGetCashAll (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_CASH_ALL)
  .get(`${BASE_URL}/cash/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetCashAll(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_CASH_ALL)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_CASH_ALL, error)) })
}

function actionPatchCash (data, status) { return {type: TYPE.PATCH_CASH.TYPE, status, data} }
export function asyncPatchCash (required, addFunds, newTariffPlan) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_CASH)
  .patch(`${BASE_URL}/cash/`, { add_funds: addFunds, new_tariff_plan: newTariffPlan })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchCash(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_CASH)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_CASH, error)) })
}
