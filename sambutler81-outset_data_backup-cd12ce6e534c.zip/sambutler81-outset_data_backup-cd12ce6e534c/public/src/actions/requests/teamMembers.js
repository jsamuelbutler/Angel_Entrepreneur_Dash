import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/teamMembers/teamMembers.types'
import Pace from 'pace-progress'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionUpdateUsersListStartUp (data, status) { return {type: TYPE.UPDATE_USERS_LIST_START_UP.TYPE, status, data} }

function actionGetTeamMemberAll (data, status) { return {type: TYPE.GET_TEAM_MEMBER_ALL.TYPE, status, data} }
function actionGetStartupTeamMember (data, status) { return {type: TYPE.STARTUP_TEAM_MEMBERS.TYPE, status, data} }
function actionSetTeamMemberTodo (data, status) { return {type: TYPE.TEAM_MEMBERS_TODO.TYPE, status, data} }
export function asyncGetTeamMemberAll (required, accelerator, startup, ordering, role, roles, loadIgnore, callback) {
  if (loadIgnore) Pace.options.ignoreURLs = ['/api/team-members/']; Pace.start()
  return dispatch => getAxios(dispatch, required, TYPE.GET_TEAM_MEMBER_ALL)
  .get(`${BASE_URL}/team-members/`, { params: { accelerator, startup, role, roles, is_active: true, ordering } })
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    if (accelerator) { dispatch(actionGetTeamMemberAll(response.data, STATUS.SUCCESS)) } else { dispatch(actionGetStartupTeamMember(response.data, STATUS.SUCCESS)) }
    dispatch(actionSetTeamMemberTodo(response.data, STATUS.SUCCESS))
    callback && callback()
    dispatch(requestSuccessHandler(TYPE.GET_TEAM_MEMBER_ALL))
  })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_TEAM_MEMBER_ALL, error)) })
}

function actionDeleteTeamMember (data, status) { return {type: TYPE.DELETE_TEAM_MEMBER.TYPE, status, data} }
export function asyncDeleteTeamMember (required, UID, close) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_TEAM_MEMBER)
  .delete(`${BASE_URL}/team-members/${UID}/`)
  .then(response => { close && close(); dispatch(actionDeleteTeamMember(UID, STATUS.SUCCESS)); dispatch(actionUpdateUsersListStartUp(UID, STATUS.SUCCESS)); dispatch(actionDeleteTeamMember(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_TEAM_MEMBER)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_TEAM_MEMBER, error.data)) })
}

function actionGetTeamMember (data, status) { return {type: TYPE.GET_TEAM_MEMBER.TYPE, status, data} }
export function asyncGetTeamMember (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_TEAM_MEMBER)
  .get(`${BASE_URL}/team-members/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetTeamMember(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_TEAM_MEMBER)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_TEAM_MEMBER, error)) })
}

function actionPatchTeamMember (data, status) { return {type: TYPE.PATCH_TEAM_MEMBER.TYPE, status, data} }
export function asyncPatchTeamMember (required, fnCloseDialog, UID, firstName, lastName, roleInCompany, role, tags, facebook, firstTime, angel, accelerator, startup, image, googlePlus, isActive, linkedin, subscribe, github, skype, twitter, email) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_TEAM_MEMBER)
  .patch(`${BASE_URL}/team-members/${UID}/`, {facebook, first_name: firstName, last_name: lastName, first_time: firstTime, angel, accelerator, startup, role, tags, image, google_plus: googlePlus, is_active: isActive, linkedin, subscribe, github, skype, twitter, role_in_company: roleInCompany, email})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchTeamMember(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_TEAM_MEMBER)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_TEAM_MEMBER, error)) })
}
