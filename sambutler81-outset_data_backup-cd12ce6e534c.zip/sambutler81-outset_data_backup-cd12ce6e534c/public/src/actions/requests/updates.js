import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import Pace from 'pace-progress'
import TYPE from '../../store/updates/updates.types'
import { getAxios, requestSuccessHandler, requestErrorHandler, asyncGetStartUpAll } from '../../actions'

function actionGetUpdates (data, startup, status) { return {type: TYPE.GET_UPDATES_ALL.TYPE, status, startup, data} }
function actionSearchUpdates (data, idStartup, status) {
  return {
    type: TYPE.SEARCH_UPDATES_ALL.TYPE,
    status,
    idStartup,
    data
  }
}
export function asyncGetUpdates (required, cohort, startup, search) {
  if (search || search === '') {
    Pace.options.ignoreURLs = ['/api/updates?search=']
    Pace.start()
  }
  return dispatch => getAxios(dispatch, required, TYPE.GET_UPDATES_ALL)
    .get(`${BASE_URL}/updates/`, {params: {cohort, startup, search}})
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      (search || search === '') ? (Pace.options.ignoreURLs = [], Pace.start(), dispatch(actionSearchUpdates(response.data, startup, STATUS.SUCCESS))) : dispatch(actionGetUpdates(response.data, startup, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.GET_UPDATES_ALL))
    })
    .catch(error => {
      if (search || search === '') {
        Pace.options.ignoreURLs = []
        Pace.start()
      }
      dispatch(requestErrorHandler(TYPE.GET_UPDATES_ALL, error))
    })
}

function actionGetUpdate (data, status) { return {type: TYPE.GET_UPDATE.TYPE, status, data} }
export function asyncGetUpdate (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_UPDATE)
    .get(`${BASE_URL}/updates/${UID}/`)
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionGetUpdate(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.GET_UPDATE))
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.GET_UPDATE, error)) })
}

function actionPostUpdate (data, status) { return {type: TYPE.POST_UPDATE.TYPE, status, data} }
export function asyncPostUpdate (required,
                                 callback,
                                 title,
                                 overview,
                                 startup,
                                 kpis,
                                 links,
                                 sendTo,
                                 nextFocus,
                                 thankYous,
                                 cpuGoodUpdates,
                                 cpuNegativeUpdates,
                                 cpuNeedHelp,
                                 ruGoodUpdates,
                                 ruNegativeUpdates,
                                 ruNeedHelp,
                                 euGoodUpdates,
                                 euNegativeUpdates,
                                 euNeedHelp,
                                 pauGoodUpdates,
                                 pauNegativeUpdates,
                                 pauNeedHelp,
                                 peuGoodUpdates,
                                 peuNegativeUpdates,
                                 peuNeedHelp,
                                 pruGoodUpdates,
                                 pruNegativeUpdates,
                                 pruNeedHelp,
                                 fuGoodUpdates,
                                 fuNegativeUpdates,
                                 fuNeedHelp) {
  return dispatch => getAxios(dispatch, required, TYPE.POST_UPDATE)
    .post(`${BASE_URL}/updates/`, {
      title,
      overview,
      startup,
      kpis,
      links,
      send_to: sendTo,
      next_focus: nextFocus,
      thank_yous: thankYous,
      cpu_good_updates: cpuGoodUpdates,
      cpu_negative_updates: cpuNegativeUpdates,
      cpu_need_help: cpuNeedHelp,
      ru_good_updates: ruGoodUpdates,
      ru_negative_updates: ruNegativeUpdates,
      ru_need_help: ruNeedHelp,
      eu_good_updates: euGoodUpdates,
      eu_negative_updates: euNegativeUpdates,
      eu_need_help: euNeedHelp,
      pau_good_updates: pauGoodUpdates,
      pau_negative_updates: pauNegativeUpdates,
      pau_need_help: pauNeedHelp,
      peu_good_updates: peuGoodUpdates,
      peu_negative_updates: peuNegativeUpdates,
      peu_need_help: peuNeedHelp,
      pru_good_updates: pruGoodUpdates,
      pru_negative_updates: pruNegativeUpdates,
      pru_need_help: pruNeedHelp,
      fu_good_updates: fuGoodUpdates,
      fu_negative_updates: fuNegativeUpdates,
      fu_need_help: fuNeedHelp
    })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      callback && callback()
      dispatch(asyncGetStartUpAll(null))
      dispatch(asyncGetUpdates(null, null, startup, null))
      dispatch(actionPostUpdate(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.POST_UPDATE))
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.POST_UPDATE, error)) })
}

function actionPatchUpdate (data, status) { return {type: TYPE.PATCH_UPDATE.TYPE, status, data} }
export function asyncPatchUpdate (required, UID,
                                  title,
                                  overview,
                                  startup,
                                  kpis,
                                  links,
                                  sendTo,
                                  nextFocus,
                                  thankYous,
                                  cpuGoodUpdates,
                                  cpuNegativeUpdates,
                                  cpuNeedHelp,
                                  pauGoodUpdates,
                                  pauNegativeUpdates,
                                  pauNeedHelp,
                                  peuGoodUpdates,
                                  peuNegativeUpdates,
                                  peuNeedHelp,
                                  pruGoodUpdates,
                                  pruNegativeUpdates,
                                  pruNeedHelp,
                                  fuGoodUpdates,
                                  fuNegativeUpdates,
                                  fuNeedHelp) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_UPDATE)
    .patch(`${BASE_URL}/updates/${UID}/`, {
      title,
      overview,
      startup,
      kpis,
      links,
      send_to: sendTo,
      next_focus: nextFocus,
      thank_yous: thankYous,
      cpu_good_updates: cpuGoodUpdates,
      cpu_negative_updates: cpuNegativeUpdates,
      cpu_need_help: cpuNeedHelp,
      pau_good_updates: pauGoodUpdates,
      pau_negative_updates: pauNegativeUpdates,
      pau_need_help: pauNeedHelp,
      peu_good_updates: peuGoodUpdates,
      peu_negative_updates: peuNegativeUpdates,
      peu_need_help: peuNeedHelp,
      pru_good_updates: pruGoodUpdates,
      pru_negative_updates: pruNegativeUpdates,
      pru_need_help: pruNeedHelp,
      fu_good_updates: fuGoodUpdates,
      fu_negative_updates: fuNegativeUpdates,
      fu_need_help: fuNeedHelp
    })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionPatchUpdate(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.PATCH_UPDATE))
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_UPDATE, error)) })
}

