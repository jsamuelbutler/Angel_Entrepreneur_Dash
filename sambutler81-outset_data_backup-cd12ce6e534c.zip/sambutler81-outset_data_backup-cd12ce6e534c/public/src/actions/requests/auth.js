/* global localStorage */
import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/auth/auth.types'
import { fnGoToLoginScreen } from '../../utils/helpers'
import { history } from '../../store'
import { getAxios, requestSuccessHandler, requestErrorHandler, actionGetUserData, asyncGetFirstCohort } from '../../actions'

function actionLoginUser (data, statusAuth, isAuthenticated, status, loginScreen) { return {type: TYPE.AUTHENTICATED.TYPE, status, data, isAuthenticated, statusAuth, loginScreen} }
export function asyncLoginUser (required, username, password) {
  return dispatch => getAxios(dispatch, required, TYPE.AUTHENTICATED, true)
  .post(`${BASE_URL}/auth/`, { username, password })
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    dispatch(actionLoginUser(response.data, null, true, STATUS.SUCCESS, !response.data.login_screen || response.data.login_screen === 'null' || response.data.login_screen === 'undefined' ? '/activity' : response.data.login_screen))
    dispatch(requestSuccessHandler(TYPE.AUTHENTICATED))
    localStorage.setItem('token', response.data.token)
    localStorage.setItem('loginScreen', !response.data.login_screen || response.data.login_screen === 'null' || response.data.login_screen === 'undefined' ? '/activity' : response.data.login_screen)
    dispatch(actionGetUserData(response.data.token))
    dispatch(asyncGetFirstCohort('required', response.data.token))
    process.env.NODE_ENV !== 'test' && fnGoToLoginScreen()
  })
  .catch(error => { dispatch(actionLoginUser(error.response.data, 'error', false, STATUS.FAILURE)); dispatch(requestErrorHandler(TYPE.AUTHENTICATED, error)) })
}

function actionRegisterUser (data, statusAuth, isAuthenticated, status) { return {type: TYPE.REGISTRATION.TYPE, status, data, isAuthenticated, statusAuth} }
export function asyncRegisterUser (required, password, invite, firstName, lastName, email) {
  return dispatch => getAxios(dispatch, required, TYPE.REGISTRATION, true)
  .post(`${BASE_URL}/auth/signup/`, { email, password, invite, first_name: firstName, last_name: lastName })
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    if (invite) {
      dispatch(actionRegisterUser(response.data, null, true, STATUS.SUCCESS))
      localStorage.setItem('loginScreen', '/activity')
      localStorage.setItem('token', response.data.token)
      dispatch(actionGetUserData(response.data.token))
      dispatch(asyncGetFirstCohort('required', response.data.token))
      process.env.NODE_ENV !== 'test' && fnGoToLoginScreen()
    } else { dispatch(actionRegisterUser(response.data, 'email_sent', false, STATUS.SUCCESS)) }
    dispatch(requestSuccessHandler(TYPE.REGISTRATION))
  })
  .catch(error => { dispatch(actionRegisterUser(error.response.data, 'error', false, STATUS.FAILURE)); dispatch(requestErrorHandler(TYPE.REGISTRATION, error)) })
}

function actionResetPassword (data, statusAuth, status) { return {type: TYPE.RESET_PASSWORD.TYPE, status, data, isAuthenticated: false, statusAuth} }
export function asyncResetPassword (required, email) {
  return dispatch => getAxios(dispatch, required, TYPE.RESET_PASSWORD, true)
  .post(`${BASE_URL}/auth/reset_password/`, {email})
  .then(response => { dispatch(actionResetPassword(response.data, 'email_reset_sent', STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.RESET_PASSWORD)) })
  .catch(error => { dispatch(actionResetPassword(error.response.data, 'error', STATUS.FAILURE)); dispatch(requestErrorHandler(TYPE.RESET_PASSWORD, error)) })
}

function actionEmailConfirm (data, statusAuth, isAuthenticated, status) { return {type: TYPE.EMAIL_CONFIRM.TYPE, status, data, isAuthenticated, statusAuth} }
export function asyncEmailConfirm (required, token, cbError) {
  return dispatch => getAxios(dispatch, required, TYPE.EMAIL_CONFIRM, true)
  .post(`${BASE_URL}/auth/email_confirm/`, { token })
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    dispatch(actionEmailConfirm(response.data, null, true, STATUS.SUCCESS))
    dispatch(requestSuccessHandler(TYPE.EMAIL_CONFIRM))
    localStorage.setItem('loginScreen', '/activity')
    localStorage.setItem('token', response.data.token)
    dispatch(actionGetUserData(response.data.token))
    dispatch(asyncGetFirstCohort('required', response.data.token))
    process.env.NODE_ENV !== 'test' && fnGoToLoginScreen()
  })
  .catch(error => { dispatch(actionEmailConfirm(error.response.data, 'error', false, STATUS.FAILURE)); dispatch(requestErrorHandler(TYPE.EMAIL_CONFIRM, error)); fnGoToLoginScreen() })
}

function actionResetPasswordConfirm (data, statusAuth, isAuthenticated, status) { return {type: TYPE.RESET_PASSWORD_CONFIRM.TYPE, status, data, isAuthenticated, statusAuth} }
export function asyncResetPasswordConfirm (required, uidb64, token, newPassword) {
  return dispatch => getAxios(dispatch, required, TYPE.RESET_PASSWORD_CONFIRM, true)
  .post(`${BASE_URL}/auth/reset_password_confirm/`, { uidb64, token, new_password: newPassword })
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    dispatch(actionResetPasswordConfirm(response.data, null, true, STATUS.SUCCESS))
    dispatch(requestSuccessHandler(TYPE.RESET_PASSWORD_CONFIRM))
    localStorage.setItem('token', response.data.token)
    process.env.NODE_ENV !== 'test' && fnGoToLoginScreen()
  })
  .catch(error => { dispatch(actionResetPasswordConfirm(error.response.data, 'email_not_sent', false, STATUS.FAILURE)); dispatch(requestErrorHandler(TYPE.RESET_PASSWORD_CONFIRM, error)) })
}

function actionSetLoginScreen (data, status) { return {type: TYPE.SET_LOGIN_SCREEN.TYPE, status, data} }
export function asyncSetLoginScreen (required, loginScreen) {
  return dispatch => getAxios(dispatch, required, TYPE.SET_LOGIN_SCREEN)
  .post(`${BASE_URL}/auth/login_screen/`, {login_screen: loginScreen})
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    localStorage.setItem('loginScreen', loginScreen)
    localStorage.setItem('token', response.data.token)
    dispatch(actionSetLoginScreen(response.data, STATUS.SUCCESS))
    dispatch(requestSuccessHandler(TYPE.SET_LOGIN_SCREEN))
  })
  .catch(error => { dispatch(requestErrorHandler(TYPE.SET_LOGIN_SCREEN, error)) })
}

function actionChangePassword (data, status) { return {type: TYPE.CHANGE_PASSWORD.TYPE, status, data} }
export function asyncChangePassword (required, currentPassword, newPassword, callback) {
  return dispatch => getAxios(dispatch, required, TYPE.CHANGE_PASSWORD)
  .post(`${BASE_URL}/auth/change_password/`, { current_password: currentPassword, new_password: newPassword })
  .then(response => { callback && callback(); dispatch(actionChangePassword(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.CHANGE_PASSWORD)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.CHANGE_PASSWORD, error)) })
}

function actionRemoveFeedback (data, status) { return {type: TYPE.REMOVE_FEEDBACK.TYPE, status, data} }
export function asyncRemoveFeedback (required, callback, contact, message, reason) {
  return dispatch => getAxios(dispatch, required, TYPE.REMOVE_FEEDBACK, !!contact)
    .post(`${BASE_URL}/auth/feedback/`, { contact, message, reason })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionRemoveFeedback(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.REMOVE_FEEDBACK))
      callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.REMOVE_FEEDBACK, error)) })
}

function actionUnsubscribe (data, status) { return {type: TYPE.UNSUBSCRIBE.TYPE, status, data} }
export function asyncUnsubscribe (required, callback, contact, token, subscribe) {
  return dispatch => getAxios(dispatch, required, TYPE.UNSUBSCRIBE, !!contact)
    .post(`${BASE_URL}/auth/unsubscribe/`, { token, subscribe })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionUnsubscribe(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.UNSUBSCRIBE))
      callback && callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.UNSUBSCRIBE, error)) })
}

function actionSocial (data, status) { return {type: TYPE.SOCIAL.TYPE, status, data} }
export function asyncSocial (required, callback, provider, invite) {
  return dispatch => getAxios(dispatch, required, TYPE.SOCIAL, true)
    .post(`${BASE_URL}/auth/social/`, { provider, invite })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      localStorage.setItem('provider', provider)
      document.location.href = response.data.redirect
      dispatch(actionSocial(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.SOCIAL))
      callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.SOCIAL, error)) })
}

function actionSocialAuth (data, status) { return {type: TYPE.SOCIAL_AUTH.TYPE, status, data} }
export function asyncSocialAuth (required, callback, code, state, provider) {
  return dispatch => getAxios(dispatch, required, TYPE.SOCIAL_AUTH, true)
    .post(`${BASE_URL}/auth/social_auth/`, { code, state, provider })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionSocialAuth(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.SOCIAL_AUTH))
      dispatch(actionLoginUser(response.data, null, true, STATUS.SUCCESS, !response.data.login_screen || response.data.login_screen === 'null' || response.data.login_screen === 'undefined' ? '/activity' : response.data.login_screen))
      dispatch(requestSuccessHandler(TYPE.AUTHENTICATED))
      localStorage.setItem('token', response.data.token)
      localStorage.setItem('loginScreen', !response.data.login_screen || response.data.login_screen === 'null' || response.data.login_screen === 'undefined' ? '/activity' : response.data.login_screen)
      dispatch(actionGetUserData(response.data.token))
      dispatch(asyncGetFirstCohort('required', response.data.token))
      process.env.NODE_ENV !== 'test' && fnGoToLoginScreen()
      localStorage.removeItem('provider')
      callback()
    })
    .catch(error => { localStorage.removeItem('provider'); dispatch(requestErrorHandler(TYPE.SOCIAL_AUTH, error)); history.push('/login') })
}

function actionGetOauthAccounts (data, status) { return {type: TYPE.GET_OAUTH_ACCOUNTS.TYPE, status, data} }
export function asyncGetOauthAccounts (required, callback) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_OAUTH_ACCOUNTS, false)
    .get(`${BASE_URL}/oauth-application/`)
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionGetOauthAccounts(response.data, STATUS.SUCCESS))
      dispatch(requestSuccessHandler(TYPE.GET_OAUTH_ACCOUNTS))
      callback && callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.GET_OAUTH_ACCOUNTS, error)) })
}

function actionPostOauthAccounts (data, status) { return {type: TYPE.POST_OAUTH_ACCOUNTS.TYPE, status, data} }
export function asyncPostOauthAccounts (required, callback, redirectUris, name, clientType, authorizationGrantType) {
  return dispatch => getAxios(dispatch, required, TYPE.POST_OAUTH_ACCOUNTS, false)
    .post(`${BASE_URL}/oauth-application/`, { redirect_uris: redirectUris, name, client_type: clientType, authorization_grant_type: authorizationGrantType })
    .then(response => {
      if (!response.data) { throw ERR_NO_DATA }
      dispatch(actionPostOauthAccounts(response.data, STATUS.SUCCESS))
      dispatch(asyncGetOauthAccounts(null))
      dispatch(requestSuccessHandler(TYPE.POST_OAUTH_ACCOUNTS))
      callback && callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.POST_OAUTH_ACCOUNTS, error)) })
}

function actionDeleteOauthAccounts (data, status) { return {type: TYPE.DELETE_OAUTH_ACCOUNTS.TYPE, status, data} }
export function asyncDeleteOauthAccounts (required, callback, ID) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_OAUTH_ACCOUNTS, false)
    .delete(`${BASE_URL}/oauth-application/${ID}/`)
    .then(response => {
      dispatch(actionDeleteOauthAccounts(response.data, STATUS.SUCCESS))
      dispatch(asyncGetOauthAccounts(null))
      dispatch(requestSuccessHandler(TYPE.DELETE_OAUTH_ACCOUNTS))
      callback && callback()
    })
    .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_OAUTH_ACCOUNTS, error)) })
}
