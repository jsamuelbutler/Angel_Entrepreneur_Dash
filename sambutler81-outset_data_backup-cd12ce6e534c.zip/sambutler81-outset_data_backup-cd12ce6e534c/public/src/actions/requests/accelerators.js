import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/accelerators/accelerators.types'
import { getAxios, requestSuccessHandler, requestErrorHandler, actionClearStore } from '../../actions'
import { history } from '../../store'

function actionAddAcceleratorsInvite (data, status) { return {type: TYPE.ADD_ACCELERATOR_INVITE.TYPE, status, data} }
export function asyncAddAcceleratorsInvite (required, fnCloseDialog, UID, emails, role, message) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_ACCELERATOR_INVITE)
  .post(`${BASE_URL}/accelerators/${UID}/invite/`, { emails, role, message })
  .then(response => { dispatch(actionAddAcceleratorsInvite(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_ACCELERATOR_INVITE)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_ACCELERATOR_INVITE, error)) })
}

function actionDeleteAccelerator (data, status) { return {type: TYPE.DELETE_ACCELERATOR.TYPE, status, data} }
export function asyncDeleteAccelerator (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_ACCELERATOR)
  .delete(`${BASE_URL}/accelerators/${UID}/`)
  .then((response) => { dispatch(actionDeleteAccelerator(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_ACCELERATOR)); dispatch(actionClearStore); history.push('/login') })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_ACCELERATOR, error)) })
}

function actionGetAccelerator (data, status) { return {type: TYPE.GET_ACCELERATOR.TYPE, status, cohorts: data.cohorts, deleted: data.deleted, id: data.id, logo: data.logo, name: data.name, website: data.website} }
export function asyncGetAccelerator (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_ACCELERATOR)
  .get(`${BASE_URL}/accelerators/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetAccelerator(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_ACCELERATOR)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_ACCELERATOR, error)) })
}

function actionPatchAccelerator (data, status) { return {type: TYPE.PATCH_ACCELERATOR.TYPE, status, cohorts: data.cohorts, deleted: data.deleted, id: data.id, logo: data.logo, name: data.name, website: data.website} }
export function asyncPatchAccelerator (required, UID, {website, logo, name}) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_ACCELERATOR)
  .patch(`${BASE_URL}/accelerators/${UID}/`, { website, logo, name })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchAccelerator(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_ACCELERATOR)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_ACCELERATOR, error)) })
}
