import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/KPI/KPI.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetChartKPI (data, status) { return {type: TYPE.GET_CHART_KPI.TYPE, status, data} }
export function asyncGetChartKPI (required, cohort, startup, scroll, year) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_CHART_KPI)
  .get(`${BASE_URL}/kpi-chart/`, {params: {cohort, startup, year}})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } scroll && scroll(); dispatch(actionGetChartKPI(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_CHART_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_CHART_KPI, error)) })
}

function actionAddKPI (data, status) { return {type: TYPE.ADD_KPI.TYPE, status, data} }
export function asyncAddKPI (required, close, scroll, cohort, startup, kpiPk, compareToKpi, period, chartType, position, kpi, cohortGet, startupGet, year) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_KPI)
  .post(`${BASE_URL}/kpi/`, { cohort, startup, compare_to_kpi: compareToKpi, period, chart_type: chartType, position, kpi: !kpi ? kpiPk : kpi })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionAddKPI(response.data, STATUS.SUCCESS)); close && close(); dispatch(asyncGetChartKPI(null, cohortGet, startupGet, scroll, year)); dispatch(requestSuccessHandler(TYPE.ADD_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_KPI, error)) })
}

function actionDeleteKPI (data, status) { return {type: TYPE.DELETE_KPI.TYPE, status, data} }
export function asyncDeleteKPI (required, UID, cohort, startup, year) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_KPI)
  .delete(`${BASE_URL}/kpi/${UID}/`)
  .then(response => { dispatch(actionDeleteKPI(response.data, STATUS.SUCCESS)); dispatch(asyncGetChartKPI(null, cohort, startup, null, year)); dispatch(requestSuccessHandler(TYPE.DELETE_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_KPI, error)) })
}

function actionGetKPI (data, status) { return {type: TYPE.GET_KPI.TYPE, status, data} }
export function asyncGetKPI (required, UID, callback) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_KPI)
  .get(`${BASE_URL}/kpi/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } callback && callback(); dispatch(actionGetKPI(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_KPI, error)) })
}

function actionPatchKPI (data, status) { return {type: TYPE.PATCH_KPI.TYPE, status, data} }
export function asyncPatchKPI (required, UID, close, kpiPk, compareToKpi, period, chartType, kpi, cohort, startup, cohortGet, startupGet) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_KPI)
  .patch(`${BASE_URL}/kpi/${UID}/`, { compare_to_kpi: compareToKpi, period, chart_type: chartType, kpi: !kpi ? kpiPk : kpi, cohort, startup })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchKPI(response.data, STATUS.SUCCESS)); close && close(); dispatch(asyncGetChartKPI(null, cohortGet, startupGet)); dispatch(requestSuccessHandler(TYPE.PATCH_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_KPI, error)) })
}

function actionGetDefinedKPI (data, status) { return {type: TYPE.GET_DEFINED_KPI.TYPE, status, data} }
export function asyncGetDefinedKPI (required, cohort = null, startup = null) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_DEFINED_KPI)
  .get(`${BASE_URL}/defined-kpi/`, {params: {cohort, startup}})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetDefinedKPI(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_DEFINED_KPI)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_DEFINED_KPI, error)) })
}

function actionGetYearsKPI (data, status) { return {type: TYPE.GET_YEARS_KPI.TYPE, status, data} }
export function asyncGetYearsKPI (required, cohort = null, startup = null) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_YEARS_KPI)
    .get(`${BASE_URL}/kpi-table/years/`, {params: {cohort, startup}})
    .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetYearsKPI(response.data, cohort, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_YEARS_KPI)) })
    .catch(error => { dispatch(requestErrorHandler(TYPE.GET_YEARS_KPI, error)) })
}

function actionGetYearsStatisticsKPI (data, cohort, startup, status) { return {type: TYPE.GET_YEARS_STATISTICS_KPI.TYPE, status, data, cohort, startup} }
export function asyncGetYearsStatisticsKPI (required, cohort = null, startup = null, year = null) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_YEARS_STATISTICS_KPI)
    .get(`${BASE_URL}/kpi-table/`, {params: {cohort, startup, year}})
    .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetYearsStatisticsKPI(response.data, cohort, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_YEARS_STATISTICS_KPI)) })
    .catch(error => { dispatch(requestErrorHandler(TYPE.GET_YEARS_STATISTICS_KPI, error)) })
}

function actionGetChartKPIValues (data, status) { return {type: TYPE.GET_CHART_KPI_VALUES.TYPE, status, data} }
export function asyncGetChartKPIValues (required, callback, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_CHART_KPI_VALUES)
    .get(`${BASE_URL}/kpi-chart/${UID}/values/`)
    .then(response => { if (!response.data) { throw ERR_NO_DATA } callback && callback(); dispatch(actionGetChartKPIValues(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_CHART_KPI_VALUES)) })
    .catch(error => { dispatch(requestErrorHandler(TYPE.GET_CHART_KPI_VALUES, error)) })
}

function actionPostChartKPIValues (data, status) { return {type: TYPE.POST_CHART_KPI_VALUES.TYPE, status, data} }
export function asyncPostChartKPIValues (required, callback, UID, kpi, value, created) {
  return dispatch => getAxios(dispatch, required, TYPE.POST_CHART_KPI_VALUES)
    .post(`${BASE_URL}/kpi-chart/${UID}/values/`, {kpi, value, created})
    .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPostChartKPIValues(response.data, STATUS.SUCCESS)); dispatch(asyncGetChartKPIValues(null, null, UID)); dispatch(requestSuccessHandler(TYPE.POST_CHART_KPI_VALUES)); callback && callback() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.POST_CHART_KPI_VALUES, error)); dispatch(asyncGetChartKPIValues(null, null, UID)) })
}

function actionPatchChartKPIValues (data, status) { return {type: TYPE.PATCH_CHART_KPI_VALUES.TYPE, status, data} }
export function asyncPatchChartKPIValues (required, callback, UID, id, kpi, value, created) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_CHART_KPI_VALUES)
    .patch(`${BASE_URL}/kpi-chart/${UID}/values/${id}/`, {kpi, value, created})
    .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchChartKPIValues(response.data, STATUS.SUCCESS)); dispatch(asyncGetChartKPIValues(null, null, UID)); dispatch(requestSuccessHandler(TYPE.PATCH_CHART_KPI_VALUES)); callback && callback() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_CHART_KPI_VALUES, error)); dispatch(asyncGetChartKPIValues(null, null, UID)) })
}

function actionDeleteChartKPIValues (data, status) { return {type: TYPE.DELETE_CHART_KPI_VALUES.TYPE, status, data} }
export function asyncDeleteChartKPIValues (required, callback, UID, id) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_CHART_KPI_VALUES)
    .delete(`${BASE_URL}/kpi-chart/${UID}/values/${id}/`)
    .then(response => { dispatch(actionDeleteChartKPIValues(response.data, STATUS.SUCCESS)); dispatch(asyncGetChartKPIValues(null, null, UID)); dispatch(requestSuccessHandler(TYPE.DELETE_CHART_KPI_VALUES)); callback && callback() })
    .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_CHART_KPI_VALUES, error)); dispatch(asyncGetChartKPIValues(null, null, UID)) })
}
