import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/todos/todos.types'
import Pace from 'pace-progress'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetTodosAll (data, itCompany, companyTeam, startup, status) { return {type: TYPE.GET_TODOS_ALL.TYPE, status, itCompany, companyTeam, startup, data} }
function actionSearchTodos (data, itCompany, idx, status) { return {type: TYPE.SEARCH_TODO.TYPE, status, data, itCompany, idx} }

export function asyncGetTodosAll (required, accelerator, cohort, startup, assignTo, isComplete, companyTeam, search, callback) {
  if (search || search === '') { Pace.options.ignoreURLs = ['/api/todos?search=']; Pace.start() }
  return dispatch => getAxios(dispatch, required, TYPE.GET_TODOS_ALL)
  .get(`${BASE_URL}/todos/`, { params: { accelerator, cohort, startup, assign_to: assignTo, is_complete: isComplete, search } })
  .then(response => {
    if (search || search === '') { Pace.options.ignoreURLs = []; Pace.start() }
    if (!response.data) { throw ERR_NO_DATA }
    (search || search === '') ? dispatch(actionSearchTodos(response.data, !!startup, startup || assignTo, STATUS.SUCCESS)) : (
    dispatch(actionGetTodosAll(response.data, !!accelerator, companyTeam, startup, STATUS.SUCCESS)))
    dispatch(requestSuccessHandler(TYPE.GET_TODOS_ALL))
    callback && callback()
  })
  .catch(error => { if (search || search === '') { Pace.options.ignoreURLs = []; Pace.start() } dispatch(requestErrorHandler(TYPE.GET_TODOS_ALL, error)) })
}

function actionGetTodosStatistic (data, status) { return {type: TYPE.GET_TODOS_STATISTIC.TYPE, status, data} }
export function asyncGetTodosStatistic (required, cohort, startup) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_TODOS_STATISTIC)
  .get(`${BASE_URL}/todos/statistic/`, { params: { cohort, startup } })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetTodosStatistic(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_TODOS_STATISTIC)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_TODOS_STATISTIC, error)) })
}

function actionAddTodos (data, companyTeam, status) { return {type: TYPE.ADD_TODOS.TYPE, status, companyTeam, data} }
export function asyncAddTodos (required, fnCloseDialog, startup, name, description, assignTo, dueDate, companyTeam, isComplete) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_TODOS)
  .post(`${BASE_URL}/todos/`, {startup, name, description, assign_to: assignTo, due_date: dueDate, is_complete: isComplete})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionAddTodos(response.data, companyTeam, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_TODOS)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_TODOS, error)) })
}

function actionDeleteTodos (data, status) { return {type: TYPE.DELETE_TODOS.TYPE, status, data} }
export function asyncDeleteTodos (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_TODOS)
  .delete(`${BASE_URL}/todos/${UID}/`)
  .then(response => { dispatch(actionDeleteTodos(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_TODOS)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_TODOS, error.data)) })
}

function actionPatchTodos (data, companyTeam, status) { return {type: TYPE.PATCH_TODOS.TYPE, status, companyTeam, data} }
export function asyncPatchTodos (required, fnCloseDialog, UID, startup, name, description, assignTo, dueDate, note, isComplete, companyTeam) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_TODOS)
  .put(`${BASE_URL}/todos/${UID}/`, {startup, name, description, assign_to: assignTo, due_date: dueDate, note, is_complete: isComplete})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchTodos(response.data, companyTeam, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_TODOS)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_TODOS, error)) })
}
