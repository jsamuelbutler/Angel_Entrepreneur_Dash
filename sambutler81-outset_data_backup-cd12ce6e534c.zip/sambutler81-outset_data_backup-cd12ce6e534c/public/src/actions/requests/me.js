/* global localStorage */
import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/me/me.types'
import TYPE_PLANS from '../../store/plans/plans.types'
import TYPE_APP from '../../store/app/app.types'
import { getAxios, requestSuccessHandler, requestErrorHandler, actionGetUserData, actionClearStore } from '../../actions'

// function actionGetMe (data, status) { return {type: TYPE.GET_ME_ALL.TYPE, status, data} }
function actionGetMeAppGoogle (data, status) { return {type: TYPE_APP.GET_USER_DATA_GOOGLE.TYPE, status, data} }
export function asyncGetMe (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_ME_ALL)
  .get(`${BASE_URL}/me/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetMeAppGoogle(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_ME_ALL)); dispatch(actionGetUserData(response.data.token)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_ME_ALL, error)) })
}

function actionDeleteMe (data, status) { return {type: TYPE.DELETE_ME.TYPE, status, data} }
export function asyncDeleteMe (required) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_ME)
  .delete(`${BASE_URL}/me/`)
  .then(response => { dispatch(actionDeleteMe(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_ME)); dispatch(actionClearStore) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_ME, error)) })
}

function actionGetMeCash (data, status) { return {type: TYPE.GET_ME_CASH.TYPE, status, data} }
export function asyncGetMeCash (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_ME_CASH)
  .get(`${BASE_URL}/me/cash/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetMeCash(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_ME_CASH)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_ME_CASH, error)) })
}

function actionPatchMeCashPlans (data, status) { return {type: TYPE_PLANS.PATCH_ME_CASH_PLANS.TYPE, status, data} }
function actionPatchMeCash (data, status) { return {type: TYPE.PATCH_ME_CASH.TYPE, status, data} }
export function asyncPatchMeCash (required, acceptedOptions, token, newPlan) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_ME_CASH)
  .put(`${BASE_URL}/me/cash/`, {accepted_options: acceptedOptions, token, new_plan: newPlan})
  .then((response) => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetUserData(response.data.token)); dispatch(actionPatchMeCash(response.data, STATUS.SUCCESS)); dispatch(actionPatchMeCashPlans(response.data, STATUS.SUCCESS)); response.data.token && localStorage.setItem('token', response.data.token); dispatch(requestSuccessHandler(TYPE.PATCH_ME_CASH)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_ME_CASH, error)) })
}

function actionPatchMe (data, status) { return {type: TYPE.PATCH_ME.TYPE, status, data} }
export function asyncPatchMe (required, image, firstName, lastName, angel, linkedin, email, subscribe) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_ME)
  .patch(`${BASE_URL}/me/`, {image, first_name: firstName, last_name: lastName, angel, linkedin, subscribe, email})
  .then((response) => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchMe(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_ME)); localStorage.setItem('token', response.data.token); dispatch(actionGetUserData(response.data.token)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_ME, error)) })
}
