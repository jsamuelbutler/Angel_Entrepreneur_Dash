import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/cohorts/cohorts.types'
import STARTUP_TYPE from '../../store/startups/startups.types'
import ACTIVITIES_TYPE from '../../store/activities/activities.types'

import KPI_TYPE from '../../store/KPI/KPI.types'
import { getAxios, requestSuccessHandler, requestErrorHandler, actionSetActiveFund, asyncGetStartUpAll } from '../../actions'

function actionGetCohortAll (data, status) { return {type: TYPE.GET_COHORT_ALL.TYPE, status, data} }
export function asyncGetCohortAll (required, activeFund, setFund) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_COHORT_ALL)
  .get(`${BASE_URL}/cohorts/`)
  .then(response => {
    if (!response.data) { throw ERR_NO_DATA }
    setFund && setFund()
    response.data && response.data.length && activeFund && dispatch(actionSetActiveFund({id: response.data[0].id, label: response.data[0].name, value: 0}, STATUS.SUCCESS)) && dispatch(asyncGetStartUpAll(null, response.data[0].id))
    dispatch(actionGetCohortAll(response.data, STATUS.SUCCESS))
    dispatch(requestSuccessHandler(TYPE.GET_COHORT_ALL))
  })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_COHORT_ALL, error)) })
}
function actionGetCohortActivities (data, status) { return {type: ACTIVITIES_TYPE.GET_ACTIVITIES_STARTUPS.TYPE, status, data} }
export function asyncGetCohortActivities (required, cohort) {
  return dispatch => getAxios(dispatch, required, ACTIVITIES_TYPE.GET_ACTIVITIES_STARTUPS.TYPE)
  .get(`${BASE_URL}/cohorts/${cohort}/activities/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetCohortActivities(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(ACTIVITIES_TYPE.GET_ACTIVITIES_STARTUPS.TYPE)) })
  .catch(error => { dispatch(requestErrorHandler(ACTIVITIES_TYPE.GET_ACTIVITIES_STARTUPS.TYPE, error)) })
}

function actionAddCohort (data, status) { return {type: TYPE.ADD_COHORT.TYPE, status, data} }
function actionGetStartUpAll (data, id, status) { return {type: STARTUP_TYPE.GET_START_UP_ALL.TYPE, status, data, id} }
export function asyncAddCohort (required, fnCloseDialog, accelerator, name, startDate, endDate) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_COHORT)
  .post(`${BASE_URL}/cohorts/`, {accelerator, start_date: startDate, end_date: endDate, name})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } fnCloseDialog && fnCloseDialog(); dispatch(actionAddCohort(response.data, STATUS.SUCCESS)); dispatch(actionSetActiveFund({id: response.data.id, label: response.data.name, value: response.data.id}, STATUS.SUCCESS)); dispatch(actionGetStartUpAll([], null, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_COHORT)); dispatch(asyncGetCohortAll(null)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_COHORT, error)) })
}

function actionDeleteCohort (data, id, status) { return {type: TYPE.DELETE_COHORT.TYPE, status, data, id} }
export function asyncDeleteCohort (required, UID, activeFund, setFund) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_COHORT)
  .delete(`${BASE_URL}/cohorts/${UID}/`)
  .then(response => { dispatch(actionDeleteCohort(response.data, UID, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_COHORT)); dispatch(asyncGetCohortAll(null, activeFund, setFund)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_COHORT, error)) })
}

function actionGetCohort (data, status) { return {type: TYPE.GET_COHORT.TYPE, status, data} }
export function asyncGetCohort (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_COHORT)
  .get(`${BASE_URL}/cohorts/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetCohort(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_COHORT)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_COHORT, error)) })
}

function actionPatchCohort (data, status) { return {type: TYPE.PATCH_COHORT.TYPE, status, data} }
export function asyncPatchCohort (required, close, UID, accelerator, name, startDate, endDate) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_COHORT)
  .patch(`${BASE_URL}/cohorts/${UID}/`, {accelerator, start_date: startDate, end_date: endDate, name})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchCohort(response.data, STATUS.SUCCESS)); close && close(); dispatch(requestSuccessHandler(TYPE.PATCH_COHORT)); dispatch(asyncGetCohortAll(null)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_COHORT, error)) })
}

function actionGetPortfolioStatistic (data, status) { return {type: KPI_TYPE.GET_PORTFOLIO_STATISTIC.TYPE, status, data} }
export function asyncGetPortfolioStatistic (required, UID) {
  return dispatch => getAxios(dispatch, required, KPI_TYPE.GET_PORTFOLIO_STATISTIC)
  .get(`${BASE_URL}/cohorts/${UID}/portfolio_statistic/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetPortfolioStatistic(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(KPI_TYPE.GET_PORTFOLIO_STATISTIC)) })
  .catch(error => { dispatch(requestErrorHandler(KPI_TYPE.GET_PORTFOLIO_STATISTIC, error)) })
}
