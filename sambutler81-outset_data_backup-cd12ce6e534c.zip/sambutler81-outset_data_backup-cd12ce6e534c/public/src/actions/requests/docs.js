/* global FormData, localStorage, atob */
import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/docs/docs.types'
import Pace from 'pace-progress'
import TYPE_APP from '../../store/app/app.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetDocsAll (data, cohort, startup, parent, status) { return {type: TYPE.GET_DOCS_ALL.TYPE, status, cohort, parent, startup, data} }
function actionSearchDocs (data, cohort, startup, parent, status) { return {type: TYPE.SEARCH_DOCS.TYPE, status, cohort, parent, startup, data} }
export function asyncGetDocsAll (required, cohort, parent, startup, search, extension, type) {
  if (search || search === '') { Pace.options.ignoreURLs = ['/api/docs?search=']; Pace.start() }
  if (parent || startup) { Pace.options.ignoreURLs = ['/api/docs/?parent=']; Pace.start() } // null, null, file.id, file.startup
  return dispatch => getAxios(dispatch, required, TYPE.GET_DOCS_ALL)
  .get(`${BASE_URL}/docs/`, {params: {parent, cohort, startup, extension, search, type, top_level: (parent || search ? 'False' : 'True')}})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } (search || search === '') ? (Pace.options.ignoreURLs = [], Pace.start(), dispatch(actionSearchDocs(response.data, cohort, startup, parent, STATUS.SUCCESS))) : dispatch(actionGetDocsAll(response.data, cohort, startup, parent, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_DOCS_ALL)) })
  .catch(error => { if (search || search === '') { Pace.options.ignoreURLs = []; Pace.start() } dispatch(requestErrorHandler(TYPE.GET_DOCS_ALL, error)) })
}

function actionAddDocs (data, status) { return {type: TYPE.ADD_DOCS.TYPE, status, data} }
export function asyncAddDocs (required, fnCloseDialog, startup, parent, file) {
  let data = new FormData()
  data.append('data', file)
  data.append('startup', startup)
  data.append('parent', parent)
  return dispatch => getAxios(dispatch, required, TYPE.ADD_DOCS)
  .post(`${BASE_URL}/docs/`, data)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionAddDocs(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_DOCS)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_DOCS, error)) })
}
export function asyncAddFolder (required, fnCloseDialog, startup, parent, title) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_DOCS)
  .post(`${BASE_URL}/docs/`, {startup, parent, title})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionAddDocs(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_DOCS)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_DOCS, error)) })
}

function actionDeleteDocs (data, startup, status) { return {type: TYPE.DELETE_DOCS.TYPE, status, startup, data} }
export function asyncDeleteDocs (required, UID, startup) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_DOCS)
  .delete(`${BASE_URL}/docs/${UID}/`)
  .then(() => { dispatch(actionDeleteDocs(UID, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.DELETE_DOCS)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_DOCS, error)) })
}

function actionGetDocs (data, status) { return {type: TYPE.GET_DOCS.TYPE, status, data} }
export function asyncGetDocs (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_DOCS)
  .get(`${BASE_URL}/docs/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetDocs(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_DOCS)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_DOCS, error)) })
}

function actionPatchDocs (data, startup, status) { return {type: TYPE.PATCH_DOCS.TYPE, status, startup, data} }
export function asyncPatchDocs (required, fnCloseDialog, UID, startup, title, parent, data) {
  return dispatch => getAxios(dispatch, required, TYPE.PATCH_DOCS)
  .patch(`${BASE_URL}/docs/${UID}/`, {startup, title, parent, data})
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionPatchDocs(response.data, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.PATCH_DOCS)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.PATCH_DOCS, error)) })
}

function actionAddNote (data, status) { return {type: TYPE.ADD_NOTE.TYPE, status, data} }
export function asyncAddNote (required, fnCloseDialog, UID, title, text) {
  return dispatch => getAxios(dispatch, required, TYPE.ADD_NOTE)
  .post(`${BASE_URL}/docs/${UID}/note/`, {title, text})
  .then(response => { dispatch(actionAddNote(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.ADD_NOTE)); fnCloseDialog() })
  .catch(error => { dispatch(requestErrorHandler(TYPE.ADD_NOTE, error)) })
}

function actionGoogleSync (data, status) { return {type: TYPE.GOOGLE_SYNC.TYPE, status, data} }
export function asyncGoogleSync (required, fnCallback, returnUrl) {
  return dispatch => getAxios(dispatch, required, TYPE.GOOGLE_SYNC)
  .post(`${BASE_URL}/docs/google_sync/`, {return_url: returnUrl})
  .then(response => { dispatch(actionGoogleSync(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GOOGLE_SYNC)); fnCallback(response.data) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GOOGLE_SYNC, error)) })
}

function actionGoogleUnSync (data, status) { return {type: TYPE.GOOGLE_UNSYNC.TYPE, status, data} }
function actionGoogleUnSyncApp (data, status, error) { return {type: TYPE_APP.UNSYNC_GOOGLE.TYPE, status, data, error} }
export function asyncGoogleUnSync (required, remove) {
  return dispatch => getAxios(dispatch, required, TYPE.GOOGLE_UNSYNC)
  .delete(`${BASE_URL}/docs/google_sync/`, {params: {remove_google_drive_files: remove}})
  .then(response => { let data = JSON.parse(atob(response.data.token.slice(11))); dispatch(actionGoogleUnSync(response.data, STATUS.SUCCESS)); localStorage.setItem('token', response.data.token); dispatch(actionGoogleUnSyncApp(data.google_drive_sync, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GOOGLE_UNSYNC)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GOOGLE_UNSYNC, error)) })
}

function actionGoogleSyncComplete (data, status, error) { return {type: TYPE.GOOGLE_SYNC_COMPLETE.TYPE, status, data, error} }
function actionGoogleSyncCompleteApp (data, status, error) { return {type: TYPE_APP.SYNC_GOOGLE.TYPE, status, data, error} }
export function asyncGoogleSyncComplete (required, fnCallback, state, code) {
  return dispatch => getAxios(dispatch, required, TYPE.GOOGLE_SYNC_COMPLETE)
  .post(`${BASE_URL}/docs/google_sync_complete/`, {state, code})
  .then(response => { let data = JSON.parse(atob(response.data.token.slice(11))); dispatch(actionGoogleSyncComplete(response.data, STATUS.SUCCESS)); localStorage.setItem('token', response.data.token); dispatch(actionGoogleSyncCompleteApp(data.google_drive_sync, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GOOGLE_SYNC_COMPLETE)); fnCallback(response.data) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GOOGLE_SYNC_COMPLETE, error)); fnCallback({error: true}) })
}
function actionGetDocsLog (data, cohort, startup, status) { return {type: TYPE.GET_DOCS_LOG.TYPE, status, cohort, startup, data} }
export function asyncGetDocsLog (required, cohort, startup, page, created) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_DOCS_LOG)
  .get(`${BASE_URL}/docs/log/`, {params: {cohort, startup, created, page}})
  .then(response => { dispatch(actionGetDocsLog(response.data, cohort, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_DOCS_LOG)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_DOCS_LOG, error)) })
}
function actionGetDocsStatistic (data, status) { return {type: TYPE.GET_DOCS_STATISTIC.TYPE, status, data} }
export function asyncGetDocsStatistic (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_DOCS_STATISTIC)
  .get(`${BASE_URL}/docs/statistic/`)
  .then(response => { dispatch(actionGetDocsStatistic(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_DOCS_STATISTIC)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_DOCS_STATISTIC, error)) })
}
