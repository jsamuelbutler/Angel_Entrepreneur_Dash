import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/plans/plans.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetPlansAll (data, status) { return {type: TYPE.GET_PLANS_ALL.TYPE, status, data} }
export function asyncGetPlansAll (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_PLANS_ALL)
  .get(`${BASE_URL}/plans/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetPlansAll(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_PLANS_ALL)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_PLANS_ALL, error)) })
}
