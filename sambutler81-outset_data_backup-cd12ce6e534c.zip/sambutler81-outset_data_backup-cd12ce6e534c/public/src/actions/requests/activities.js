import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/activities/activities.types'
import Pace from 'pace-progress'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetActivities (data, startup, status) { return {type: TYPE.GET_ACTIVITIES_ALL.TYPE, status, startup, data} }
function actionGetActivitiesPage (data, startup, page, status) { return {type: TYPE.GET_ACTIVITIES_PAGE.TYPE, status, startup, page, data} }
function actionSearchActivities (data, startup, status) { return {type: TYPE.SEARCH_ACTIVITIES_ALL.TYPE, status, startup, data} }
export function asyncGetActivitiesAll (required, cohort, startup, search, page) {
  if (search || search === '') { Pace.options.ignoreURLs = ['/api/activities?search=']; Pace.start() }
  if (page) { Pace.options.ignoreURLs = ['/api/activities/?page=']; Pace.start() }
  return dispatch => getAxios(dispatch, required, TYPE.GET_ACTIVITIES_ALL)
  .get(`${BASE_URL}/activities/`, { params: { cohort, startup, search, page } })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } (search || search === '') ? (Pace.options.ignoreURLs = [], Pace.start(), dispatch(actionSearchActivities(response.data, startup, STATUS.SUCCESS))) : startup && page ? (dispatch(actionGetActivitiesPage(response.data, startup, page, STATUS.SUCCESS))) : dispatch(actionGetActivities(response.data, startup, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_ACTIVITIES_ALL)) })
  .catch(error => { if (search || search === '') { Pace.options.ignoreURLs = []; Pace.start() } dispatch(requestErrorHandler(TYPE.GET_ACTIVITIES_ALL, error)) })
}

function actionGetActivitiesStatistic (data, status) { return {type: TYPE.GET_ACTIVITIES_STATISTIC.TYPE, status, data} }
export function asyncGetActivitiesStatistic (required, cohort) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_ACTIVITIES_STATISTIC)
  .get(`${BASE_URL}/activities/statistic/`, { params: { cohort } })
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetActivitiesStatistic(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_ACTIVITIES_STATISTIC)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_ACTIVITIES_STATISTIC, error)) })
}

