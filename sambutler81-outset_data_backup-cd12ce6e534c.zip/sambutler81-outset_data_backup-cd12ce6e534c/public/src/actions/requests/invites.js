import { STATUS, BASE_URL, ERR_NO_DATA } from '../../constants'
import TYPE from '../../store/invites/invites.types'
import { getAxios, requestSuccessHandler, requestErrorHandler } from '../../actions'

function actionGetInviteAll (data, status) { return {type: TYPE.GET_INVITE_ALL.TYPE, status, data} }
export function asyncGetInviteAll (required) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_INVITE_ALL)
  .get(`${BASE_URL}/invites/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetInviteAll(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_INVITE_ALL)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_INVITE_ALL, error)) })
}

function actionDeleteInvite (data, status) { return {type: TYPE.DELETE_INVITE.TYPE, status, data} }
export function asyncDeleteInvite (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.DELETE_INVITE)
  .delete(`${BASE_URL}/invites/${UID}/`)
  .then(response => { dispatch(actionDeleteInvite(response.data, STATUS.SUCCESS)); dispatch(asyncGetInviteAll(null)); dispatch(requestSuccessHandler(TYPE.DELETE_INVITE)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.DELETE_INVITE, error)) })
}

function actionGetInvite (data, status) { return {type: TYPE.GET_INVITE.TYPE, status, data} }
export function asyncGetInvite (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.GET_INVITE)
  .get(`${BASE_URL}/invites/${UID}/`)
  .then(response => { if (!response.data) { throw ERR_NO_DATA } dispatch(actionGetInvite(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.GET_INVITE)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.GET_INVITE, error)) })
}

function actionResendInvite (data, status) { return {type: TYPE.RESEND_INVITE.TYPE, status, data} }
export function asyncResendInvite (required, UID) {
  return dispatch => getAxios(dispatch, required, TYPE.RESEND_INVITE)
  .post(`${BASE_URL}/invites/${UID}/resend/`)
  .then(response => { dispatch(actionResendInvite(response.data, STATUS.SUCCESS)); dispatch(requestSuccessHandler(TYPE.RESEND_INVITE)) })
  .catch(error => { dispatch(requestErrorHandler(TYPE.RESEND_INVITE, error)) })
}
