import TYPE from '../store/network/network.types'
export function actionNetworkActive (action, required) { return {type: TYPE.NETWORK_ACTIVE.TYPE, action, required} }
export function actionNetworkInactive (action, error, errorType) { return {type: TYPE.NETWORK_INACTIVE.TYPE, action, error, errorType} }
