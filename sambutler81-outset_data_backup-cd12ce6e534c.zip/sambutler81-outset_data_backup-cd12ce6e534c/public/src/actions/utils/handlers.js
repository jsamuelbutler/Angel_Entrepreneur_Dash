/* global setTimeout */
import { actionNetworkInactive, errorToast, successToast, actionCrashApp, actionClearStore } from '../../actions'
import { VRSN, CODE_SERVER_ERROR, CODE_UNAUTHORIZED, TOASTER_OPTIONS } from '../../constants'
import { history } from '../../store'

const NODE_ENV = 'production'

export function requestSuccessHandler (action) {
  return dispatch => {
    dispatch(actionNetworkInactive(action.TYPE, false))
    if (NODE_ENV === VRSN.DEVELOPMENT) { successToast('', typeof action.MESSAGE === 'function' ? action.MESSAGE() : 'Success!') } else { action.VERSION === VRSN.PRODUCTION && successToast('', typeof action.MESSAGE === 'function' ? action.MESSAGE() : 'Success!') }
  }
}

export function requestErrorHandler (action, err) {
  return dispatch => {
    let status = false
    let errorType = null
    console.error(action, err)
    if (!err || !err.response) {
      errorType = 'NETWORK'
    } else {
      try {
        if (CODE_UNAUTHORIZED.indexOf(err.response.status) !== -1) { status = true; setTimeout(() => { dispatch(actionClearStore()); history.push('/login') }) }
        if (!err || !err.response || CODE_SERVER_ERROR.indexOf(err.response.status) !== -1) { errorType = 'CRASH_APP'; dispatch(actionCrashApp()) }
        parseError(err.response.data)
      } catch (err) { console.error(err); errorToast('Woooops!', err.replace('_', ' '), TOASTER_OPTIONS) }
    }
    dispatch(actionNetworkInactive(action.TYPE, status, errorType))
  }
}

function parseError (error) {
  for (let item in error) {
    if (error[item].constructor === Object) {
      parseError(error[item])
    } else if (item === 'non_field_errors') {
      errorToast((error[item][0][0].toUpperCase() + error[item][0].slice(1)).replace('_', ' '), null, TOASTER_OPTIONS)
    } else {
      Array.isArray(error[item]) ? error[item].map(text => {
        if (Array.isArray(text)) {
          errorToast((item[0].toUpperCase() + item.slice(1)).replace('_', ' '), text[0], TOASTER_OPTIONS)
        } else {
          errorToast((item[0].toUpperCase() + item.slice(1)).replace('_', ' '), text, TOASTER_OPTIONS)
        }
      }) : errorToast((item[0].toUpperCase() + item.slice(1)).replace('_', ' '), error[item], TOASTER_OPTIONS)
    }
  }
}
