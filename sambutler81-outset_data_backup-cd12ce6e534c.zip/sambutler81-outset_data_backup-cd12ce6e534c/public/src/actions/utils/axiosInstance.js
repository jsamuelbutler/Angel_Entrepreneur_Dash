/* global localStorage */
import axios from 'axios'
import { actionNetworkActive } from '../../actions'

export function getAxios (dispatch, required, action, tokenStatus) {
  dispatch && dispatch(actionNetworkActive(action.TYPE, required === 'required'))
  const TOKEN = !tokenStatus ? {Authorization: `Token ${localStorage.getItem('token')}`} : ''
  return axios.create({
    responseType: 'json',
    headers: TOKEN
  })
}
