/* global atob, localStorage */
import { toastr } from 'react-redux-toastr'
import APP_TYPE from '../store/app/app.types'
import AUTH_TYPE from '../store/auth/auth.types'
import COHORTS_TYPE from '../store/cohorts/cohorts.types'
import { STATUS, BASE_URL } from '../constants'
import { asyncGetAccelerator, asyncGetStartUpAll, asyncGetStartUp, asyncGetTeamMemberAll, asyncGetTodosStatistic, requestSuccessHandler, requestErrorHandler, getAxios } from '../actions'

const LOCAL_STORAGE_VARIABLES = ['token', 'loginScreen', 'welcomeConnect']
const messagesArray = ['We\'ll take care of that for you', 'Your wish is my command', 'You\'re looking swell today', 'Plugging away on that request for you', 'Sit back & relax, we\'ve got this covered', 'Soon you will rule the world']
let randomNumber = Math.floor(Math.random() * messagesArray.length)
export function successToast (header, text, options = {}) { toastr.success(header, messagesArray[randomNumber], options) }
export function errorToast (header, text, options = {}) { toastr.error(header, text, options) }
export function actionClearStore () { LOCAL_STORAGE_VARIABLES.map(item => localStorage.removeItem(item)); return { type: 'CLEAR_STORE' } }
export function actionCrashApp () { return { type: APP_TYPE.CRASH_APP.TYPE, crashApp: true } }
function getUserData (data) {
  let token = ''
  try { token = JSON.parse(atob(data.slice(11))) } catch (err) { token = null }
  return token
}
export function actionGetUserData (token) {
  let data = null
  try { data = JSON.parse(atob(token.slice(11))) } catch (err) { console.error('Invalid token') }
  return data ? {type: APP_TYPE.GET_USER_DATA.TYPE, token, accelerator: data.accelerator, is_social: data.is_social, allow_connect: data.allow_connect, account_type: data.account_type, angel: data.angel, email: data.email, facebook: data.facebook, first_name: data.first_name, first_time: data.first_time, github: data.github, google_plus: data.google_plus, id: data.id, image: data.image, is_active: data.is_active, last_name: data.last_name, linkedin: data.linkedin, recognize: data.recognize, role: data.role, role_in_company: data.role_in_company, skype: data.skype, startup: data.startup, subscribe: data.subscribe, tariff_plan: data.tariff_plan, twitter: data.twitter, google_drive_sync: data.google_drive_sync, view_api: data.view_api} : { type: APP_TYPE.CRASH_APP.TYPE, crashApp: true }
}
export function actionResetAuthState () { return {type: AUTH_TYPE.EMAIL_SENT.TYPE, statusAuth: ''} }
export function actionSetActiveFund (data) { return {type: APP_TYPE.SET_ACTIVE_FUND.TYPE, data} }

function actionGetFirstCohort (data, status) { return {type: COHORTS_TYPE.GET_COHORT_ALL.TYPE, status, data} }
export function asyncGetFirstCohort (required, token) {
  const USER_DATA = getUserData(token)
  if (USER_DATA.startup) {
    return dispatch => { dispatch(asyncGetStartUp('required', USER_DATA.startup)); dispatch(asyncGetStartUpAll(null)) }
  } else {
    return dispatch => getAxios(dispatch, required, COHORTS_TYPE.GET_COHORT_ALL)
    .get(`${BASE_URL}/cohorts/`)
    .then(response => {
      dispatch(actionGetFirstCohort(response.data, STATUS.SUCCESS))
      if (USER_DATA && response.data && response.data.length) {
        dispatch(actionSetActiveFund({id: response.data[0].id, label: response.data[0].name, value: 0}, STATUS.SUCCESS))
        dispatch(asyncGetStartUpAll('required', null, USER_DATA.startup, '-todo_count, name'))
        dispatch(asyncGetStartUpAll('required', response.data[0].id, USER_DATA.startup, '-todo_count, name'))
        dispatch(asyncGetTeamMemberAll('required', response.data[0].accelerator, null, '-todo_count'))
        dispatch(asyncGetTodosStatistic('required', response.data[0].id))
        USER_DATA.accelerator && dispatch(asyncGetAccelerator('required', USER_DATA.accelerator))
      } else { dispatch(actionSetActiveFund(null, STATUS.FAILURE)) }
      dispatch(requestSuccessHandler(COHORTS_TYPE.GET_COHORT_ALL))
    })
    .catch(error => { dispatch(requestErrorHandler(COHORTS_TYPE.GET_COHORT_ALL, error)) })
  }
}
